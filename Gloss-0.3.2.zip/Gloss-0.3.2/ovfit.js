/* Gloss: English drawn over the sign (stage 3), the pure part: which LINES entries may be drawn over, how big the letters are, what
   colour. No DOM, no Chrome; loaded by the page (overlay.js uses it) and by node tests.

   A label that lands on the wrong line is worse than none, so a line is drawn over only when it passes every gate. v0.3.1 has two kinds of line:

   A QUADRILATERAL LINE (the model gave the four corners of the lettering, q, clockwise from the top left of the text as read) is measured along its own axes,
   not the screen's: its length along the reading edge (the mean of its top and bottom edges), its height across (its area over that length), and the lean of
   the reading edge on the screen. Its gates, in order:
     - it has its four corner directions and a translation that is not just the original again;
     - its text is not a cropped fragment (an ellipsis in the translation or the original: the model read part of a word at the picture's edge);
     - it is not vertical writing: the reading edge leans no more than MAX_ANGLE (45) degrees from level on the screen, and its height across is no more than
       MAX_STACK (1.6) times its length (a stack of characters is taller than it is long; a short level word such as BUN, about 0.7, passes);
     - its height across in the picture that was sent is at least 18 px (smaller text is where the model's corners are poor);
     - its corners lie inside that picture (the model did not run off the edge: the text is not cut off);
     - it does not overlap another line by more than 10 % of the smaller one (30 % in 0.3.1's first build), as the polygons themselves intersect (two outlines on one spot: one is wrong, and two panels one over the other read badly);
     - its translation fits: the largest font that fits the quadrilateral's own length and height (two lines allowed, a little padding) is at least 9 px, at
       the zoom the question was asked at.
   The label is then drawn on the quadrilateral: laid out as a rectangle of that length and height and warped onto the four corners every frame (overlay.js).

   A BOX LINE (b only: a saved note made by an earlier version, or a reply whose q was not usable) behaves exactly as it did in 0.3.0:
     - it has a box, its four corner directions and a translation that is not just the original again;
     - its box is clearly horizontal: at least 1.3 times wider than tall (vertical text stays in the card), and the lettering in it is not
       tilted by more than 10 degrees (the label is level: on a sloped sign it would hang off the sign);
     - its text is not a cropped fragment; its height in the picture that was sent is at least 18 px; its box lies wholly inside that picture;
     - it does not overlap another line's box by more than 30 %;
     - its translation fits (as above, in the box).
   If fewer than half of a mark's lines pass, the mark gets no automatic overlay (the lines that do pass can still be drawn when he
   presses Overlay on the card).

   WAITING LINES (v0.3.2). A line whose FIRST failing gate is "nofit" (it passes every other gate; its English cannot be set at 9 px inside its outline AS IT IS ON SCREEN
   NOW) is looked at again: when there is a zoom factor k, 1 < k <= kmax, at which the English does fit at 9 px inside its outline enlarged k times, and its outline overlaps no
   line that passes and no waiting line accepted before it by more than the same limit, it is a WAITING line. It keeps ok: false and why: 'nofit' (so everything that counts
   "lines that pass" is exactly what 0.3.1 counted: waiting lines are only ever added) and carries wait: true, k, and the label's layout at that size (bw, bh = the outline's size
   times k, fit = the English set at 9 px or more inside it). overlay.js makes a label of it like any other: its font on screen at the zoom it was asked at is 1 / k of that
   layout's, under the 9 px floor, so the floor that already hides small labels keeps it hidden until the zoom reaches k. kmax is K_MAX (6: from Street View's widest view, 90
   degrees, the narrowest, 15, magnifies 7.6 times; from the owner's 75 degrees 5.8), or less when the caller knows the ask's own field of view (kmaxFor).
   plan() gives { items, pass, waiting, tight, total, auto }; auto is: pass + waiting >= 1 and (pass + waiting) * 2 >= total (a waiting line counts as placeable: the owner's ruling, 15 Nov).

   TIGHT LINES (v0.3.2). The normal fit keeps 6 % of the height (at least 1 px) of padding top and bottom and sets the lines 1.12 high, so 9 px type needs an outline 12.1 px tall: a line 11 px
   tall gets 8 px type and was refused (or made to wait) while the sign's own capitals fill it. Order per line: when the normal fit gives 9 px or more nothing changes (the same layout, field for field).
   Otherwise a TIGHT fit is tried before the line is refused or made to wait: one line of English, no vertical padding, line height 1, so the type may be as tall as the outline (font <= height),
   2 px of padding at each end. It passes at 9 px or more, with tight: true. A long translation: the label may be SQUEEZED to no less than 85 % of its natural width (it is laid out wider than the outline and the
   mapping onto the four corners narrows it: item.sq), and when that is not enough it may RUN ON past each end of the outline along the line's own direction (item.aL, aR: shares of the line's length; item.qx the
   corners it is drawn on, in the picture's pixels, before they become directions), at most the smaller of twice the outline's height and 30 % of its length, only as far as the longer outline stays inside the
   picture, meets no other line's outline at all (nor a longer outline already given to a tight line before it), and, when the picture was read (line.xr, snap.js), the picture just past that end is the sign's own
   background colour. A note made before xr existed has no xr: its tight labels are squeezed, never lengthened. The line must still pass the overlap gate (30 %) first, which every line does before its fit is
   looked at. A waiting line uses the tight fit too when it works out the zoom it needs (waitZoom), so it appears sooner.

   THE DIGITS GATE (v0.3.2, 'drops'). A line whose original holds a run of two or more digits that its English does not hold (a phone number, a price, opening hours: "TEL 03-3987-8855" over "Phone") gets no label:
   the label would cover the number. The English stays in the card.


   A line is { b, q, qd, sb, o, t, dirs, sd, bg, fg, ang, spill }: b the model's box (pixels of the picture sent, clamped; a quadrilateral's bounding box when it has
   one), q the four corners [x0,y0,...,y3] (pixels of the picture sent) and qd their four directions, sb the box snapped to the ink (box lines only) and sd its
   directions, o / t original and translation, dirs the corner directions of b, bg / fg colours [r,g,b] (the sign, the lettering) or null, ang the lettering's
   tilt in degrees or null (box lines only), spill true when the model's box ran off the picture before it was clamped.
   cs = [w, h] of the picture sent; ref = [w, h] in CSS px of the rectangle that was pictured (what the picture is worth on screen). */
(function (root) {
  'use strict';

  const MIN_RATIO = 1.3; // box lines only
  const MIN_LINE_H = 18;
  const MAX_OVERLAP = 0.3;
  const MAX_OVERLAP_QUAD = 0.3; // a line with corners: the same limit as a box line (as specified for 0.3.1). The fix round tried 0.2 (two panels one over the other read badly: 3 of the 17 flawed labels in the blind
                                // judge's pictures) and took it back: replayed on 40 asks it cost 1 line in 95, but on the owner's own sign (nine real asks) it cost his example, BUN, three asks of nine (labelled
                                // 6 of 9, 9 of 9 at 0.3) and 0.6 of a label per ask (5.1 against 5.75). A separate constant stays so that the limit can be moved on its own.
  const MAX_ANGLE = 45; // degrees: a quadrilateral's reading edge may lean this much from level on the screen (steeper is vertical writing, which stays in the card)
  const MAX_STACK = 1.6; // a quadrilateral's height across over its length: more than this is a stack of characters (vertical writing). A short word such as BUN reads about 0.7, a single letter 1.4
  let overlapShrink = 0; // quadrilaterals: 0 = the polygons themselves are compared (as specified for 0.3.1). A share s (0 to 0.5) shrinks each quadrilateral's height about its centre line before
                         // two of them are compared. The model's corners are loose by instruction ("if unsure make it slightly larger"), so two touching lines can overlap past the 30 % limit
                         // although their lettering does not; measured on saved asks (BUILD-NOTES section 21) a shrink of 0.15 to 0.2 gives most of them back. NOT turned on: setOverlapShrink() is for the
                         // person who judges it.
  const MAX_TILT = 10; // (box lines only) // degrees: the lettering of a line may lean this much and still be drawn over with a level label (measured on the evalset's 78 wide boxes: 95 % read under 8.6, 2 over 10; the sloped Maid Casino board reads 14.5)
  const K_MAX = 6; // the largest zoom a waiting line may wait for (see above and kmaxFor)
  const MIN_FONT = 9; // CSS px on screen: below this the label hides until he zooms in
  const TIGHT_PADX = 2; // CSS px of padding at each end of a tight label (the normal fit keeps 3 px or 12 % of the height)
  const SQUEEZE_MIN = 0.85; // a tight label may be drawn no narrower than this share of the English's natural width
  const EXT_MAX_H = 2; // a tight label may run on past each end by at most this many outline heights ...
  const EXT_MAX_LEN = 0.3; // ... and at most this share of the outline's length (the smaller of the two)
  const LINE_H = 1.12; // line height, in fonts
  const SLACK = 0.96; // measured widths may be a little off in the browser: keep 4 % in hand

  /* ---------- colour ---------- */
  const lin = (v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); };
  const luminance = (c) => 0.2126 * lin(c[0]) + 0.7152 * lin(c[1]) + 0.0722 * lin(c[2]);
  function contrast(a, b) {
    const la = luminance(a), lb = luminance(b);
    return (Math.max(la, lb) + 0.05) / (Math.min(la, lb) + 0.05);
  }
  const LIGHT = [255, 255, 255];
  const DARK = [4, 10, 18];
  const GLOSS_LIFT = 0.08; // the gloss lightens the sign's colour a little under the type (measured: +5 to +13 per channel in the middle of a label, where the type sits)
  const mixWhite = (c, k) => [Math.round(c[0] + (255 - c[0]) * k), Math.round(c[1] + (255 - c[1]) * k), Math.round(c[2] + (255 - c[2]) * k)];
  const dist = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2]);
  /* What the type sits on as drawn: light type is judged against the sign's colour lightened by the gloss, dark type (which the gloss helps) against the colour itself. */
  const readsOn = (c, bg) => contrast(c, luminance(c) > luminance(bg) ? mixWhite(bg, GLOSS_LIFT) : bg);

  /* The text colour. The lettering's own colour when it reads on the sign (contrast 4.5 or better as drawn). Otherwise the sign keeps its
     polarity: lettering that was darker than the sign stays dark, lighter stays light, as long as that reads at 3 or better (the text shadow
     helps from there); only when it does not, black or white, whichever reads better. */
  function pickText(bg, fg) {
    if (!bg) return { color: LIGHT, from: 'auto' };
    if (fg && readsOn(fg, bg) >= 4.5) return { color: fg, from: 'ink' };
    const dark = readsOn(DARK, bg), light = readsOn(LIGHT, bg);
    if (fg) {
      const wantDark = luminance(fg) < luminance(bg);
      if ((wantDark ? dark : light) >= 3) return { color: wantDark ? DARK : LIGHT, from: 'polarity' };
    }
    return { color: light >= dark ? LIGHT : DARK, from: 'auto' };
  }

  /* Lines of one board (their sign colours are close) get one text colour, not a grey on one chip and white on the next: the candidate that
     reads best on the worst of them. items: the ok items of plan(). */
  function unifyColors(items, only) { // only: when given, the items whose colour may change (the others still count as peers)
    const ok = items.filter((r) => (r.ok || r.wait) && r.bg);
    const same = (a, b) => a[0] === b[0] && a[1] === b[1] && a[2] === b[2];
    // decided from the colours as picked per line, then applied together
    const next = ok.map((r) => {
      const peers = ok.filter((q) => dist(q.bg, r.bg) < 40);
      if (peers.length < 2 || peers.every((q) => same(q.color, peers[0].color))) return r.color;
      let best = null, bestV = -1;
      peers.map((q) => q.color).concat([LIGHT, DARK]).forEach((c) => {
        const v = Math.min.apply(null, peers.map((q) => readsOn(c, q.bg)));
        if (v > bestV + 1e-9) { bestV = v; best = c; }
      });
      return best;
    });
    ok.forEach((r, i) => { if (!only || only(r)) r.color = next[i]; });
  }

  /* ---------- fitting ---------- */

  /* Break a translation into at most two lines no wider than maxW at font size f. w100(text) = width of the text at 100 px.
     Returns the lines, or null when it cannot be done (a word wider than the box, or more than two lines needed). */
  function wrap(text, maxW, f, w100) {
    const width = (s) => (w100(s) * f) / 100;
    const limit = maxW * SLACK;
    if (width(text) <= limit) return [text];
    const words = text.split(/\s+/).filter(Boolean);
    if (words.length < 2) return null;
    let best = null, bestW = Infinity;
    for (let k = 1; k < words.length; k++) {
      const a = words.slice(0, k).join(' '), b = words.slice(k).join(' ');
      const wa = width(a), wb = width(b), w = Math.max(wa, wb);
      if (wa <= limit && wb <= limit && w < bestW) { best = [a, b]; bestW = w; }
    }
    return best;
  }

  /* The largest font (0.25 px steps) at which the text fits a w x h box with a little padding, in at most two lines.
     Returns { font, lines, lh, padX, padY } or null when not even 4 px fits. */
  function fitText(text, w, h, w100) {
    text = String(text || '').replace(/\s+/g, ' ').trim();
    if (!text || !(w > 0) || !(h > 0)) return null;
    const padY = Math.max(1, Math.round(h * 0.06));
    const padX = Math.max(3, Math.round(h * 0.12));
    const aw = w - 2 * padX, ah = h - 2 * padY;
    if (aw < 4 || ah < 4) return null;
    const fits = (f) => {
      const lines = wrap(text, aw, f, w100);
      return lines && lines.length * LINE_H * f <= ah + 0.01 ? lines : null;
    };
    let lo = 4, hi = Math.max(4, Math.floor((ah / LINE_H) * 4) / 4);
    if (!fits(lo)) return null;
    let bestLines = fits(lo);
    while (hi - lo > 0.25) {
      const mid = Math.round(((lo + hi) / 2) * 4) / 4;
      if (mid <= lo) break;
      const l = fits(mid);
      if (l) { lo = mid; bestLines = l; } else hi = mid;
    }
    if (fits(hi)) { lo = hi; bestLines = fits(hi); }
    return { font: lo, lines: bestLines, lh: LINE_H, padX: padX, padY: padY };
  }

  /* The TIGHT fit (v0.3.2, see the top of the file): one line of English, no vertical padding, line height 1, 2 px at each end. text: the English; len x hgt: the outline's length and height in CSS px;
     room: [left, right], the shares of len the outline may be run on past each end (null: none). The type is the largest (0.25 px steps) that is no taller than the outline and whose natural width
     (with the padding) squeezed to SQUEEZE_MIN of it fits the outline, run on as far as room allows; the run-on is only as much as is needed, shared between the two ends (more at one end when the other has
     no room). Returns { font, lines, lh, padX, padY, tight, bw, bh, sq, aL, aR } or null: bw x bh is the rectangle the label is laid out in (wider than the outline when it is squeezed), sq the share it is
     narrowed to (1 = not squeezed), aL and aR the shares of len added at each end; the caller holds font to MIN_FONT. */
  const floor4 = (v) => Math.floor(v * 4 + 1e-9) / 4;
  function fitTight(text, len, hgt, w100, room) {
    text = String(text || '').replace(/\s+/g, ' ').trim();
    if (!text || !(len > 0) || !(hgt > 0)) return null;
    const tw = w100(text) / 100; // width of the English per px of type
    if (!(tw > 0)) return null;
    const rl = room ? Math.max(0, +room[0] || 0) : 0, rr = room ? Math.max(0, +room[1] || 0) : 0;
    const font = Math.min(floor4(hgt), floor4((len * (1 + rl + rr) / SQUEEZE_MIN - 2 * TIGHT_PADX) / tw));
    if (!(font >= 4)) return null;
    const W = tw * font + 2 * TIGHT_PADX; // its natural width, with the padding
    let a = 0;
    if (SQUEEZE_MIN * W > len) a = (SQUEEZE_MIN * W) / len - 1; // squeezing alone is not enough: run on
    let aL = 0, aR = 0;
    if (a > 1e-9) { aL = Math.min(a / 2, rl); aR = Math.min(a - aL, rr); aL = Math.min(a - aR, rl); }
    const pane = len * (1 + aL + aR);
    return { font: font, lines: [text], lh: 1, padX: TIGHT_PADX, padY: 0, tight: true, bw: Math.max(W, pane), bh: hgt, sq: W <= pane ? 1 : Math.max(SQUEEZE_MIN, pane / W), aL: aL, aR: aR };
  }

  /* A label laid out again at a new size, z times what it was laid out at (overlay.js rebase: he zoomed and the view is at rest). it: { text, tight, bw, bh, sq, font, lines } as the plan gave it (or as the label
     holds it). Returns { bw, bh, font, lines, sq } or null. When the layout is only enlarged (z >= 1) and the English breaks where it did, the type of the old layout times z always fits (the padding minimums do
     not grow), so that is the font when the fit's quarter-pixel steps would give a hair less: the type is never drawn smaller by being laid out again. */
  function refit(it, z, w100) {
    let r;
    if (it.tight) {
      const t = fitTight(it.text, it.bw * (it.sq || 1) * z, it.bh * z, w100, null);
      r = t ? { bw: t.bw, bh: t.bh, font: t.font, lines: t.lines, sq: t.sq } : null;
    } else {
      const f = fitText(it.text, it.bw * z, it.bh * z, w100);
      r = f ? { bw: it.bw * z, bh: it.bh * z, font: f.font, lines: f.lines, sq: 1 } : null;
    }
    if (r && z >= 1 && it.font && r.font < it.font * z && it.lines && r.lines.join('|') === it.lines.join('|')) {
      r.font = it.font * z;
      if (it.tight) { // its natural width at that type, against the (enlarged) outline
        const W = (w100(it.text) / 100) * r.font + 2 * TIGHT_PADX, pane = it.bw * (it.sq || 1) * z;
        r.bw = Math.max(W, pane);
        r.sq = W <= pane ? 1 : pane / W;
      }
    }
    return r;
  }

  /* ---------- gates ---------- */
  const area = (b) => Math.max(0, b[2] - b[0]) * Math.max(0, b[3] - b[1]);
  function inter(a, b) {
    return area([Math.max(a[0], b[0]), Math.max(a[1], b[1]), Math.min(a[2], b[2]), Math.min(a[3], b[3])]);
  }
  /* The "same as the original" test (v0.3.2): case, accents and spacing set aside, the way repaint-core.js normalise() does it for the same question ("Mi Quang" over MÌ QUẢNG adds
     nothing). Letters that Unicode does not take apart into letter + accent are the plain letter. Kept here as a copy (this file loads in the page and in node on its own). */
  const PLAIN = { 'đ': 'd', 'ð': 'd', 'ł': 'l', 'ø': 'o', 'ı': 'i', 'ß': 'ss', 'æ': 'ae', 'œ': 'oe', 'þ': 'th' };
  const PLAIN_RE = /[đðłøıßæœþ]/g;
  const norm = (s) => String(s || '').normalize('NFKD').replace(/[̀-ͯ]/g, '').normalize('NFKC').toLowerCase().replace(PLAIN_RE, (c) => PLAIN[c]).replace(/[^\p{L}\p{N}]/gu, '');

  /* The digits gate (v0.3.2): runs of two or more decimal digits in plain 0 to 9 (full-width digits, and those of other scripts, are the digits they are). A line "drops" digits when its
     original holds a run that its English does not hold (as digits, separators set aside: 03-3987-8855 is held by 0339878855 and by 03 3987 8855). */
  const ND = /\p{Nd}/u;
  function plainDigits(s) {
    let out = '';
    for (const c of String(s || '').normalize('NFKC')) {
      if (c >= '0' && c <= '9') { out += c; continue; }
      if (!ND.test(c)) { out += ' '; continue; }
      const cp = c.codePointAt(0);
      let z = cp;
      while (ND.test(String.fromCodePoint(z - 1))) z--; // the zero of this script's block of ten
      out += String((cp - z) % 10);
    }
    return out;
  }
  function dropsDigits(o, t) {
    const runs = plainDigits(o).split(/[^0-9]+/).filter((r) => r.length >= 2);
    if (!runs.length) return false;
    const have = plainDigits(t).replace(/[^0-9]/g, '');
    return runs.some((r) => have.indexOf(r) < 0);
  }

  const snapped = (l) => !!(l.sb && l.sd); // a snapped box is used with ITS OWN corner directions; without them the model's box and its directions
  const boxOf = (l) => (snapped(l) ? l.sb : l.b) || null;
  const dirsOf = (l) => (snapped(l) ? l.sd : l.dirs) || null;

  /* ---------- quadrilaterals (v0.3.1) ---------- */
  const isQuad = (l) => !!(l && Array.isArray(l.q) && l.q.length === 8 && l.q.every((v) => typeof v === 'number' && isFinite(v)));
  const quadPts = (q) => [[q[0], q[1]], [q[2], q[3]], [q[4], q[5]], [q[6], q[7]]];
  const quadBox = (q) => [Math.min(q[0], q[2], q[4], q[6]), Math.min(q[1], q[3], q[5], q[7]), Math.max(q[0], q[2], q[4], q[6]), Math.max(q[1], q[3], q[5], q[7])];

  function polyArea(p) {
    let s = 0;
    for (let i = 0; i < p.length; i++) { const a = p[i], b = p[(i + 1) % p.length]; s += a[0] * b[1] - b[0] * a[1]; }
    return Math.abs(s) / 2;
  }
  /* the intersection of two convex polygons (Sutherland-Hodgman); either winding */
  function clipPoly(subject, clipper) {
    let sg = 0;
    for (let i = 0; i < clipper.length; i++) { const a = clipper[i], b = clipper[(i + 1) % clipper.length]; sg += a[0] * b[1] - b[0] * a[1]; }
    sg = sg >= 0 ? 1 : -1;
    let out = subject;
    for (let i = 0; i < clipper.length && out.length; i++) {
      const a = clipper[i], b = clipper[(i + 1) % clipper.length];
      const inside = (p) => sg * ((b[0] - a[0]) * (p[1] - a[1]) - (b[1] - a[1]) * (p[0] - a[0])) >= 0;
      const cut = (p, q) => {
        const d = (p[0] - q[0]) * (a[1] - b[1]) - (p[1] - q[1]) * (a[0] - b[0]);
        const t = ((p[0] - a[0]) * (a[1] - b[1]) - (p[1] - a[1]) * (a[0] - b[0])) / (d || 1e-12);
        return [p[0] + t * (q[0] - p[0]), p[1] + t * (q[1] - p[1])];
      };
      const inp = out;
      out = [];
      for (let j = 0; j < inp.length; j++) {
        const p = inp[j], q = inp[(j + 1) % inp.length];
        if (inside(q)) { if (!inside(p)) out.push(cut(p, q)); out.push(q); } else if (inside(p)) out.push(cut(p, q));
      }
    }
    return out;
  }
  const rectPoly = (b) => [[b[0], b[1]], [b[2], b[1]], [b[2], b[3]], [b[0], b[3]]];

  /* a line's shape for the overlap gate: a box [x0,y0,x1,y1], four corners [x0,y0,...,y3], or { box } / { poly }; null stays null */
  function shape(o) {
    if (!o) return null;
    if (Array.isArray(o)) return o.length === 4 ? { box: o, poly: rectPoly(o) } : o.length === 8 ? { box: null, poly: quadPts(o), quad: true } : null;
    if (o.poly) return o;
    if (o.box) return { box: o.box, poly: rectPoly(o.box) };
    return null;
  }

  /* how much of the smaller of two shapes the other covers (0 to 1). Two boxes: the box formula of 0.3.0, as it was; otherwise the polygons themselves intersect. */
  function overlapShare(a, b) {
    a = shape(a); b = shape(b);
    if (!a || !b) return 0;
    if (a.box && b.box) return inter(a.box, b.box) / Math.min(area(a.box), area(b.box));
    const pa = a.quad && overlapShrink > 0 ? shrinkPoly(a.poly, overlapShrink) : a.poly, pb = b.quad && overlapShrink > 0 ? shrinkPoly(b.poly, overlapShrink) : b.poly;
    return polyArea(clipPoly(pa, pb)) / Math.min(polyArea(pa), polyArea(pb));
  }
  /* a quadrilateral [tl, tr, br, bl] with its height shrunk by share s about its centre line (the corners move towards the opposite ones along the left and right edges) */
  function shrinkPoly(p, s) {
    const mv = (a, b) => [a[0] + (b[0] - a[0]) * s / 2, a[1] + (b[1] - a[1]) * s / 2];
    return [mv(p[0], p[3]), mv(p[1], p[2]), mv(p[2], p[1]), mv(p[3], p[0])];
  }

  /* A quadrilateral measured along its own axes, in the units of its numbers scaled by rx, ry (crop pixels to CSS px, or 1, 1 for crop pixels):
     len = the length along the reading edge (mean of the top and bottom edges), hgt = the height across (the area over len, which for a sheared
     quadrilateral is the true height of the lettering, not the length of its slanted side), angle = the lean of the reading edge on the screen in degrees
     (positive = downhill to the right), area. */
  function quadMetrics(q, rx, ry) {
    const P = quadPts(q).map((p) => [p[0] * rx, p[1] * ry]);
    const d = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1]);
    const len = (d(P[0], P[1]) + d(P[3], P[2])) / 2;
    const ar = polyArea(P);
    const angle = (Math.atan2((P[1][1] - P[0][1]) + (P[2][1] - P[3][1]), (P[1][0] - P[0][0]) + (P[2][0] - P[3][0])) * 180) / Math.PI;
    return { len: len, hgt: len > 0 ? ar / len : 0, angle: angle, area: ar };
  }

  /* ---------- running a tight outline on past its ends (v0.3.2) ---------- */
  const EXT_EPS = 0.5; // px2 of the picture: another outline "meets" the new stretch when it covers more than this of it
  /* The stretch added at one end of a quadrilateral P = [tl, tr, br, bl] (points in the picture's pixels): side -1 the left end, +1 the right; a = the share of the top and the bottom edge added, along
     each edge's own direction (so the longer outline keeps the perspective of the lettering). */
  function extStrip(P, side, a) {
    const out = (p, q) => [p[0] + (p[0] - q[0]) * a, p[1] + (p[1] - q[1]) * a]; // p moved on, away from q
    return side < 0 ? [out(P[0], P[1]), P[0], P[3], out(P[3], P[2])] : [P[1], out(P[1], P[0]), out(P[2], P[3]), P[2]];
  }
  /* The corners [x0,y0,...,y3] of the quadrilateral q run on by the shares aL (left end) and aR (right end). */
  function extQuad(q, aL, aR) {
    const P = quadPts(q);
    const tl = extStrip(P, -1, aL)[0], bl = extStrip(P, -1, aL)[3], tr = extStrip(P, 1, aR)[1], br = extStrip(P, 1, aR)[2];
    return [tl[0], tl[1], tr[0], tr[1], br[0], br[1], bl[0], bl[1]];
  }
  const validXr = (xr) => Array.isArray(xr) && xr.length === 2 && xr.every((v) => typeof v === 'number' && isFinite(v) && v >= 0);
  /* How far the outline q may be run on at each end, as shares of its length: [left, right]. No more than cap, nor xr (how far the picture past that end is the sign's own background colour: snap.js), and
     only as far as the longer outline stays inside the picture cs and meets none of obstacles (polygons: every other line's outline, and the longer outlines already given to tight lines before this one). */
  function extRoom(q, cs, obstacles, cap, xr) {
    if (!validXr(xr)) return [0, 0];
    const P = quadPts(q);
    const side = (sd, lim) => {
      let hi = Math.min(cap, lim);
      if (!(hi > 0)) return 0;
      const ok = (a) => {
        const st = extStrip(P, sd, a);
        const outer = sd < 0 ? [st[0], st[3]] : [st[1], st[2]];
        if (outer.some((p) => p[0] < 0 || p[1] < 0 || p[0] > cs[0] || p[1] > cs[1])) return false;
        return !obstacles.some((o) => polyArea(clipPoly(st, o)) > EXT_EPS);
      };
      if (ok(hi)) return hi;
      let lo = 0;
      for (let i = 0; i < 12; i++) { const mid = (lo + hi) / 2; if (ok(mid)) lo = mid; else hi = mid; }
      return lo;
    };
    return [side(-1, xr[0]), side(1, xr[1])];
  }
  /* the room for one quadrilateral line: its own length and height in CSS px (the cap is a share of them), the other lines' shapes, and the longer outlines already given out */
  function roomOf(l, len, hgt, cs, others, claimed) {
    if (!validXr(l.xr) || !(len > 0)) return null;
    const cap = Math.min((EXT_MAX_H * hgt) / len, EXT_MAX_LEN);
    const obstacles = others.map((o) => { const sh = shape(o); return sh ? sh.poly : null; }).filter(Boolean).concat(claimed || []);
    return extRoom(l.q, cs, obstacles, cap, l.xr);
  }

  /* The tight stage (see the top of the file): the tight fit of the English in len x hgt, run on where room() (called only when it can help) says there is room. Null when the type would be under MIN_FONT. */
  function tightStage(t, len, hgt, w100, room) {
    let tf = fitTight(t, len, hgt, w100, null);
    if (tf && tf.font >= floor4(hgt)) return tf.font >= MIN_FONT ? tf : null; // the type is as tall as the outline: a longer outline would add nothing
    const rm = room ? room() : null;
    if (rm && (rm[0] > 0 || rm[1] > 0)) {
      const tg = fitTight(t, len, hgt, w100, rm);
      if (tg && tg.font > (tf ? tf.font : 0)) tf = tg;
    }
    return tf && tf.font >= MIN_FONT ? tf : null;
  }

  /* One quadrilateral line against the gates (see the top of the file). others = the other lines' shapes; ctx (optional) = { claimed: the longer outlines of tight lines accepted before this one }. */
  function gateQuad(l, cs, ref, others, w100, ctx) {
    const dirs = l.qd;
    if (!dirs || !dirs.tl || !dirs.tr || !dirs.br || !dirs.bl) return { ok: false, why: 'nodirs' };
    const t = String(l.t || '').trim();
    if (!t) return { ok: false, why: 'notext' };
    if (l.o && norm(l.o) && norm(l.o) === norm(t)) return { ok: false, why: 'same' };
    if (dropsDigits(l.o, t)) return { ok: false, why: 'drops' };
    if (/…|\.{2,}/.test(t) || /…|\.{2,}/.test(String(l.o || ''))) return { ok: false, why: 'fragment' };
    const m = quadMetrics(l.q, ref[0] / cs[0], ref[1] / cs[1]); // on the screen the question was asked on
    if (!(m.len > 0) || Math.abs(m.angle) > MAX_ANGLE || m.hgt > MAX_STACK * m.len) return { ok: false, why: 'vertical' };
    if (quadMetrics(l.q, 1, 1).hgt < MIN_LINE_H) return { ok: false, why: 'small' }; // in the picture the model read
    if (l.spill || l.q.some((v, i) => v < 0 || v > (i % 2 ? cs[1] : cs[0]))) return { ok: false, why: 'edge' };
    const me = { box: null, poly: quadPts(l.q), quad: true };
    for (const o of others) if (o && overlapShare(me, o) > MAX_OVERLAP_QUAD) return { ok: false, why: 'overlap' };
    const fit = fitText(t, m.len, m.hgt, w100); // the rectangle the label is laid out in (len x hgt) is warped onto the quadrilateral, so it fits inside it
    const colors = pickText(l.bg || null, l.fg || null);
    if (fit && fit.font >= MIN_FONT) return { ok: true, why: '', quad: true, q: l.q, box: quadBox(l.q), dirs: dirs, text: t, bw: m.len, bh: m.hgt, angle: m.angle, fit: fit, bg: l.bg || null, color: colors.color, colorFrom: colors.from };
    const tf = tightStage(t, m.len, m.hgt, w100, () => roomOf(l, m.len, m.hgt, cs, others, ctx && ctx.claimed)); // not at 9 px with the padding: the tight fit
    if (!tf) return { ok: false, why: 'nofit' };
    const qx = tf.aL || tf.aR ? extQuad(l.q, tf.aL, tf.aR) : null;
    return { ok: true, why: '', quad: true, tight: true, q: l.q, qx: qx, box: quadBox(qx || l.q), dirs: dirs, text: t, bw: tf.bw, bh: tf.bh, sq: tf.sq, aL: tf.aL, aR: tf.aR, angle: m.angle, fit: tf, bg: l.bg || null, color: colors.color, colorFrom: colors.from };
  }

  /* One line against the gates. others = the drawn shapes of the other lines (a box [x0,y0,x1,y1] for a box line, see shape()). Returns { ok, why, ... } (why names the first gate that failed). */
  function gateLine(l, cs, ref, others, w100, ctx) {
    if (isQuad(l)) return gateQuad(l, cs, ref, others, w100, ctx);
    const box = boxOf(l);
    if (!box) return { ok: false, why: 'nobox' };
    const dirs = dirsOf(l);
    if (!dirs || !dirs.tl || !dirs.tr || !dirs.br || !dirs.bl) return { ok: false, why: 'nodirs' };
    const t = String(l.t || '').trim();
    if (!t) return { ok: false, why: 'notext' };
    if (l.o && norm(l.o) && norm(l.o) === norm(t)) return { ok: false, why: 'same' }; // already English: nothing to say
    if (dropsDigits(l.o, t)) return { ok: false, why: 'drops' };
    const w = box[2] - box[0], h = box[3] - box[1];
    if (/…|\.{2,}/.test(t) || /…|\.{2,}/.test(String(l.o || ''))) return { ok: false, why: 'fragment' };
    if (!(w >= MIN_RATIO * h)) return { ok: false, why: 'vertical' };
    if (typeof l.ang === 'number' && Math.abs(l.ang) > MAX_TILT) return { ok: false, why: 'rotated' };
    if (h < MIN_LINE_H) return { ok: false, why: 'small' };
    if (l.spill || box[0] < 0 || box[1] < 0 || box[2] > cs[0] || box[3] > cs[1]) return { ok: false, why: 'edge' };
    for (const o of others) if (o && overlapShare(box, o) > MAX_OVERLAP) return { ok: false, why: 'overlap' };
    // the size the label has on the screen the question was asked on (the base the browser lays the text out at)
    const bw = (w * ref[0]) / cs[0], bh = (h * ref[1]) / cs[1];
    const fit = fitText(t, bw, bh, w100);
    const colors = pickText(l.bg || null, l.fg || null);
    if (fit && fit.font >= MIN_FONT) return { ok: true, why: '', box: box, dirs: dirs, text: t, bw: bw, bh: bh, fit: fit, bg: l.bg || null, color: colors.color, colorFrom: colors.from };
    const tf = tightStage(t, bw, bh, w100, null); // a box line is squeezed, never run on (it has no reading of the picture past its ends)
    if (!tf) return { ok: false, why: 'nofit' };
    return { ok: true, why: '', tight: true, box: box, dirs: dirs, text: t, bw: tf.bw, bh: tf.bh, sq: tf.sq, fit: tf, bg: l.bg || null, color: colors.color, colorFrom: colors.from };
  }

  /* The smallest zoom factor k, 1 < k <= kmax, at which the English fits at MIN_FONT or more inside an outline w x h enlarged k times (null when there is none): by the normal fit, or, when that does not
     give 9 px at that k, by the tight fit (v0.3.2: a line waits for a smaller zoom that way). The fit is not perfectly smooth in k (the padding has minimums, the break into two lines jumps), so k is
     searched upwards in steps of 2 % and the first that fits is taken. room (optional, a function): the room to run a tight outline on, in shares of its length, which does not depend on k. Returns
     { k, fit } and tight: true when it is the tight fit that works. */
  function waitZoom(text, w, h, w100, kmax, room) {
    let rm; // worked out once, the first time a longer outline could help
    const roomOnce = room ? () => (rm === undefined ? (rm = room()) : rm) : null;
    for (let k0 = 1.02; ; k0 *= 1.02) {
      if (k0 > kmax) k0 = kmax;
      if (!(k0 > 1)) return null;
      const k = Math.round(k0 * 1000) / 1000; // (the fit is made at the k that is returned)
      const fit = fitText(text, w * k, h * k, w100);
      if (fit && fit.font >= MIN_FONT) return { k: k, fit: fit };
      const tf = tightStage(text, w * k, h * k, w100, roomOnce);
      if (tf) return { k: k, fit: tf, tight: true };
      if (k0 >= kmax) return null;
    }
  }

  /* The largest zoom that is worth waiting for from a view with this field of view (degrees; null or not a number: K_MAX). Street View's narrowest view is 15 degrees (measured: wheel
     notches stop there), and what an outline grows by between two fields of view is tan(wide / 2) / tan(narrow / 2) in any direction; 5 % is kept in hand. */
  function kmaxFor(fov) {
    if (typeof fov !== 'number' || !isFinite(fov) || fov > 120) return K_MAX;
    if (fov <= 15) return 1; // already as far in as Street View goes: nothing to wait for
    return Math.min(K_MAX, Math.max(1, (0.95 * Math.tan((fov * Math.PI) / 360)) / Math.tan((15 * Math.PI) / 360)));
  }

  /* All of a mark's lines. Returns { items: [{ i, ok, why, ... }], pass, waiting, tight, total, auto }. total counts every line the card lists (one with a box or not); pass counts the lines that can be drawn now
     (tight ones included: tight is how many of them are); auto is true when at least one line can be drawn now or later (pass + waiting >= 1) and at least half of all the lines can ((pass + waiting) * 2 >= total):
     a waiting line counts as placeable (the owner's ruling, 15 Nov 2026).
     opts.kmax: the largest zoom a waiting line may wait for (default K_MAX). */
  function plan(lines, cs, ref, w100, opts) {
    const list = (lines || []).map((l, i) => ({ l: l, i: i })).filter((x) => x.l && (x.l.o || x.l.t));
    const shapes = list.map((x) => (isQuad(x.l) ? { box: null, poly: quadPts(x.l.q), quad: true } : boxOf(x.l)));
    const claimed = []; // the longer outlines (polygons) given to tight lines so far: the next tight line's run-on keeps off them
    const items = list.map((x, k) => {
      const others = shapes.filter((b, j) => j !== k);
      const r = gateLine(x.l, cs, ref, others, w100, { claimed: claimed });
      r.i = x.i;
      if (r.ok && r.qx) claimed.push(quadPts(r.qx));
      return r;
    });
    unifyColors(items);
    const pass = items.filter((r) => r.ok).length;
    const tight = items.filter((r) => r.ok && r.tight).length;
    // waiting lines: only lines that failed on size alone, only ever added to the lines that pass
    const kmax = opts && typeof opts.kmax === 'number' ? opts.kmax : K_MAX;
    let waiting = 0;
    if (kmax > 1) {
      const taken = []; // the shapes of the lines that pass and of the waiting lines accepted so far
      items.forEach((r, k) => { if (r.ok) taken.push(shapes[k]); });
      items.forEach((r, k) => {
        if (r.ok || r.why !== 'nofit') return;
        const l = list[k].l;
        const t = String(l.t || '').trim();
        const quad = isQuad(l);
        let w, h;
        if (quad) { const m = quadMetrics(l.q, ref[0] / cs[0], ref[1] / cs[1]); w = m.len; h = m.hgt; } else { const b = boxOf(l); w = ((b[2] - b[0]) * ref[0]) / cs[0]; h = ((b[3] - b[1]) * ref[1]) / cs[1]; }
        const others = shapes.filter((b, j) => j !== k);
        const z = waitZoom(t, w, h, w100, kmax, quad ? () => roomOf(l, w, h, cs, others, claimed) : null);
        if (!z) return;
        const limit = quad ? MAX_OVERLAP_QUAD : MAX_OVERLAP;
        for (const o of taken) if (o && overlapShare(shapes[k], o) > limit) return;
        taken.push(shapes[k]);
        waiting++;
        const colors = pickText(l.bg || null, l.fg || null);
        const common = { wait: true, k: z.k, text: t, bw: z.tight ? z.fit.bw : w * z.k, bh: z.tight ? z.fit.bh : h * z.k, fit: z.fit, bg: l.bg || null, color: colors.color, colorFrom: colors.from };
        if (z.tight) Object.assign(common, { tight: true, sq: z.fit.sq });
        if (quad) {
          const qx = z.tight && (z.fit.aL || z.fit.aR) ? extQuad(l.q, z.fit.aL, z.fit.aR) : null;
          Object.assign(r, common, { quad: true, q: l.q, box: quadBox(qx || l.q), dirs: l.qd, angle: quadMetrics(l.q, ref[0] / cs[0], ref[1] / cs[1]).angle });
          if (z.tight) { r.qx = qx; r.aL = z.fit.aL; r.aR = z.fit.aR; }
          if (qx) claimed.push(quadPts(qx));
        } else Object.assign(r, common, { box: boxOf(l), dirs: dirsOf(l) });
      });
      if (waiting) unifyColors(items, (r) => r.wait);
    }
    return { items: items, pass: pass, waiting: waiting, tight: tight, total: items.length, auto: pass + waiting >= 1 && (pass + waiting) * 2 >= items.length };
  }

  const API = { K_MAX: K_MAX, kmaxFor: kmaxFor, waitZoom: waitZoom, fitTight: fitTight, refit: refit, extRoom: extRoom, extQuad: extQuad, extStrip: extStrip, dropsDigits: dropsDigits, norm: norm, TIGHT_PADX: TIGHT_PADX, SQUEEZE_MIN: SQUEEZE_MIN, EXT_MAX_H: EXT_MAX_H, EXT_MAX_LEN: EXT_MAX_LEN, setOverlapShrink: (v) => { overlapShrink = Math.max(0, Math.min(0.5, +v || 0)); }, MAX_ANGLE: MAX_ANGLE, MAX_STACK: MAX_STACK, isQuad: isQuad, quadMetrics: quadMetrics, overlapShare: overlapShare, polyArea: polyArea, clipPoly: clipPoly, MAX_TILT: MAX_TILT, readsOn: readsOn, MIN_RATIO: MIN_RATIO, MIN_LINE_H: MIN_LINE_H, MAX_OVERLAP: MAX_OVERLAP, MAX_OVERLAP_QUAD: MAX_OVERLAP_QUAD, MIN_FONT: MIN_FONT, LINE_H: LINE_H, luminance: luminance, contrast: contrast, pickText: pickText, wrap: wrap, fitText: fitText, gateLine: gateLine, plan: plan };
  root.PAAOvFit = API;
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
})(typeof self !== 'undefined' ? self : globalThis);
