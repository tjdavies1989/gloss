/* Gloss: wiring, and the rules for which card is open.
   One card is open at a time. A caption click opens its card and closes any other; a plain press on the scene
   closes the open card WITHOUT swallowing the press (Street View still gets its drag); Esc closes the open card
   (swallowed, see keys.js), otherwise goes to Maps; a new ask collapses the previous card. */
(function () {
  'use strict';
  if (window.__paaLoaded) return;
  window.__paaLoaded = true;

  const PAA = self.PAA;
  const P = self.PAAPose;
  const MENU_QUIET = 600; // ms presses in a closed menu's rectangle are swallowed

  /* the card that is open and showing right now (a hidden or still-"Reading" mark does not count, so Esc is
     only swallowed when there is something on screen to close) */
  function openCard() {
    return PAA.layer.all().find((m) => m.open && m.viewKind() === 'card' && m.vis.card) || null;
  }
  function composing() {
    return PAA.layer.all().find((m) => m.state === 'compose') || null;
  }
  function closeMark(m) {
    if (m.state === 'compose') PAA.ask.cancelCompose(m); // composing: closing means cancelling
    else m.setOpen(false);
  }
  function collapseOthers(keep) {
    PAA.layer.all().forEach((m) => {
      if (m !== keep && m.open) closeMark(m);
    });
  }
  function openMark(m) {
    collapseOthers(m);
    m.setOpen(true);
  }

  /* Copy to the clipboard. The page's own clipboard API needs focus; the old way works without. */
  function copyText(text) {
    PAA.lastCopied = text;
    const legacy = () => {
      const ta = document.createElement('textarea'); // inside our closed shadow root, where page scripts cannot see it
      ta.value = text;
      ta.style.cssText = 'position:fixed;left:-9999px;top:0;opacity:0';
      PAA.layer.pane().appendChild(ta);
      ta.select();
      try { document.execCommand('copy'); } catch (e) { /* nothing more to try */ }
      ta.remove();
    };
    try {
      navigator.clipboard.writeText(text).catch(legacy);
    } catch (e) {
      legacy();
    }
  }

  function goTo(m) {
    const url = PAA.goUrl(m.rec);
    if (!url) return;
    PAA.book.goTo({ id: m.id, url: url }, () => { // an answer is still being written: the jump waits for it, and the button says so
      const b = m.cardEl && m.cardEl.querySelector('[data-act="goto"]');
      if (b && b.lastChild) b.lastChild.textContent = 'Finishing the answer…';
    });
  }

  function action(m, act) {
    if (act === 'delete') PAA.ask.remove(m);
    else if (act === 'retry') PAA.ask.retry(m);
    else if (act === 'settings') { try { chrome.runtime.sendMessage({ type: 'openOptions' }); } catch (e) { /* extension gone */ } }
    else if (act === 'ask') m.toggleAsk();
    else if (act === 'more') m.setMenu(!m.menuOpen);
    else if (act === 'copy-t' || act === 'copy-o') {
      copyText(act === 'copy-t' ? m.translation() : m.orig2());
      const b = m.cardEl && m.cardEl.querySelector('[data-act="' + act + '"]');
      if (b && b.lastChild) b.lastChild.textContent = 'Copied';
      setTimeout(() => { // the menu closes; a second click where it was must not land on the scene (and walk): swallow presses there for a moment
        const menu = m.cardEl && m.cardEl.querySelector('.menu');
        if (menu && PAA.press) {
          const r = menu.getBoundingClientRect();
          PAA.press.guard({ x: r.left, y: r.top, w: r.width, h: r.height }, MENU_QUIET);
        }
        m.setMenu(false);
      }, 700);
    } else if (act === 'goto') goTo(m);
    else if (act === 'overlay') {
      if (PAA.patch && PAA.patch.on(m)) { // (a mark with a repaint showing draws no labels: asking for them takes the repaint off and puts the labels on)
        PAA.patch.toggle(m);
        PAA.overlay.show(m);
      } else PAA.overlay.toggle(m);
    } else if (act === 'repaint') PAA.patch.click(m);
    else if (act === 'repaint-again') { m.setMenu(false); PAA.patch.start(m); }
    else if (act === 'repaint-remove') { m.setMenu(false); PAA.patch.remove(m); }
  }

  /* the text field that has the keyboard, if one of ours has: the compose field or a follow-up field */
  function activeField() {
    const ae = PAA.layer.activeElement();
    if (!ae) return null;
    const m = PAA.layer.all().find((x) => x.input === ae || (x.fuInput === ae && x.askOpen));
    if (!m) return null;
    return { mark: m, submit: () => (m.input === ae ? PAA.ask.submitCompose(m) : submitFollowUp(m)) };
  }

  function submitFollowUp(m) {
    const text = m.fuInput ? m.fuInput.value.trim() : '';
    if (!text) return;
    m.fuInput.value = '';
    PAA.ask.followUp(m, text);
  }

  /* Esc: the menu first, then the card */
  function escape(m) {
    if (m.menuOpen) m.setMenu(false);
    else closeMark(m);
  }

  // a plain press on the scene closes the open card; the press itself is left alone
  function onScenePress(e) {
    if (!e.isTrusted || e.altKey || PAA.layer.inOurs(e)) return;
    const m = openCard();
    if (m) closeMark(m);
    PAA.book.close();
  }

  // a new panorama (or none): leave the old marks behind, bring this panorama's saved marks back
  function onPano(pid) {
    PAA.layer.all().forEach((m) => {
      if (m.rec.pano && m.rec.pano.id !== pid && !m.occupied() && m.state !== 'compose') PAA.layer.remove(m);
    });
    if (pid) {
      PAA.ask.restore(pid);
      PAA.far.arrive(pid); // the saved marks from other panoramas that can be seen from here (soft anchors)
    }
  }

  PAA.app = {
    openCard: openCard,
    composing: composing,
    openMark: openMark,
    collapseOthers: collapseOthers,
    action: action,
    escape: escape,
    submit: (m) => PAA.ask.submitCompose(m),
    activeField: activeField,
  };

  /* Test helpers for the harness (isolated world only; a page script cannot reach them). */
  PAA.debug = {
    layer: () => PAA.layer.debug(),
    pose: () => P.getPose(),
    /* n synthetic, finished marks scattered over the current view, not saved (the 30-marks smoothness test) */
    spawn(n) {
      const pose = P.getPose();
      const vr = pose.canvasRect || { x: 0, y: 0, width: innerWidth, height: innerHeight };
      const ids = [];
      for (let i = 0; i < n; i++) {
        const w = 60 + ((i * 37) % 90), h = 34 + ((i * 53) % 60);
        const x = vr.x + 40 + ((i * 197) % Math.max(1, vr.width - 200)), y = vr.y + 80 + ((i * 131) % Math.max(1, vr.height - 220));
        const s = { x: x, y: y, w: w, h: h };
        const dirs = pose.panoId ? ['tl', 'tr', 'br', 'bl', 'c'].reduce((o, k) => {
          const px = k === 'tl' || k === 'bl' ? x : k === 'c' ? x + w / 2 : x + w, py = k === 'tl' || k === 'tr' ? y : k === 'c' ? y + h / 2 : y + h;
          o[k] = P.screenToDir(px, py);
          return o;
        }, {}) : null;
        const rec = {
          id: 'spawn-' + i + '-' + Date.now(), v: 2, createdAt: Date.now(), kind: 'box',
          pano: pose.panoId ? { id: pose.panoId, type: pose.kind, lat: pose.lat, lng: pose.lng } : null,
          view: { url: location.href, heading: pose.heading, pitch: pose.pitch, fov: pose.fov },
          dirs: dirs, screen: { x: x, y: y, w: w, h: h, vw: innerWidth, vh: innerHeight }, world: null, q: null,
          a: { say: 'Synthetic mark ' + (i + 1), orig: '', read: '', note: i % 3 === 0 ? 'A note.' : '', unsure: '', lines: [], structured: true, raw: '' },
          fu: [], stats: null, thumb: null, overlay: null, repaint: null,
        };
        const m = new PAA.Mark(rec, { open: false });
        PAA.layer.add(m);
        ids.push(m.id);
      }
      PAA.layer.trackNow();
      PAA.layer.requestLayout(0);
      return ids;
    },
    /* one synthetic finished mark at a given screen rect (not saved) */
    /* opts.yaw: turn the mark's directions by this many degrees (a mark off screen), opts.age: its age in ms */
    spawnAt(x, y, w, h, say, extra, opts) {
      opts = opts || {};
      const pose = P.getPose();
      const pt = (px, py) => {
        const d = P.screenToDir(px, py);
        return d && opts.yaw ? { yaw: ((d.yaw + opts.yaw) % 360 + 360) % 360, pitch: d.pitch } : d;
      };
      // opts.point: an Option-click's mark (a 36 px ring at the middle of the pictured rectangle; the LINES lie anywhere in that rectangle)
      const rx = opts.point ? x + w / 2 - 18 : x, ry = opts.point ? y + h / 2 - 18 : y, rw = opts.point ? 36 : w, rh = opts.point ? 36 : h;
      const dirs = pose.panoId ? { tl: pt(rx, ry), tr: pt(rx + rw, ry), br: pt(rx + rw, ry + rh), bl: pt(rx, ry + rh), c: pt(rx + rw / 2, ry + rh / 2) } : null;
      const rec = {
        id: 'spawn-at-' + Date.now() + '-' + Math.floor(Math.random() * 1e6), v: 2, createdAt: Date.now() - (opts.age || 0), kind: opts.point ? 'point' : 'box',
        pano: pose.panoId ? { id: pose.panoId, type: pose.kind, lat: pose.lat, lng: pose.lng } : null,
        view: { url: location.href, heading: pose.heading, pitch: pose.pitch, fov: pose.fov },
        dirs: dirs, screen: { x: rx, y: ry, w: rw, h: rh, vw: innerWidth, vh: innerHeight }, world: null, q: null,
        a: Object.assign({ say: say || 'Synthetic', orig: '', read: '', note: '', unsure: '', lines: [], structured: true, raw: '' }, extra || {}),
        fu: [], stats: { ms: 5300, cost: 0.0042, model: 'test' }, thumb: opts.thumb || null, overlay: null, repaint: null,
      };
      if (opts.fu) rec.fu = opts.fu;
      if (opts.lines && dirs) { // stage 3: LINES at screen rectangles {x, y, w, h, o, t, bg, fg} (v0.3.1: or {quad: [[x,y] tl, tr, br, bl], o, t, bg, fg}); the "picture sent" is twice the mark's size
        rec.overlay = { v: 1, cs: [w * 2, h * 2], ref: [w, h], on: opts.on === undefined ? null : opts.on };
        rec.a.lines = opts.lines.map((l) => {
          if (l.quad) { // v0.3.1: a line with four corners (screen points tl, tr, br, bl, clockwise): q in the picture's pixels (twice the screen's), qd their directions, b the bounding box
            const q = [];
            l.quad.forEach((p) => q.push(Math.round((p[0] - x) * 20) / 10, Math.round((p[1] - y) * 20) / 10));
            const xs = l.quad.map((p) => p[0]), ys = l.quad.map((p) => p[1]);
            const bx0 = Math.min.apply(null, xs), bx1 = Math.max.apply(null, xs), by0 = Math.min.apply(null, ys), by1 = Math.max.apply(null, ys);
            return { b: [Math.round((bx0 - x) * 2), Math.round((by0 - y) * 2), Math.round((bx1 - x) * 2), Math.round((by1 - y) * 2)],
              dirs: { tl: pt(bx0, by0), tr: pt(bx1, by0), br: pt(bx1, by1), bl: pt(bx0, by1) },
              q: q, qd: { tl: pt(l.quad[0][0], l.quad[0][1]), tr: pt(l.quad[1][0], l.quad[1][1]), br: pt(l.quad[2][0], l.quad[2][1]), bl: pt(l.quad[3][0], l.quad[3][1]) },
              o: l.o, t: l.t, bg: l.bg || [200, 30, 40], fg: l.fg || null };
          }
          const b = [Math.round((l.x - x) * 2), Math.round((l.y - y) * 2), Math.round((l.x + l.w - x) * 2), Math.round((l.y + l.h - y) * 2)];
          const d = { tl: pt(l.x, l.y), tr: pt(l.x + l.w, l.y), br: pt(l.x + l.w, l.y + l.h), bl: pt(l.x, l.y + l.h) };
          return { b: b, sb: b.slice(), dirs: d, sd: d, o: l.o, t: l.t, bg: l.bg || [200, 30, 40], fg: l.fg || null };
        });
      }
      const m = new PAA.Mark(rec, { open: false });
      PAA.layer.add(m);
      PAA.layer.trackNow();
      PAA.layer.requestLayout(0);
      return m.id;
    },
    clearSpawned() {
      PAA.layer.all().filter((m) => /^spawn/.test(m.id)).forEach((m) => PAA.layer.remove(m));
    },
  };

  PAA.layer.ensure();
  PAA.prefs.onChange(() => { // density changed (here or in another tab): everything is placed again
    PAA.layer.trackNow();
    PAA.layer.requestLayout(0);
    PAA.dock.refresh();
  });
  PAA.keys.init();
  PAA.hover.init();
  PAA.dock.init();
  PAA.finder.init();
  PAA.gesture.init((plan) => { PAA.ask.begin(plan).catch((e) => console.error('[PAA] begin', e)); });
  PAA.layer.setPanoHandler(onPano);
  window.addEventListener('pointerdown', onScenePress, { capture: true, passive: true });
  // The pose module only calls us when the camera or the address changes; make sure a page that loads already
  // sitting on a panorama (a reload) is noticed even before the first frame is drawn.
  const watch = () => {
    if (P.getPose().panoId !== PAA.layer.lastPano()) PAA.layer.trackNow();
  };
  setInterval(watch, 500);
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', watch, { once: true });
  else watch();
})();
