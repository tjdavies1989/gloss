/* Gloss: AI repaint (stage 4), the pure part. No DOM, no Chrome, no network: loaded by the page (what to repaint, what shape of picture), by the
   service worker (the instruction, the checks) and by the node tests, which run it on the repaint experiment's saved results.

   The idea (research/repaint/NOTES.txt): Haiku reads the sign and supplies the exact English; an image model only does the LETTERING; Haiku then
   reads the result back blind and the picture outside the text is compared with the original. A result that fails is never shown.

   What lives here:
     paintable / assess     which LINES entries may be painted, and which make the crop "cut off" (then it is not repainted: leftover old writing
                            beside new English is worse than nothing)
     buildInstruction       the lettering job, worded exactly as in the experiment (the unit test compares it with the experiment's saved prompts)
     pickRatio / planCrop   the picture sent for repainting must contain the whole sign with a margin AND have a shape the image model can output
     evaluate / explain     the read-back check (words, digits, nothing invented) and its reasons in plain words
     pixelCheck             the picture outside the text boxes did not change much (experiment: mean grey difference and colour drift)
   The model's boxes are HINTS only: never a mask. */
(function (root) {
  'use strict';

  const IMAGE_MODEL = 'openai/gpt-image-2.6-sunburst'; // measured best of four (experiment): good in 5 of 6 cases, 28 s, about 4 cents
  const QUALITY = 'medium';
  /* the shapes the image model can output (GET /api/v1/images/models, 14 Nov: aspect_ratio enum) */
  const RATIOS = [['1:1', 1], ['3:2', 3 / 2], ['2:3', 2 / 3], ['4:3', 4 / 3], ['3:4', 3 / 4], ['16:9', 16 / 9], ['9:16', 9 / 16], ['21:9', 21 / 9]];
  const SHAPE_TOL = 0.03; // a stored crop is used as it is only when its shape is within 3 % of one of those (the experiment's crops matched exactly)
  const EDGE_MARGIN = 0.03; // a line of writing whose box comes closer than this (of the short side) to the picture's edge is cut off
  const INPUT_MAX = 1536; // long side of the picture sent to the image model (it outputs about this size; a bigger one only slows it)
  const INPUT_MIN = 768; // a fresh picture smaller than this on its long side is enlarged to it (at most 4 times): the model draws at its own size from what it is given
  const WORK = 128; // long side of the pictures the pixel check compares
  const GROW = 0.35; // the text boxes are grown by this before the pixel check leaves them out (as in the experiment)
  const MAD_MAX = 15; // mean grey difference outside the text, 0 to 255 (experiment: good results 2.6 to 13.7, the one that changed the board's colours 18.3)
  const COL_MAX = 8.4; // mean colour drift outside the text (good results 0.5 to 8.0; changed colours 8.6 to 20)
  const BLOB_MAX = 20; // the largest mean grey difference of any window of a fifth of the picture's long side, outside the text (good saved results 2 to 12, a rejected one 27; a live result that painted a pale block over the wall: 50 and more)
  const INSIDE_MIN = 6; // the mean grey difference INSIDE the text boxes must be at least this, and ... (saved good results 11.4 to 44; the scene given back unchanged is about as different there as anywhere)
  const INSIDE_GAIN = 1.5; // ... this much more than outside them (the 12 saved results, good or not: 2.2 to 36 more)
  const FRAME_TOL = 0.04; // the result's shape against the picture's: more than 4 % off means it was re-framed

  const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));

  /* ---------------------------------------------------------------- text */
  /* letters Unicode does not take apart into letter + accent: for the comparison they are the plain letter (Vietnamese đ, Polish ł, Danish ø, Turkish dotless ı ...) */
  const PLAIN = { 'đ': 'd', 'ð': 'd', 'ł': 'l', 'ø': 'o', 'ı': 'i', 'ß': 'ss', 'æ': 'ae', 'œ': 'oe', 'þ': 'th' };
  const PLAIN_RE = /[đðłøıßæœþ]/g;
  function normalise(s) {
    return String(s || '')
      .normalize('NFKD').replace(/[̀-ͯ]/g, '').normalize('NFKC').toLowerCase()
      .replace(PLAIN_RE, (c) => PLAIN[c])
      .replace(/[‘’]/g, "'").replace(/[“”]/g, '"')
      .replace(/[^\p{L}\p{N}]+/gu, ' ').trim().replace(/\s+/g, ' ');
  }

  const NON_LATIN = /[\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}\p{Script=Hangul}\p{Script=Cyrillic}\p{Script=Greek}\p{Script=Arabic}\p{Script=Hebrew}\p{Script=Thai}\p{Script=Devanagari}]/u;
  const GAP = /(…|\.\.\.|\[hidden\]|\?\?)/;

  /* The text to paint. The model often adds a gloss, "Tanima (shop name)": the image model paints everything it is given, so brackets are removed
     unless the original itself has brackets. */
  function paintText(e) {
    let t = String(e.t || '');
    if (!/[(（]/.test(e.o || '')) t = t.replace(/\s*[(（][^)）]*[)）]/g, '');
    t = t.replace(/\s+/g, ' ').trim();
    t = t.replace(/ı/g, 'i').replace(/İ/g, 'I'); // the image model draws the dotted i for a dotless one every time (3 of 3 Istanbul pictures) and the blind reader cannot tell: English spells Kadikoy with the plain i
    return t || String(e.t || '').trim();
  }

  /* Two painted lines of one sign with the same English of two words or more and different old writing: the model gave each line the whole phrase ("business centre" for CENTRE and
     again for D'AFFAIRES), and the picture would say it twice. Single words are left alone (OPEN, OUVERT and ABIERTO may all be "open"). Returns [[i, j]] (indexes into paint). */
  function repeated(paint) {
    const out = [];
    const L = paint || [];
    for (let i = 0; i < L.length; i++) {
      const a = normalise(L[i].t);
      if (a.indexOf(' ') < 0) continue;
      for (let j = i + 1; j < L.length; j++) if (normalise(L[j].t) === a && normalise(L[j].o) !== normalise(L[i].o)) out.push([i, j]);
    }
    return out;
  }

  /* Which line is worth painting (v0.3.1: any language). Left alone: no original or no translation; the translation is the original once case, accents and spacing are
     set aside (English already, a brand name the model repeated, "Thuy" for "Thủy"); and, when the original is in Latin letters, a NUMBER line (it has a digit and no
     word of 4 letters or more: "ĐT: 0983 177 039", "Giá 50.000", "350 m2" are left; "Loja e andares 350 m2" has "andares" and is painted) and a web or mail address.
     An original in any other script is painted whenever the English differs (as in 0.3.0). The rules and what they were measured on: research/any-sign/repaint/DESIGN.md. */
  const ADDRESS = /(^|[\s(])www\.|https?:\/\/|\S@\S|\.(com|net|org|info|vn|br|tr|pl|cz|de|fr|es|it|nl|id|my|hu|gr|ru|jp|cn|th)(\/|\s|$)/i;
  const isLatin = (o) => !!o && /\p{L}/u.test(o) && !NON_LATIN.test(o);
  function wantPaint(o, t) {
    o = String(o || '');
    if (!o.trim() || !t) return false;
    if (normalise(t) === normalise(o)) return false;
    if (NON_LATIN.test(o)) return true;
    if (/\d/.test(o) && !/\p{L}{4,}/u.test(o)) return false; // a number line
    return !ADDRESS.test(o);
  }

  /* Lines worth painting: see wantPaint. Dropped besides: a gap or a guess in it ("..." or an ellipsis: the model would paint the gap); and, with hints.edgeMargin,
     a piece whose box touches the picture's edge (cut off). */
  function paintable(lines, hints) {
    hints = hints || {};
    const W = hints.width, H = hints.height;
    const m = hints.edgeMargin && W && H ? hints.edgeMargin * Math.min(W, H) : 0;
    const inside = (b) => !m || (b[0] >= m && b[1] >= m && b[2] <= W - m && b[3] <= H - m);
    return (lines || []).filter((e) => inside(e.b)).map((e) => ({ b: e.b, q: e.q, o: e.o, t: paintText(e) }))
      .filter((e) => wantPaint(e.o, e.t) && !GAP.test(e.o + ' ' + e.t));
  }

  /* a line's four corners as eight finite numbers (the picture's pixels), or null */
  const quadOf = (e) => (e && Array.isArray(e.q) && e.q.length === 8 && e.q.every(Number.isFinite) ? e.q : null);

  /* What a mark's LINES come to for repainting: { paint: [{i, b, q, o, t}], cut: [{i, why}], left: n }.
     Every line that would have to be painted but cannot be makes the picture "cut off" (cut): its old writing would stay beside the new English, so the caller
     refuses rather than repaints badly. Lines that need no repainting (see wantPaint) are just left.
     lines carry b (the box in the pixels of a picture w x h; null: no box), q (the four corners, same pixels, or null), optional spill (the model's box ran off the
     picture it saw, so its text was cut off then); opts.edgeMargin (of the short side; default EDGE_MARGIN: 0 means a line close to the picture's edge is not
     taken for cut off, which is what a tightly dragged box needs: the page asks with 0 and takes a roomy picture of its own). */
  function assess(lines, w, h, opts) {
    opts = opts || {};
    const m = (opts.edgeMargin == null ? EDGE_MARGIN : opts.edgeMargin) * Math.min(w, h);
    const paint = [], cut = [];
    let left = 0;
    (lines || []).forEach((e, i) => {
      const o = e.o || '';
      const t = paintText(e);
      if (!wantPaint(o, t)) { left++; return; }
      if (GAP.test(o + ' ' + t)) { cut.push({ i: i, why: 'fragment' }); return; }
      if (e.spill) { cut.push({ i: i, why: 'spill' }); return; }
      const b = Array.isArray(e.b) && e.b.length === 4 && e.b.every(Number.isFinite) ? e.b : null;
      if (b && (b[0] < m || b[1] < m || b[2] > w - m || b[3] > h - m)) { cut.push({ i: i, why: 'edge' }); return; }
      paint.push({ i: i, b: b, q: quadOf(e), o: o, t: t });
    });
    return { paint: paint, cut: cut, left: left };
  }

  /* Latin mode: at least one line to paint has its original in Latin letters (Vietnamese, Portuguese ...). What is new for such signs (the wording to the image model,
     the old-writing-gone rule of the check) is switched on by this and only by this: a job whose lines are all in other scripts is built and checked as in 0.3.0. */
  const latinMode = (lines) => (lines || []).some((e) => isLatin(e.o));

  /* ---------------------------------------------------------------- the instruction */
  function place(b, W, H) {
    const cx = (b[0] + b[2]) / 2 / W, cy = (b[1] + b[3]) / 2 / H;
    const h = cx < 0.34 ? 'left' : cx > 0.66 ? 'right' : 'centre';
    const v = cy < 0.34 ? 'upper' : cy > 0.66 ? 'lower' : 'middle';
    return v + ' ' + h;
  }
  const pct = (v, n) => Math.round((v / n) * 100) + '%';

  /* lines: [{b,o,t}]. hints: { width, height (of the picture sent), keep: [texts that must stay], unreadable: 'short note', firm, problems: [reasons from a
     failed check], noBoxes }. The wording is the experiment's (sun-med): the unit test holds it to the saved prompts. */
  function buildInstruction(lines, hints) {
    hints = hints || {};
    lines = paintable(lines, hints);
    const W = hints.width || 0, H = hints.height || 0;
    const L = [];
    L.push('This is a photo of a real street scene. Do a LETTERING JOB ONLY: replace the written text listed below with the exact English given, and change nothing else in the picture.');
    L.push('');
    if (hints.noBoxes) L.push('Text to replace (' + lines.length + ' piece' + (lines.length > 1 ? 's' : '') + '); find each piece by what it says now:');
    else L.push('Text to replace (' + lines.length + ' piece' + (lines.length > 1 ? 's' : '') + '). Boxes are approximate hints, [left, top, right, bottom]' + (W ? ' in pixels of this ' + W + 'x' + H + ' image' : '') + '; find each piece by what it says now:');
    lines.forEach((e, i) => {
      let where = '';
      if (!hints.noBoxes && Array.isArray(e.b)) {
        const b = e.b.map(Math.round);
        where = 'Box [' + b.join(', ') + ']';
        if (W && H) where += ', ' + place(b, W, H) + ' of the image, from ' + pct(b[0], W) + ' to ' + pct(b[2], W) + ' across and ' + pct(b[1], H) + ' to ' + pct(b[3], H) + ' down';
        where += '. ';
      }
      L.push((i + 1) + '. ' + where + 'Now reads: "' + (e.o || '(original text)') + '". Paint exactly: "' + e.t + '"');
    });
    L.push('');
    L.push('Rules:');
    L.push('- Paint each piece of English exactly as spelled between the quotation marks: same letters, same digits, same punctuation, nothing added, nothing missing. Do not correct, complete or embellish it.');
    L.push('- First remove the old lettering cleanly (restore the sign surface behind it), then letter the English in the same style as the original: same kind of font, weight, colour, outline, shadow, slant, perspective, wear, blur and lighting, so it looks painted by the same sign-maker. Keep it where the old lettering was. If the English is longer or shorter, change the letter size or wrap to fit; do not resize the sign.');
    L.push('- Everything else stays exactly as in the input, pixel for pixel: the sign itself, its frame and background, all objects, people, other signs, sky, colours, grain, blur, framing and aspect ratio.');
    if (latinMode(lines)) {
      L.push('- Some of the old words are in a language written with Latin letters (for example Vietnamese, Portuguese or Turkish), not in English. Replace them like any other: when you are done none of the old words listed above may remain anywhere on the sign, not even small or faint. Names that the English keeps (Thủy, Quảng) keep their accents exactly as given.');
      L.push('- Any other text (English that is already there, shop and brand names, numbers, phone numbers, prices, web addresses, tiny text, blurred text, or text not listed above) must stay exactly as it is: same letters, same accents, same digits, even when it is in the same language as the lines above. Do not invent, translate, sharpen or "fix" it.');
      // (0.3.2) the image model leaves the old accent on the new letter ("gamé" from HERNÍ, "servicés" from AGRÉÉS, "Homė" from À) or draws another one ("Kadikőy"): when none of the English has an accented letter, say so
      if (!lines.some((e) => specialIn(String(e.t || '')))) L.push('- The English above has no accented letters: use only the letters given and draw no accent marks (no acute, grave, circumflex, umlaut, macron, tilde or other mark above or below a letter) on any letter, not even where the old writing had one. The ordinary dot on an i and a j stays.');
    } else {
      L.push('- Any other text (including text already in English or Latin letters, numbers, phone numbers, tiny text, blurred text, or text not listed above) must stay exactly as it is. Do not invent, translate, sharpen or "fix" it.');
    }
    if (hints.keep && hints.keep.length) L.push('- These existing texts must stay exactly as they are: ' + hints.keep.map((s) => '"' + s + '"').join(', ') + '.');
    if (hints.unreadable) L.push('- Leave alone (cannot be read): ' + hints.unreadable + '.');
    if (hints.firm) {
      L.push('');
      L.push('STRICT RETRY. A previous attempt failed the check' + (hints.problems && hints.problems.length ? ': ' + hints.problems.join('; ') : '') + '. Spell every listed English text letter by letter exactly as given, and do not touch anything outside the listed boxes. If you cannot letter a piece exactly, leave that piece as it was rather than guessing.');
    }
    L.push('');
    L.push('Return the full edited image at the same framing.');
    return L.join('\n');
  }

  /* ---------------------------------------------------------------- the shape of the picture */
  /* the output shape closest to w / h: { name: '3:2', ratio: 1.5, off: how far w / h is from it (0.02 = 2 %) } */
  function pickRatio(w, h) {
    const ar = w / h;
    let best = null;
    RATIOS.forEach((r) => {
      const off = Math.abs(ar / r[1] - 1);
      if (!best || off < best.off) best = { name: r[0], ratio: r[1], off: off };
    });
    return best;
  }

  /* The picture to repaint, in screen pixels: it must contain content (the sign: the mark's rectangle and its lines of writing, {x, y, w, h}) with a margin,
     have exactly one of the shapes above, and lie inside the picture rectangle vr. Tries a roomy margin first, then tighter ones. Returns
     { x, y, w, h, ratio: '3:2', margin } or { refuse: 'edge' | 'big' | 'small' } (edge: the sign runs off the picture; big: no room for it with a margin;
     small: it is too small on screen to repaint, zoom in). */
  function planCrop(content, vr, opts) {
    opts = opts || {};
    const c = content;
    const eps = 2; // px
    if (!(c.w > 0 && c.h > 0)) return { refuse: 'small' };
    if (c.x < vr.x + eps || c.y < vr.y + eps || c.x + c.w > vr.x + vr.w - eps || c.y + c.h > vr.y + vr.h - eps) return { refuse: 'edge' };
    if (Math.max(c.w, c.h) < (opts.minContent || 40)) return { refuse: 'small' };
    const margins = opts.margins || [0.16, 0.11, 0.07, 0.04];
    const clear = Math.max(2, 0.02 * Math.min(c.w, c.h)); // the content stays this far from the new edge
    const avoid = opts.avoid || []; // Google's own buttons and cards drawn over the picture: a crop that includes one would carry a frozen copy of it
    const hits = (r, a) => r.x < a.x + a.w && r.x + r.w > a.x && r.y < a.y + a.h && r.y + r.h > a.y;
    let blocked = false;
    for (let k = 0; k < margins.length; k++) {
      const g = margins[k] * (c.w + c.h) / 2;
      const gx = c.x - g, gy = c.y - g, gw = c.w + 2 * g, gh = c.h + 2 * g;
      const r = pickRatio(gw, gh);
      let w = gw, h = gh;
      if (gw / gh < r.ratio) w = gh * r.ratio; else h = gw / r.ratio; // grow the short side to the shape
      if (w > vr.w || h > vr.h) continue;
      let x = gx + gw / 2 - w / 2, y = gy + gh / 2 - h / 2;
      x = clamp(x, vr.x, vr.x + vr.w - w); // slide it back inside the picture
      y = clamp(y, vr.y, vr.y + vr.h - h);
      if (c.x < x + clear || c.y < y + clear || c.x + c.w > x + w - clear || c.y + c.h > y + h - clear) continue; // sliding cost the margin
      if (Math.min(w, h) < (opts.minSide || 56)) return { refuse: blocked ? 'controls' : 'small' }; // (a tighter margin than one that touched a control: it is the control that is in the way, not the size)
      if (avoid.some((a) => hits({ x: x, y: y, w: w, h: h }, a))) { blocked = true; continue; } // a tighter margin may clear it
      return { x: x, y: y, w: w, h: h, ratio: r.name, margin: margins[k] };
    }
    return { refuse: blocked ? 'controls' : 'big' };
  }

  /* the size a picture of w x h is sent at: its long side at most INPUT_MAX */
  function inputSize(w, h) {
    const k = Math.min(1, INPUT_MAX / Math.max(w, h));
    return [Math.max(1, Math.round(w * k)), Math.max(1, Math.round(h * k))];
  }

  /* the size a FRESH picture is cut at: reduced when over INPUT_MAX, enlarged (at most 4 times, same shape) when under INPUT_MIN */
  function sendSize(w, h) {
    const long = Math.max(w, h);
    const k = long > INPUT_MAX ? INPUT_MAX / long : long < INPUT_MIN ? Math.min(4, INPUT_MIN / long) : 1;
    return [Math.max(1, Math.round(w * k)), Math.max(1, Math.round(h * k))];
  }

  /* ---------------------------------------------------------------- the read-back check */
  function sim(a, b) { // 1 - edit distance / longer length
    const m = a.length, n = b.length;
    if (!m || !n) return 0;
    let prev = [];
    for (let j = 0; j <= n; j++) prev[j] = j;
    for (let i = 1; i <= m; i++) {
      const cur = [i];
      for (let j = 1; j <= n; j++) cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
      prev = cur;
    }
    return 1 - prev[n] / Math.max(m, n);
  }

  /* per intended line: 'exact' (a read piece equals it after normalising case and punctuation), 'joined' (found across neighbouring pieces: the reader
     split or merged lines differently), 'joined-loose', or 'none' */
  const LOOSE_MIN = 7; // letters: only a line this long may be found with the spaces left out, across other text
  function compare(lines, got) {
    const gotN = got.map(normalise).filter(Boolean);
    const joined = gotN.join(' ');
    const joinedC = joined.replace(/ /g, '');
    return lines.map((e) => {
      const want = normalise(e.t);
      let status = 'none';
      if (gotN.indexOf(want) >= 0) status = 'exact';
      else if (want && (' ' + joined + ' ').indexOf(' ' + want + ' ') >= 0) status = 'joined';
      else if (want && want.replace(/ /g, '').length >= LOOSE_MIN && joinedC.indexOf(want.replace(/ /g, '')) >= 0) status = 'joined-loose'; // (not for a short line: "bar" is inside "barber")
      return { want: e.t, status: status };
    });
  }

  /* The check on what was read back from the result. got: strings (null: the read-back could not be parsed). baselineTexts: the English / Latin text that
     was already on the ORIGINAL (read back the same way): expected to be there, so neither missing nor new. Rules (research/repaint/NOTES.txt): (1) every
     intended line is read back; (2) every digit run of 3+ on the original is still there and no new one has appeared; (3) no read piece of 6+ letters that
     resembles neither an intended line nor anything on the original (short fragments of blurred background text are read differently each time). */
  /* Street View's own watermark ("© 2023 Google") is on every picture, faint: the image model can sharpen it enough to be read back where the original's
     read-back missed it, and the reader sometimes mistakes it for something else ("© 2023 Getty Images"). It is not an invention and not a changed number:
     any piece with a copyright sign, Google or Getty in it, or a bare year, is left out of both read-backs. */
  const watermark = (s) => {
    const n = normalise(s);
    return /[©]|\(c\)/i.test(String(s)) || /\b(google|getty)\b/.test(n) || /^(19|20)\d\d$/.test(n);
  };

  /* ---- the check, v0.3.1 (repaint/DESIGN.md rule 3, tightened) ---- */
  /* whole-word occurrences of needle in hay, both already normalised (a word shared with the next occurrence counts: "ca" in "ca ca" is 2) */
  function countWord(hay, needle) {
    if (!needle) return 0;
    const H = ' ' + hay + ' ', N = ' ' + needle + ' ';
    let n = 0, i = 0;
    while ((i = H.indexOf(N, i)) >= 0) { n++; i += N.length - 1; }
    return n;
  }
  /* The old writing of the lines to paint, by its normalised text: { n: { o: first spelling, pc: how many lines to paint have it } } (Latin originals only: an old word in
     another script is not something the read-back lists) */
  function oldWritings(lines) {
    const orig = {};
    (lines || []).forEach((e) => {
      if (!isLatin(e.o)) return;
      const n = normalise(e.o);
      if (!n) return;
      (orig[n] = orig[n] || { o: e.o, pc: 0 }).pc++;
    });
    return orig;
  }
  /* GONE. The old words of a line that was painted must not be on the result: each may stay only as often as the original had it beyond the lines painted (a longer
     line that is left alone can hold it) plus as often as it is part of the English. Returns the spellings that stayed. It is what stops "the old words and the English
     side by side", and a result that re-drew the old words. Latin originals only (the read-back lists Latin letters). */
  function oldLeft(lines, got, base) {
    const orig = oldWritings(lines);
    const joined = (arr) => arr.map(normalise).filter(Boolean).join(' ');
    const jg = joined(got), jb = joined(base);
    const wanted = (lines || []).map((e) => normalise(e.t)).filter(Boolean);
    const out = [];
    Object.keys(orig).forEach((n) => {
      const nr = countWord(jg, n), nb = countWord(jb, n);
      const tOcc = wanted.reduce((sum, w) => sum + countWord(w, n), 0);
      if (nr > Math.max(0, nb - orig[n].pc) + tOcc) out.push(orig[n].o);
    });
    return out;
  }

  /* ACCENTS. normalise() sets accents aside on both sides (so that "Thuy" finds "Thủy"); that is right for finding a line, and wrong for judging it: an image model that
     paints "tố" where the English says "tô" has changed the word. For every word of a painted line that carries an accent or a special letter (Kadıköy, tô, Thủy, Ørsted):
     among the words of the read-back that are the same word with accents set aside, one must have the accents exactly as given. If none has, and every one of them is
     flat (no accent or special letter at all: the reader gave "Thuy", "Kadikoy"), the read-back simply cannot tell and the word passes; if one of them carries another
     accent or letter ("tố" for "tô", "Kadiköy" for "Kadıköy": the ö was read, the dotless ı was not) the word fails. Returns [{ want, got }]. */
  const marks = (s) => String(s).normalize('NFC').toLowerCase();
  const flatten = (w) => w.normalize('NFKD').replace(/\p{M}/gu, '').replace(PLAIN_RE, (c) => PLAIN[c]);
  const specialIn = (w) => marks(w) !== flatten(marks(w));
  const wordsOf = (s) => marks(s).replace(/[‘’]/g, "'").split(/[^\p{L}\p{N}\p{M}]+/u).filter(Boolean);
  function accentFaults(lines, got) {
    const pool = {};
    // (a dotless ı or İ, on either side, is the plain i / I: the product paints Kadıköy as Kadiköy, and a reader who knows Turkish writes it back with the dotless i. That is the reader autocorrecting,
    //  not an accent drawn on the sign. 0.3.2: on the Istanbul posters, whose other lettering is now the original's, the reader did so on all three replays and a good picture was refused)
    (got || []).forEach((g) => wordsOf(dots(g)).forEach((w) => { (pool[flatten(w)] = pool[flatten(w)] || new Set()).add(marks(w)); }));
    const out = [], seen = new Set();
    (lines || []).forEach((e) => {
      wordsOf(dots(e.t)).forEach((w) => {
        if (!specialIn(w) || seen.has(w)) return;
        seen.add(w);
        const cands = pool[flatten(w)];
        if (!cands || cands.has(w)) return; // not read at all (the words rule says so), or read exactly as given
        const marked = Array.from(cands).filter((c) => specialIn(c));
        if (marked.length) out.push({ want: w, got: marked[0] }); // read with another accent or letter
      });
    });
    return out;
  }

  /* MARKS, 0.3.2. The blind read-back autocorrects ("gamé" is read "game", "Kadikőy" is read "Kadiköy"), so a stray accent on a painted word is never seen by it. Each painted line is therefore
     cropped out of the composite, enlarged, and Haiku is asked to copy it exactly as drawn, mark for mark, without being told what it should say (the worker's copyLines). This judges what it
     copied against the English the line should say: an expected word whose copy is the same word with other marks, where the copy carries a mark or special letter, is a fault ("game" drawn
     "gamé", "Kadiköy" drawn "Kadikőy"). A copy with the marks left off ("Kadikoy" for "Kadiköy") is not: the reader cannot always see them, and a missing mark is not a stray one. A word the copy has
     in the very spelling asked for passes whatever else is in the crop. copies: one string (or null: not read) per line. Returns [{ want, got, line }] like accentFaults. */
  const dots = (s) => String(s).replace(/ı/g, 'i').replace(/İ/g, 'I'); // (the dotless i is painted as a plain i, and a reader who knows Turkish writes it back: not a stray mark)
  function markFaults(lines, copies) {
    const out = [], seen = new Set();
    (lines || []).forEach((e, i) => {
      const c = copies && copies[i];
      if (typeof c !== 'string' || !c) return;
      const pool = {};
      wordsOf(dots(c)).forEach((w) => { (pool[flatten(w)] = pool[flatten(w)] || new Set()).add(w); });
      wordsOf(dots(e.t)).forEach((w) => {
        const cands = pool[flatten(w)];
        if (!cands || cands.has(w)) return;
        const marked = Array.from(cands).filter((x) => specialIn(x));
        if (!marked.length) return;
        const key = w + '>' + marked[0];
        if (seen.has(key)) return;
        seen.add(key);
        out.push({ want: w, got: marked[0], line: i });
      });
    });
    return out;
  }

  /* where to cut a painted line out of the picture for the copy, and how much to enlarge it: the corners' bounding box (the box for a line from 0.3.0) with 0.3 of the line's thickness on both ends
     and 0.45 above and below (an accent sits above the letter), at least 220 px thick on the copy (at most 5 times, the long side at most 1400). The picture is w x h. Returns { x, y, w, h, k, ow, oh } (the
     rectangle in the picture's pixels, the enlargement, the copy's size) or null for a line with no geometry. The numbers are the experiment's (BUILD-NOTES). */
  const MARKS = { PAD_ALONG: 0.3, PAD_ACROSS: 0.45, THICK: 220, K_MAX: 5, LONG_MAX: 1400, LINES_MAX: 14 };
  function markCrop(e, w, h) {
    const f = lineFrame(e);
    if (!f) return null;
    const xs = f.p.map((a) => a[0]), ys = f.p.map((a) => a[1]);
    const th = Math.max(8, Math.min(f.lu, f.lv));
    const x0 = clamp(Math.floor(Math.min.apply(null, xs) - MARKS.PAD_ALONG * th), 0, w - 1), x1 = clamp(Math.ceil(Math.max.apply(null, xs) + MARKS.PAD_ALONG * th), x0 + 1, w);
    const y0 = clamp(Math.floor(Math.min.apply(null, ys) - MARKS.PAD_ACROSS * th), 0, h - 1), y1 = clamp(Math.ceil(Math.max.apply(null, ys) + MARKS.PAD_ACROSS * th), y0 + 1, h);
    let k = Math.min(MARKS.K_MAX, Math.max(1, MARKS.THICK / th));
    if (Math.max(x1 - x0, y1 - y0) * k > MARKS.LONG_MAX) k = MARKS.LONG_MAX / Math.max(x1 - x0, y1 - y0);
    k = Math.max(k, 0.01);
    return { x: x0, y: y0, w: x1 - x0, h: y1 - y0, k: k, ow: Math.max(1, Math.round((x1 - x0) * k)), oh: Math.max(1, Math.round((y1 - y0) * k)) };
  }

  /* The check on what was read back from the picture that will be SHOWN (the composite: the original, with the image model's lettering let in where the painted lines are).
     got: strings (null: the read-back could not be parsed). baselineTexts: the English / Latin text that was already on the ORIGINAL (read back the same way): expected to be
     there, so neither missing nor new. Rules: (1) every painted line is read back (exact, or found across neighbouring pieces); (2) every digit run of 3+ on the original is
     still there and no new one has appeared; (3) no read piece of 6+ letters that resembles neither a painted line nor anything on the original (short fragments of blurred
     background text are read differently each time); (4) GONE: the old words of the painted lines are not there any more (Latin originals); (5) ACCENTS: a word whose
     English carries an accent keeps it, unless the reader cannot tell. What was NOT painted needs no rule of its own any more: outside the painted lines' region the
     picture is the original's own pixels. */
  function evaluate(lines, got, baselineTexts, copies) {
    // (a piece that is, or is part of, a line that was asked for is never taken for the watermark: a sign that says "Since 1923" or "Google Store")
    const wanted = lines.map((e) => normalise(e.t)).filter(Boolean);
    const isWatermark = (s) => { const n = normalise(s); return watermark(s) && !(n && !/[©]|\(c\)/i.test(String(s)) && wanted.some((w) => (' ' + w + ' ').indexOf(' ' + n + ' ') >= 0)); };
    const base = (baselineTexts || []).filter((s) => !isWatermark(s));
    if (got) got = got.filter((s) => !isWatermark(s));
    if (!got) return { ok: false, wordsOk: false, digitsOk: false, noExtra: false, goneOk: false, accentsOk: false, per: [], got: [], extra: [], missingDigits: [], newDigits: [], stayed: [], accents: [] };
    const per = compare(lines, got);
    const wordsOk = per.every((p) => p.status !== 'none');
    const digitRuns = (arr) => (arr.join(' ').match(/\d{3,}/g) || []);
    const wantDigits = digitRuns(base.concat(lines.map((e) => e.t)));
    const gotDigits = digitRuns(got);
    const missingDigits = wantDigits.filter((d) => gotDigits.indexOf(d) < 0);
    const newDigits = gotDigits.filter((d) => wantDigits.indexOf(d) < 0);
    const digitsOk = missingDigits.length === 0 && newDigits.length === 0;
    const known = lines.map((e) => normalise(e.t)).concat(base.map(normalise)).filter(Boolean);
    const extra = got.filter((g) => {
      const n = normalise(g);
      if (n.replace(/ /g, '').length < 6) return false;
      return !known.some((k) => k.indexOf(n) >= 0 || n.indexOf(k) >= 0 || sim(k, n) >= 0.55);
    });
    const noExtra = extra.length === 0;
    const stayed = latinMode(lines) ? oldLeft(lines, got, base) : [];
    const accents = accentFaults(lines, got).concat(copies ? markFaults(lines, copies) : []);
    const goneOk = stayed.length === 0, accentsOk = accents.length === 0;
    return { ok: wordsOk && digitsOk && noExtra && goneOk && accentsOk, wordsOk: wordsOk, digitsOk: digitsOk, noExtra: noExtra, goneOk: goneOk, accentsOk: accentsOk, per: per, got: got, extra: extra, missingDigits: missingDigits, newDigits: newDigits, stayed: stayed, accents: accents };
  }

  /* why a check failed, in plain words (shown in the card, and told to the image model on the retry) */
  function explain(ev, lines) {
    const out = [];
    if (!ev.got || (!ev.got.length && !ev.per.length)) { out.push('the result could not be read back'); return out; }
    ev.per.forEach((p) => {
      if (p.status !== 'none') return;
      const want = normalise(p.want);
      let best = null, bs = 0;
      (ev.got || []).forEach((g) => { const s = sim(want, normalise(g)); if (s > bs) { bs = s; best = g; } });
      out.push(best && bs >= 0.4 ? 'should say "' + p.want + '", reads "' + best + '"' : 'could not find "' + p.want + '" in the result');
    });
    if (ev.missingDigits.length) out.push('digits lost: ' + ev.missingDigits.join(', '));
    if (ev.newDigits.length) out.push('digits that were not there: ' + ev.newDigits.join(', '));
    ev.extra.forEach((x) => out.push('text that was not asked for: "' + x + '"'));
    (ev.stayed || []).forEach((x) => out.push('the old writing "' + x + '" is still there'));
    (ev.accents || []).forEach((x) => out.push('the accents are wrong: should say "' + x.want + '", reads "' + x.got + '"'));
    return out;
  }

  /* ---------------------------------------------------------------- what is let in: the region and the composite (v0.3.1) */
  /* ONLY THE LETTERING is taken from the image model. The picture that is shown is the ORIGINAL with the image model's picture let in only where the painted lines are: each
     line's four corners (its box, for a note made by 0.3.0) grown by a share of the line's height, more along the reading direction (English is often longer), the union of
     those, with a soft edge. Everywhere else the picture is the original's own pixels, so a price tag, a web address or the lettering on a door beside the sign cannot be
     changed by the image model, by construction. The check reads the composite (what will be shown), not the model's picture. */
  const REGION = {
    ALONG: 0.6, // grown by this share of the line's height at each end of the reading direction ...
    LONGER: 0.65, // ... and, when the English is longer than the old writing, by this share of how much longer it is (about 1.3 x half of the extra length) at each end
    LONGER_MAX: 1.5, // (but by no more than this many line lengths at each end)
    ACROSS: 0.4, // and by this one above and below
    SOFT: 0.3, // the soft edge: this share of the line's height (the mask falls from 1 to 0 across it, centred on the grown outline)
    R_MAX: 24, // px: the blur radius never grows past this (a very tall line would otherwise give a very wide ramp)
    WIDEN: 3, // a WIDER region (all the growth times this) is tried once, and only when the first region cut the image model's lettering: see the worker
  };

  /* How much wider the English is than the old writing, as a number of at least 1 (an estimate: a character is as wide as its script's letters usually are; the image model
     can also make its letters smaller). "GHORI WALA" painted as "horse-carriage owner" comes out at about 1.9: the line needs room along its reading direction. */
  const WIDE = /[\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}\p{Script=Hangul}]/u;
  function widthOf(s) {
    let w = 0;
    for (const ch of String(s || '')) w += /\s/.test(ch) ? 0.28 : WIDE.test(ch) ? 1 : /[\p{P}\p{S}]/u.test(ch) ? 0.3 : 0.55;
    return w;
  }
  const longer = (o, t) => (widthOf(o) > 0 ? Math.max(1, widthOf(t) / widthOf(o)) : 1);

  /* a line as a frame: its four corners p (clockwise from the top left of the reading direction), the unit vectors along the top edge (u) and down the end edges (v), and the
     lengths lu (along the top) and lv (across). A line with no corners and no box has no frame. */
  function lineFrame(e) {
    let p;
    const q = quadOf(e);
    if (q) p = [[q[0], q[1]], [q[2], q[3]], [q[4], q[5]], [q[6], q[7]]];
    else if (e && Array.isArray(e.b) && e.b.length === 4 && e.b.every(Number.isFinite)) p = [[e.b[0], e.b[1]], [e.b[2], e.b[1]], [e.b[2], e.b[3]], [e.b[0], e.b[3]]];
    else return null;
    const sub = (a, b) => [a[0] - b[0], a[1] - b[1]];
    const len = (a) => Math.hypot(a[0], a[1]);
    const top = sub(p[1], p[0]), bot = sub(p[2], p[3]), lft = sub(p[3], p[0]), rgt = sub(p[2], p[1]);
    const unit = (a, b) => { const x = a[0] + b[0], y = a[1] + b[1], n = Math.hypot(x, y) || 1; return [x / n, y / n]; };
    return { p: p, u: unit(top, bot), v: unit(lft, rgt), lu: (len(top) + len(bot)) / 2, lv: (len(lft) + len(rgt)) / 2 };
  }

  /* the grown outline of a line: four points. grow: { along, across } shares of the line's thickness (its shorter side: a vertical line of writing is thin the other way);
     more: how many times wider the English is than the old writing (1: no wider), which adds room along the reading direction. The outline is where the soft edge is
     half way (the mask is 0.5 there); the soft edge reaches half its width beyond it */
  function growLine(f, grow, more, mul) {
    mul = mul || 1;
    const th = Math.min(f.lu, f.lv), len = Math.max(f.lu, f.lv);
    const readU = f.lu >= f.lv;
    const extra = more > 1 ? Math.min(REGION.LONGER_MAX * len, REGION.LONGER * (more - 1) * len) : 0;
    const ga = (grow.along * th + extra) * mul, gc = grow.across * th * mul;
    const gu = readU ? ga : gc, gv = readU ? gc : ga;
    const at = (pt, su, sv) => [pt[0] + su * gu * f.u[0] + sv * gv * f.v[0], pt[1] + su * gu * f.u[1] + sv * gv * f.v[1]];
    return [at(f.p[0], -1, -1), at(f.p[1], 1, -1), at(f.p[2], 1, 1), at(f.p[3], -1, 1)];
  }

  /* fill a convex-ish polygon (points [x, y]) into a w x h mask of 0 / 1 (pixel centres inside) */
  function fillPoly(mask, w, h, pts) {
    let y0 = Infinity, y1 = -Infinity;
    pts.forEach((q) => { y0 = Math.min(y0, q[1]); y1 = Math.max(y1, q[1]); });
    for (let y = Math.max(0, Math.ceil(y0 - 0.5)); y <= Math.min(h - 1, Math.floor(y1 - 0.5)); y++) {
      const yc = y + 0.5;
      let xa = Infinity, xb = -Infinity;
      for (let k = 0; k < pts.length; k++) {
        const a = pts[k], b = pts[(k + 1) % pts.length];
        if ((a[1] <= yc) === (b[1] <= yc)) continue;
        const x = a[0] + ((yc - a[1]) * (b[0] - a[0])) / (b[1] - a[1]);
        if (x < xa) xa = x;
        if (x > xb) xb = x;
      }
      if (xa > xb) continue;
      const from = Math.max(0, Math.ceil(xa - 0.5)), to = Math.min(w - 1, Math.floor(xb - 0.5));
      if (to >= from) mask.fill(1, y * w + from, y * w + to + 1);
    }
  }

  /* one box-blur pass over integer counts (window 2r+1, zero outside the picture), running sums: the cost does not depend on r */
  function boxPass(src, dst, w, h, r, horizontal) {
    const n = horizontal ? w : h, lines = horizontal ? h : w, step = horizontal ? 1 : w, lstep = horizontal ? w : 1;
    for (let l = 0; l < lines; l++) {
      const base = l * lstep;
      let sum = 0;
      for (let i = 0; i < Math.min(n, r); i++) sum += src[base + i * step];
      for (let i = 0; i < n; i++) {
        if (i + r < n) sum += src[base + (i + r) * step];
        if (i - r - 1 >= 0) sum -= src[base + (i - r - 1) * step];
        dst[base + i * step] = sum;
      }
    }
  }

  /* The mask of what the image model may change: { data: Float32Array (w * h, 0 to 1), r (the blur radius), covered (the share of the picture that is let in at all) }, or
     null when no line has corners or a box. lines: [{ q | b, o, t }] in the pixels of the w x h picture (o and t, the old writing and the English, say how much room there
     should be along the line). The outline of every painted line is grown (REGION), the outlines are united, and the edge is made soft: two box blurs of radius r (the ramp's
     quarter) in each direction (opts.mul: everything grown by this factor, the soft edge too: the wider region), so the mask is 0.5 on the grown outline, falls to exactly 0 two radii outside it and is 1 two radii inside it. Integer counts are blurred, so
     that the mask is EXACTLY 0 outside that reach and nothing there can ever come from the image model. */
  function regionMask(w, h, lines, opts) {
    opts = opts || {};
    const grow = { along: opts.along == null ? REGION.ALONG : opts.along, across: opts.across == null ? REGION.ACROSS : opts.across };
    const mul = opts.mul || 1;
    const soft = (opts.soft == null ? REGION.SOFT : opts.soft) * mul;
    const frames = (lines || []).map((e) => { const f = lineFrame(e); if (f) f.more = opts.noLonger ? 1 : longer(e.o, e.t); return f; }).filter(Boolean);
    if (!frames.length) return null;
    const ths = frames.map((f) => Math.min(f.lu, f.lv)).sort((a, b) => a - b);
    const ramp = Math.max(0, soft * ths[Math.floor(ths.length / 2)]); // the ramp's width, from the median line
    const r = Math.min(REGION.R_MAX, Math.max(ramp >= 2 ? 1 : 0, Math.round(ramp / 4)));
    const hard = new Uint8Array(w * h);
    frames.forEach((f) => fillPoly(hard, w, h, growLine(f, grow, f.more, mul)));
    const data = new Float32Array(w * h);
    let covered = 0;
    if (r === 0) { for (let i = 0; i < w * h; i++) { data[i] = hard[i]; covered += hard[i]; } return { data: data, r: 0, covered: covered / (w * h) }; }
    const a = new Int32Array(w * h), b = new Int32Array(w * h);
    for (let i = 0; i < w * h; i++) a[i] = hard[i];
    boxPass(a, b, w, h, r, true);
    boxPass(b, a, w, h, r, true);
    boxPass(a, b, w, h, r, false);
    boxPass(b, a, w, h, r, false);
    const norm = Math.pow(2 * r + 1, 4);
    for (let i = 0; i < w * h; i++) { const v = a[i] / norm; data[i] = v; if (v > 0.5) covered++; }
    return { data: data, r: r, covered: covered / (w * h) };
  }

  /* The picture that is shown. orig, res: { w, h, data: RGBA bytes } at the same size; mask: regionMask().data. Where the mask is 0 the pixel is the original's exactly; where
     it is 1 it is the image model's; between, a blend. Returns the RGBA bytes (opaque). */
  function composite(orig, res, mask) {
    const n = orig.w * orig.h;
    const out = new Uint8ClampedArray(n * 4);
    const a = orig.data, b = res.data;
    for (let i = 0; i < n; i++) {
      const m = mask[i], o = i * 4;
      if (m <= 0) { out[o] = a[o]; out[o + 1] = a[o + 1]; out[o + 2] = a[o + 2]; }
      else if (m >= 1) { out[o] = b[o]; out[o + 1] = b[o + 1]; out[o + 2] = b[o + 2]; }
      else { out[o] = a[o] + (b[o] - a[o]) * m; out[o + 1] = a[o + 1] + (b[o + 1] - a[o + 1]) * m; out[o + 2] = a[o + 2] + (b[o + 2] - a[o + 2]) * m; }
      out[o + 3] = 255;
    }
    return out;
  }

  /* ---------------------------------------------------------------- what is let in, v0.3.1 fix round: the lettering, followed by what changed
     The first version let in the grown outlines of the painted lines (regionMask above). Judged blind, that left three kinds of fault: the tail of an old word just past the
     end of an outline ("wall stickers" + the "nu" of "stěnu"), a pale or coloured patch where the image model's tone differs from the street's, and, on a dense sign, an outline
     that covered a neighbour (the emblem beside the lettering, the door's writing) and let the model redraw it. So the model's picture is now taken in three steps:
       1. TONE. The model's picture is matched to the original's tone (a smooth, slowly changing offset worked out from the pixels round the painted lines where the two pictures
          agree) so that, where there is no lettering, the two pictures are the same and no patch edge can show.
       2. SEEDS. Each painted line's four corners, grown a little (SEED), are let in whatever they hold.
       3. WHAT CHANGED. Round the seeds, within REACH, the pixels where the (tone-matched) picture still differs from the original by more than CHANGE grey levels are the old
          lettering that was taken away and the new that was put there. Only the changes that join a seed (through changes that join, closed over a letter's gaps) are let in, with a
          small margin. A change that does not join one (the emblem, a door's writing, a phone number, whatever the model redrew by itself) stays the original's pixels.
     Outside REACH (plus the soft edge, two blur radii) every pixel is the original's, exactly: nothing there can change, whatever the image model drew. */
  const LETTER = {
    SEED: { along: 0.4, across: 0.3 }, // the corners, grown by this share of the line's thickness (along the reading direction, across it)
    REACH: { along: 2.4, across: 0.5 }, // how far a change is followed from a seed
    REACH_WIDE: { along: 3.0, across: 1.2 }, // the same for the second try, when the corners were off by a line (the worker's WIDEN) ...
    SEED_WIDE: { along: 0.7, across: 0.45 }, // ... with larger seeds ...
    CLOSE_WIDE: 0.3, // ... and gaps of this share of the thickness closed (lettering that landed a little way from its corners is then joined to them)
    CHANGE: 28, // grey levels (after the tone match, 3 x 3 mean) that make a pixel "changed"
    CLOSE: 0.12, // changes this share of the thickness apart are one letter
    PAD: 0.18, // the let-in changes are grown by this share of the thickness
    TONE_SIGMA: 1.5, // the tone offset varies over this many line thicknesses
    TONE_RING: 4, // and is worked out from the pixels up to this many line thicknesses outside the reach
    TONE_AGREE: 28, // grey levels: a pixel where the two pictures differ more is not used for the tone (it is lettering or something the model redrew)
  };

  /* a running-sum box blur of a Float32Array (window 2r + 1, zero outside) in place of a Gaussian: three passes, both directions */
  function blurF32(a, w, h, r) {
    if (r < 1) return a;
    const t = new Float32Array(a.length);
    const pass = (src, dst, n, lines, step, lstep) => {
      const inv = 1 / (2 * r + 1);
      for (let l = 0; l < lines; l++) {
        const base = l * lstep;
        let sum = 0;
        for (let i = 0; i < Math.min(n, r); i++) sum += src[base + i * step];
        for (let i = 0; i < n; i++) {
          if (i + r < n) sum += src[base + (i + r) * step];
          if (i - r - 1 >= 0) sum -= src[base + (i - r - 1) * step];
          dst[base + i * step] = sum * inv;
        }
      }
    };
    for (let k = 0; k < 3; k++) { pass(a, t, w, h, 1, w); pass(t, a, h, w, w, 1); }
    return a;
  }

  /* the share of a binary mask within a square window of radius r, as 0 / 1 (a dilation by a square; running sums: the cost does not depend on r) */
  function dilate(mask, w, h, r) {
    if (r < 1) return mask.slice();
    const a = new Int32Array(w * h), b = new Int32Array(w * h);
    for (let i = 0; i < w * h; i++) a[i] = mask[i];
    boxPass(a, b, w, h, r, true);
    boxPass(b, a, w, h, r, false);
    const out = new Uint8Array(w * h);
    for (let i = 0; i < w * h; i++) out[i] = a[i] > 0 ? 1 : 0;
    return out;
  }

  const lum = (d, p) => 0.299 * d[p] + 0.587 * d[p + 1] + 0.114 * d[p + 2];

  /* The union of the painted lines' outlines grown by grow ({ along, across }, shares of the line's thickness; the room for longer English comes on top, as for regionMask).
     frames: lineFrame()s with .more. Returns a w * h Uint8Array. */
  function growMask(w, h, frames, grow, moreScale) {
    const m = new Uint8Array(w * h);
    frames.forEach((f) => fillPoly(m, w, h, growLine(f, grow, 1 + (f.more - 1) * (moreScale || 1), 1))); // (moreScale: the room for longer English, times this)
    return m;
  }

  /* The tone offset: where the two pictures agree up to a tone (outside `inside`, within TONE_RING thicknesses of it, the grey difference under TONE_AGREE), the difference
     original - model, smoothed over TONE_SIGMA thicknesses (normalised convolution: where no such pixel is near, there is no offset). Returns { f: Float32Array (w * h * 3),
     mean: the mean absolute offset over `inside` }. res.data is not changed. */
  function toneField(orig, res, inside, th) {
    const w = orig.w, h = orig.h, n = w * h;
    const near = dilate(inside, w, h, Math.max(2, Math.round(LETTER.TONE_RING * th)));
    const ch = [new Float32Array(n), new Float32Array(n), new Float32Array(n)], wt = new Float32Array(n);
    const a = orig.data, b = res.data;
    for (let i = 0; i < n; i++) {
      if (inside[i] || !near[i]) continue;
      const p = i * 4;
      if (Math.abs(lum(a, p) - lum(b, p)) >= LETTER.TONE_AGREE) continue;
      wt[i] = 1;
      ch[0][i] = a[p] - b[p]; ch[1][i] = a[p + 1] - b[p + 1]; ch[2][i] = a[p + 2] - b[p + 2];
    }
    const r = Math.max(2, Math.round(LETTER.TONE_SIGMA * th));
    blurF32(wt, w, h, r);
    const f = new Float32Array(n * 3);
    let sum = 0, cnt = 0;
    for (let k = 0; k < 3; k++) blurF32(ch[k], w, h, r);
    for (let i = 0; i < n; i++) {
      const d = wt[i];
      const conf = Math.min(1, d / 0.05); // (where hardly any pixel is near, hardly any offset)
      if (d < 1e-4) continue;
      for (let k = 0; k < 3; k++) f[i * 3 + k] = (ch[k][i] / d) * conf;
      if (inside[i]) { sum += (Math.abs(f[i * 3]) + Math.abs(f[i * 3 + 1]) + Math.abs(f[i * 3 + 2])) / 3; cnt++; }
    }
    return { f: f, mean: cnt ? sum / cnt : 0 };
  }

  /* The lettering to let in, and the model's picture matched to the original's tone. orig, res: { w, h, data: RGBA } at the same size; lines: [{ q | b, o, t }] in the pixels of
     that size; opts.wide: follow changes further (REACH_WIDE). Returns null when no line has corners or a box, else
     { data: Float32Array (w * h, 0 to 1: the share of the picture that is the model's), r, covered (share of the picture let in), res: Uint8ClampedArray (the model's picture, tone
     matched, RGBA), tone: the mean offset over the seeds, grown: the share of the picture let in beyond the seeds, reach: the hard outline of how far a change is followed }.
     The mask is 0.5 on the edge of what is let in, 1 two radii inside and EXACTLY 0 two radii outside the reach. */
  function lettering(orig, res, lines, opts) {
    opts = opts || {};
    const w = orig.w, h = orig.h, n = w * h;
    const frames = (lines || []).map((e) => { const f = lineFrame(e); if (f) f.more = longer(e.o, e.t); return f; }).filter(Boolean);
    if (!frames.length) return null;
    const ths = frames.map((f) => Math.min(f.lu, f.lv)).sort((x, y) => x - y);
    const th = Math.max(2, ths[Math.floor(ths.length / 2)]);
    let keepM = opts.keep && opts.keep.length ? keepMask(w, h, opts.keep) : null; // (0.3.2) writing nobody asked to change: its pixels stay the original's
    if (keepM) {
      // ... except inside the painted lines' OWN corners: where a kept piece's corners overlap a painted line's (the model's corners are loose by instruction: a phone number just under a line of
      // lettering reaches into it) the line's own corners win, so the new English is never cut by a neighbour. Two corner boxes that overlap by half are a painted line already (keptPieces).
      // and the line's own BAND along its reading direction, where the English is longer than the old writing and needs room (the Da Nang "Enter alley, 10m": a phone number's loose corners
      // reached into the end of the band and cut the "m")
      const own = growMask(w, h, frames, { along: (opts.wide ? LETTER.SEED_WIDE : LETTER.SEED).along, across: 0 }, opts.wide ? 2 : 1);
      frames.forEach((f) => fillPoly(own, w, h, f.p));
      let cov = 0;
      for (let i = 0; i < n; i++) { if (own[i]) { keepM.data[i] = 0; keepM.hard[i] = 0; } cov += keepM.hard[i]; }
      keepM.area = cov / n;
    }
    const seed = growMask(w, h, frames, opts.wide ? LETTER.SEED_WIDE : LETTER.SEED);
    const reach = growMask(w, h, frames, opts.wide ? LETTER.REACH_WIDE : LETTER.REACH, opts.wide ? 2 : 1);
    for (let i = 0; i < n; i++) if (seed[i]) reach[i] = 1;
    // 1. TONE (the offset is worked out outside the reach, so lettering and anything the model redrew beside it does not pull on it)
    const tone = toneField(orig, res, reach, th);
    const out = new Uint8ClampedArray(n * 4);
    const a = orig.data, b = res.data, f = tone.f;
    for (let i = 0; i < n; i++) {
      const p = i * 4;
      out[p] = b[p] + f[i * 3]; out[p + 1] = b[p + 1] + f[i * 3 + 1]; out[p + 2] = b[p + 2] + f[i * 3 + 2]; out[p + 3] = 255;
    }
    // 3. WHAT CHANGED, within the reach (a 3 x 3 mean of the grey difference, so a single noisy pixel is not a change)
    const dg = new Float32Array(n);
    for (let i = 0; i < n; i++) if (reach[i]) dg[i] = Math.abs(lum(a, i * 4) - lum(out, i * 4));
    blurF32(dg, w, h, 1);
    const ch = new Uint8Array(n);
    for (let i = 0; i < n; i++) if (reach[i] && dg[i] > LETTER.CHANGE) ch[i] = 1;
    const closed = dilate(ch, w, h, Math.max(1, Math.round((opts.wide ? LETTER.CLOSE_WIDE : LETTER.CLOSE) * th)));
    if (keepM) for (let i = 0; i < n; i++) if (keepM.hard[i]) closed[i] = 0; // (the changes are not followed through a kept piece: what lies beyond it is not let in by way of it)
    // the changes that join a seed: a flood fill from every seed pixel through the closed changes (4-neighbours), within the reach
    const got = new Uint8Array(n);
    const stack = new Int32Array(n);
    let sp = 0;
    for (let i = 0; i < n; i++) if (seed[i]) { got[i] = 1; stack[sp++] = i; }
    while (sp) {
      const i = stack[--sp], x = i % w;
      let j = i - 1;
      if (x > 0 && !got[j] && reach[j] && closed[j]) { got[j] = 1; stack[sp++] = j; }
      j = i + 1;
      if (x < w - 1 && !got[j] && reach[j] && closed[j]) { got[j] = 1; stack[sp++] = j; }
      j = i - w;
      if (i >= w && !got[j] && reach[j] && closed[j]) { got[j] = 1; stack[sp++] = j; }
      j = i + w;
      if (i < n - w && !got[j] && reach[j] && closed[j]) { got[j] = 1; stack[sp++] = j; }
    }
    const padded = dilate(got, w, h, Math.max(1, Math.round(LETTER.PAD * th)));
    const hard = new Uint8Array(n);
    let grown = 0;
    for (let i = 0; i < n; i++) { if ((padded[i] && reach[i]) || seed[i]) hard[i] = 1; if (hard[i] && !seed[i]) grown++; }
    // the soft edge, as regionMask makes it (two box blurs of integer counts: exactly 0 two radii outside the hard outline)
    const ramp = REGION.SOFT * th;
    const r = Math.min(REGION.R_MAX, Math.max(ramp >= 2 ? 1 : 0, Math.round(ramp / 4)));
    const data = new Float32Array(n);
    let covered = 0;
    if (r === 0) { for (let i = 0; i < n; i++) { data[i] = hard[i]; covered += hard[i]; } }
    else {
      const x1 = new Int32Array(n), x2 = new Int32Array(n);
      for (let i = 0; i < n; i++) x1[i] = hard[i];
      boxPass(x1, x2, w, h, r, true); boxPass(x2, x1, w, h, r, true); boxPass(x1, x2, w, h, r, false); boxPass(x2, x1, w, h, r, false);
      const norm = Math.pow(2 * r + 1, 4);
      for (let i = 0; i < n; i++) { const v = x1[i] / norm; data[i] = v; if (v > 0.5) covered++; }
    }
    // the kept pieces are cut out of what is let in (a soft edge: the mask of the kept piece is 1 on the piece and its grown margin, 0 beyond the ramp)
    let keptCut = 0;
    if (keepM) {
      let before = 0;
      covered = 0;
      for (let i = 0; i < n; i++) {
        const v0 = data[i];
        if (v0 > 0.5) before++;
        const v = v0 * (1 - keepM.data[i]);
        data[i] = v;
        if (v > 0.5) covered++;
      }
      keptCut = before ? (before - covered) / before : 0;
    }
    return { data: data, r: r, covered: covered / n, res: out, tone: tone.mean, grown: grown / n, reach: reach, keptCut: keptCut, keptArea: keepM ? keepM.area : 0 };
  }

  /* ---------------------------------------------------------------- writing nobody asked to change (0.3.2)
     The let-in region follows the changes that join the painted lines, so writing that sits BESIDE a painted line was let in with it (VACCINATION on the Lyon window cut to
     "VACCINA", the vertical PRODEJ SKLA turned into glyphs, a Hindi fragment erased). The product does not know where that writing is (the answer's LINES hold only the lines to
     translate), so while the image model draws, Haiku is asked for every OTHER piece of writing in the same picture, with four corners each (the worker's protect()). Here: reading that
     answer, the safety net (a piece that is really a painted line is dropped), and the mask that cuts the kept pieces out of the let-in region. */
  const KEEP = {
    GROW: 0.1, // a kept piece is grown by this share of its thickness (its shorter side) all round
    SOFT: 0.04, // the soft edge's blur radius, as a share of the median thickness (at least 1 px, at most 4); the grown margin is never less than twice the radius
    OVERLAP: 0.5, // dropped as a painted line: this share of the piece's area lies inside the painted lines' own corners
    MIN_TEXT: 3, // letters a folded text needs before "contained in" counts (a shorter one is judged by the area alone)
    HUGE: 0.4, // dropped: a piece covering this share of the whole picture is a bad answer, not a line of writing
    MAX: 60, // at most this many pieces are used
    OUTSIDE: 0.2, // a piece whose corners lie further outside the picture than this share of its size is a bad answer
  };

  /* a quadrilateral from the model, as eight numbers, made safe to use: finite, inside the picture (clamped; far outside is refused), clockwise from the top left (the order is turned
     round when it came the other way) and convex; anything else becomes its bounding box. Returns the eight numbers or null. */
  function keepQuad(q, w, h) {
    if (!Array.isArray(q) || q.length !== 8 || !q.every((v) => typeof v === 'number' && Number.isFinite(v))) return null;
    const xs = [q[0], q[2], q[4], q[6]], ys = [q[1], q[3], q[5], q[7]];
    const x0 = Math.min.apply(null, xs), x1 = Math.max.apply(null, xs), y0 = Math.min.apply(null, ys), y1 = Math.max.apply(null, ys);
    const sw = Math.max(1, x1 - x0), sh = Math.max(1, y1 - y0);
    if (x0 < -KEEP.OUTSIDE * sw || y0 < -KEEP.OUTSIDE * sh || x1 > w + KEEP.OUTSIDE * sw || y1 > h + KEEP.OUTSIDE * sh) return null;
    let p = [[q[0], q[1]], [q[2], q[3]], [q[4], q[5]], [q[6], q[7]]].map((a) => [clamp(a[0], 0, w), clamp(a[1], 0, h)]);
    const area2 = (a) => { let s = 0; for (let i = 0; i < 4; i++) { const b = a[i], c = a[(i + 1) % 4]; s += b[0] * c[1] - c[0] * b[1]; } return s; };
    if (area2(p) < 0) p = [p[0], p[3], p[2], p[1]];
    let first = 0; // the corner nearest the top left comes first (the order the answer's corners use)
    for (let i = 1; i < 4; i++) if (p[i][0] + p[i][1] < p[first][0] + p[first][1] - 1e-9) first = i;
    p = p.slice(first).concat(p.slice(0, first));
    const cross = (a, b, c) => (b[0] - a[0]) * (c[1] - b[1]) - (b[1] - a[1]) * (c[0] - b[0]);
    let convex = true;
    for (let i = 0; i < 4; i++) if (cross(p[i], p[(i + 1) % 4], p[(i + 2) % 4]) < -1e-6) convex = false;
    if (!convex || Math.abs(area2(p)) < 8) {
      const bx0 = clamp(x0, 0, w), bx1 = clamp(x1, 0, w), by0 = clamp(y0, 0, h), by1 = clamp(y1, 0, h);
      if (bx1 - bx0 < 2 || by1 - by0 < 2) return null;
      return [bx0, by0, bx1, by0, bx1, by1, bx0, by1];
    }
    return [p[0][0], p[0][1], p[1][0], p[1][1], p[2][0], p[2][1], p[3][0], p[3][1]];
  }

  /* what Haiku answered to "every other piece of writing": the first JSON array in the reply, each entry { t: the text, q: eight numbers }. Returns { pieces: [{ t, q }], bad: n } (bad: entries that
     could not be used) or null when no array could be read (the call failed in effect: nothing is protected). w, h: the size of the picture the corners are in. */
  function parseKept(text, w, h) {
    const s = String(text || '');
    const a = s.indexOf('['), z = s.lastIndexOf(']');
    if (a < 0 || z <= a) return null;
    let v;
    try { v = JSON.parse(s.slice(a, z + 1)); } catch (e) { return null; }
    if (!Array.isArray(v)) return null;
    const pieces = [];
    let bad = 0;
    v.forEach((e) => {
      const q = e && typeof e === 'object' ? keepQuad(e.q || e.corners, w, h) : null;
      const t = e && typeof e === 'object' ? String(e.t == null ? (e.text == null ? '' : e.text) : e.t).trim() : '';
      if (!q) { bad++; return; }
      pieces.push({ t: t.slice(0, 120), q: q });
    });
    return { pieces: pieces.slice(0, KEEP.MAX), bad: bad };
  }

  /* the share of a polygon (points [x, y]) that lies inside another set of polygons, worked out on a grid of at most 512 px on the long side */
  function shareInside(poly, others, w, h) {
    const k = Math.min(1, 512 / Math.max(w, h));
    const gw = Math.max(1, Math.round(w * k)), gh = Math.max(1, Math.round(h * k));
    const sc = (pts) => pts.map((a) => [a[0] * k, a[1] * k]);
    const m = new Uint8Array(gw * gh);
    others.forEach((o) => fillPoly(m, gw, gh, sc(o)));
    const a = new Uint8Array(gw * gh);
    fillPoly(a, gw, gh, sc(poly));
    let n = 0, inside = 0;
    for (let i = 0; i < a.length; i++) if (a[i]) { n++; if (m[i]) inside++; }
    return n ? inside / n : 0;
  }

  /* The safety net. found: [{ t, q }] in the pixels of the w x h picture; paint: the lines being painted ({ o, q | b }) in the same pixels. A found piece that is really a painted line is dropped
     (the model has listed it although it was told not to, and cutting it out would take the new English away): its folded text (case, accents, spacing and punctuation set aside) is contained
     in, or contains, a painted line's original text (whole words; a text under MIN_TEXT letters is judged by the area alone), or half or more of its area lies inside the painted lines' own corners.
     Dropped too: a piece that covers a large part of the picture (a bad answer). Returns { kept: [{ t, q }], dropped: [{ t, why }] }. */
  function keptPieces(found, paint, w, h) {
    const polys = (paint || []).map((e) => { const q = quadOf(e); if (q) return [[q[0], q[1]], [q[2], q[3]], [q[4], q[5]], [q[6], q[7]]]; const b = e && e.b; return b && b.length === 4 && b.every(Number.isFinite) ? [[b[0], b[1]], [b[2], b[1]], [b[2], b[3]], [b[0], b[3]]] : null; }).filter(Boolean);
    const olds = (paint || []).map((e) => normalise(e.o)).filter(Boolean);
    const within = (a, b) => (' ' + b + ' ').indexOf(' ' + a + ' ') >= 0;
    const kept = [], dropped = [];
    (found || []).forEach((f) => {
      const q = quadOf(f);
      if (!q) { dropped.push({ t: f && f.t, why: 'corners' }); return; }
      const poly = [[q[0], q[1]], [q[2], q[3]], [q[4], q[5]], [q[6], q[7]]];
      const area = Math.abs(poly.reduce((s, c, i) => { const d = poly[(i + 1) % 4]; return s + c[0] * d[1] - d[0] * c[1]; }, 0)) / 2;
      if (area > KEEP.HUGE * w * h) { dropped.push({ t: f.t, why: 'huge' }); return; }
      const n = normalise(f.t);
      if (n) {
        const hit = olds.some((o) => o === n || (Math.min(o.length, n.length) >= KEEP.MIN_TEXT && (within(n, o) || within(o, n))));
        if (hit) { dropped.push({ t: f.t, why: 'text' }); return; }
      }
      if (polys.length && shareInside(poly, polys, w, h) >= KEEP.OVERLAP) { dropped.push({ t: f.t, why: 'area' }); return; }
      kept.push({ t: f.t, q: q });
    });
    return { kept: kept, dropped: dropped };
  }

  /* What becomes of the protection, given what the call to Haiku came to: kr is null when it had not answered in time (carry on without protection), { pieces: null, err } when it failed or its list
     could not be read (without), else { pieces } (through the safety net). Returns { list: [{ t, q }] (what is cut out of the let-in region: empty without protection), info } where info is what is recorded:
     { state: 'late' | 'failed' | 'none' | 'used', found, kept, dropped: [{ t, why }], texts, error }. */
  function keepDecision(kr, paint, w, h) {
    if (!kr) return { list: [], info: { state: 'late' } };
    if (!kr.pieces) return { list: [], info: { state: 'failed', error: kr.err || 'the list could not be read' } };
    const kp = keptPieces(kr.pieces, paint, w, h);
    return { list: kp.kept, info: { state: kp.kept.length ? 'used' : 'none', found: kr.pieces.length, kept: kp.kept.length, dropped: kp.dropped.slice(0, 20), texts: kp.kept.map((e) => e.t).slice(0, 12) } };
  }

  /* The mask of the kept pieces: { data: Float32Array (w * h, 1 on a piece and its grown margin, a soft edge, exactly 0 beyond), hard: Uint8Array (the grown outlines), area: their share of the picture, r }
     or null when there is no piece. Each piece is grown by KEEP.GROW of its thickness (never less than twice the soft edge's radius, so the piece itself is at 1). */
  function keepMask(w, h, pieces) {
    const frames = (pieces || []).map((e) => lineFrame(e)).filter(Boolean);
    if (!frames.length) return null;
    const ths = frames.map((f) => Math.min(f.lu, f.lv)).sort((a, b) => a - b);
    const r = clamp(Math.round(KEEP.SOFT * ths[Math.floor(ths.length / 2)]), 1, 4);
    const hard = new Uint8Array(w * h);
    frames.forEach((f) => {
      const th = Math.max(1, Math.min(f.lu, f.lv));
      const g = Math.max(KEEP.GROW * th, 2 * r) / th;
      fillPoly(hard, w, h, growLine(f, { along: g, across: g }, 1, 1));
    });
    const a = new Int32Array(w * h), b = new Int32Array(w * h);
    let cov = 0;
    for (let i = 0; i < w * h; i++) { a[i] = hard[i]; cov += hard[i]; }
    boxPass(a, b, w, h, r, true); boxPass(b, a, w, h, r, true); boxPass(a, b, w, h, r, false); boxPass(b, a, w, h, r, false);
    const norm = Math.pow(2 * r + 1, 4);
    const data = new Float32Array(w * h);
    for (let i = 0; i < w * h; i++) data[i] = a[i] / norm;
    return { data: data, hard: hard, area: cov / (w * h), r: r };
  }

  /* ---------------------------------------------------------------- planning, the pure half (patch.js and the evidence harness both call these) */
  const ROOMY = [0.30, 0.22, 0.16, 0.11, 0.07, 0.04]; // a fresh picture: the roomiest margin the screen has room for, then tighter ones (0.3.0 began at 0.16)

  /* The first look at what a note can be repainted from, before any picture is planned. L: the note's lines [{i, o, t, b, q, spill}]; cs: the size of the picture the answer was
     read from (or null); unsure: the model's note. The writing is "cut off" (refused, the model read part of it) when a line to paint is an ellipsis or a guess, ran off the picture
     the model saw (spill), or the model says so in its note. A line that merely lies close to the picture's edge is NOT cut off: a tightly dragged box does that all the time, and
     the picture that is repainted is a roomy one of its own. Returns { refuse: 'nothing' | 'cut' | 'twice' } or { paint: [...] }. */
  function planEarly(L, cs, unsure) {
    if (!(L && L.length)) return { refuse: 'nothing' };
    if (cutNote(unsure)) return { refuse: 'cut' };
    const a0 = cs ? assess(L, cs[0], cs[1], { edgeMargin: 0 }) : assess(L.map((l) => Object.assign({}, l, { b: null, q: null })), 1, 1, { edgeMargin: 0 }); // (no picture size: only the ellipsis and spill rules)
    if (a0.cut.length) return { refuse: 'cut', cut: a0.cut };
    if (!a0.paint.length) return { refuse: 'nothing' };
    if (repeated(a0.paint).length) return { refuse: 'twice' };
    return { paint: a0.paint };
  }

  /* may the stored crop be repainted as it is? Only when every line to paint lies clear of its edge (3 % of the short side): the picture the model letters should have room
     round the lines, and a fresh one has it wherever the screen does. */
  function storedClear(paint, cs) {
    const m = EDGE_MARGIN * Math.min(cs[0], cs[1]);
    return (paint || []).every((e) => e.b && e.b[0] >= m && e.b[1] >= m && e.b[2] <= cs[0] - m && e.b[3] <= cs[1] - m);
  }

  /* A fresh picture of the sign. L: the lines; shapes: parallel to L, each null or { box: [x0, y0, x1, y1], quad: [8] | null } in screen pixels; mark: the mark's own rectangle
     {x, y, w, h} (null for a point); vr: the picture's rectangle on screen; avoid: Google's own controls. The picture takes the roomiest margin the screen allows. Returns
     { mode: 'fresh', rect, lines: [{i, o, t, spill, b, cq}] (boxes and corners in the rectangle's own pixels), a } or { refuse }. */
  function planFresh(L, shapes, mark, vr, avoid) {
    // The lines are clamped to the rectangle that was dragged (0.3.2). The model read the writing from a picture that IS that rectangle, so a line cannot lie outside it: how far the
    // model's outlines ran past it is looseness, not information, and it decided whether Repaint was offered at all ("big" on one of two asks of the same box: the live case, the owner's
    // closer view, box [360, 170, 665, 595]). The four corners are kept as they are (the let-in region follows them). A line that does not meet the rectangle AT ALL is not looseness: the
    // answer put writing where the picture it read has none, so nothing is planned ('cut', "ask again": an earlier build made such a line the whole rectangle, which seeded the let-in region from the whole sign).
    const mk = mark && mark.w > 0 && mark.h > 0 ? [mark.x, mark.y, mark.x + mark.w, mark.y + mark.h] : null;
    if (mk) {
      let miss = false;
      shapes = shapes.map((s) => {
        if (!s) return s;
        const b = [Math.max(s.box[0], mk[0]), Math.max(s.box[1], mk[1]), Math.min(s.box[2], mk[2]), Math.min(s.box[3], mk[3])];
        if (!(b[2] > b[0] && b[3] > b[1])) { miss = true; return s; }
        return { box: b, quad: s.quad };
      });
      if (miss) return { refuse: 'cut' };
    }
    let u = null;
    const grow = (x0, y0, x1, y1) => {
      if (!u) u = { x0: x0, y0: y0, x1: x1, y1: y1 };
      else { u.x0 = Math.min(u.x0, x0); u.y0 = Math.min(u.y0, y0); u.x1 = Math.max(u.x1, x1); u.y1 = Math.max(u.y1, y1); }
    };
    shapes.forEach((s) => { if (s) grow(s.box[0], s.box[1], s.box[2], s.box[3]); });
    if (!u) return { refuse: 'old' };
    const asRect = (c) => ({ x: c.x0, y: c.y0, w: c.x1 - c.x0, h: c.y1 - c.y0 });
    const opts = { avoid: avoid || [], margins: ROOMY };
    // the LINES decide whether the writing runs off the screen ('edge') or is too small; the box that was dragged is more to take in (the picture is planned round it too, as in 0.3.0),
    // but it never makes the sign "run off" when it was dragged up to the screen's edge (it is kept 3 px clear of it)
    const linesOnly = planCrop(asRect(u), vr, opts);
    if (linesOnly.refuse === 'edge' || linesOnly.refuse === 'small') return { refuse: linesOnly.refuse };
    let rect = null, why = linesOnly.refuse;
    if (mark) {
      const inset = 3;
      const w = { x0: u.x0, y0: u.y0, x1: u.x1, y1: u.y1 };
      w.x0 = Math.min(w.x0, Math.max(mark.x, vr.x + inset)); w.y0 = Math.min(w.y0, Math.max(mark.y, vr.y + inset));
      w.x1 = Math.max(w.x1, Math.min(mark.x + mark.w, vr.x + vr.w - inset)); w.y1 = Math.max(w.y1, Math.min(mark.y + mark.h, vr.y + vr.h - inset));
      const withMark = planCrop(asRect(w), vr, opts);
      if (!withMark.refuse) rect = withMark;
      else why = withMark.refuse;
    }
    if (!rect && !linesOnly.refuse) rect = linesOnly;
    if (!rect) return { refuse: why };
    const lines = L.map((l, i) => {
      const s = shapes[i];
      return { i: l.i, o: l.o, t: l.t, spill: l.spill, b: s ? [s.box[0] - rect.x, s.box[1] - rect.y, s.box[2] - rect.x, s.box[3] - rect.y] : null, cq: s && s.quad ? s.quad.map((v, k) => v - (k % 2 ? rect.y : rect.x)) : null };
    });
    const a = assess(lines.map((l) => Object.assign({}, l, { q: l.cq })), rect.w, rect.h, { edgeMargin: 0.01 }); // (planCrop has seen to the margin: a sign near the picture's edge is not "cut off")
    if (a.cut.length) return { refuse: 'cut' };
    if (!a.paint.length) return { refuse: 'nothing' };
    return { mode: 'fresh', rect: rect, lines: lines, a: a };
  }

  /* ---------------------------------------------------------------- the pixel check */
  /* a, b: { w, h, ch (3 or 4), data } the original and the result at the same small size (WORK px long side). boxes: [[x0, y0, x1, y1]] in those pixels (the
     text boxes: hints, grown by GROW on every side and left out). Mean grey difference and mean colour drift over everything else, and the BLOTCH: the largest mean
     grey difference of any window (a fifth of the long side, half overlapping, at least half of it outside the text boxes): means over the whole picture let a block the
     image model painted over a wall through (a live result: a pale rectangle, +70 grey, 5 % of the picture). weak: the boxes (grown) cover nearly all of the picture, so
     there is too little left to judge by (the read-back still runs). */
  function pixelCheck(a, b, boxes) {
    const w = a.w, h = a.h;
    const mask = new Uint8Array(w * h).fill(1);
    (boxes || []).forEach((bx) => {
      const dx = (bx[2] - bx[0]) * GROW, dy = (bx[3] - bx[1]) * GROW;
      const x0 = Math.max(0, Math.floor(bx[0] - dx)), y0 = Math.max(0, Math.floor(bx[1] - dy));
      const x1 = Math.min(w, Math.ceil(bx[2] + dx)), y1 = Math.min(h, Math.ceil(bx[3] + dy));
      for (let y = y0; y < y1; y++) mask.fill(0, y * w + x0, y * w + x1);
    });
    // INSIDE the text boxes themselves (not grown): the lettering must have been repainted there, so the picture must differ there (an image model that gave the scene back unchanged)
    const inner = new Uint8Array(w * h);
    (boxes || []).forEach((bx) => {
      const x0 = Math.max(0, Math.floor(bx[0])), y0 = Math.max(0, Math.floor(bx[1])), x1 = Math.min(w, Math.ceil(bx[2])), y1 = Math.min(h, Math.ceil(bx[3]));
      for (let y = y0; y < y1; y++) inner.fill(1, y * w + x0, y * w + x1);
    });
    let ni = 0, si = 0;
    for (let i = 0; i < w * h; i++) {
      if (!inner[i]) continue;
      const pa = i * (a.ch || 4), pb = i * (b.ch || 4);
      si += Math.abs((0.299 * a.data[pa] + 0.587 * a.data[pa + 1] + 0.114 * a.data[pa + 2]) - (0.299 * b.data[pb] + 0.587 * b.data[pb + 1] + 0.114 * b.data[pb + 2]));
      ni++;
    }
    const inside = ni ? si / ni : -1; // -1: no box to look in
    let n = 0, sad = 0;
    const sa = [0, 0, 0], sb = [0, 0, 0];
    const ca = a.ch || 4, cb = b.ch || 4;
    const diff = new Float32Array(w * h); // signed grey difference (a - b), where it counts
    for (let i = 0; i < w * h; i++) {
      if (!mask[i]) continue;
      const pa = i * ca, pb = i * cb;
      const la = 0.299 * a.data[pa] + 0.587 * a.data[pa + 1] + 0.114 * a.data[pa + 2];
      const lb = 0.299 * b.data[pb] + 0.587 * b.data[pb + 1] + 0.114 * b.data[pb + 2];
      diff[i] = la - lb;
      sad += Math.abs(diff[i]);
      for (let k = 0; k < 3; k++) { sa[k] += a.data[pa + k]; sb[k] += b.data[pb + k]; }
      n++;
    }
    const inkedOk = (mad) => inside < 0 || (inside >= INSIDE_MIN && inside - mad >= INSIDE_GAIN);
    if (n < 0.06 * w * h) return { ok: inkedOk(0), weak: true, mad: 0, col: 0, blob: 0, frac: n / (w * h), inside: Math.round(inside * 10) / 10, inked: inkedOk(0) };
    const mad = sad / n;
    const col = (Math.abs(sa[0] - sb[0]) + Math.abs(sa[1] - sb[1]) + Math.abs(sa[2] - sb[2])) / 3 / n;
    const cell = Math.max(8, Math.round(Math.max(w, h) / 5)), step = Math.max(4, cell >> 1);
    let blob = 0;
    for (let cy = 0; cy < h; cy += step) {
      for (let cx = 0; cx < w; cx += step) {
        const x1 = Math.min(w, cx + cell), y1 = Math.min(h, cy + cell);
        let cn = 0, cs = 0;
        for (let y = cy; y < y1; y++) for (let x = cx; x < x1; x++) { const i = y * w + x; if (mask[i]) { cn++; cs += diff[i]; } }
        if (cn >= 0.5 * (x1 - cx) * (y1 - cy) && cn >= 0.5 * cell * cell * 0.5) blob = Math.max(blob, Math.abs(cs / cn));
      }
    }
    return { ok: mad <= MAD_MAX && col <= COL_MAX && blob <= BLOB_MAX && inkedOk(mad), inked: inkedOk(mad), weak: false, mad: Math.round(mad * 10) / 10, col: Math.round(col * 10) / 10, blob: Math.round(blob * 10) / 10, frac: n / (w * h), inside: Math.round(inside * 10) / 10 };
  }

  /* the size the pixel check compares at, for a picture w x h */
  function workSize(w, h) {
    const s = WORK / Math.max(w, h);
    return [Math.max(1, Math.round(w * s)), Math.max(1, Math.round(h * s))];
  }

  /* The model's own UNSURE note says the writing is cut off ("Top line is cut off at the top edge."): the lines it gave are then not the whole sign, whether or not
     it left the cut line out of LINES (live: 4 of 6 asks of one box did). A false alarm costs nothing (the repaint is refused before any money is spent). */
  const CUT_NOTE = /cut[\s-]?off|cropped|truncated|clipped|\bedge\b|runs? off|partly (visible|hidden|out)|partially (visible|hidden|out)/i;
  const cutNote = (s) => CUT_NOTE.test(String(s || ''));

  /* did the result keep the picture's shape? */
  function frameOk(w, h, rw, rh) {
    return Math.abs(rw / rh / (w / h) - 1) <= FRAME_TOL;
  }

  /* the feathered edge of the patch: this many pixels of a w x h picture fade out */
  function featherPx(w, h) {
    return Math.max(2, Math.round(Math.min(w, h) * 0.06));
  }

  const API = {
    IMAGE_MODEL: IMAGE_MODEL, QUALITY: QUALITY, RATIOS: RATIOS, SHAPE_TOL: SHAPE_TOL, EDGE_MARGIN: EDGE_MARGIN, INPUT_MAX: INPUT_MAX, INPUT_MIN: INPUT_MIN, WORK: WORK, MAD_MAX: MAD_MAX, INSIDE_MIN: INSIDE_MIN, INSIDE_GAIN: INSIDE_GAIN, COL_MAX: COL_MAX, BLOB_MAX: BLOB_MAX, FRAME_TOL: FRAME_TOL,
    normalise: normalise, paintText: paintText, paintable: paintable, assess: assess, buildInstruction: buildInstruction, pickRatio: pickRatio, planCrop: planCrop, inputSize: inputSize, sendSize: sendSize,
    wantPaint: wantPaint, latinMode: latinMode, isLatin: isLatin, countWord: countWord, oldLeft: oldLeft, accentFaults: accentFaults, REGION: REGION, ROOMY: ROOMY, lineFrame: lineFrame, growLine: growLine, regionMask: regionMask, composite: composite,
    planEarly: planEarly, storedClear: storedClear, planFresh: planFresh, KEEP: KEEP, MARKS: MARKS, markFaults: markFaults, markCrop: markCrop, keepQuad: keepQuad, parseKept: parseKept, keptPieces: keptPieces, keepDecision: keepDecision, keepMask: keepMask,
    compare: compare, repeated: repeated, LETTER: LETTER, lettering: lettering, toneField: toneField, cutNote: cutNote, evaluate: evaluate, explain: explain, sim: sim, pixelCheck: pixelCheck, workSize: workSize, frameOk: frameOk, featherPx: featherPx, NON_LATIN: NON_LATIN,
  };
  root.PAARepaint = API;
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
})(typeof self !== 'undefined' ? self : globalThis);
