/* Gloss: English drawn over the sign (stage 3). One label per LINES entry that passes the gates (ovfit.js), a glossy sticker in the
   WORLD layer (so it sits under Google's own controls and takes no pointer events), warped every frame onto the entry's quadrilateral
   with PAAPose.quadToMatrix3d, exactly as a mark's ticks are. (v0.3.1: the quadrilateral is the four corners the model gave for the line, so the label
   leans with the lettering and follows its perspective; a line saved as a box gets the box's corners as before. ovfit.js decides the shape and size of the
   rectangle the text is laid out in, bw x bh, which this file only warps.) The text is laid out once at a base size (the size the question was asked
   at, or the size on screen when the view last came to rest) and the warp does the rest, so a frame costs four projections and one
   transform write per label: no layout, no measuring, no deferral to a frame of our own.

   What decides whether a mark shows its labels: its record's overlay.on (true / false, set by the card's Overlay button and remembered),
   else the setting "Draw English over text automatically" together with the gates (at least half of the lines pass).
   A mark seen from another panorama (a FarMark) never has labels: they are built only for a mark with its own four corner directions.

   v0.3.2, WAITING LABELS: a line that cannot be set at 9 px inside its outline today but could at some zoom k (ovfit.js plan(): item.wait, item.k) gets a label like any other, laid out at the
   size it will have at that zoom (base size = its outline times k). Its font on screen is then 1 / k of the layout's, under the 9 px floor, and the floor that hides every small label
   keeps it hidden until the zoom reaches k: no new rule. While the overlay shows and at least one such label is hidden for its size (L.small), the mark's card says so (hint()).

   v0.3.2, TIGHT LABELS: a line that passes only the tight fit (ovfit.js: one line, no vertical padding, type as tall as the outline, squeezed to 85 % or run on past its ends) gets class "tight" (a thin rim and
   line-height 1: design/extensions.css). Its layout is wider than its outline when it is squeezed (L.sq < 1: the warp narrows it, so the area of the quadrilateral over the layout is sq times the zoom squared), and
   when it runs on its four corners are the extended ones: the plan carries them in picture pixels (item.qx) and PAAGeo.extendDirs turns them into directions from the line's own four stored ones.

   Per label state (m.ov.labels[i]): el, dirs, bw / bh (base size in CSS px), font (base font in CSS px), sq (the share the layout is narrowed to, 1 unless tight and squeezed), pts (the projected corners), vis, sup
   (hidden because a newer answer about the same sign has its own label there), wait (a waiting label), small (hidden this frame because its type is under the floor). THE FLOOR IS JUDGED BY THE TYPE AS DRAWN:
   font * scale / sqrt(sq), scale being how much bigger or smaller than its layout the label is on screen now (the area of its corners over bw * bh, square-rooted). m.ov.nVis is how many labels are on screen
   this frame: the mark's caption comes back when it is 0 (a mark whose English cannot be seen at the moment has no reason to be quiet).

   A label is not a button, but it is pressed like one: press.js asks hitAt() and a still click on a label opens the card, as a click on a
   caption does (otherwise a click on the most prominent thing on screen would walk to the next panorama). A drag from a label pans. */
(function () {
  'use strict';
  const PAA = self.PAA;
  const P = self.PAAPose;
  const F = self.PAAOvFit;
  const G = self.PAAGeo;

  const STAGGER = 40; // ms between one label and the next when they appear
  const MIN_FONT = F.MIN_FONT; // CSS px on screen: below this a label hides until he zooms in
  const FLOOR_NOISE = 0.1; // CSS px of slack at the floor for a label that is not showing yet (see place())
  let againLater = false; // a pass at rest has been asked for (place())
  const REBASE = 0.08; // at rest, a label whose on-screen size differs from its base by more than this is laid out again at the new size

  /* ---------- measuring ---------- */
  let ctx = null;
  let family = '';
  const wcache = new Map();
  function w100(text) {
    let w = wcache.get(text);
    if (w === undefined) {
      if (!ctx) ctx = document.createElement('canvas').getContext('2d');
      ctx.font = '700 100px ' + (family || 'sans-serif');
      w = ctx.measureText(text).width;
      if (wcache.size > 2000) wcache.clear();
      wcache.set(text, w);
    }
    return w;
  }
  function readFamily() {
    if (family) return;
    const stage = PAA.layer.stage();
    if (!stage) return;
    const probe = document.createElement('div');
    probe.className = 'ov';
    stage.appendChild(probe);
    family = getComputedStyle(probe).fontFamily || '';
    probe.remove();
    wcache.clear();
  }

  const rgb = (c) => c[0] + ',' + c[1] + ',' + c[2];

  /* ---------- building ---------- */
  function paint(L) {
    const e = L.el;
    const bw = L.bw, bh = L.bh;
    e.style.width = bw + 'px';
    e.style.height = bh + 'px';
    e.style.fontSize = L.font + 'px';
    e.style.setProperty('--ovr', Math.max(2, Math.min(9, Math.round(bh * 0.2))) + 'px');
  }

  /* The element of a label, from what the plan says about its line (L.it). */
  function buildEl(L) {
    const it = L.it;
    const e = document.createElement('div');
    e.className = 'ov';
    const sp = document.createElement('span');
    L.lines.forEach((ln, i) => {
      if (i) sp.appendChild(document.createElement('br'));
      sp.appendChild(document.createTextNode(ln)); // model text goes in as text, never as HTML
    });
    const g = document.createElement('i'); // the glint
    g.className = 'g';
    e.append(g, sp);
    const bg = L.bg;
    e.style.setProperty('--bg', rgb(bg));
    e.style.setProperty('--fg', rgb(it.color));
    e.classList.add(F.luminance(it.color) > 0.4 ? 'lt' : 'dk');
    if (L.lines.length > 1) e.classList.add('two'); // the gel cap is thin over two lines of type
    if (L.tight) e.classList.add('tight'); // one line as tall as the outline: a thin rim, line height 1 (design/extensions.css)
    // dark signs would turn into a pale tile under the full gel cap: it is eased on them (0.55 on near black, full from a luminance of .2)
    e.style.setProperty('--ovk', String(Math.round((0.55 + 0.45 * Math.min(1, F.luminance(bg) / 0.2)) * 100) / 100));
    L.el = e;
    paint(L);
    return e;
  }

  /* the four corner directions the label is drawn on: the line's own, or, for a tight label that runs on past its ends, those of its longer outline (item.qx, in the picture's pixels) */
  function dirsOfItem(it) {
    const d = it.dirs;
    if (it.qx && it.q && G && G.extendDirs) {
      const e = G.extendDirs(it.q, d, [[it.qx[0], it.qx[1]], [it.qx[2], it.qx[3]], [it.qx[4], it.qx[5]], [it.qx[6], it.qx[7]]]);
      if (e && e.every((x) => x && isFinite(x.yaw) && isFinite(x.pitch))) return e;
    }
    return [d.tl, d.tr, d.br, d.bl];
  }

  function makeLabel(it, k) {
    const bg = it.bg || [128, 128, 128];
    const sq = it.sq || 1;
    const L = { el: null, it: it, i: it.i, k: k, text: it.text, dirs: dirsOfItem(it), bw: it.bw, bh: it.bh, font: it.fit.font, lines: it.fit.lines, bg: bg, color: it.color,
      pts: [{ x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }], vis: false, glinted: false, ok: false, sup: false, scale: 1,
      wait: !!it.wait, small: false, fresh: true, tight: !!it.tight, sq: sq, rsq: Math.sqrt(sq), drawn: 0 };
    // A waiting label's element is made now but is NOT in the page until the zoom brings the label into size (place() puts it in, and takes it out again when it has gone): a hidden label in the page is
    // still styled and kept up to date by the browser, and 180 of them were most of the cost when the labels kept coming into size in the churn measurement (see place()).
    buildEl(L);
    L.inDom = !L.wait;
    return L;
  }

  function ensureLabels(m) {
    const ov = m.ov;
    if (ov.labels) return;
    const stage = PAA.layer.stage();
    ov.labels = [];
    let k = 0;
    ov.plan.items.forEach((it) => {
      if (!it.ok && !it.wait) return;
      const L = makeLabel(it, k++);
      if (L.inDom) stage.appendChild(L.el);
      ov.labels.push(L);
    });
  }

  function dropLabels(m) {
    const ov = m.ov;
    if (!ov || !ov.labels) return;
    ov.labels.forEach((L) => L.el.remove());
    ov.labels = null;
  }

  /* ---------- which marks show ---------- */
  function wanted(m) {
    const ov = m.ov;
    if (!ov || !(ov.plan.pass + ov.plan.waiting)) return false;
    if (PAA.patch && PAA.patch.on(m)) return false; // stage 4: a mark with a repaint showing does not also draw English labels over it
    const on = m.rec.overlay ? m.rec.overlay.on : null;
    if (on === true) return true;
    if (on === false) return false;
    return !!PAA.prefs.overlayAuto && ov.plan.auto;
  }

  /* (Re)build a mark's overlay from its record: the gates, the fit; labels are made when they are first to show. */
  function attach(m, quiet) {
    detach(m);
    const rec = m.rec;
    const o = rec.overlay;
    if (m.far || !m.dirArr || !o || !o.cs || !o.ref || !rec.a || !rec.a.lines || !rec.a.lines.length) return;
    readFamily();
    // (the plan is made again from the stored lines whenever a note loads: a note made by 0.3.1 gains its waiting labels here, nothing is stored or migrated)
    m.ov = { plan: F.plan(rec.a.lines, o.cs, o.ref, w100, { kmax: F.kmaxFor(rec.view && rec.view.fov) }), labels: null, show: false, reveal: false, nVis: 0, nWait: 0 };
    if (!refresh(m, quiet)) m.ovChanged(quiet); // (the card's action row may now offer Overlay, whether or not the labels show)
  }

  function detach(m) {
    if (!m.ov) return;
    dropLabels(m);
    m.ov = null;
    dedupe(); // an older answer about the same sign may have its labels back
  }

  /* the mark should show (or stop showing) its labels: re-evaluate, and tell the mark */
  function refresh(m, quiet) {
    const ov = m.ov;
    if (!ov) return false;
    const want = wanted(m);
    if (want === ov.show) return false;
    ov.show = want;
    if (want) {
      ensureLabels(m);
      ov.labels.forEach((L) => { L.glinted = false; L.fresh = true; }); // they glint again each time they are brought back (and a waiting label that is not showing is looked at at once)
      ov.reveal = true; // the next frames that draw them stagger their appearance
    } else {
      ov.labels && ov.labels.forEach((L) => setVis(L, false, false));
      ov.nVis = 0;
      ov.nWait = 0;
    }
    dedupe();
    m.ovChanged(quiet);
    return true;
  }

  function toggle(m) {
    const ov = m.ov;
    if (!ov || !(ov.plan.pass + ov.plan.waiting)) return;
    if (!m.rec.overlay) return;
    m.rec.overlay.on = !ov.show;
    refresh(m);
    m.actsKey = '';
    if (m.state === 'done' && !m.dead) PAA.store.save(m.rec).catch((e) => console.warn('[PAA] save failed', e));
  }

  /* the labels on, whatever they were (the card's Overlay button with a repaint showing: the repaint goes off and the labels come, never both off) */
  function show(m) {
    const ov = m.ov;
    if (!ov || !(ov.plan.pass + ov.plan.waiting) || !m.rec.overlay) return;
    m.rec.overlay.on = true;
    refresh(m);
    m.actsKey = '';
    if (m.state === 'done' && !m.dead) PAA.store.save(m.rec).catch((e) => console.warn('[PAA] save failed', e));
  }

  const shown = (m) => !!(m.ov && m.ov.show);
  const seen = (m) => !!(m.ov && m.ov.show && m.ov.nVis > 0); // at least one label is on screen now
  const available = (m) => (m.ov ? m.ov.plan.pass + m.ov.plan.waiting : 0); // the Overlay button is offered when one line can be drawn now or later

  /* What the card says about lines waiting for a zoom (see the top): 0 nothing; 1 some label is showing and waiting ones are hidden for their size; 2 none is showing and waiting ones are hidden for their size. */
  function hint(m) {
    const ov = m.ov;
    if (!ov || !ov.show || !ov.nWait) return 0;
    return ov.nVis > 0 ? 1 : 2;
  }
  const HINT = { 1: 'Zoom in to see the smaller lines in English.', 2: 'Too small to draw the English on from here. Zoom in.' };

  /* ---------- every frame ---------- */
  /* instant: hidden because of motion (a flight, the 9 px floor, a pan): at once, where it is. Otherwise (the card's button, the setting) it fades. */
  function setVis(L, on, instant) {
    if (L.vis === on) return;
    L.vis = on;
    L.el.classList.toggle('now', !on && instant !== false);
    L.el.classList.toggle('vis', on);
    if (on && !L.glinted) {
      L.glinted = true;
      L.el.classList.add('glint'); // a quick glint when it first appears
      setTimeout(() => L.el.classList.remove('glint'), 1400);
    }
  }

  function place(m, f) {
    const ov = m.ov;
    if (!ov || !ov.show || !ov.labels) { if (ov) ov.nWait = 0; return 0; }
    const labels = ov.labels, vr = f.vr;
    let appearing = 0, seen = 0, flipped = false, small = 0, waitFlip = false;
    const atRest = !!(f.pose && !f.pose.moving); // the camera has stopped (layer.js: the pass at rest)
    let again = false; // a waiting label's element went into the page this frame: it fades in on the next one, and at rest there may be none unless one is asked for
    ov.tick = ((ov.tick || 0) + 1) & 3;
    for (let n = 0; n < labels.length; n++) {
      const L = labels[n];
      // A waiting label that is not showing is looked at every 4th frame (a different quarter of them each frame), not every frame: it can only come into size when the zoom changes, a label is a fade in
      // anyway, and a sign with six of them hidden would otherwise cost six labels' projections a frame for nothing. The first look is at once. (perf-gloss's 30 marks with six waiting labels on each, the
      // picture dragged: labels that stay hidden 60.2 fps against 59.8 for the same marks without them; labels that keep coming into size and going out as the picture turns 53 fps, 44 before this and the
      // element rule in makeLabel. Numbers: BUILD-NOTES section 23.)
      // (and the pass at rest, once the camera has stopped, looks at every one: a label whose turn did not come on the last frame of a zoom would otherwise stay as the frame before it left it, hidden although the final view
      // makes its type 9 px or more; the live test found 14 of 700 samples so)
      if (L.wait && !L.vis && !L.fresh && !atRest && ((n + ov.tick) & 3) !== 0) { if (L.small) small++; continue; }
      L.fresh = false;
      const d = L.dirs, p = L.pts;
      let ok = !L.sup;
      L.small = false;
      for (let k = 0; ok && k < 4; k++) {
        const s = P.dirToScreen(d[k].yaw, d[k].pitch);
        if (!s || s.behind) { ok = false; break; }
        p[k].x = s.x;
        p[k].y = s.y;
      }
      if (ok) {
        const x0 = Math.min(p[0].x, p[1].x, p[2].x, p[3].x), x1 = Math.max(p[0].x, p[1].x, p[2].x, p[3].x);
        const y0 = Math.min(p[0].y, p[1].y, p[2].y, p[3].y), y1 = Math.max(p[0].y, p[1].y, p[2].y, p[3].y);
        if (x1 < vr.x - 40 || x0 > vr.x + vr.w + 40 || y1 < vr.y - 40 || y0 > vr.y + vr.h + 40) ok = false;
        else {
          // the area of the quadrilateral (half the cross product of its diagonals) against the base size: how big the letters are on screen now
          L.scale = Math.sqrt(P.quadArea(p) / (L.bw * L.bh));
          // THE TYPE AS DRAWN: the font the label is laid out in, times how much bigger or smaller than its layout it is on screen now (a squeezed tight label is narrower than its layout by sq, which is not a smaller type).
          // Laying the English out again at rest (rebase) never gives a smaller drawn size than the label had (it keeps the old layout instead), so a label near the floor does not vanish after a zoom in and out to
          // the very same view (0.3.1; the 0.3.2 first build judged by the first layout instead, and drew labels under 8.5 px: the check found 8.25).
          // (a little hysteresis: no flicker at the floor; and 0.1 px of slack where it appears, because a line that fits at exactly 9.0 px when asked has a scale of 0.9999 on screen after the corners went through the stored
          // directions, and used to stay hidden on that: a plan that passed with nothing on screen, seen on the owner's sign in the 0.3.2 run)
          L.drawn = (L.font * L.scale) / L.rsq;
          if (L.drawn < (L.vis ? MIN_FONT - 0.5 : MIN_FONT - FLOOR_NOISE)) { ok = false; L.small = true; }
        }
      }
      if (L.wait && ok && !L.inDom) { PAA.layer.stage().appendChild(L.el); L.inDom = true; L.fresh = true; ok = false; again = true; } // (see makeLabel) its element goes into the page one frame before it fades in
      if (ok) {
        const mt = P.quadToMatrix3d(d, L.bw, L.bh);
        if (mt === P.HIDDEN_MATRIX) ok = false;
        else L.el.style.transform = 'translate(' + -f.ox + 'px,' + -f.oy + 'px) ' + mt;
      }
      if (L.wait && !ok && !L.vis && L.inDom && !L.fresh) { L.el.remove(); L.inDom = false; } // ... and is taken out once it has gone
      L.ok = ok;
      if (L.small && L.wait) small++;
      if (ok && !L.vis && ov.reveal) L.el.style.setProperty('--d', appearing++ * STAGGER + 'ms');
      if (ok !== L.vis) { flipped = true; if (L.wait) waitFlip = true; }
      setVis(L, ok);
      if (ok) seen++;
    }
    ov.nVis = seen;
    ov.nWait = small;
    if (again && atRest && !againLater) { againLater = true; setTimeout(() => { againLater = false; PAA.layer.trackNow(); }, 30); } // (a pass of its own, as dedupe does)
    if (waitFlip) dedupe(true); // a waiting label came into size (it now hides an older answer's label of the same stretch) or went out of it (the older one comes back)
    if (flipped) PAA.layer.requestLayout(0); // the caption of a mark that shows no label now comes back (and goes again): a pass at the next rest
    if (ov.reveal && appearing) {
      ov.reveal = false;
      setTimeout(() => { if (ov.labels) ov.labels.forEach((L) => L.el.style.removeProperty('--d')); }, appearing * STAGGER + 800);
    }
    return seen;
  }

  /* the mark is hidden (off screen, another panorama, Off, a flight): nothing of it shows */
  function hide(m) {
    const ov = m.ov;
    if (!ov || !ov.labels) return;
    for (let n = 0; n < ov.labels.length; n++) setVis(ov.labels[n], false);
    ov.nVis = 0;
    ov.nWait = 0;
  }


  /* ---------- pressing, collisions ---------- */
  function inQuad(pts, x, y) {
    let pos = false, neg = false;
    for (let i = 0; i < 4; i++) {
      const a = pts[i], b = pts[(i + 1) % 4];
      const c = (b.x - a.x) * (y - a.y) - (b.y - a.y) * (x - a.x);
      if (c > 0) pos = true;
      else if (c < 0) neg = true;
    }
    return !(pos && neg);
  }

  /* the window rectangle of the label showing at this point, or null (press.js: a still click on it opens the card) */
  function hitAt(m, x, y) {
    const ov = m.ov;
    if (!ov || !ov.nVis || !ov.labels) return null;
    for (let n = 0; n < ov.labels.length; n++) {
      const L = ov.labels[n];
      if (L.vis && L.ok && inQuad(L.pts, x, y)) return boundsOf(L.pts);
    }
    return null;
  }

  function boundsOf(p) {
    const x0 = Math.min(p[0].x, p[1].x, p[2].x, p[3].x), x1 = Math.max(p[0].x, p[1].x, p[2].x, p[3].x);
    const y0 = Math.min(p[0].y, p[1].y, p[2].y, p[3].y), y1 = Math.max(p[0].y, p[1].y, p[2].y, p[3].y);
    return { x: x0, y: y0, w: x1 - x0, h: y1 - y0 };
  }

  /* the rectangles of the labels showing now (captions keep off them: layer.layoutAll) */
  function rects(m, out) {
    const ov = m.ov;
    if (!ov || !ov.nVis || !ov.labels) return out;
    ov.labels.forEach((L) => { if (L.vis && L.ok) out.push(boundsOf(L.pts)); });
    return out;
  }

  /* Two answers about one sign draw two sets of labels on top of each other (a faint second edge, 1 or 2 px off). Where a newer answer's label
     covers an older one's (the same stretch of the picture, by direction), the older one stays hidden. Runs when marks come and go or show
     and hide, never per frame. */
  function span(L) {
    if (L.span) return L.span;
    const y0 = L.dirs[0].yaw;
    const dy = (v) => ((v - y0 + 540) % 360) - 180;
    const ys = L.dirs.map((d) => dy(d.yaw)), ps = L.dirs.map((d) => d.pitch);
    L.span = [Math.min.apply(null, ys), Math.min.apply(null, ps), Math.max.apply(null, ys), Math.max.apply(null, ps), y0];
    return L.span;
  }
  function overlapRatio(a, b) {
    const sa = span(a), sb = span(b);
    const sh = ((sb[4] - sa[4] + 540) % 360) - 180; // b's yaw frame in a's
    const ix = Math.min(sa[2], sb[2] + sh) - Math.max(sa[0], sb[0] + sh), iy = Math.min(sa[3], sb[3]) - Math.max(sa[1], sb[1]);
    if (ix <= 0 || iy <= 0) return 0;
    const i = ix * iy, ua = (sa[2] - sa[0]) * (sa[3] - sa[1]), ub = (sb[2] - sb[0]) * (sb[3] - sb[1]);
    return i / Math.max(1e-9, ua + ub - i);
  }
  let dedupeLater = false;
  function dedupe(fromFrame) { // fromFrame: called while a frame is being placed: the new state is applied by a pass of its own, not inside this one
    if (!PAA.layer || !PAA.layer.all) return;
    const marks = PAA.layer.all().filter((m) => m.ov && m.ov.show && m.ov.labels && !m.dead);
    let changed = false;
    marks.forEach((m) => m.ov.labels.forEach((L) => { if (L.sup) { L.sup = false; changed = true; } }));
    marks.sort((a, b) => (a.rec.createdAt || 0) - (b.rec.createdAt || 0));
    for (let i = 0; i < marks.length; i++) {
      for (let j = i + 1; j < marks.length; j++) {
        marks[i].ov.labels.forEach((La) => {
          if (La.sup) return;
          // a waiting label that is hidden for its size (it has no type on screen yet) does not hide an older answer's readable label: it suppresses while it shows (place() runs this again when one comes or goes)
          if (marks[j].ov.labels.some((Lb) => (!Lb.wait || Lb.vis) && overlapRatio(La, Lb) > 0.5)) La.sup = true;
        });
      }
    }
    if (marks.some((m) => m.ov.labels.some((L) => L.sup)) || changed) {
      if (!fromFrame) PAA.layer.trackNow();
      else if (!dedupeLater) { dedupeLater = true; setTimeout(() => { dedupeLater = false; PAA.layer.trackNow(); }, 0); }
    }
  }

  /* the label's text as these lines (model text goes in as text, never as HTML); a label of two lines has a thinner gel cap */
  function setLines(L, lines) {
    const sp = L.el.querySelector('span');
    if (!sp) return false;
    while (sp.firstChild) sp.removeChild(sp.firstChild);
    lines.forEach((ln, i) => {
      if (i) sp.appendChild(document.createElement('br'));
      sp.appendChild(document.createTextNode(ln));
    });
    L.el.classList.toggle('two', lines.length > 1);
    L.lines = lines;
    return true;
  }

  /* At rest (called from the mark's layout): a label whose on-screen size has drifted from its base (he zoomed) is laid out again at the
     size it has now, so its text is drawn sharp, not stretched. The shape is the same, so the breaks are nearly always the same and only the numbers change; where the larger
     (or smaller) box would break the English elsewhere (the padding does not scale with the box: a quadrilateral that the model drew a little loose can sit right on the
     edge between one line and two), the text is set again as it breaks now. (0.3.0 kept the old, stretched layout then; a line with corners is likelier to be on that edge.)
     A new layout is never one that draws the type smaller than it is drawn now (ovfit.js refit gives the proportional font when the layout is only enlarged and the breaks are the same; padding minimums and the
     quarter-pixel steps of the fit can come out a hair under): then the old layout stays, a little soft. That is the 0.3.1 loss of a near-floor label after a zoom in and a zoom back out: the layout made
     on the way in was a hair under proportional, and on the way out the label fell under the floor. */
  function rebase(m) {
    const ov = m.ov;
    if (!ov || !ov.show || !ov.labels) return;
    ov.labels.forEach((L) => {
      if (!L.ok || !L.scale) return;
      const z = L.scale / L.rsq; // how much bigger than its layout the label is on screen (uniformly: a squeeze is not part of it)
      if (Math.abs(z - 1) < REBASE) return;
      const r = F.refit({ text: L.text, tight: L.tight, bw: L.bw, bh: L.bh, sq: L.sq, font: L.font, lines: L.lines }, z, w100);
      if (!r || r.font + 0.001 < L.font * z) return;
      if (r.lines.join('|') !== L.lines.join('|') && !setLines(L, r.lines)) return;
      L.bw = r.bw;
      L.bh = r.bh;
      L.font = r.font;
      L.sq = r.sq;
      L.rsq = Math.sqrt(r.sq);
      L.scale = L.rsq;
      paint(L);
    });
  }

  function debug(m) {
    const ov = m.ov;
    if (!ov) return null;
    return {
      show: ov.show, pass: ov.plan.pass, waiting: ov.plan.waiting, total: ov.plan.total, auto: ov.plan.auto, nVis: ov.nVis, nWait: ov.nWait, hint: hint(m),
      tight: ov.plan.tight, items: ov.plan.items.map((it) => ({ i: it.i, ok: it.ok, why: it.why, wait: !!it.wait, k: it.k || null, tight: !!it.tight, sq: it.sq || 1, aL: it.aL || 0, aR: it.aR || 0, font: it.fit ? it.fit.font : null, bw: it.bw, bh: it.bh })),
      labels: (ov.labels || []).map((L) => {
        const r = L.el.getBoundingClientRect();
        return { i: L.i, text: L.text, vis: L.vis, ok: L.ok, wait: L.wait, small: L.small, tight: L.tight, sq: L.sq, font: L.font, drawn: L.drawn, bw: L.bw, bh: L.bh, scale: L.scale, dirs: L.dirs, rect: { x: r.x, y: r.y, w: r.width, h: r.height }, pts: L.pts.map((q) => ({ x: q.x, y: q.y })),
          bg: L.bg, color: L.color, opacity: getComputedStyle(L.el).opacity, backdrop: getComputedStyle(L.el).backdropFilter, inDom: L.inDom };
      }),
    };
  }

  /* the setting changed (here or in another tab): every mark decides again */
  if (PAA.prefs && PAA.prefs.onOverlayChange) {
    PAA.prefs.onOverlayChange(() => PAA.layer.all().forEach((m) => refresh(m)));
  }

  PAA.overlay = { attach: attach, detach: detach, refresh: refresh, toggle: toggle, show: show, shown: shown, seen: seen, available: available, hint: hint, HINT: HINT, place: place, hide: hide, rebase: rebase, hitAt: hitAt, inQuad: inQuad, boundsOf: boundsOf, rects: rects, dedupe: dedupe, debug: debug, w100: w100 };
})();
