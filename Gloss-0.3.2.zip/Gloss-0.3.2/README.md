# Gloss

Gloss is a small Chrome extension for Google Street View. Hold Option, drag a box over anything (a shop sign, a menu, a street name, a strange building) and Gloss tells you what it says and what it is. The answer is a small piece of blue glass stuck to the thing you pointed at. It follows the picture as you look around, and it is still there when you come back.

It reads with Claude (Haiku 5.5, from Anthropic). It can also draw the English over the sign, or repaint the sign in English with an image model.

This is version 0.3.2. It is a hobby project, free, and it works on Google Maps Street View (any Google country site). It has not been tried on other map sites.

## Install it (one minute)

1. Unzip the download. You get a folder called `Gloss-0.3.2`. Put it somewhere it can stay (Chrome reads the extension from that folder, so do not delete it afterwards).
2. In Chrome, open `chrome://extensions` and turn on **Developer mode** (top right).
3. Press **Load unpacked** and pick the `Gloss-0.3.2` folder.
4. Open Google Maps, go into Street View, and ask.

There is nothing to sign up for: this copy comes with shared keys built in (see "Keys" below).

**If you already have Gloss, upgrade in place.** Do not load the new folder next to the old one: Chrome treats a new folder as a different extension, and the notes you saved stay behind with the old one. Instead, copy everything inside the new `Gloss-0.3.2` folder over the contents of the folder you loaded before (replace the files), then open `chrome://extensions`, press the reload arrow on Gloss, and refresh the Street View tab. Your notes are still there.

## How to use it

- **Option and drag** draws a box. A small "Reading" chip appears, then it grows into the card as the answer arrives. (On Windows and Linux, Option is the Alt key.)
- **Option and click** means "this thing here". A small ring, with its caption and card.
- **Option, Shift and drag** lets you type your own question. Enter sends, Esc cancels.

Click a caption to open its card. A plain press anywhere else closes a card, and Street View still gets the press. Esc closes the card too. Without Option held, Gloss does nothing to the page.

**The card** shows the answer first, then the original text, and a note only when there is one. Along the bottom:

- **Overlay** draws the English on the sign itself. Each line of English follows its line of lettering, so on a sign that slopes or is seen at an angle the English slopes with it. Gloss tries to give every line its own piece of glass:
  - A line of lettering that is big enough gets its English at a comfortable size, as before.
  - A line that is small on the screen (about 10 to 12 pixels tall) is set "tight": one line of English, as tall as the lettering, with no spare room above or below. If the English is longer than the lettering, it is squeezed a little (never below 85 % of its natural width) and, if that is not enough, it runs on past the ends of the lettering, but only where the sign's own background colour runs on, and it stops at any other line of lettering.
  - A line that is too small even for that (under 9 pixels tall) waits. When you zoom in far enough for the English to be readable, it appears on the sign by itself. While some lines are waiting, the card says "Zoom in to see the smaller lines in English." (or "Too small to draw the English on from here. Zoom in." when none of them can be drawn yet). The line goes away when nothing is waiting any more.
  - A line whose lettering holds a number (two digits or more: a phone number, a price) that the English leaves out gets no label of its own, so its own label never hides the number. Its English stays in the card. (A label for a neighbouring line can still lie over a number, when the outline the model gave for that line is loose.)
  When at least one line can be drawn now or after zooming in, and at least half of all the lines can, the English is already on the sign when the card opens and the button is lit. On a busy sign it may hold back: press Overlay to draw what it can. Press the button again to take the English off. In Settings, "Draw English over text automatically" turns the automatic part off. Notes you made with an older version get the same treatment, except that a label never runs on past the lettering there.
  **What Overlay still gets wrong.** The outline of each line comes from Claude, not from the pixels, so it is not exact. A label can sit a third of a line, or half a line, too high or too low, and then the lower part of the old letters shows under it. Two lines that touch each other can both be refused (they overlap), and Claude sometimes marks a line as cut off; those get no label, and the card still lists every line. With a few dozen labels on screen at once (many notes open at the same time) Street View can feel less smooth.
- **Repaint** asks an image model to letter the English over the sign in the sign's own style. It works for signs in any language, including ones written in Latin letters such as Vietnamese, Portuguese or Turkish. It takes about 20 to 45 seconds (about twice that if it has to try again) and costs a few cents. Lines that are already English, numbers, prices, phone numbers and web addresses are not repainted. Only the lettering is taken from the image model: the picture you see is Street View's own, with the image model's picture let in where the repainted lines are (and where what it changed joins them). On a sign that is mostly lettering (a menu board, say) that is most of the picture. A name with a dotless i, such as Kadıköy, is lettered with a plain i (Kadiköy), because the image model cannot draw the dotless one. A repaint carries an "AI repaint" badge. Press and hold the badge to see the original underneath, and compare.
  **What is checked.** Nothing is shown unless it passes a check. Claude reads the finished picture back without being told what it should say. Every line that was asked for must be there, no long number (three digits or more) may be lost or added, no writing may be invented, and the old words of a Latin-letter line must be gone. Then each repainted line is cropped from the finished picture, enlarged, and copied letter for letter by Claude, again without being told what it should say; a stray accent mark (a leftover acute on an o, a dot where there should be none) refuses the picture. If the check fails Repaint tries once more on its own; if that fails too, nothing is shown and you have still paid for both tries.
  **What it can still get wrong.** A picture that passes the check is not a picture a person has approved. Look closely before you trust one:
  - A ghost of the old lettering can remain: a stub of an old letter under or beside the new words ("Thelivery" for "Delivery"), or part of an old word left when the new one is smaller.
  - A wrong accent the check missed. Claude reading the picture tends to "correct" what it sees, so a stray mark can slip through (an extra mark on an o, a dot above an e).
  - Small writing right next to a repainted line can be damaged. The image model redraws the area round the lines it was asked to change, and nothing looks after the neighbours separately: a phone number, a sticker, a thin vertical line of lettering or a half-hidden word beside a repainted line can come out smudged, clipped or turned into nonsense, and a logo or a lamp can be redrawn a little.
  - A patch can show: a colour that is slightly off, or a hard edge where the picture meets the street.
  - In a strict review of the previous version, about half of 15 real repaints had one of these faults even though they had passed their own check. This version has not been through that review.
  If your box cut the sign, or part of the writing is hidden, or the model's idea of where a line is does not meet your box, Repaint says so in the card and asks for the whole sign in the box.
- **Ask** lets you type a follow-up about the same thing.
- **The three dots**: copy the translation, copy the original, delete, and how long the answer took. (The cost is recorded too; it shows there if you turn on "Show what each answer cost" in Settings.)

**The dock** is the small pill at the top right of the picture. It shows how many notes are on this view. Click it for the notebook: notes here, notes nearby (with an arrow that points the way), and the latest 20 from anywhere. Every finished answer is saved by itself, so come back to the same view and the notes are where you left them. Step to the next panorama and notes asked a few metres back are still there as a small ring ("about here").

## Keys

Gloss needs two keys, one for each service it talks to. You do not have to do anything: this copy has two **shared** keys built in, made for friends trying it out.

- **Reading** (every answer and follow-up) uses an Anthropic key.
- **Repaint** (painting the English onto a sign) uses an OpenRouter key for the image model, and the Anthropic key as well, for Claude's checks of the result.

The shared keys are limited. The OpenRouter one has a **$20** limit, and **both stop working on 14 December 2026**. Everyone who got this copy shares them, so please go easy. When a shared key has run out or expired, the card says so ("The shared key built into Gloss has expired or run out. Add your own ... key in Settings.") and has a **Settings** button.

**To use your own key** (you can add either or both): click the Gloss icon in Chrome's toolbar (it may be under the puzzle-piece menu) to open Settings, paste the key in its field, and press **Save**. The **Check** button next to each field asks the service whether the key works, and the line under the field says which key is in use: your own, or the built-in shared one. Your own key is always used before the shared one. To go back to the shared key, empty the field and press Save. (The "left" figure on the OpenRouter line is OpenRouter's own counter, and it can run a little behind your latest repaint.)

- Anthropic keys come from the Anthropic Console (console.anthropic.com), under API keys.
- OpenRouter keys come from openrouter.ai, under Keys. Repaint is the only thing that uses it.

The shared Anthropic key always reads with Claude Haiku 5.5. If you add your own Anthropic key, the **Model** field in Settings lets you pick another Claude model; it only applies to your own key.

## What is sent where

- **To Anthropic** (api.anthropic.com), for every question and follow-up: the picture of the box you drew, a picture of the Street View screen with the box outlined (so Claude can see the surroundings), the approximate place (the camera's latitude and longitude, the direction it faces and the field of view), and anything you typed. Never the page title, and nothing about you.
- **To Anthropic, as well, only when you press Repaint** (it has to check what the image model drew). Everything in this list goes to the same address and the same Claude model, and each item is a separate request:
  1. The picture of the sign that also goes to the image model (a part of the Street View screen, at most 1,536 pixels on its long side), to read what the sign says now.
  2. The finished picture, to read it back. (Twice, if the check has to look again with a wider area.)
  3. A small enlarged crop of each repainted line, cut from the finished picture, to copy its lettering letter for letter. One request per repainted line, at most 14 lines.
  4. Only when a word or a number looks wrong: a yes-or-no question about the original or the finished picture, with the few words in question (is writing like this really there?).
  5. If the check fails and Repaint tries again, items 2 to 4 are sent once more for the second picture.
  Nothing else goes to Anthropic for a repaint. Showing English on the sign (Overlay) sends nothing at all: it works from the answer Claude already gave.
- **To OpenRouter** (openrouter.ai), only when you press Repaint: a picture of the sign and what is round it (the same one as item 1), and the instruction to letter the English over it, which lists each repainted line's old words and its English. OpenRouter passes it to the image model.
- **Stored only in your browser**: your notes, their pictures and any repaints are saved in the extension's own storage on your computer. Nothing goes to any server of ours; there is none, and there are no accounts or analytics. The keys you add are kept the same way, and only the extension itself can read them. Settings has **Delete all saved notes**.
- The **Check** button sends a key only to the service it belongs to (a key pasted into the wrong field is refused before anything is sent).

Each service's own terms apply to what you send it.

## The permission it asks for

Chrome says Gloss can "read and change all your data on all websites". It asks for that because taking a picture of the Street View tab when you press Option and drag needs it (a narrower permission only works when you click the toolbar icon). Gloss only runs on Google Maps and Yandex Maps pages, and the only places it sends anything are the two services above (and, now and then, the page's own request to Google for the details of a panorama, the same request Google Maps itself makes). It also asks to store notes on your computer.

## What it costs

Reading is cheap: a typical answer costs 0.05 to 0.1 of a cent (the model thinks before it answers, and thinking is billed), and even a long one stays under 0.2 of a cent. Showing English on the sign (Overlay) costs nothing extra.

Repaint costs about 2 to 6 cents when the first try passes (in this version's test runs: 2.5, 2.5, 4.7, 5.3 and 5.7 cents), and about 10 or 11 cents when the first picture fails its check and it tries again, since you pay the image model twice. Nearly all of that is the image model. Claude's checks add about 0.1 to 0.5 of a cent per picture (a second picture doubles it). The shared $20 pays for a few hundred repaints. The card's three-dot menu shows how long each answer and repaint took, and what it cost if you turn on "Show what each answer cost" in Settings. With the shared keys, someone else pays: please use them lightly. With your own keys, you pay the service directly.

## If something does not work

- Nothing happens when you hold Option and drag: refresh the Street View tab, and make sure no older Gloss is also turned on.
- The card shows an amber message: it says what went wrong. A key problem has a **Settings** button; anything else has **Retry**.
- A tab that was open when you loaded Gloss needs a refresh before it works.
- Gloss was built and tested in Chrome. Other Chromium browsers may work.
