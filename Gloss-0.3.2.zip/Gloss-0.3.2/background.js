/* Gloss: background service worker (classic script, so importScripts works).
   Jobs: capture the visible tab and cut the two images (capture port), call Claude on the Anthropic API and stream the
   answer back (ask port), paint with the image model on OpenRouter (repaint port), keep the saved marks (store messages,
   see store.js) and hold the API keys (providers.js: the person's own, else the shared one built into this copy).
   The worker keeps nothing in memory between messages: images are written to storage under the mark's id
   the moment they exist, and every later step reads them back from there. */
'use strict';

try {
  importScripts('keys.bundled.js'); // the shared keys of this copy: defines self.PAA_BUNDLED_KEYS (a copy without the file still starts, and says "no key")
} catch (e) {
  /* no shared keys in this copy */
}
importScripts('prompts.js', 'shared.js', 'vendor/anthropic-sdk.js', 'providers.js', 'fit-image.js', 'geo.js', 'store.js', 'snap.js', 'repaint-core.js', 'repaint-worker.js');

/* The API keys live in chrome.storage.local (the person's own) and in keys.bundled.js (the shared ones). By default that storage is readable from content
   scripts, which run inside web pages (and would also be told when a key changes): make it readable from extension pages and this worker only.
   Pages reach their data through messages (marks: store messages; preferences: prefs messages, see below). */
try {
  chrome.storage.local.setAccessLevel({ accessLevel: 'TRUSTED_CONTEXTS' });
} catch (e) {
  /* an older Chrome: the key stays where it was */
}

const store = PAAStore.create(chrome.storage.local, { rowOf: PAA.rowOf, geo: self.PAAGeo });
const CONTEXT_WIDTH = 1280;
const SMALL_SIDE = 384; // a crop whose short side is under this is enlarged before it is sent (whole-number factor, at most 4)
const MAX_ENLARGE = 4;
const PREFS_KEY = 'paaPrefs'; // { density, hints, overlayAuto, showCost }: lives in storage.local, which pages cannot read (see above)
const THUMB_LONG_SIDE = 200;
const MARK = '#ff00ff';

/* The keys and the model for one job: { anthropic: { key, source }, openrouter: { key, source }, model }, source 'own' | 'builtin' | 'none'. An old v0.2 apiKey is
   moved to openrouterKey here, the first time it is seen. These never leave the worker. */
async function getSettings() {
  let s = {};
  try {
    s = await PAAProviders.loadStored(chrome.storage.local);
  } catch (e) {
    /* fall through to defaults */
  }
  return PAAProviders.choose(s, self.PAA_BUNDLED_KEYS);
}

const NO_ANTHROPIC = 'No Anthropic key set. Reading needs one: add it in Settings.';
const NO_OPENROUTER = 'No OpenRouter key set. Repaint needs one: add it in Settings.';

/* ---------- preferences (density, first-run hint count) ----------
   Pages ask the worker; a change is also pushed to every other tab so they follow. */

async function getPrefs() {
  try {
    return (await chrome.storage.local.get(PREFS_KEY))[PREFS_KEY] || {};
  } catch (e) {
    return {};
  }
}

/* Tell every open page that notes were deleted somewhere else (the settings page's Delete all, or the same note in another tab): a page keeps its marks in
   memory, and any later save from one of them (Overlay, a follow-up, a finished answer) would write the note back without its pictures. */
function tellPages(msg) {
  chrome.tabs.query({}, (tabs) => {
    for (const t of tabs || []) chrome.tabs.sendMessage(t.id, msg, () => void chrome.runtime.lastError);
  });
}

async function setPrefs(patch) {
  const cur = await getPrefs();
  const next = Object.assign({ density: 'labels', hints: 0, overlayAuto: true, showCost: false }, cur);
  if (patch && ['labels', 'dots', 'off'].indexOf(patch.density) >= 0) next.density = patch.density;
  if (patch && typeof patch.hints === 'number') next.hints = patch.hints;
  if (patch && typeof patch.overlayAuto === 'boolean') next.overlayAuto = patch.overlayAuto;
  if (patch && typeof patch.showCost === 'boolean') next.showCost = patch.showCost;
  await chrome.storage.local.set({ [PREFS_KEY]: next });
  chrome.tabs.query({}, (tabs) => {
    for (const t of tabs || []) chrome.tabs.sendMessage(t.id, { type: 'prefs-changed', prefs: next }, () => void chrome.runtime.lastError);
  });
  return next;
}

/* ---------- image work ---------- */

async function blobToDataUrl(blob) {
  const bytes = new Uint8Array(await blob.arrayBuffer());
  let bin = '';
  const step = 0x8000;
  for (let i = 0; i < bytes.length; i += step) {
    bin += String.fromCharCode.apply(null, bytes.subarray(i, i + step));
  }
  return 'data:' + (blob.type || 'image/jpeg') + ';base64,' + btoa(bin);
}

const encode = (canvas, quality) => canvas.convertToBlob({ type: 'image/jpeg', quality: quality });
const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));

/* Cut the crop (image 1), the context picture (image 2) and the thumbnail out of one screenshot.
   g: { kind: 'box'|'point', rect: {x,y,w,h} CSS px, point: {x,y}, iw, ih (window.innerWidth/Height) }
   Image 1 is resized with PAAFit.fitSize BEFORE it is encoded, so the pixel boxes the model returns map 1:1
   onto the image we hold (a bigger crop would be silently shrunk by the server and the boxes would come back
   in the smaller frame). */
async function prepareImages(shotUrl, g, opts) {
  const bmp = await createImageBitmap(await (await fetch(shotUrl)).blob());
  const k = bmp.width / g.iw; // screenshot pixels per CSS pixel, from the real screenshot width

  const r = g.rect;
  const sx = clamp(Math.round(r.x * k), 0, bmp.width - 1);
  const sy = clamp(Math.round(r.y * k), 0, bmp.height - 1);
  const sw = clamp(Math.round(r.w * k), 1, bmp.width - sx);
  const sh = clamp(Math.round(r.h * k), 1, bmp.height - sy);

  // Small boxes: Haiku reads text better when it is bigger. Whole-number enlargement with smoothing, then the usual fit; the
  // size sent (and returned as cropSize) is the enlarged one, so the model's pixel boxes still map 1:1.
  const short = Math.min(sw, sh);
  const up = short < SMALL_SIDE && !(opts && opts.noEnlarge) ? Math.min(MAX_ENLARGE, Math.ceil(SMALL_SIDE / short)) : 1;
  const fit = PAAFit.fitSize(sw * up, sh * up);
  const cw = fit[0];
  const ch = fit[1];
  const crop = new OffscreenCanvas(cw, ch);
  const cctx = crop.getContext('2d');
  cctx.imageSmoothingQuality = 'high';
  cctx.drawImage(bmp, sx, sy, sw, sh, 0, 0, cw, ch);
  const cropBlob = await encode(crop, 0.9);

  // Image 2: the whole view at about 1280 px wide, with the box or point drawn on it.
  const f = Math.min(1, CONTEXT_WIDTH / bmp.width);
  const fw = Math.round(bmp.width * f);
  const fh = Math.round(bmp.height * f);
  const full = new OffscreenCanvas(fw, fh);
  const fctx = full.getContext('2d');
  fctx.imageSmoothingQuality = 'high';
  fctx.drawImage(bmp, 0, 0, fw, fh);
  const stroke = (draw) => {
    fctx.lineJoin = 'round';
    fctx.strokeStyle = '#ffffff'; // white halo so the mark reads on any background
    fctx.lineWidth = 7;
    draw();
    fctx.strokeStyle = MARK;
    fctx.lineWidth = 4;
    draw();
  };
  if (g.kind === 'point' && g.point) {
    const px = g.point.x * k * f;
    const py = g.point.y * k * f;
    const rad = 22;
    stroke(() => {
      fctx.beginPath();
      fctx.arc(px, py, rad, 0, Math.PI * 2);
      fctx.moveTo(px - rad - 8, py);
      fctx.lineTo(px + rad + 8, py);
      fctx.moveTo(px, py - rad - 8);
      fctx.lineTo(px, py + rad + 8);
      fctx.stroke();
    });
  } else {
    stroke(() => fctx.strokeRect(sx * f, sy * f, sw * f, sh * f));
  }
  const fullBlob = await encode(full, 0.85);

  const t = Math.min(1, THUMB_LONG_SIDE / Math.max(cw, ch));
  const thumb = new OffscreenCanvas(Math.max(1, Math.round(cw * t)), Math.max(1, Math.round(ch * t)));
  const tctx = thumb.getContext('2d');
  tctx.imageSmoothingQuality = 'high';
  tctx.drawImage(crop, 0, 0, thumb.width, thumb.height);

  bmp.close();
  return {
    cropUrl: await blobToDataUrl(cropBlob),
    contextUrl: await blobToDataUrl(fullBlob),
    thumbUrl: await blobToDataUrl(await encode(thumb, 0.75)),
    cropSize: [cw, ch],
  };
}

/* Stage 3. The picture that was sent to the model is in storage under the mark's id: decode it, snap each box to the ink and read the colours
   (snap.js: the pure part, tested on the evalset). Returns { w, h, lines: [{ sb, moved, bg, fg, ang } | { q, bg, fg } | null] } in the picture's own pixels.
   v0.3.1: a line that came with four corners (quads[i], flat [x0,y0,...,y3]) is not snapped; the colours are read inside the quadrilateral and the line comes
   back as { q, bg, fg }. boxes[i] is still sent for every line (a quadrilateral's bounding box), so the lines that are boxes keep out of its way. */
async function snapLines(id, boxes, quads) {
  const imgs = await store.getImages(id);
  if (!imgs.crop) throw new Error('no picture for this note');
  const bmp = await createImageBitmap(await (await fetch(imgs.crop.url)).blob());
  const cv = new OffscreenCanvas(bmp.width, bmp.height);
  const cx = cv.getContext('2d', { willReadFrequently: true });
  cx.drawImage(bmp, 0, 0);
  const data = cx.getImageData(0, 0, bmp.width, bmp.height);
  const w = bmp.width, h = bmp.height;
  bmp.close();
  const img = { data: data.data, width: w, height: h, channels: 4 };
  const qs = Array.isArray(quads) ? quads : [];
  const lines = self.PAASnap.analyse(img, boxes, { skip: qs.map((q) => !!q) });
  if (qs.some((q) => q)) {
    const qr = self.PAASnap.analyseQuads(img, qs);
    qr.forEach((r, i) => { if (r) lines[i] = r; });
  }
  return { w: w, h: h, lines: lines };
}

/* ---------- messages: saved marks, settings ---------- */

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (sender.id !== chrome.runtime.id || !msg) return false;
  const reply = (p) => {
    p.then(sendResponse, (e) => sendResponse({ error: String((e && e.message) || e) }));
    return true; // async response
  };
  if (msg.type === 'store') {
    switch (msg.op) {
      case 'list':
        if (msg.pano) store.gc().catch(() => {}); // a page load is a good moment to sweep abandoned images
        return reply(store.list(msg));
      case 'recent':
        return reply(store.recent(msg.limit));
      case 'nearby':
        return reply(store.nearby(msg));
      case 'get':
        return reply(store.get(msg.id));
      case 'save':
        return reply(store.save(msg.record));
      case 'remove':
        return reply(store.remove(msg.id).then((r) => { tellPages({ type: 'store-changed', op: 'removed', id: msg.id }); return r; }));
      case 'discard':
        return reply(store.discard(msg.id));
      case 'patch': // stage 4: the repaint picture of a mark (the page asks for it when it restores the mark or has just made it)
        return reply(store.getPatch(msg.id));
      case 'unpatch':
        return reply(store.removePatch(msg.id));
      case 'stats':
        return reply(store.stats());
      case 'clear':
        return reply(store.clear().then((r) => { tellPages({ type: 'store-changed', op: 'cleared' }); return r; }));
      default:
        return false;
    }
  }
  if (msg.type === 'snap') { // stage 3: snap the model's boxes to the ink in the picture that was sent, and read the sign's colours from it
    return reply(snapLines(msg.id, msg.boxes, msg.quads));
  }
  if (msg.type === 'prefs') {
    if (msg.op === 'set') return reply(setPrefs(msg.patch));
    return reply(getPrefs());
  }
  if (msg.type === 'openOptions') {
    chrome.runtime.openOptionsPage();
    return false;
  }
  if (msg.type === 'keyStatus') { // where each key comes from (never a key)
    return reply(getSettings().then((s) => PAAProviders.status(s, self.PAA_BUNDLED_KEYS)));
  }
  if (msg.type === 'checkKey') { // the settings page's Check button: asks the provider whether a key works. A key typed in the field is tried as it is; an empty field means the built-in key, which never leaves here
    return reply((async () => {
      const provider = msg.provider === 'openrouter' ? 'openrouter' : 'anthropic';
      const typed = typeof msg.key === 'string' ? msg.key.trim() : '';
      const builtin = (self.PAA_BUNDLED_KEYS && self.PAA_BUNDLED_KEYS[provider]) || '';
      const key = typed || builtin;
      const source = typed ? 'own' : 'builtin';
      const r = await PAAProviders.check(provider, key, source, { model: (await getSettings()).model });
      r.source = key ? source : 'none';
      return r;
    })());
  }
  return false;
});

chrome.action.onClicked.addListener(() => chrome.runtime.openOptionsPage());

/* ---------- ports ---------- */

function portHelpers(port) {
  const ac = new AbortController();
  let gone = false;
  port.onDisconnect.addListener(() => {
    gone = true;
    ac.abort(); // the page cancelled (tab closed or reloaded)
  });
  const send = (m) => {
    if (gone) return;
    try {
      port.postMessage(m);
    } catch (e) {
      gone = true;
    }
  };
  return { ac, send, isGone: () => gone };
}

chrome.runtime.onConnect.addListener((port) => {
  if (port.sender.id !== chrome.runtime.id) return;
  if (port.name === 'capture') handleCapture(port);
  else if (port.name === 'ask') handleAsk(port);
  else if (port.name === 'repaint') handleRepaint(port);
});

/* capture port. In:  { type:'capture', id, gesture }
   Out: { type:'shot' } as soon as the screenshot exists (the page can show its layers again),
        then { type:'prepared', cropSize, thumb } once the images are cut and saved under the id,
        or { type:'error', message }. */
function handleCapture(port) {
  const { send, isGone } = portHelpers(port);
  port.onMessage.addListener(async (msg) => {
    if (!msg || msg.type !== 'capture' || !port.sender.tab) return;
    try {
      // captureVisibleTab takes whichever tab is showing in that window: if he switched away since asking, it is not his picture
      const tab = await chrome.tabs.get(port.sender.tab.id);
      if (!tab.active) throw new Error('You switched tab before the picture was taken. Try again.');
      const shot = await chrome.tabs.captureVisibleTab(port.sender.tab.windowId, { format: 'png' });
      send({ type: 'shot' });
      const img = await prepareImages(shot, msg.gesture);
      if (isGone()) return; // the page went away: do not keep images nobody can use
      await store.putImages(msg.id, { url: img.cropUrl, w: img.cropSize[0], h: img.cropSize[1] }, { url: img.contextUrl });
      send({ type: 'prepared', cropSize: img.cropSize, thumb: img.thumbUrl });
    } catch (e) {
      send({ type: 'shot' }); // never leave the page hiding its layers
      send({ type: 'error', message: String((e && e.message) || e) });
    }
  });
}

/* ask port. In:  { type:'ask', id, question, info, kind, turns }   (images come from storage, by id)
   Out: { type:'delta', text }..., { type:'done', cost, usage, ms, model } or { type:'error', message, settings } (settings: true = a key problem, the card offers Settings). */
function handleAsk(port) {
  const { ac, send } = portHelpers(port);
  // The worker is stopped after 30 s without an extension call, and the model can think silently for longer than that:
  // while a request is open, call a cheap extension API every 20 s.
  const keepAlive = setInterval(() => { chrome.runtime.getPlatformInfo(() => void chrome.runtime.lastError); }, 20000);
  port.onDisconnect.addListener(() => clearInterval(keepAlive));
  port.onMessage.addListener(async (msg) => {
    if (!msg || msg.type !== 'ask') return;
    const settings = await getSettings();
    if (!settings.anthropic.key) {
      send({ type: 'error', message: NO_ANTHROPIC, settings: true });
      return;
    }
    try {
      const imgs = await store.getImages(msg.id);
      if (!imgs.crop || !imgs.ctx) {
        send({ type: 'error', message: 'The picture for this note is gone. Ask again.' });
        return;
      }
      const prompt = PAA.buildPrompt({
        info: msg.info,
        kind: msg.kind,
        images: [imgs.crop.url, imgs.ctx.url],
        cropSize: [imgs.crop.w, imgs.crop.h],
        turns: msg.turns,
        question: msg.question,
      });
      const t0 = Date.now();
      const r = await PAAProviders.streamChat({
        apiKey: settings.anthropic.key,
        keySource: settings.anthropic.source,
        model: settings.model,
        prompt: prompt,
        signal: ac.signal,
        onDelta: (text) => send({ type: 'delta', text: text }),
      });
      send({ type: 'done', cost: r.cost, usage: r.usage, ms: Date.now() - t0, model: settings.model });
    } catch (e) {
      if (e && e.name === 'AbortError') return;
      send({ type: 'error', message: String((e && e.message) || e), settings: !!(e && e.settings) });
    } finally {
      clearInterval(keepAlive);
    }
  });
}

/* repaint port (stage 4). In:  { type:'repaint', job }  (job: see repaint-worker.js run(); a fresh job also carries gesture { rect, iw } for the screenshot)
   Out: { type:'shot' } (a fresh screenshot was taken: the page shows its layers again), { type:'phase', phase: 'paint' | 'check' | 'retry' },
        then { type:'done', result } (result.ok false is an answer, not an error: refused, or it did not pass its check). A closed port cancels everything:
        the page's cancel button, a deleted mark, a closed or reloaded tab. The worker is kept alive by the same 20 s call as an ask. */
function handleRepaint(port) {
  const { ac, send } = portHelpers(port);
  const keepAlive = setInterval(() => { chrome.runtime.getPlatformInfo(() => void chrome.runtime.lastError); }, 20000);
  port.onDisconnect.addListener(() => clearInterval(keepAlive));
  port.onMessage.addListener(async (msg) => {
    if (!msg || msg.type !== 'repaint' || !msg.job) return;
    const job = msg.job;
    try {
      const settings = await getSettings();
      const missing = !settings.openrouter.key ? NO_OPENROUTER : !settings.anthropic.key ? NO_ANTHROPIC : ''; // (Repaint paints on OpenRouter and reads the result back with Claude)
      if (missing) {
        send({ type: 'done', result: { ok: false, kind: 'error', message: missing, settings: true } });
        return;
      }
      const deps = {
        anthropic: settings.anthropic,
        openrouter: settings.openrouter,
        signal: ac.signal,
        phase: (p) => send({ type: 'phase', phase: p }),
        source: async () => {
          if (job.source !== 'fresh') {
            const imgs = await store.getImages(job.id);
            if (!imgs.crop) throw new Error('The picture for this note is gone. Ask again.');
            return { url: imgs.crop.url, w: imgs.crop.w, h: imgs.crop.h };
          }
          if (!port.sender.tab) throw new Error('No tab to take the picture from.');
          const tab = await chrome.tabs.get(port.sender.tab.id);
          if (!tab.active) throw new Error('You switched tab before the picture was taken. Try again.');
          const shot = await chrome.tabs.captureVisibleTab(port.sender.tab.windowId, { format: 'png' });
          send({ type: 'shot' });
          return PAARun.cutSource(shot, job.gesture);
        },
        save: (patch) => store.putPatch(job.id, patch),
      };
      const result = await PAARun.run(job, deps);
      if (ac.signal.aborted) return;
      send({ type: 'done', result: result });
    } catch (e) {
      if (ac.signal.aborted) return; // the page closed the port: nobody is listening
      send({ type: 'shot' }); // never leave the page hiding its layers
      send({ type: 'done', result: { ok: false, kind: 'error', message: String((e && e.message) || e), settings: !!(e && e.settings), stats: (e && e.stats) || null } });
    } finally {
      clearInterval(keepAlive);
    }
  });
}
