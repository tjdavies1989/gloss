/* Gloss: tolerant parser for the short-answer reply format.
   Plain classic script, no dependencies. Works in the browser/service worker (self.PAAParse) and in node (require).

   The reply is up to six labelled lines:
     SAY: ... / ORIG: ... / READ: ... / NOTE: ... / UNSURE: ... / LINES: [{"q":[x0,y0,x1,y1,x2,y2,x3,y3],"o":"..","t":".."}, ...]
   (v0.3.1: a LINES entry carries "q", the four corners of the lettering clockwise from the top left of the text as read. Entries from the
   older prompt carry "b", a box [x0,y0,x1,y1]; both are still read, and saved notes made by earlier versions have b only.)

   parseReply(text, opts) is pure and cheap: call it again with the whole text so far every time a chunk arrives
   (do not feed it deltas). It never throws. Result:
     { say, orig, read, note, unsure, lines, structured, noteIsFallback, linesTruncated, preface, active }
   - lines: array of {b:[x0,y0,x1,y1]|null, q:[8 numbers]|null, qb:[x0,y0,x1,y1]|null, o, t}; only COMPLETE objects (a half-streamed object is held back).
     q is set only when the entry gave exactly eight finite numbers (flat, or four [x,y] pairs); it is NOT yet checked against the picture (lineGeometry does that).
     qb is the bounding box of whatever numbers a malformed q held (the fall-back when q turns out bad); b is the explicit box, or the four numbers of a q that was really a box.
   - structured: false when the reply ignored the format (then everything is in `note`, noteIsFallback = true).
   - linesTruncated: the LINES array was not closed (still streaming, or cut off) or its last object was incomplete.
   - saySynth: true when the first line had no 'SAY:' label and was taken as the answer anyway.
   - active: name of the field currently being written (lowercase) or '' - handy for a typing indicator.
   opts.final = true when the stream has ended (changes nothing but `linesTruncated` semantics stay true if cut off).

   looksOff(result) says whether a finished reply should be retried (see below).

   boxToPixels(b, convention, width, height) turns a model box into integer pixels of the image the box refers to
   (convention: 'px' | 'n1000' | 'frac'), fixing swapped corners and clamping. Returns null when unusable.

   validQuad(q, width, height) checks a q strictly (eight finite numbers, inside the picture to within QUAD_TOL px, clockwise as drawn on the screen (y down),
   convex with no straight corner, an area of at least 20 px2, no edge under 2 px, and no wedge: the shorter of the two end edges, and of the top and bottom, at least a quarter of the longer) and returns the quad clamped into the picture, or null.
   lineGeometry(line, width, height) is the one call ask.js makes for a LINES entry: { q, b, spill, fallback } where q is the checked quad (flat, rounded to 0.1)
   or null, b the integer pixel box (the quad's bounding box when there is a quad), spill that the model ran off the picture, fallback that a bad q was
   replaced by its bounding box (treated as a b: such a line is gated and drawn exactly as a b-only line from an older version). */
(function (root) {
  'use strict';

  var LABELS = ['SAY', 'ORIG', 'READ', 'NOTE', 'UNSURE', 'LINES'];
  // optional bullet / heading / bold markers, the label, optional bold close, colon (ascii or full width)
  var LABEL_RE = /^[\s>#*_`\-•]*\**_*\s*(SAY|ORIG|READ|NOTE|UNSURE|LINES)\s*\**_*\s*[:：]\s*\**\s*(.*)$/i;
  var EMPTY_RE = /^(none|n\/a|na|nil|null|-+|—|–|\.+|no)$/i;

  function isLabelPrefix(s) {
    // "SA", "ORI" ... a reply that has only just begun; not yet evidence of an unstructured reply
    s = s.replace(/^[\s>#*_`\-•]+/, '').toUpperCase();
    if (!s) return true;
    for (var i = 0; i < LABELS.length; i++) {
      var l = LABELS[i] + ':';
      if (l.indexOf(s) === 0 || s.indexOf(l) === 0) return true;
    }
    return false;
  }

  function cleanValue(v) {
    v = String(v || '');
    v = v.replace(/\*\*/g, '').replace(/(^|\s)__(?=\S)/g, '$1').replace(/^\s*`+|`+\s*$/g, '');
    return v.replace(/[ \t]+/g, ' ').trim();
  }

  /* ---- LINES: pull complete {...} objects out of a possibly truncated JSON array ---- */

  function scanObjects(s) {
    // returns {objs: [string], closed: bool, tail: bool}   tail = an object was started but not finished
    var start = s.indexOf('[');
    var objs = [];
    if (start < 0) return { objs: objs, closed: false, tail: s.indexOf('{') >= 0 };
    var i = start + 1, n = s.length, depth = 0, inStr = false, esc = false, from = -1, closed = false;
    for (; i < n; i++) {
      var c = s.charAt(i);
      if (inStr) {
        if (esc) esc = false;
        else if (c === '\\') esc = true;
        else if (c === '"') inStr = false;
        continue;
      }
      if (c === '"') { inStr = true; continue; }
      if (c === '{') { if (depth === 0) from = i; depth++; continue; }
      if (c === '}') {
        if (depth > 0) { depth--; if (depth === 0 && from >= 0) { objs.push(s.slice(from, i + 1)); from = -1; } }
        continue;
      }
      if (c === ']' && depth === 0) { closed = true; break; }
    }
    return { objs: objs, closed: closed, tail: depth > 0 };
  }

  function num(v) {
    if (typeof v === 'number') return isFinite(v) ? v : null;
    if (typeof v === 'string' && /^\s*-?\d+(\.\d+)?\s*$/.test(v)) return parseFloat(v);
    return null;
  }

  /* the numbers of an array that is flat ([x0,y0,...]) or made of [x,y] pairs; an entry that is not a finite number is null */
  function numList(a) {
    if (!Array.isArray(a)) return null;
    var flat = [];
    for (var i = 0; i < a.length; i++) {
      var it = a[i];
      if (Array.isArray(it)) { if (it.length === 2) flat.push(num(it[0]), num(it[1])); else flat.push(null, null); } // (a pair is two numbers: a three-number pair would shift every later x and y)
      else flat.push(num(it));
    }
    return flat;
  }

  /* bounding box [x0,y0,x1,y1] of the (x, y) pairs of a list that are both finite; null when fewer than two pairs */
  function pairsBox(flat) {
    var x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity, n = 0;
    for (var i = 0; i + 1 < flat.length; i += 2) {
      if (flat[i] === null || flat[i + 1] === null) continue;
      n++;
      if (flat[i] < x0) x0 = flat[i];
      if (flat[i] > x1) x1 = flat[i];
      if (flat[i + 1] < y0) y0 = flat[i + 1];
      if (flat[i + 1] > y1) y1 = flat[i + 1];
    }
    return n >= 2 ? [x0, y0, x1, y1] : null;
  }

  function normObj(o) {
    if (!o || typeof o !== 'object') return null;
    var b = o.b || o.box || o.bbox || o.bounding_box || null;
    var nb = null;
    if (Array.isArray(b) && b.length >= 4) {
      var a = [num(b[0]), num(b[1]), num(b[2]), num(b[3])];
      if (a.every(function (x) { return x !== null; })) nb = a;
    }
    // q: the four corners. Exactly eight finite numbers (flat or as pairs) make a q; four numbers are a box given under the wrong key; anything else
    // that holds at least two (x, y) pairs only leaves its bounding box behind (qb), for the fall-back
    var nq = null, qb = null;
    var rq = o.q != null ? o.q : o.quad != null ? o.quad : o.corners != null ? o.corners : null;
    var flat = numList(rq);
    if (flat && flat.length) {
      var finite = flat.every(function (x) { return x !== null; });
      if (finite && flat.length === 8) nq = flat;
      else if (finite && flat.length === 4) { if (!nb) nb = flat; }
      else qb = pairsBox(flat);
    }
    var orig = o.o != null ? o.o : o.orig != null ? o.orig : o.original != null ? o.original : o.src != null ? o.src : '';
    var tr = o.t != null ? o.t : o.tr != null ? o.tr : o.translation != null ? o.translation : o.en != null ? o.en : '';
    return { b: nb, q: nq, qb: qb, o: String(orig), t: String(tr) };
  }

  function parseObj(str) {
    try { return JSON.parse(str); } catch (e) { /* try repairs */ }
    var r = str.replace(/,\s*([}\]])/g, '$1').replace(/[“”]/g, '"');
    try { return JSON.parse(r); } catch (e) { /* fall through */ }
    r = r.replace(/'/g, '"');
    try { return JSON.parse(r); } catch (e) { return null; }
  }

  function parseLines(raw) {
    var s = String(raw || '').replace(/```[a-z]*/gi, ' ');
    var sc = scanObjects(s);
    var lines = [];
    for (var i = 0; i < sc.objs.length; i++) {
      var ln = normObj(parseObj(sc.objs[i]));
      if (ln && (ln.o || ln.t || ln.b || ln.q || ln.qb)) lines.push(ln);
    }
    return { lines: lines, truncated: !sc.closed || sc.tail };
  }

  /* ---- main ---- */

  function parseReply(text, opts) {
    var res = {
      say: '', orig: '', read: '', note: '', unsure: '', lines: [],
      structured: false, noteIsFallback: false, linesTruncated: false, preface: '', active: '',
    };
    try {
      text = String(text == null ? '' : text).replace(/\r\n?/g, '\n');
      var rows = text.split('\n');
      var cur = null;
      var acc = { say: [], orig: [], read: [], note: [], unsure: [], lines: [] };
      var pre = [];
      var seen = false;
      var inFence = false;
      for (var i = 0; i < rows.length; i++) {
        var row = rows[i];
        // streaming: a half-written next label ("ORI", "NOT") on the unfinished last row must not flash into the field above
        if (i === rows.length - 1 && !(opts && opts.final) && cur && /^[\s>#*_`\-•]*[A-Za-z]{1,6}:?$/.test(row) && isLabelPrefix(row)) continue;
        var m = LABEL_RE.exec(row);
        // inside a LINES json block a row like `"o": "NOTE: x"` is not at line start so the regex cannot match it;
        // a fenced block is also never a label row
        if (m && !(inFence && cur === 'lines')) {
          cur = m[1].toLowerCase();
          seen = true;
          acc[cur].push(m[2]);
          continue;
        }
        if (/^\s*```/.test(row)) { inFence = !inFence; if (cur === 'lines') continue; }
        if (cur) acc[cur].push(row);
        else pre.push(row);
      }
      if (!seen) {
        var t = text.trim();
        if (!t || (!(opts && opts.final) && isLabelPrefix(t) && t.length < 8 && t.indexOf('\n') < 0)) return res; // nothing yet
        res.structured = false;
        res.noteIsFallback = true;
        res.note = cleanValue(t.replace(/\s*\n\s*/g, ' '));
        return res;
      }
      res.structured = true;
      res.preface = cleanValue(pre.join(' '));
      res.saySynth = false;
      ['say', 'orig', 'read', 'note', 'unsure'].forEach(function (k) {
        var v = cleanValue(acc[k].join(' '));
        if (k !== 'say' && k !== 'orig' && EMPTY_RE.test(v)) v = '';
        res[k] = v;
      });
      // the model sometimes drops the SAY label on the first line: unlabelled text before the first label is the answer
      if (!res.say && res.preface && !acc.say.length) { res.say = res.preface; res.preface = ''; res.saySynth = true; }
      var lp = parseLines(acc.lines.join('\n'));
      res.lines = lp.lines;
      res.linesTruncated = acc.lines.length ? lp.truncated : false;
      res.active = cur || '';
    } catch (e) {
      /* never throw: return what we have */
    }
    return res;
  }


  /* True when a finished reply looks broken enough to retry (e.g. with thinking on): no answer, an answer over 25 words, or the
     model thinking out loud inside a field ("Actually, let me read it carefully...", seen in about 1 in 10 replies with thinking off). */
  var SELF_TALK = /\b(wait|actually|let me|let's|hmm|i need to)\b/i;
  function looksOff(r) {
    if (!r || !r.say) return true;
    if (r.say.split(/\s+/).length > 25) return true;
    return SELF_TALK.test(r.say) || SELF_TALK.test(r.orig);
  }

  /* b: [x0,y0,x1,y1] in the given convention -> integer pixel box in the image of size width x height */
  function boxToPixels(b, convention, width, height) {
    if (!Array.isArray(b) || b.length < 4 || !(width > 0) || !(height > 0)) return null;
    var v = b.slice(0, 4).map(Number);
    if (v.some(function (x) { return !isFinite(x); })) return null;
    var fx = 1, fy = 1;
    if (convention === 'n1000') { fx = width / 1000; fy = height / 1000; }
    else if (convention === 'frac') { fx = width; fy = height; }
    var x0 = v[0] * fx, y0 = v[1] * fy, x1 = v[2] * fx, y1 = v[3] * fy;
    if (x1 < x0) { var t = x0; x0 = x1; x1 = t; }
    if (y1 < y0) { var u = y0; y0 = y1; y1 = u; }
    x0 = Math.max(0, Math.min(width, x0)); x1 = Math.max(0, Math.min(width, x1));
    y0 = Math.max(0, Math.min(height, y0)); y1 = Math.max(0, Math.min(height, y1));
    if (x1 - x0 < 1 || y1 - y0 < 1) return null;
    return [Math.round(x0), Math.round(y0), Math.round(x1), Math.round(y1)];
  }

  /* ---- quadrilaterals (v0.3.1) ---- */
  var QUAD_MIN_RATIO = 0.25; // the shorter of a quadrilateral's two end edges (and of its top and bottom edges) over the longer
  var QUAD_TOL = 2; // px: a corner this far outside the picture is still read as on its edge (and moved onto it); further out the model ran off the picture

  /* twice the signed area of a polygon given as a flat list [x0,y0,x1,y1,...]; positive = clockwise as drawn on a screen with y down */
  function area2(q) {
    var s = 0, n = q.length / 2;
    for (var i = 0; i < n; i++) {
      var j = (i + 1) % n;
      s += q[2 * i] * q[2 * j + 1] - q[2 * j] * q[2 * i + 1];
    }
    return s;
  }

  function validQuad(q, width, height) {
    if (!Array.isArray(q) || q.length !== 8 || !(width > 0) || !(height > 0)) return null;
    var v = [];
    for (var i = 0; i < 8; i++) {
      if (typeof q[i] !== 'number' || !isFinite(q[i])) return null;
      v.push(q[i]);
    }
    for (var k = 0; k < 4; k++) {
      if (v[2 * k] < -QUAD_TOL || v[2 * k] > width + QUAD_TOL || v[2 * k + 1] < -QUAD_TOL || v[2 * k + 1] > height + QUAD_TOL) return null; // ran off the picture
    }
    v = v.map(function (x, i) { return Math.round(Math.max(0, Math.min(i % 2 ? height : width, x)) * 10) / 10; });
    if (!(area2(v) > 40)) return null; // not clockwise, or no area (twice the area: 20 px2)
    var sign = 0;
    for (var e = 0; e < 4; e++) {
      var a = e, b = (e + 1) % 4, c = (e + 2) % 4;
      var ex = v[2 * b] - v[2 * a], ey = v[2 * b + 1] - v[2 * a + 1];
      if (Math.hypot(ex, ey) < 2) return null; // an edge under 2 px: degenerate
      var z = ex * (v[2 * c + 1] - v[2 * b + 1]) - ey * (v[2 * c] - v[2 * b]);
      if (!(z > 1e-6)) return null; // a straight or a reflex corner: not convex (clockwise on the screen = every turn positive)
      sign = 1;
    }
    // a wedge (one end a few pixels high and the other a hundred) passes every test above and would pinch the label to a point: the shorter of the two end edges, and of the top and
    // bottom edges, must be at least a quarter of the longer. (Of 314 real quadrilaterals the model gave in the experiment none came near it: the least was 0.35; a real sign seen at a
    // steep angle can have one end twice as high as the other.)
    var el = function (a, b) { return Math.hypot(v[2 * a] - v[2 * b], v[2 * a + 1] - v[2 * b + 1]); };
    var l1 = el(0, 3), l2 = el(1, 2), t1 = el(0, 1), t2 = el(3, 2);
    if (Math.min(l1, l2) < QUAD_MIN_RATIO * Math.max(l1, l2) || Math.min(t1, t2) < QUAD_MIN_RATIO * Math.max(t1, t2)) return null;
    return sign ? v : null;
  }

  function quadBox(q) {
    return [Math.min(q[0], q[2], q[4], q[6]), Math.min(q[1], q[3], q[5], q[7]), Math.max(q[0], q[2], q[4], q[6]), Math.max(q[1], q[3], q[5], q[7])];
  }

  /* does a raw box [x0,y0,x1,y1] run more than 2 px off the picture? */
  function spillsOff(b, width, height) {
    var v = b.slice(0, 4).map(Number);
    if (v.some(function (x) { return !isFinite(x); })) return false;
    return Math.min(v[0], v[2]) < -2 || Math.min(v[1], v[3]) < -2 || Math.max(v[0], v[2]) > width + 2 || Math.max(v[1], v[3]) > height + 2;
  }

  function lineGeometry(l, width, height) {
    var out = { q: null, b: null, spill: false, fallback: false };
    if (!l) return out;
    var vq = l.q ? validQuad(l.q, width, height) : null;
    if (vq) {
      out.q = vq;
      out.b = boxToPixels(quadBox(vq), 'px', width, height);
      return out;
    }
    var raw = l.q ? quadBox(l.q) : l.qb ? l.qb : l.b; // a bad q is replaced by its bounding box, which is then treated as a b
    if (!raw) return out;
    if (l.q || l.qb) out.fallback = true;
    out.b = boxToPixels(raw, 'px', width, height);
    if (out.b && spillsOff(raw, width, height)) out.spill = true;
    if (!out.b && Array.isArray(raw) && raw.length >= 4) { // a box or corners wholly outside the picture: the model ran off it, and the repaint says "cut off", not "an older version" (a sliver inside it stays as 0.3.0 had it)
      var xs = [Number(raw[0]), Number(raw[2])], ys = [Number(raw[1]), Number(raw[3])];
      if (Math.max.apply(null, xs) < 0 || Math.min.apply(null, xs) > width || Math.max.apply(null, ys) < 0 || Math.min.apply(null, ys) > height) out.spill = true;
    }
    return out;
  }

  var API = { parseReply: parseReply, boxToPixels: boxToPixels, looksOff: looksOff, LABELS: LABELS, validQuad: validQuad, quadBox: quadBox, lineGeometry: lineGeometry, spillsOff: spillsOff, QUAD_TOL: QUAD_TOL, QUAD_MIN_RATIO: QUAD_MIN_RATIO };
  root.PAAParse = API;
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
})(typeof self !== 'undefined' ? self : globalThis);
