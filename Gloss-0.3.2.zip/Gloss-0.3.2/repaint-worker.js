/* Gloss: AI repaint (stage 4), the service worker's part. Classic script (importScripts, after shared.js and repaint-core.js).

   run(job, deps) does one repaint from start to finish and never shows (never even returns the picture of) a result that failed its check:
     1. the picture to repaint (deps.source(): the stored crop, or a fresh screenshot cut to the shape the page planned) and the lines to paint
     2. refuse before spending anything when the writing is cut off or there is nothing to paint (PAARepaint.assess)
     3. the image model letters the English (one call, about 28 s, about 4 cents). Only its LETTERING is taken: the picture that is shown (the composite) is the original with
        the image model's picture let in only where the painted lines are (their corners, grown, with a soft edge: PAARepaint.regionMask / composite), so nothing outside them
        can change. The picture outside the text boxes is still compared with the original, as a test that the model's picture is aligned with it (a shifted or recomposed
        picture would show seams). Haiku reads the COMPOSITE back blind (and, in parallel at the start, the original, so English that was already on the sign is not mistaken
        for something invented); one automatic retry with the firm instruction when any of that fails
        (0.3.2) While the image model draws, Haiku also lists every OTHER piece of writing in the same picture, with four corners each (protectList): those pieces are cut out of what is let in, so
        writing nobody asked to change keeps the original's pixels. A call that fails, or has not answered a few seconds after the image arrives, means no protection (recorded). And each painted
        line is cropped out of the composite and Haiku copies it exactly as drawn (copyLines), so that a stray accent the blind read-back autocorrects ("gamé", "Kadikőy") is seen.
     4. a composite that passed is feathered into a patch (WebP with alpha) and stored under the mark's own key; the page warps it onto the sign.
   Two providers: the image model is on OpenRouter (deps.openrouter), the read-backs are Claude Haiku on the Anthropic API (deps.anthropic): each { key, source }.
   Everything is cancelled by deps.signal (the page closed the port: the cancel button, a deleted mark, a closed tab). Costs are the real usage.cost of each
   call, summed. Nothing here touches the DOM; the only browser APIs are fetch, createImageBitmap and OffscreenCanvas. */
(function (root) {
  'use strict';
  const R = root.PAARepaint;
  const PAA = root.PAA;

  const IMAGES = 'https://openrouter.ai/api/v1/images';
  const IMAGE_TIMEOUT = 240000; // ms (the experiment's slowest run was 37 s)
  const MAX_TRIES = 2; // the first attempt and one automatic retry with the firm instruction
  // 0.3.2: PROTECTION OF OTHER WRITING IS OFF. With it on, the cut that keeps a neighbour's pixels brought back the old lettering of a painted line on a blind judge's 14 signs
  // (the old "Th" over "Delivery", clipped letter tops on "Kadiköy's" and "Warranty") and the product's own check passed them. Off: no list call is made, nothing extra is sent, nothing is counted,
  // no state is recorded, and the composite is the 0.3.1 composite. The pure functions (repaint-core parseKept / keptPieces / keepDecision / keepMask, lettering opts.keep) and their tests stay.
  // deps.protect (true / false), or self.__paaProtect in the worker, overrides the constant for a test that wants the stand-in list; the product sets neither.
  const PROTECT_OTHER_WRITING = false;
  const KEEP_WAIT = 5000; // ms: the list of other writing is waited for this long after the image model's picture arrives, then the repaint goes on without it

  const cancelled = () => { const e = new Error('cancelled'); e.name = 'AbortError'; return e; };
  /* a promise's value, or null when it has not come within ms (the promise itself is left to finish: its cost is counted when it does) */
  function waitFor(p, ms) {
    let t;
    return Promise.race([p, new Promise((r) => { t = setTimeout(() => r(null), ms); })]).finally(() => clearTimeout(t));
  }

  async function blobToDataUrl(blob) {
    const bytes = new Uint8Array(await blob.arrayBuffer());
    let bin = '';
    for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
    return 'data:' + (blob.type || 'image/jpeg') + ';base64,' + btoa(bin);
  }
  const bitmapOf = async (url) => createImageBitmap(await (await fetch(url)).blob());

  /* a bitmap as a JPEG data URL at w x h */
  async function jpegUrl(bmp, w, h, quality) {
    const cv = new OffscreenCanvas(w, h);
    const cx = cv.getContext('2d');
    cx.imageSmoothingQuality = 'high';
    cx.drawImage(bmp, 0, 0, w, h);
    return blobToDataUrl(await cv.convertToBlob({ type: 'image/jpeg', quality: quality }));
  }

  /* the pixels of a bitmap at w x h (for the pixel check) */
  function pixelsOf(bmp, w, h) {
    const cv = new OffscreenCanvas(w, h);
    const cx = cv.getContext('2d', { willReadFrequently: true });
    cx.imageSmoothingQuality = 'high';
    cx.drawImage(bmp, 0, 0, w, h);
    return { w: w, h: h, ch: 4, data: cx.getImageData(0, 0, w, h).data };
  }

  /* ---------- the picture to repaint, cut from a screenshot (a fresh capture) ----------
     g: { rect: {x, y, w, h} CSS px, iw (window.innerWidth) }. The rectangle has one of the shapes the image model outputs; it is cut at the screen's own
     resolution, reduced when its long side is over INPUT_MAX and enlarged (smoothly, at most 4 times) when it is under INPUT_MIN: the model re-draws the whole picture at its own size. */
  async function cutSource(shotUrl, g) {
    const bmp = await bitmapOf(shotUrl);
    try {
      const k = bmp.width / g.iw;
      const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));
      const sx = clamp(Math.round(g.rect.x * k), 0, bmp.width - 1);
      const sy = clamp(Math.round(g.rect.y * k), 0, bmp.height - 1);
      const sw = clamp(Math.round(g.rect.w * k), 1, bmp.width - sx);
      const sh = clamp(Math.round(g.rect.h * k), 1, bmp.height - sy);
      const sz = R.sendSize(sw, sh);
      const cv = new OffscreenCanvas(sz[0], sz[1]);
      const cx = cv.getContext('2d');
      cx.imageSmoothingQuality = 'high';
      cx.drawImage(bmp, sx, sy, sw, sh, 0, 0, sz[0], sz[1]);
      return { url: await blobToDataUrl(await cv.convertToBlob({ type: 'image/jpeg', quality: 0.92 })), w: sz[0], h: sz[1] };
    } finally {
      bmp.close();
    }
  }

  /* ---------- the image model ---------- */
  function errText(raw) {
    try {
      const j = JSON.parse(raw);
      return (j.error && (j.error.message || JSON.stringify(j.error))) || raw;
    } catch (e) {
      return raw;
    }
  }

  /* One image edit through OpenRouter (POST /api/v1/images; checked against GET /api/v1/images/models on 14 Nov: aspect_ratio, quality, input_references).
     o.openrouter: { key, source }. Returns { dataUrl, cost, ms }. A failure is an Error with a plain message (the shared key that ran out says so, with settings: true). */
  async function imageCall(o) {
    const f = o.fetchImpl || fetch;
    const body = {
      model: o.model || R.IMAGE_MODEL,
      prompt: o.prompt,
      n: 1,
      quality: o.quality || R.QUALITY,
      aspect_ratio: o.ratio,
      input_references: [{ type: 'image_url', image_url: { url: o.input } }],
    };
    if (o.signal && o.signal.aborted) throw cancelled();
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), IMAGE_TIMEOUT);
    const onAbort = () => ctl.abort();
    if (o.signal) o.signal.addEventListener('abort', onAbort);
    const t0 = Date.now();
    try {
      let res;
      try {
        res = await f(IMAGES, {
          method: 'POST', signal: ctl.signal, referrerPolicy: 'no-referrer',
          headers: { Authorization: 'Bearer ' + o.openrouter.key, 'Content-Type': 'application/json', 'X-Title': 'Gloss' },
          body: JSON.stringify(body),
        });
      } catch (e) {
        if (o.signal && o.signal.aborted) throw cancelled();
        if (e && e.name === 'AbortError') throw new Error('The image model took too long. Try again.');
        throw new Error('Network error: ' + ((e && e.message) || e));
      }
      let raw;
      try {
        raw = await res.text();
      } catch (e) {
        if (o.signal && o.signal.aborted) throw cancelled();
        throw new Error('The image model took too long. Try again.');
      }
      if (!res.ok) throw PAAProviders.failure('openrouter', res.status, errText(raw).slice(0, 400), o.openrouter.source);
      let j;
      try { j = JSON.parse(raw); } catch (e) { throw new Error('The image model sent something unreadable.'); }
      const d = j.data && j.data[0];
      if (!d || !d.b64_json) throw new Error('The image model sent no picture' + (j.error ? ': ' + errText(JSON.stringify(j)).slice(0, 200) : '.'));
      const mime = d.media_type || (d.b64_json.indexOf('/9j/') === 0 ? 'image/jpeg' : d.b64_json.indexOf('UklGR') === 0 ? 'image/webp' : 'image/png');
      const u = j.usage || {};
      return { dataUrl: 'data:' + mime + ';base64,' + d.b64_json, cost: typeof u.cost === 'number' ? u.cost : 0, ms: Date.now() - t0 };
    } finally {
      clearTimeout(timer);
      if (o.signal) o.signal.removeEventListener('abort', onAbort);
    }
  }

  /* ---------- the read-back ---------- */
  const READBACK = 'You are a careful transcriber. List every piece of readable text in this image that is written in English or Latin letters or digits (signs, boards, labels, phone numbers), verbatim, exactly as spelled, including any misspellings, in reading order. Do not correct, complete or guess. Ignore text you cannot read. Reply with ONE JSON array of strings and nothing else.';

  /* Haiku reads the English / Latin text off a picture, blind (it is not told what should be there). Returns { got: [strings] | null, cost }. */
  async function readBack(url, o) {
    const r = await PAAProviders.streamChat({
      apiKey: o.anthropic.key, keySource: o.anthropic.source, model: PAA.DEFAULT_MODEL, signal: o.signal, fetchImpl: o.fetchImpl,
      prompt: { system: READBACK, messages: [{ role: 'user', content: [{ type: 'text', text: 'Transcribe the English/Latin text.' }, PAA.imageBlock(url)] }] },
    });
    let got = null;
    const s = r.text;
    const a = s.indexOf('['), z = s.lastIndexOf(']');
    if (a >= 0 && z > a) { try { got = JSON.parse(s.slice(a, z + 1)).map(String); } catch (e) { got = null; } }
    return { got: got, cost: r.cost || 0 };
  }

  /* A second, narrower look. The read-back is blind and small text is read differently each time, so a piece that is flagged ("text nobody asked for", a "new"
     number, a number that is "gone") is put to Haiku as a plain yes / no question about the picture it is supposed to be on or in: is there writing like it there (it may be a misreading of small, blurred text)?
     Returns { flags: [bool] (one per item; all false when the answer cannot be read), cost }. */
  const PRESENT = 'You are a careful reader. Each item below is a piece of text that someone else read, from a picture like this one, in small, partly hidden or blurred writing: it may be misspelled or only part of a word. For each item say true if this image contains writing that the item plausibly is (a reading, or a misreading, of it), anywhere in the picture, and false if there is nothing like it. Reply with ONE JSON array of true or false, one per item in the same order, and nothing else.';
  async function presentIn(url, items, o) {
    const r = await PAAProviders.streamChat({
      apiKey: o.anthropic.key, keySource: o.anthropic.source, model: PAA.DEFAULT_MODEL, signal: o.signal, fetchImpl: o.fetchImpl,
      prompt: { system: PRESENT, messages: [{ role: 'user', content: [{ type: 'text', text: 'Items:\n' + items.map((t, i) => (i + 1) + '. ' + JSON.stringify(t)).join('\n') }, PAA.imageBlock(url)] }] },
    });
    let flags = items.map(() => false);
    const a = r.text.indexOf('['), z = r.text.lastIndexOf(']');
    if (a >= 0 && z > a) { try { const v = JSON.parse(r.text.slice(a, z + 1)); if (Array.isArray(v) && v.length === items.length) flags = v.map((x) => x === true); } catch (e) { /* none confirmed */ } }
    return { flags: flags, cost: r.cost || 0 };
  }

  /* ---------- writing nobody asked to change (0.3.2) ----------
     The same picture the image model gets (so the corners are in the same pixels), the list of the lines being painted, and the question: every OTHER piece of writing, with four corners each.
     The corners are asked for in the words of the answer instructions (design/system-prompt-v8.txt, LINES), which Haiku follows well. Returns { pieces: [{ t, q }] | null (null: no list could be read),
     bad, cost, ms }. */
  const PROTECT = 'You find writing in a photo of a street scene. You are given the size of the picture in pixels and a list of pieces of writing that are being replaced. List EVERY OTHER piece of writing you can see in the picture, however small, faint, partly hidden, vertical or at an angle: shop and brand names, phone numbers, prices, web addresses, door and window lettering, the writing on other signs and buildings, the small print under a sign, a watermark. Do not list the pieces that are being replaced, and do not list anything that is not writing (pictures, logos without letters, windows). One entry per line of text: words printed together on one line are one entry, do not split a line into words. Reply with ONE JSON array and nothing else: [{"t":"the text as written","q":[x0,y0,x1,y1,x2,y2,x3,y3]}]. q is the four corners of the quadrilateral that encloses every character of that piece, from its first stroke to its last, taken clockwise from the top left of the text as it is read: top left, top right, bottom right, bottom left. The top and bottom edges follow the slope and perspective of the lettering, so a line that rises, falls or is seen at an angle gets a tilted quadrilateral and level text a rectangle. Pixels of the picture exactly as you receive it (origin top-left, x to the right, y downward, integers); if unsure make it slightly larger, never cut a character off. If there is no other writing, reply [].';
  async function protectList(url, paint, sz, o) {
    const t0 = Date.now();
    const list = paint.map((e, i) => (i + 1) + '. ' + JSON.stringify(String(e.o || '').slice(0, 160))).join('\n');
    const r = await PAAProviders.streamChat({
      apiKey: o.anthropic.key, keySource: o.anthropic.source, model: PAA.DEFAULT_MODEL, signal: o.signal, fetchImpl: o.fetchImpl,
      prompt: { system: PROTECT, messages: [{ role: 'user', content: [{ type: 'text', text: 'Picture size: ' + sz[0] + ' x ' + sz[1] + ' pixels.\nBeing replaced (do not list these):\n' + list }, PAA.imageBlock(url)] }] },
    });
    const parsed = R.parseKept(r.text, sz[0], sz[1]);
    return { pieces: parsed ? parsed.pieces : null, bad: parsed ? parsed.bad : 0, cost: r.cost || 0, ms: Date.now() - t0 };
  }

  /* the same, and never an error (a cancel apart): a call that fails, or whose answer is no list, gives { pieces: null, err } and the repaint goes on without protection */
  async function protectSafe(url, paint, sz, o) {
    const t0 = Date.now();
    try {
      return await protectList(url, paint, sz, o);
    } catch (e) {
      if (o.signal && o.signal.aborted) throw cancelled();
      return { pieces: null, bad: 0, cost: (e && e.cost) || 0, ms: Date.now() - t0, err: String((e && e.message) || e).slice(0, 160) };
    }
  }

  /* ---------- the copy of each painted line, exactly as drawn (0.3.2) ----------
     Built on the experiment in BUILD-NOTES (section 23): this wording, a crop of the composite round each painted line (R.markCrop), enlarged. Haiku is not told what the line should say. */
  const COPY = 'You are a forensic transcriber of lettering in a cropped photo of a sign. The lettering may contain misspellings and stray accent marks or dots that do not belong to the language: reproduce them faithfully, because the point is to find them. English text normally has no accent marks at all, so a small mark above a letter of an English word is something you must report, not ignore. Look closely above every vowel. Never replace a letter by the one you would expect. Reply with ONE JSON object {"text": "<the main line, exactly as drawn>"} and nothing else.';
  const copyText = (s) => {
    const a = s.indexOf('{'), z = s.lastIndexOf('}');
    if (a >= 0 && z > a) { try { const j = JSON.parse(s.slice(a, z + 1)); if (j && typeof j.text === 'string') return j.text; } catch (e) { /* the text as it is */ } }
    return s.trim().replace(/^[`"' \n]+|[`"' \n]+$/g, '');
  };
  /* cv: the composite (a canvas); lines: the painted lines in the canvas's own pixels; o.count(cost) is called for every call that was paid. Returns { copies: [string | null per line], n (calls made), failed (calls that gave nothing) }.
     A call that fails costs the check nothing but its own answer: that line is not judged (a cancel ends the whole run, as everywhere). */
  async function copyLines(cv, lines, o) {
    const t0 = Date.now();
    const copies = lines.map(() => null);
    let cost = 0;
    const jobs = [];
    lines.forEach((e, i) => {
      if (jobs.length >= R.MARKS.LINES_MAX || !/\p{L}/u.test(String(e.t || ''))) return;
      const c = R.markCrop(e, cv.width, cv.height);
      if (c) jobs.push({ i: i, c: c });
    });
    let failed = 0;
    await Promise.all(jobs.map(async (j) => {
      const sh = new OffscreenCanvas(j.c.ow, j.c.oh);
      const cx = sh.getContext('2d');
      cx.imageSmoothingQuality = 'high';
      cx.drawImage(cv, j.c.x, j.c.y, j.c.w, j.c.h, 0, 0, j.c.ow, j.c.oh);
      const url = await blobToDataUrl(await sh.convertToBlob({ type: 'image/jpeg', quality: 0.92 }));
      try {
        const r = await PAAProviders.streamChat({
          apiKey: o.anthropic.key, keySource: o.anthropic.source, model: PAA.DEFAULT_MODEL, signal: o.signal, fetchImpl: o.fetchImpl,
          prompt: { system: COPY, messages: [{ role: 'user', content: [{ type: 'text', text: 'Transcribe the lettering exactly as drawn.' }, PAA.imageBlock(url)] }] },
        });
        cost += r.cost || 0;
        if (o.count) o.count(r.cost || 0);
        copies[j.i] = copyText(r.text);
      } catch (e) {
        if (o.signal && o.signal.aborted) throw cancelled();
        if (e && e.cost) { cost += e.cost; if (o.count) o.count(e.cost); }
        failed++;
      }
    }));
    return { copies: copies, n: jobs.length, failed: failed, cost: Math.round(cost * 1e6) / 1e6, ms: Date.now() - t0 };
  }

  /* ---------- the patch: the result with a feathered edge ----------
     The result at its own size (the model draws at about 1536 px: the lettering is crisper than the screenshot it came from), the outer 6 % of the short
     side fading to nothing so the patch settles into the picture. WebP keeps the alpha at a fraction of a PNG's size. */
  async function makePatch(bmp) {
    const w = bmp.width, h = bmp.height;
    const f = R.featherPx(w, h);
    const cv = new OffscreenCanvas(w, h);
    const cx = cv.getContext('2d');
    cx.drawImage(bmp, 0, 0);
    const mask = new OffscreenCanvas(w, h);
    const mc = mask.getContext('2d');
    mc.filter = 'blur(' + f / 2 + 'px)';
    mc.fillStyle = '#fff';
    mc.fillRect(f, f, w - 2 * f, h - 2 * f);
    cx.globalCompositeOperation = 'destination-in';
    cx.drawImage(mask, 0, 0);
    return { url: await blobToDataUrl(await cv.convertToBlob({ type: 'image/webp', quality: 0.92 })), w: w, h: h };
  }

  /* ---------- the composite: the original, with the image model's picture let in where the painted lines are ----------
     inputUrl: the picture that was sent; rb: the result's bitmap; paint: the lines (b and q in the pixels of the picture that was sent, sz its size). Everything is made at the
     result's size (the original is drawn at it): where the mask is 0 a pixel is the original's own. Returns { canvas, mask: { data, r, covered }, ms } or null when no
     painted line has corners or a box (the caller refuses such a job before the image call, so that does not happen). */
  async function composeResult(inputUrl, rb, paint, sz, opts) {
    const t0 = Date.now();
    const w = rb.width, h = rb.height;
    const kx = w / sz[0], ky = h / sz[1];
    const scaled = paint.map((e) => ({ b: e.b ? [e.b[0] * kx, e.b[1] * ky, e.b[2] * kx, e.b[3] * ky] : null, q: e.q ? e.q.map((v, i) => v * (i % 2 ? ky : kx)) : null, o: e.o, t: e.t }));
    const keep = opts && opts.keep && opts.keep.length ? opts.keep.map((e) => ({ t: e.t, q: e.q.map((v, i) => v * (i % 2 ? ky : kx)) })) : null; // (the kept pieces, in the pixels of the result)
    if (!scaled.some((e) => e.q || e.b)) return null;
    const ob = await bitmapOf(inputUrl);
    let o, r;
    try {
      const co = new OffscreenCanvas(w, h);
      const xo = co.getContext('2d', { willReadFrequently: true });
      xo.imageSmoothingQuality = 'high';
      xo.drawImage(ob, 0, 0, w, h);
      o = xo.getImageData(0, 0, w, h);
    } finally { ob.close(); }
    const cr = new OffscreenCanvas(w, h);
    const xr = cr.getContext('2d', { willReadFrequently: true });
    xr.drawImage(rb, 0, 0);
    r = xr.getImageData(0, 0, w, h);
    // the lettering, followed by what changed (repaint-core lettering): the model's picture matched to the original's tone and let in only where the painted lines are and what changed beside them
    const L = R.lettering({ w: w, h: h, data: o.data }, { w: w, h: h, data: r.data }, scaled, { wide: !!(opts && opts.mul > 1), keep: keep });
    if (!L) return null;
    const mask = { data: L.data, r: L.r, covered: L.covered, tone: L.tone, grown: L.grown, keptCut: L.keptCut, keptArea: L.keptArea };
    const out = R.composite({ w: w, h: h, data: o.data }, { w: w, h: h, data: L.res }, mask.data);
    const canvas = new OffscreenCanvas(w, h);
    canvas.getContext('2d').putImageData(new ImageData(out, w, h), 0, 0);
    // how well the two pictures agree in the soft edge of what is let in, where a different tone would show as a seam (recorded; before and after the tone match)
    let seamN = 0, seamS = 0, rawS = 0;
    for (let i = 0; i < w * h; i++) {
      const m = mask.data[i];
      if (m > 0.02 && m < 0.98) {
        const j = i * 4, y = 0.299 * o.data[j] + 0.587 * o.data[j + 1] + 0.114 * o.data[j + 2];
        seamS += Math.abs(y - (0.299 * L.res[j] + 0.587 * L.res[j + 1] + 0.114 * L.res[j + 2]));
        rawS += Math.abs(y - (0.299 * r.data[j] + 0.587 * r.data[j + 1] + 0.114 * r.data[j + 2]));
        seamN++;
      }
    }
    return { canvas: canvas, mask: mask, seam: seamN ? Math.round((seamS / seamN) * 10) / 10 : 0, seamRaw: seamN ? Math.round((rawS / seamN) * 10) / 10 : 0, ms: Date.now() - t0, scaled: scaled, orig: root.__paaKeep ? o : null }; // (scaled: the painted lines in the result's pixels; orig: the original at the result's size, for the evidence a test asks for)
  }

  /* a canvas as a PNG data URL (kept only for the evidence a test or a harness asks for with __paaKeep) */
  const pngUrl = async (cv) => blobToDataUrl(await cv.convertToBlob({ type: 'image/png' }));
  async function imageDataUrl(id) {
    const cv = new OffscreenCanvas(id.width, id.height);
    cv.getContext('2d').putImageData(id, 0, 0);
    return pngUrl(cv);
  }
  async function maskUrl(mask, w, h) {
    const cv = new OffscreenCanvas(w, h);
    const id = new ImageData(w, h);
    for (let i = 0; i < w * h; i++) { const v = Math.round(mask.data[i] * 255); id.data[i * 4] = v; id.data[i * 4 + 1] = v; id.data[i * 4 + 2] = v; id.data[i * 4 + 3] = 255; }
    cv.getContext('2d').putImageData(id, 0, 0);
    return pngUrl(cv);
  }

  /* ---------- one repaint ----------
     job: { id, source: 'stored' | 'fresh', lines: [{i, o, t, b | cb, q | cq, spill}], css: {w, h} (fresh: the CSS size of the rectangle the cb boxes and cq corners are in), unreadable }
     deps: { anthropic: { key, source }, openrouter: { key, source }, signal, fetchImpl, phase(name), source() -> { url, w, h }, save(patch) -> Promise }
     Returns { ok: true, patch: {w, h}, stats, check, lines } | { ok: false, kind: 'refused' | 'check' | 'error', why, message, problems, stats, tries }. */
  async function run(job, deps) {
    const acc = {};
    try {
      return await runOnce(job, deps, acc);
    } catch (e) { // money already spent on this run is not lost with it: the error carries the stats so far
      // (the first read of the original is usually still on its way when an image call fails: give it a moment to be counted)
      if (acc.pending) await Promise.race([acc.pending.catch(() => {}), new Promise((r) => setTimeout(r, 4000))]);
      if (e && typeof e === 'object' && acc.stats) e.stats = acc.stats();
      throw e;
    }
  }

  async function runOnce(job, deps, acc) {
    const t0 = Date.now();
    const signal = deps.signal;
    const phase = deps.phase || (() => {});
    const guard = () => { if (signal && signal.aborted) throw cancelled(); };
    const spend = { cost: 0, calls: 0 };
    const protectOn = deps.protect !== undefined ? !!deps.protect : root.__paaProtect !== undefined ? !!root.__paaProtect : PROTECT_OTHER_WRITING; // (the two overrides are test hooks: a harness's deps.protect, or __paaProtect set in the worker; the product sets neither)
    const keepInfo = {}; // (0.3.2, only when the protection is on) what became of it: used / none / late / failed (the last try's)
    const stats = () => { const s = { ms: Date.now() - t0, cost: Math.round(spend.cost * 1e6) / 1e6, calls: spend.calls, model: R.IMAGE_MODEL, quality: R.QUALITY, tries: tries.length }; if (protectOn) s.keep = keepInfo; return s; };
    const tries = [];
    acc.stats = stats;
    const common = { anthropic: deps.anthropic, openrouter: deps.openrouter, signal: signal, fetchImpl: deps.fetchImpl };

    const src = await deps.source();
    guard();
    // the boxes in the pixels of the picture
    const k = job.source === 'fresh' && job.css ? src.w / job.css.w : 1;
    const lines = job.lines.map((l) => {
      const raw = l.b || l.cb, rawQ = l.q || l.cq;
      const b = raw ? raw.map((v) => v * k) : null;
      const q = Array.isArray(rawQ) && rawQ.length === 8 ? rawQ.map((v) => v * k) : null;
      return { i: l.i, o: l.o, t: l.t, b: b, q: q, spill: !!l.spill };
    });
    // a fresh picture was planned roomy (a line near its edge is not "cut off": the page has already refused what really runs off the screen); a stored crop is judged as in 0.3.0
    const a = R.assess(lines, src.w, src.h, { edgeMargin: job.source === 'fresh' ? 0.01 : R.EDGE_MARGIN });
    if (a.cut.length) return { ok: false, kind: 'refused', why: 'cut', problems: [], stats: stats(), cut: a.cut };
    if (!a.paint.length) return { ok: false, kind: 'refused', why: 'nothing', problems: [], stats: stats() };
    if (R.repeated(a.paint).length) return { ok: false, kind: 'refused', why: 'twice', problems: [], stats: stats() }; // two lines were given the same English phrase: the picture would say it twice
    if (a.paint.some((e) => !e.b && !e.q)) return { ok: false, kind: 'refused', why: 'old', problems: [], stats: stats() }; // a line that does not know where it is cannot be let in alone: nothing is painted
    const ratio = R.pickRatio(src.w, src.h);
    if (ratio.off > R.SHAPE_TOL) return { ok: false, kind: 'refused', why: 'shape', problems: [], stats: stats() };

    // what is sent: the picture itself (a screenshot cut is already at most INPUT_MAX; a stored crop is reduced when it is bigger)
    const sz = R.inputSize(src.w, src.h);
    const bmp = await bitmapOf(src.url);
    let input = src.url;
    try {
      if (sz[0] !== src.w || sz[1] !== src.h) input = await jpegUrl(bmp, sz[0], sz[1], 0.92);
    } catch (e) {
      bmp.close();
      throw e;
    }
    // What the ORIGINAL says is read at the scale the result will be read at (the image model draws at about 1536 px on the long side): outside the painted lines the composite IS the
    // original at that scale, so the same small writing is read from the same pixels both times (read at the small size once and the large one later, the reader gave "117 Nguyễn Văn
    // Thoại" the first time and "TP Nguyễn Văn Trỗi" the second, and a good picture was refused for a "lost" number).
    const bsz = Math.max(sz[0], sz[1]) < R.INPUT_MAX ? [Math.round(sz[0] * R.INPUT_MAX / Math.max(sz[0], sz[1])), Math.round(sz[1] * R.INPUT_MAX / Math.max(sz[0], sz[1]))] : sz;
    let baseUrl = input;
    try {
      if (bsz[0] !== sz[0] || bsz[1] !== sz[1]) baseUrl = await jpegUrl(bmp, bsz[0], bsz[1], 0.9);
    } catch (e) {
      bmp.close();
      throw e;
    }
    const sk = sz[0] / src.w;
    const paint = a.paint.map((e) => ({ b: e.b ? e.b.map((v) => v * sk) : null, q: e.q ? e.q.map((v) => v * sk) : null, o: e.o, t: e.t }));
    const wsz = R.workSize(sz[0], sz[1]);
    const orig = pixelsOf(bmp, wsz[0], wsz[1]);
    bmp.close();
    // (the pixel check's text boxes: a tilted line's corners give its bounding box)
    const boxOf = (e) => e.b || (e.q ? [Math.min(e.q[0], e.q[2], e.q[4], e.q[6]), Math.min(e.q[1], e.q[3], e.q[5], e.q[7]), Math.max(e.q[0], e.q[2], e.q[4], e.q[6]), Math.max(e.q[1], e.q[3], e.q[5], e.q[7])] : null);
    const boxesWork = paint.map(boxOf).filter(Boolean).map((b) => b.map((v) => v * (wsz[0] / sz[0])));
    const unreadable = job.unreadable ? String(job.unreadable).slice(0, 160) : '';

    // what the ORIGINAL says in English / Latin letters, read while the image model works
    // (its cost is counted when it comes back, not when the first check needs it: an image call that fails first must not hide a call that was paid)
    // A key problem seen by this read-back (the Claude key ran out) ends the run at once: the image model is told to stop, so a picture is not paid for that could never be checked.
    const stopImage = new AbortController();
    const imageSignal = signal ? (() => { const c = new AbortController(); signal.addEventListener('abort', () => c.abort()); stopImage.signal.addEventListener('abort', () => c.abort()); return c.signal; })() : stopImage.signal;
    let keyFail = null;
    const baseline = readBack(baseUrl, common).catch((e) => {
      if (signal && signal.aborted) return Promise.reject(cancelled());
      if (e && e.settings) { keyFail = e; stopImage.abort(); }
      return { got: null, cost: (e && e.cost) || 0, err: e }; // (a reply cut off at max_tokens was paid for: e.cost; it only means "no baseline")
    }).then((r) => { spend.cost += r.cost || 0; spend.calls++; return r; });
    baseline.catch(() => {}); // (an abort is raised where it is awaited; this only keeps a run that ends before that quiet)
    // 0.3.2: while the image model draws, Haiku lists every OTHER piece of writing in the same picture the image model gets. Never fatal: a failure means no protection, recorded.
    const keptCall = {}; // (the list's own time and cost, for the record)
    const protect = protectOn ? protectSafe(input, paint, sz, common).then((r) => { spend.cost += r.cost || 0; spend.calls++; keptCall.ms = r.ms; keptCall.cost = Math.round((r.cost || 0) * 1e6) / 1e6; return r; }) : null;
    if (protect) protect.catch(() => {});
    acc.pending = protect ? Promise.all([baseline, protect]) : baseline;
    const baseOnce = () => baseline;
    const count = (c) => { spend.cost += c || 0; spend.calls++; }; // (the copies of the painted lines: counted as each call comes back)

    // A read-back that was cut off at max_tokens ends the run with that message (a second image call would be paid for nothing: the check never saw the picture), but what the
    // cut-off call cost is still counted.
    const counted = async (p) => {
      try { return await p; } catch (e) { if (e && e.cost) { spend.cost += e.cost; spend.calls++; } throw e; }
    };

    let problems = [];
    let last = null;
    for (let attempt = 0; attempt < MAX_TRIES; attempt++) {
      guard();
      phase(attempt ? 'retry' : 'paint');
      const instruction = R.buildInstruction(paint, { width: sz[0], height: sz[1], firm: attempt > 0, problems: problems.slice(0, 6), unreadable: unreadable });
      let img;
      try {
        img = await imageCall(Object.assign({ prompt: instruction, ratio: ratio.name, input: input }, common, { signal: imageSignal }));
      } catch (e) {
        if (keyFail && !(signal && signal.aborted)) throw keyFail;
        throw e;
      }
      spend.cost += img.cost;
      spend.calls++;
      guard();
      phase('check');
      const t1 = Date.now();
      // the other writing in the picture (asked while the image model drew): waited for a few seconds at most, else the repaint goes on without it
      let keepList = [];
      if (protect) {
        const tw = Date.now();
        const kd = R.keepDecision(await waitFor(protect, KEEP_WAIT), paint, sz[0], sz[1]);
        const keepWaitMs = Date.now() - tw; // (how long the repaint waited for the list after the image arrived: nothing when the list was ready)
        guard();
        keepList = kd.list;
        Object.keys(keepInfo).forEach((k) => { delete keepInfo[k]; });
        Object.assign(keepInfo, kd.info);
        keepInfo.waitMs = keepWaitMs;
        if (keptCall.ms != null) { keepInfo.ms = keptCall.ms; keepInfo.cost = keptCall.cost; } // (what the call itself took and cost: it ran while the image model drew)
      }
      const rb = await bitmapOf(img.dataUrl);
      const rec = { attempt: attempt, imageMs: img.ms, imageCost: img.cost, problems: [] };
      if (protect) rec.keep = Object.assign({}, keepInfo, { pieces: keepList.map((e) => ({ t: e.t, q: e.q.map((v) => Math.round(v * 10) / 10) })) });
      const kept = root.__paaKeep ? { attempt: attempt, instruction: instruction, dataUrl: img.dataUrl, rec: rec } : null; // (a test hook: the harness sets __paaKeep to look at what came back)
      if (kept) (root.__paaLast = root.__paaLast || []).push(kept);
      let comp = null, narrowJ = null;
      try {
        if (!R.frameOk(sz[0], sz[1], rb.width, rb.height)) {
          rec.problems.push('the picture came back re-framed (' + rb.width + ' x ' + rb.height + ' for ' + sz[0] + ' x ' + sz[1] + ')');
        } else {
          // ALIGNMENT: outside the lettering the model's picture must be the original's picture (the same framing, not shifted, stretched or re-drawn): the composite lets
          // parts of the model's picture in, and a picture that did not line up with the original would show seams there
          const res = pixelsOf(rb, wsz[0], wsz[1]);
          const px = R.pixelCheck(orig, res, boxesWork);
          rec.pixel = px;
          const base = await baseOnce();
          rec.baselineFailed = !base.got;
          rec.baseline = base.got;
          // WHAT WILL BE SHOWN: the original with the model's lettering let in where the painted lines are, read back blind and checked. mul: the region's growth times this (1: as planned)
          const judge = async (mul) => {
            const c = await composeResult(input, rb, paint, sz, { mul: mul, keep: keepList });
            const rsz = R.inputSize(c.canvas.width, c.canvas.height);
            const resJpeg = await jpegUrl(c.canvas, rsz[0], rsz[1], 0.9);
            // each painted line is also copied exactly as drawn (0.3.2), in parallel with the blind read-back: a stray accent is seen there, not in the read-back
            const cpP = copyLines(c.canvas, c.scaled, Object.assign({}, common, { count: count }));
            cpP.catch(() => {});
            const back = await counted(readBack(resJpeg, common));
            spend.cost += back.cost;
            spend.calls++;
            const cp = await cpP;
            // (what the yes / no questions below confirm accumulates: text confirmed on the ORIGINAL joins its read, a number confirmed on the RESULT joins that read;
            //  the second question used to start again from the unconfirmed reads and undo the first answer: a result with one "new" and one "lost" number could never pass)
            let gotX = back.got, baseX = base.got || [], confirmed = null, confirmedPresent = null;
            let ev = R.evaluate(paint, gotX, baseX, cp.copies);
            // text flagged as invented (or a number as new) that is in fact on the ORIGINAL, small enough for the blind read-back to have missed it, is not an invention
            if (!ev.ok && ev.wordsOk && (ev.extra.length || ev.newDigits.length)) {
              const items = ev.extra.concat(ev.newDigits);
              const pr = await counted(presentIn(input, items, common));
              spend.cost += pr.cost; spend.calls++;
              const found = items.filter((x, i) => pr.flags[i]);
              if (found.length) { confirmed = found; baseX = baseX.concat(found); ev = R.evaluate(paint, gotX, baseX, cp.copies); }
            }
            // and a number flagged as gone that is in fact still on the RESULT
            if (!ev.ok && ev.wordsOk && ev.missingDigits.length) {
              const pr = await counted(presentIn(resJpeg, ev.missingDigits, common));
              spend.cost += pr.cost; spend.calls++;
              const found = ev.missingDigits.filter((x, i) => pr.flags[i]);
              if (found.length) { confirmedPresent = found; gotX = gotX.concat(found); ev = R.evaluate(paint, gotX, baseX, cp.copies); }
            }
            return { comp: c, ev: ev, confirmed: confirmed, confirmedPresent: confirmedPresent, copies: cp };
          };
          let j = await judge(1);
          comp = j.comp;
          rec.region = { covered: Math.round(comp.mask.covered * 1000) / 1000, grown: Math.round(comp.mask.grown * 1000) / 1000, tone: Math.round(comp.mask.tone * 10) / 10, r: comp.mask.r, seam: comp.seam, seamRaw: comp.seamRaw, composeMs: comp.ms, mul: 1, keptArea: Math.round((comp.mask.keptArea || 0) * 1000) / 1000, keptCut: Math.round((comp.mask.keptCut || 0) * 1000) / 1000 };
          // The region follows the corners the model gave, and a corner can be off by a line's height. When the check fails because the region cut the lettering (a painted line not read
          // back in full, old writing still showing), the composite is made once more with a wider region (REGION.WIDEN) from the same picture of the image model and
          // checked again, with no second image call (a read of a few tenths of a cent). Only a composite that passes its check is shown; if the wider one fails too its faults are the ones told.
          const aligned = px.ok && px.inked;
          if (!j.ev.ok && aligned && !(j.ev.wordsOk && j.ev.goneOk) && R.REGION.WIDEN > 1) {
            rec.narrow = { ok: false, problems: R.explain(j.ev, paint), covered: rec.region.covered, r: rec.region.r, seam: rec.region.seam, words: j.ev.wordsOk, digits: j.ev.digitsOk, noExtra: j.ev.noExtra, gone: j.ev.goneOk, accents: j.ev.accentsOk, got: j.ev.got };
            narrowJ = j;
            const j2 = await judge(R.REGION.WIDEN);
            rec.widened = { ok: j2.ev.ok, covered: Math.round(j2.comp.mask.covered * 1000) / 1000, r: j2.comp.mask.r, seam: j2.comp.seam, problems: R.explain(j2.ev, paint), words: j2.ev.wordsOk, digits: j2.ev.digitsOk, noExtra: j2.ev.noExtra, got: j2.ev.got };
            j = j2; comp = j2.comp; rec.region = { covered: rec.widened.covered, r: j2.comp.mask.r, seam: j2.comp.seam, composeMs: j2.comp.ms, mul: R.REGION.WIDEN, keptArea: Math.round((j2.comp.mask.keptArea || 0) * 1000) / 1000, keptCut: Math.round((j2.comp.mask.keptCut || 0) * 1000) / 1000 };
          }
          const ev = j.ev;
          if (kept && narrowJ) { kept.narrowComposite = await pngUrl(narrowJ.comp.canvas); kept.narrowMask = await maskUrl(narrowJ.comp.mask, narrowJ.comp.canvas.width, narrowJ.comp.canvas.height); }
          if (kept) { kept.composite = await pngUrl(comp.canvas); kept.mask = await maskUrl(comp.mask, comp.canvas.width, comp.canvas.height); kept.size = [comp.canvas.width, comp.canvas.height]; kept.origAtResult = await imageDataUrl(comp.orig); }
          rec.marks = { n: j.copies.n, failed: j.copies.failed, cost: j.copies.cost, ms: j.copies.ms, copies: j.copies.copies };
          if (j.confirmed) rec.confirmed = j.confirmed;
          if (j.confirmedPresent) rec.confirmedPresent = j.confirmedPresent;
          rec.words = ev.wordsOk; rec.digits = ev.digitsOk; rec.noExtra = ev.noExtra; rec.gone = ev.goneOk; rec.accents = ev.accentsOk; rec.stayed = ev.stayed; rec.accentFaults = ev.accents; rec.got = ev.got;
          if (!ev.ok) rec.problems.push.apply(rec.problems, R.explain(ev, paint));
          if (!px.inked) rec.problems.push('the lettering was not repainted (the picture inside the text boxes hardly changed)');
          if (!px.ok && px.inked) {
            if (px.blob > R.BLOB_MAX) rec.problems.push('part of the picture outside the lettering was changed (a block of it differs by ' + px.blob + ' grey levels)');
            else rec.problems.push('the picture outside the lettering changed too much (grey ' + px.mad + ', colour ' + px.col + ')');
          }
        }
        rec.ok = rec.problems.length === 0;
        rec.checkMs = Date.now() - t1;
        tries.push(rec);
        if (rec.ok) {
          const patch = await makePatch(comp.canvas); // (the composite, at the model's own size)
          patch.t = Date.now(); // the token that ties the stored picture to the record (rec.repaint.img.t): the page checks it when it loads the picture
          guard();
          const saved = await deps.save(patch);
          if (saved === false) return { ok: false, kind: 'error', why: 'gone', message: 'This note was deleted while its repaint was being made.', problems: [], stats: stats(), tries: tries };
          return { ok: true, patch: { w: patch.w, h: patch.h, t: patch.t }, stats: stats(), tries: tries, lines: paint.map((e) => ({ o: e.o, t: e.t })), source: job.source, ratio: ratio.name, input: sz };
        }
        problems = rec.problems;
        last = rec;
      } finally {
        rb.close();
      }
    }
    return { ok: false, kind: 'check', why: 'check', problems: last ? last.problems : problems, stats: stats(), tries: tries };
  }

  root.PAARun = { run: run, cutSource: cutSource, imageCall: imageCall, readBack: readBack, presentIn: presentIn, protectList: protectList, protectSafe: protectSafe, copyLines: copyLines, makePatch: makePatch, composeResult: composeResult, MAX_TRIES: MAX_TRIES, KEEP_WAIT: KEEP_WAIT, PROTECT_OTHER_WRITING: PROTECT_OTHER_WRITING };
})(typeof self !== 'undefined' ? self : globalThis);
