/* Gloss: snapping a model's box to the ink, and reading the sign's colours (stage 3). Pure: no DOM, no Chrome. Loaded by the
   service worker (importScripts) and by node tests.

   The model's LINES boxes are approximate (median overlap with the true text box 0.58; bottoms run short; about 9 % on the wrong
   line). The text is where the contrast energy is, so each edge is pulled to the tight extent of the high-contrast pixels within a
   small margin (6 % of the box size: see DEFAULTS), never into a neighbouring line's box. Then, from the same pixels: the colour of the sign
   round the text (the median of a thin band just outside the box) and the colour of the lettering itself (when it clearly differs).

   img = { data: Uint8ClampedArray | Uint8Array, width, height, channels: 3 | 4 }   (RGB or RGBA, row by row)
   box = [x0, y0, x1, y1] in pixels of that image.

   analyse(img, boxes, opts) is the one call the worker makes: for every box { sb (the snapped box, or the model's own when snapping
   found nothing better), moved (true when it changed), bg [r,g,b] | null, fg [r,g,b] | null, ang (the lettering's tilt in degrees | null) }.

   v0.3.1: the model may give each line four corners (a quadrilateral q = [x0,y0,x1,y1,x2,y2,x3,y3], pixels of the picture, clockwise from the top
   left of the text as read) instead of a box. Such a line is NOT snapped (see "QUAD REFINEMENT" below) and has no tilt to measure (the quadrilateral is
   the slope); what is read from the pixels is the sign's colour and the lettering's, inside the quadrilateral. analyseQuads(img, quads) does that: it
   rectifies each quadrilateral into a level patch through the homography of its four corners (with a margin round it) and reads the colours there
   with the same code as for a box. v0.3.2: it also says how far the sign's own background runs on past each end of the line (xr, freeRun: where a tight label may be lengthened). */
(function (root) {
  'use strict';

  const DEFAULTS = {
    margin: 0.06, // how far an edge may GROW outward, as a share of the box's own size (an edge may shrink inward as far as the ink goes).
                  // The brief said 30 %: measured on the evalset it made the median overlap WORSE (0.57 -> 0.54: it grabbed the sign's border and
                  // the neighbouring clutter); 6 % made it better (0.57 -> 0.65). See test/snap-eval.mjs and BUILD-NOTES.
    inkRel: 0.35, // a pixel is ink when its edge energy is above this share of the box's own strong energy (and above inkMin)
    inkMin: 14, // ... and above this (mean channel difference over two pixels, 0 to 255)
    rowRel: 0.2, // a row is inky when its ink count is at least this share of the box's typical row count (and above rowMin)
    rowMin: 2,
    gapY: 0.05, // an inky stretch continues across a gap of this many line heights (at least 2 px)
    gapX: 0.3, // across the words of one line: this many line heights
    minKeep: 0.3, // never shrink a side to less than this share of the box
    pad: 0.06, // breathing room round the ink, as a share of the line height (at least 1 px)
    bandMax: 8, // the thin band for the sign's colour: at most this many px
  };

  const clamp = (v, lo, hi) => (v < lo ? lo : v > hi ? hi : v);
  const area = (b) => Math.max(0, b[2] - b[0]) * Math.max(0, b[3] - b[1]);
  function inter(a, b) {
    return area([Math.max(a[0], b[0]), Math.max(a[1], b[1]), Math.min(a[2], b[2]), Math.min(a[3], b[3])]);
  }
  const overlapX = (a, b) => Math.min(a[2], b[2]) - Math.max(a[0], b[0]);
  const overlapY = (a, b) => Math.min(a[3], b[3]) - Math.max(a[1], b[1]);

  /* edge energy of a region, as a Float32Array (w x h): the mean over the colour channels of |c(x+1,y) - c(x-1,y)| + |c(x,y+1) - c(x,y-1)| */
  function energy(img, x0, y0, x1, y1) {
    const W = img.width, H = img.height, ch = img.channels || 4, d = img.data;
    const w = x1 - x0, h = y1 - y0;
    const out = new Float32Array(w * h);
    for (let y = 0; y < h; y++) {
      const yy = y0 + y;
      const ya = Math.max(0, yy - 1), yb = Math.min(H - 1, yy + 1);
      for (let x = 0; x < w; x++) {
        const xx = x0 + x;
        const xa = Math.max(0, xx - 1), xb = Math.min(W - 1, xx + 1);
        const i1 = (yy * W + xa) * ch, i2 = (yy * W + xb) * ch, i3 = (ya * W + xx) * ch, i4 = (yb * W + xx) * ch;
        out[y * w + x] = (Math.abs(d[i1] - d[i2]) + Math.abs(d[i1 + 1] - d[i2 + 1]) + Math.abs(d[i1 + 2] - d[i2 + 2]) +
          Math.abs(d[i3] - d[i4]) + Math.abs(d[i3 + 1] - d[i4 + 1]) + Math.abs(d[i3 + 2] - d[i4 + 2])) / 3;
      }
    }
    return out;
  }

  const percentile = (arr, p) => {
    if (!arr.length) return 0;
    const s = Array.prototype.slice.call(arr).sort((a, b) => a - b);
    return s[Math.min(s.length - 1, Math.floor(p * s.length))];
  };

  /* The search region round a box: the box plus the margin, inside the picture, and never reaching into a neighbouring line's box.
     A neighbour above, below, left or right (it must share some of the other axis) limits that side to the half way point between
     the two boxes' centres, but a side never has to move inward because of a neighbour: boxes that already overlap keep their edge. */
  function searchRegion(b, others, W, H, o) {
    const bw = b[2] - b[0], bh = b[3] - b[1];
    const mx = o.margin * bw, my = o.margin * bh;
    const R = [Math.max(0, Math.floor(b[0] - mx)), Math.max(0, Math.floor(b[1] - my)), Math.min(W, Math.ceil(b[2] + mx)), Math.min(H, Math.ceil(b[3] + my))];
    const cx = (b[0] + b[2]) / 2, cy = (b[1] + b[3]) / 2;
    for (const q of others) {
      if (!q) continue;
      const qcx = (q[0] + q[2]) / 2, qcy = (q[1] + q[3]) / 2;
      if (overlapX(b, q) > 0.15 * Math.min(bw, q[2] - q[0])) {
        if (qcy > cy) R[3] = Math.min(R[3], Math.max(Math.ceil(b[3]), Math.floor((cy + qcy) / 2)));
        else if (qcy < cy) R[1] = Math.max(R[1], Math.min(Math.floor(b[1]), Math.ceil((cy + qcy) / 2)));
      }
      if (overlapY(b, q) > 0.15 * Math.min(bh, q[3] - q[1])) {
        if (qcx > cx) R[2] = Math.min(R[2], Math.max(Math.ceil(b[2]), Math.floor((cx + qcx) / 2)));
        else if (qcx < cx) R[0] = Math.max(R[0], Math.min(Math.floor(b[0]), Math.ceil((cx + qcx) / 2)));
      }
    }
    return R;
  }

  /* The extent of the inky entries of a profile [lo, hi) that belongs to the box [blo, bhi): from the first inky entry inside the box to
     the last, then outward across gaps of at most `gap` entries (so a letter's descender or the next word is taken, a separate clutter
     is not). null when the box holds no ink. */
  function extent(inky, lo, hi, blo, bhi, gap) {
    let first = -1, last = -1;
    for (let i = Math.max(lo, blo); i < Math.min(hi, bhi); i++) if (inky[i - lo]) { if (first < 0) first = i; last = i; }
    if (first < 0) return null;
    let a = first, b = last;
    for (let i = first - 1, g = 0; i >= lo && g <= gap; i--) { if (inky[i - lo]) { a = i; g = 0; } else g++; }
    for (let i = last + 1, g = 0; i < hi && g <= gap; i++) { if (inky[i - lo]) { b = i; g = 0; } else g++; }
    return [a, b + 1];
  }

  /* One box snapped to the ink. Returns { box, moved }. */
  function refineBox(img, b, others, opts) {
    const o = Object.assign({}, DEFAULTS, opts || {});
    const W = img.width, H = img.height;
    const orig = [clamp(Math.round(b[0]), 0, W), clamp(Math.round(b[1]), 0, H), clamp(Math.round(b[2]), 0, W), clamp(Math.round(b[3]), 0, H)];
    const bw = orig[2] - orig[0], bh = orig[3] - orig[1];
    const keep = { box: orig, moved: false };
    if (bw < 6 || bh < 6) return keep;
    const R = searchRegion(orig, others || [], W, H, o);
    const rw = R[2] - R[0], rh = R[3] - R[1];
    if (rw < 6 || rh < 6) return keep;
    const E = energy(img, R[0], R[1], R[2], R[3]);
    // a neighbouring line's box is not ours: its lettering is not ink for this box (the model's boxes can overlap a little)
    for (const q of others || []) {
      if (!q) continue;
      const qx0 = Math.max(R[0], Math.round(q[0]) - 1), qx1 = Math.min(R[2], Math.round(q[2]) + 1), qy0 = Math.max(R[1], Math.round(q[1]) - 1), qy1 = Math.min(R[3], Math.round(q[3]) + 1); // (the energy of a pixel looks one pixel either way)
      for (let y = qy0; y < qy1; y++) for (let x = qx0; x < qx1; x++) E[(y - R[1]) * rw + (x - R[0])] = 0;
    }
    // what counts as ink is judged against the box's own strong edges (text is the strongest thing in it)
    const inside = [];
    for (let y = Math.max(R[1], orig[1]); y < Math.min(R[3], orig[3]); y++) {
      for (let x = Math.max(R[0], orig[0]); x < Math.min(R[2], orig[2]); x++) inside.push(E[(y - R[1]) * rw + (x - R[0])]);
    }
    if (!inside.length) return keep;
    const strong = percentile(inside, 0.92);
    const thr = Math.max(o.inkMin, o.inkRel * strong);
    if (strong < o.inkMin * 1.5) return keep; // nothing in the box stands out from its background: nothing to snap to
    let top = orig[1], bottom = orig[3], left = orig[0], right = orig[2];
    for (let pass = 0; pass < 2; pass++) {
      // rows: ink pixels per row across the columns of the current box (plus the margin on both sides)
      const cx0 = Math.max(R[0], pass ? left : orig[0]), cx1 = Math.min(R[2], pass ? right : orig[2]);
      const cnt = new Float32Array(rh);
      for (let y = 0; y < rh; y++) {
        let c = 0;
        for (let x = cx0; x < cx1; x++) if (E[y * rw + (x - R[0])] > thr) c++;
        cnt[y] = c;
      }
      const inRows = [];
      for (let y = Math.max(R[1], top); y < Math.min(R[3], bottom); y++) inRows.push(cnt[y - R[1]]);
      const typical = percentile(inRows, 0.75);
      const rowThr = Math.max(o.rowMin, o.rowRel * typical);
      const inky = new Uint8Array(rh);
      for (let y = 0; y < rh; y++) inky[y] = cnt[y] >= rowThr ? 1 : 0;
      const gy = Math.max(2, Math.round(o.gapY * bh));
      const ry = extent(inky, R[1], R[3], pass ? top : orig[1], pass ? bottom : orig[3], gy);
      if (!ry) return keep;
      top = ry[0];
      bottom = ry[1];
      // columns: ink pixels per column within the rows found
      const colCnt = new Float32Array(rw);
      for (let x = 0; x < rw; x++) {
        let c = 0;
        for (let y = top; y < bottom; y++) if (E[(y - R[1]) * rw + x] > thr) c++;
        colCnt[x] = c;
      }
      const colThr = Math.max(1, 0.12 * (bottom - top));
      const colInky = new Uint8Array(rw);
      for (let x = 0; x < rw; x++) colInky[x] = colCnt[x] >= colThr ? 1 : 0;
      const gx = Math.max(3, Math.round(o.gapX * (bottom - top)));
      const rx = extent(colInky, R[0], R[2], orig[0], orig[2], gx);
      if (!rx) return keep;
      left = rx[0];
      right = rx[1];
    }
    const lh = bottom - top;
    const pd = Math.max(1, Math.round(o.pad * lh));
    const out = [clamp(left - pd, R[0], W), clamp(top - pd, R[1], H), clamp(right + pd, 0, R[2]), clamp(bottom + pd, 0, R[3])];
    if (out[2] - out[0] < o.minKeep * bw || out[3] - out[1] < o.minKeep * bh) return keep;
    const moved = out.some((v, i) => Math.abs(v - orig[i]) >= 1);
    return { box: out, moved: moved };
  }

  /* ---------- colours ---------- */

  const median = (arr) => {
    const s = Array.prototype.slice.call(arr).sort((a, b) => a - b);
    return s.length ? s[s.length >> 1] : 0;
  };

  /* median colour of the thin band just outside the box (a gap of 1 px, then the band), leaving out the pixels that lie in other lines' boxes */
  function bandColor(img, b, others, opts) {
    const o = Object.assign({}, DEFAULTS, opts || {});
    const W = img.width, H = img.height, ch = img.channels || 4, d = img.data;
    const bh = b[3] - b[1];
    const t = clamp(Math.round(bh * 0.15), 2, o.bandMax);
    const x0 = Math.max(0, b[0] - 1 - t), y0 = Math.max(0, b[1] - 1 - t), x1 = Math.min(W, b[2] + 1 + t), y1 = Math.min(H, b[3] + 1 + t);
    const rs = [], gs = [], bs = [];
    for (let y = y0; y < y1; y++) {
      for (let x = x0; x < x1; x++) {
        if (x >= b[0] - 1 && x < b[2] + 1 && y >= b[1] - 1 && y < b[3] + 1) continue; // the box and its 1 px gap
        let skip = false;
        for (let k = 0; k < others.length; k++) {
          const q = others[k];
          if (q && x >= q[0] && x < q[2] && y >= q[1] && y < q[3]) { skip = true; break; }
        }
        if (skip) continue;
        const i = (y * W + x) * ch;
        rs.push(d[i]); gs.push(d[i + 1]); bs.push(d[i + 2]);
      }
    }
    if (rs.length < 12) return null;
    return [median(rs), median(gs), median(bs)];
  }

  /* the colour of the sign's face inside the box: the median of the pixels that are NOT ink. Returns { color, share } (share = how much of the
     box that is), or null when there are too few. */
  function insideColor(img, b) {
    const W = img.width, ch = img.channels || 4, d = img.data;
    const E = energy(img, b[0], b[1], b[2], b[3]);
    const w = b[2] - b[0];
    const rs = [], gs = [], bs = [];
    for (let y = b[1]; y < b[3]; y++) {
      for (let x = b[0]; x < b[2]; x++) {
        if (E[(y - b[1]) * w + (x - b[0])] > DEFAULTS.inkMin) continue;
        const i = (y * W + x) * ch;
        rs.push(d[i]); gs.push(d[i + 1]); bs.push(d[i + 2]);
      }
    }
    if (rs.length < 20) return null;
    return { color: [median(rs), median(gs), median(bs)], share: rs.length / Math.max(1, (b[2] - b[0]) * (b[3] - b[1])) };
  }

  const dist = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2]);

  /* the dominant colour of the lettering: the median of the pixels inside the box that are far from the background colour, when there
     are enough of them and they are clearly different. null otherwise (the label then picks black or white for contrast). */
  function inkColor(img, b, bg) {
    if (!bg) return null;
    const W = img.width, ch = img.channels || 4, d = img.data;
    const far = [];
    let n = 0;
    for (let y = b[1]; y < b[3]; y++) {
      for (let x = b[0]; x < b[2]; x++) {
        n++;
        const i = (y * W + x) * ch;
        const p = [d[i], d[i + 1], d[i + 2]];
        const dd = dist(p, bg);
        if (dd >= 70) far.push({ p: p, dd: dd });
      }
    }
    if (n < 20 || far.length < Math.max(8, 0.05 * n)) return null;
    far.sort((a, b2) => b2.dd - a.dd);
    const top = far.slice(0, Math.max(6, Math.round(far.length * 0.5))); // the farthest half: not the anti-aliased edges
    return [median(top.map((f) => f.p[0])), median(top.map((f) => f.p[1])), median(top.map((f) => f.p[2]))];
  }

  /* How far the lettering in the box is tilted, in degrees (positive = the line runs downhill to the right). Read from where the lettering sits in
     each column: the centre of the lettering's pixels in every column across the box, and the least squares line through those centres (weighted by
     how many pixels the column has), so tall letters do not hide a slope (the principal axis does: a short word of tall letters reads half its
     slope). The lettering's pixels are the ones that lie beyond the lettering's own colour on the way from the sign's colour (bg, fg: `ink` and
     `analyse` have them); without both colours, the strongest edges stand in (which a busy sign face confuses). null when there is too little to
     say. A level line reads near 0 (95 % of real level lines under 5 degrees); a sign seen at a slant reads 10 or more. The label is always level,
     so ovfit.js refuses a tilted line. */
  function tilt(img, b, bg, fg) {
    const w = b[2] - b[0], h = b[3] - b[1];
    if (w < 8 || h < 6) return null;
    const ch = img.channels || 4, d = img.data, W = img.width;
    let hit;
    if (bg && fg && dist(bg, fg) > 40) {
      const v = [fg[0] - bg[0], fg[1] - bg[1], fg[2] - bg[2]], vv = v[0] * v[0] + v[1] * v[1] + v[2] * v[2];
      hit = (x, y) => { const i = ((b[1] + y) * W + b[0] + x) * ch; return ((d[i] - bg[0]) * v[0] + (d[i + 1] - bg[1]) * v[1] + (d[i + 2] - bg[2]) * v[2]) / vv > 0.8; };
    } else {
      const E = energy(img, b[0], b[1], b[2], b[3]);
      const thr = Math.max(DEFAULTS.inkMin, DEFAULTS.inkRel * percentile(E, 0.92));
      hit = (x, y) => E[y * w + x] > thr;
    }
    let n = 0, sw = 0, sx = 0, sy = 0, cols = 0;
    const cy = new Float32Array(w), cw = new Float32Array(w);
    for (let x = 0; x < w; x++) {
      let c = 0, s = 0;
      for (let y = 0; y < h; y++) if (hit(x, y)) { c++; s += y; }
      if (c >= 2) { cy[x] = s / c; cw[x] = c; sw += c; sx += c * x; sy += c * cy[x]; cols++; n += c; }
    }
    if (n < 40 || cols < 0.3 * w) return null;
    const mx = sx / sw, my = sy / sw;
    let sxx = 0, sxy = 0;
    for (let x = 0; x < w; x++) if (cw[x]) { sxx += cw[x] * (x - mx) * (x - mx); sxy += cw[x] * (x - mx) * (cy[x] - my); }
    if (sxx < 1e-6) return null;
    return (Math.atan2(sxy, sxx) * 180) / Math.PI;
  }

  /* The sign's colour and the lettering's colour for one box (the snapped one): the band outside it, or, where the box took in the sign's edge or trim and the
     band is the wall or the roof beyond it (Kani Doraku: a dark roof round a cream sign), the face between the letters: where the two disagree clearly
     and the box is mostly face, the inside wins. */
  function colourOf(img, box, others, opts) {
    let bg = bandColor(img, box, others, opts);
    const face = insideColor(img, box);
    if (face && (!bg || (face.share >= 0.3 && dist(bg, face.color) > 45))) bg = face.color;
    return { bg: bg, fg: inkColor(img, box, bg) };
  }

  /* ---------- the one call ---------- */
  /* opts.skip (optional): an array parallel to boxes; a box marked true is only there as a neighbour (a line that has a quadrilateral and is read by analyseQuads): it is not
     snapped and its result is null, but the others keep out of its way. */
  function analyse(img, boxes, opts) {
    const skip = (opts && opts.skip) || [];
    const bx = boxes.map((b) => (b ? [Math.round(b[0]), Math.round(b[1]), Math.round(b[2]), Math.round(b[3])] : null));
    const snapped = bx.map((b, i) => {
      if (!b) return null;
      if (skip[i]) return { box: b, moved: false, skipped: true };
      const r = refineBox(img, b, bx.filter((q, j) => j !== i), opts);
      return { box: r.box, moved: r.moved };
    });
    const sbs = snapped.map((s) => (s ? s.box : null));
    return snapped.map((s, i) => {
      if (!s || s.skipped) return null;
      const others = sbs.filter((q, j) => j !== i);
      // the sign's colour: the band just outside the box, which is the sign's face when the box hugs the lettering (see colourOf)
      const c = colourOf(img, s.box, others, opts);
      return { sb: s.box, moved: s.moved, bg: c.bg, fg: c.fg, ang: tilt(img, s.box, c.bg, c.fg) };
    });
  }

  /* ---------- quadrilaterals (v0.3.1) ---------- */

  /* The homography that takes the four points src to the four points dst: [a,b,c,d,e,f,g,h] with X = (ax+by+c)/(gx+hy+1), Y = (dx+ey+f)/(gx+hy+1). null when singular. */
  function homography4(src, dst) {
    const A = [], r = [];
    for (let i = 0; i < 4; i++) {
      const x = src[i][0], y = src[i][1], X = dst[i][0], Y = dst[i][1];
      A.push([x, y, 1, 0, 0, 0, -x * X, -y * X]); r.push(X);
      A.push([0, 0, 0, x, y, 1, -x * Y, -y * Y]); r.push(Y);
    }
    for (let c = 0; c < 8; c++) { // Gauss with partial pivoting
      let p = c;
      for (let k = c + 1; k < 8; k++) if (Math.abs(A[k][c]) > Math.abs(A[p][c])) p = k;
      if (Math.abs(A[p][c]) < 1e-12) return null;
      [A[c], A[p]] = [A[p], A[c]]; [r[c], r[p]] = [r[p], r[c]];
      for (let k = c + 1; k < 8; k++) {
        const f = A[k][c] / A[c][c];
        if (!f) continue;
        for (let j = c; j < 8; j++) A[k][j] -= f * A[c][j];
        r[k] -= f * r[c];
      }
    }
    const h = new Array(8);
    for (let c = 7; c >= 0; c--) {
      let v = r[c];
      for (let j = c + 1; j < 8; j++) v -= A[c][j] * h[j];
      h[c] = v / A[c][c];
    }
    return h;
  }
  function mapH(h, x, y) {
    const w = h[6] * x + h[7] * y + 1;
    if (!(w > 1e-9)) return null;
    return [(h[0] * x + h[1] * y + h[2]) / w, (h[3] * x + h[4] * y + h[5]) / w];
  }
  function bilinear(img, x, y, out) {
    const W = img.width, H = img.height, ch = img.channels || 4, d = img.data;
    x = Math.min(W - 1, Math.max(0, x - 0.5)); y = Math.min(H - 1, Math.max(0, y - 0.5));
    const x0 = Math.floor(x), y0 = Math.floor(y), x1 = Math.min(W - 1, x0 + 1), y1 = Math.min(H - 1, y0 + 1), fx = x - x0, fy = y - y0;
    for (let k = 0; k < 3; k++) {
      const a = d[(y0 * W + x0) * ch + k], b = d[(y0 * W + x1) * ch + k], c = d[(y1 * W + x0) * ch + k], e = d[(y1 * W + x1) * ch + k];
      out[k] = (a * (1 - fx) + b * fx) * (1 - fy) + (c * (1 - fx) + e * fx) * fy;
    }
  }
  const RECT_MARGIN = DEFAULTS.bandMax + 2; // px of the patch kept round the quadrilateral: the band that gives the sign's colour (one px gap, up to bandMax) needs it
  const RECT_MAX = 900; // the patch's long side is at most this (a quadrilateral is rarely longer than the picture's 2576 px; the colours do not need it)

  /* The quadrilateral q as a level patch: its length along the top and bottom edges across, its height (the area over the length) down, RECT_MARGIN px of
     the picture's own surroundings on every side. Returns { img (the patch), box (the quadrilateral's place in it), toPatch(x, y) (a point of the picture in the patch) } or null. */
  function rectify(img, q, sides) {
    const P = [[q[0], q[1]], [q[2], q[3]], [q[4], q[5]], [q[6], q[7]]];
    const len = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1]);
    const top = len(P[0], P[1]), bot = len(P[3], P[2]);
    let area = 0;
    for (let i = 0; i < 4; i++) { const a = P[i], b = P[(i + 1) % 4]; area += a[0] * b[1] - b[0] * a[1]; }
    area = Math.abs(area) / 2;
    let Wp = (top + bot) / 2, Hp = area / Math.max(1e-6, Wp);
    const k = Math.min(1, RECT_MAX / Math.max(Wp, Hp));
    Wp = Math.round(Wp * k); Hp = Math.round(Hp * k);
    if (Wp < 8 || Hp < 6) return null;
    const m = RECT_MARGIN, mx = sides ? Math.max(m, runCap(Wp, Hp) + 2) : m; // sides: room at the two ends for freeRun (v0.3.2); the colours are read from the same pixels as before
    const PW = Wp + 2 * mx, PH = Hp + 2 * m;
    const rect = [[mx, m], [mx + Wp, m], [mx + Wp, m + Hp], [mx, m + Hp]];
    const fwd = homography4(rect, P), inv = homography4(P, rect);
    if (!fwd || !inv) return null;
    const data = new Uint8ClampedArray(PW * PH * 4), c = [0, 0, 0];
    for (let y = 0; y < PH; y++) {
      for (let x = 0; x < PW; x++) {
        const p = mapH(fwd, x + 0.5, y + 0.5), i = (y * PW + x) * 4;
        if (!p) { data[i + 3] = 255; continue; }
        bilinear(img, p[0], p[1], c);
        data[i] = c[0]; data[i + 1] = c[1]; data[i + 2] = c[2]; data[i + 3] = 255;
      }
    }
    return { img: { data: data, width: PW, height: PH, channels: 4 }, box: [mx, m, mx + Wp, m + Hp], toPatch: (x, y) => mapH(inv, x, y) };
  }

  /* ---------- how far the sign's own background runs on past each end of a line (v0.3.2) ----------
     A tight label (ovfit.js) that does not fit its outline may be run on past the ends of the line along its own direction, by at most the smaller of twice the outline's height and 30 % of its length
     (these two are ovfit.js's EXT_MAX_H and EXT_MAX_LEN), and only over the sign's own background colour. freeRun reads that in the level patch: from each end of the quadrilateral outwards, column by column, over
     the middle 76 % of the line's height, a column is background while at most 12 % of its pixels are further than PIX_T from the sign's colour (or lie in another line's outline) and its mean colour is within
     MEAN_T of it. The run stops at the first column that is not. Returns [left, right] as shares of the line's length. Nothing read: [0, 0]. */
  const RUN_MAX_H = 2, RUN_MAX_LEN = 0.3, PIX_T = 55, MEAN_T = 36, RUN_BAD = 0.12, RUN_SKIP = 2;
  const runCap = (Wp, Hp) => Math.ceil(Math.min(RUN_MAX_H * Hp, RUN_MAX_LEN * Wp));
  function freeRun(patch, box, bg, others) {
    if (!bg) return [0, 0];
    const img = patch, W = img.width, d = img.data, ch = img.channels || 4;
    const Wp = box[2] - box[0], Hp = box[3] - box[1], maxCols = runCap(Wp, Hp);
    const y0 = Math.round(box[1] + 0.12 * Hp), y1 = Math.max(y0 + 1, Math.round(box[3] - 0.12 * Hp));
    const inOther = (x, y) => others.some((o) => x >= o[0] && x < o[2] && y >= o[1] && y < o[3]);
    const run = (dir) => {
      let n = 0;
      for (let step = 1; step <= maxCols; step++) {
        const x = dir > 0 ? box[2] + step - 1 : box[0] - step;
        if (x < 0 || x >= W) break;
        let bad = 0, cnt = 0;
        const sum = [0, 0, 0];
        for (let y = y0; y < y1; y++) {
          const i = (y * W + x) * ch, c = [d[i], d[i + 1], d[i + 2]];
          cnt++;
          sum[0] += c[0]; sum[1] += c[1]; sum[2] += c[2];
          if (inOther(x, y) || dist(c, bg) > PIX_T) bad++;
        }
        if (step > RUN_SKIP && (!cnt || bad / cnt > RUN_BAD || dist([sum[0] / cnt, sum[1] / cnt, sum[2] / cnt], bg) > MEAN_T)) break; // (the first RUN_SKIP columns are the model's own margin, blended with the ink at its edge: they are not asked)
        n = step;
      }
      return n;
    };
    const share = (n) => Math.round((n / Wp) * 1000) / 1000;
    return [share(run(-1)), share(run(1))];
  }

  /* The colours of every quadrilateral line: [{ q, bg, fg } | null], q being the quadrilateral the label is drawn on.
     QUAD REFINEMENT (not built, on purpose): the experiment (research/any-sign/geom/scripts/geometry.mjs, method D, refineQuad) rectifies a quadrilateral through
     this same homography, runs refineBox on the patch and maps the box back, which tightens loose corners. It was not judged, so it is NOT used: the label is drawn on
     the model's corners as they came. When it has been judged, it goes HERE: replace `q` by the refined quadrilateral before it is rectified for the colours (and let the
     result carry it: ask.js takes the corners of the label from the `q` this returns). */
  function analyseQuads(img, quads, opts) {
    const qs = quads.map((q) => (Array.isArray(q) && q.length === 8 && q.every((v) => typeof v === 'number' && isFinite(v)) ? q : null));
    return qs.map((q, i) => {
      if (!q) return null;
      // >>> QUAD REFINEMENT POINT: q = refined(q) <<<
      const r = rectify(img, q, true);
      if (!r) return { q: q, bg: null, fg: null, xr: [0, 0] };
      const others = [];
      qs.forEach((o, j) => {
        if (j === i || !o) return;
        const pts = [0, 1, 2, 3].map((n) => r.toPatch(o[2 * n], o[2 * n + 1]));
        if (pts.some((p) => !p)) return;
        others.push([Math.min.apply(null, pts.map((p) => p[0])), Math.min.apply(null, pts.map((p) => p[1])), Math.max.apply(null, pts.map((p) => p[0])), Math.max.apply(null, pts.map((p) => p[1]))].map((v) => Math.round(v)));
      });
      const c = colourOf(r.img, r.box, others, opts);
      return { q: q, bg: c.bg, fg: c.fg, xr: freeRun(r.img, r.box, c.bg, others) };
    });
  }

  const API = { analyse: analyse, analyseQuads: analyseQuads, rectify: rectify, freeRun: freeRun, homography4: homography4, mapH: mapH, colourOf: colourOf, tilt: tilt, refineBox: refineBox, bandColor: bandColor, inkColor: inkColor, insideColor: insideColor, energy: energy, DEFAULTS: DEFAULTS };
  root.PAASnap = API;
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
})(typeof self !== 'undefined' ? self : globalThis);
