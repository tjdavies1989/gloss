/* Gloss: the arrow chip (flow J). A notebook Here row whose mark is off screen shows a small chip at the
   nearest edge of the picture, pointing the way, for about 6 s or until the mark comes into view; then its card opens.
   The chip follows the view on every frame while it exists (one element, a transform), and costs nothing otherwise. */
(function () {
  'use strict';
  const PAA = self.PAA;
  const P = self.PAAPose;

  const SHOW_MS = 6000;
  const MARGIN = 10;
  const ARROW = '<svg viewBox="0 0 24 24"><path d="M5 12h14M13 6l6 6-6 6"/></svg>';

  let chip = null, arrow = null, target = null, timer = 0, w = 0, h = 0;

  const wrap = (d) => ((d + 540) % 360) - 180;
  const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));

  function clear() {
    clearTimeout(timer);
    target = null;
    if (chip) { if (self.PAAGlass) PAAGlass.forget(chip); chip.remove(); }
    chip = null;
    arrow = null;
  }

  function viewRect(pose) {
    const iw = window.innerWidth, ih = window.innerHeight;
    const cr = pose.panoId && pose.canvasRect;
    if (!cr) return { x: 0, y: 0, w: iw, h: ih };
    const x = Math.max(0, cr.x), y = Math.max(0, cr.y);
    return { x: x, y: y, w: Math.min(iw, cr.x + cr.width) - x, h: Math.min(ih, cr.y + cr.height) - y };
  }

  /* where the mark lies, as a direction from the middle of the picture (dx, dy) */
  function bearing(pose, vr) {
    const d = target.centerDir();
    const p = P.dirToScreen(d.yaw, d.pitch);
    const cx = vr.x + vr.w / 2, cy = vr.y + vr.h / 2;
    if (p && !p.behind) return { dx: p.x - cx, dy: p.y - cy };
    // behind the camera (or no projection): turn the short way round; the pitch decides up or down
    const dyaw = wrap(d.yaw - pose.heading);
    const dpitch = d.pitch - (pose.pitch || 0);
    return { dx: dyaw >= 0 ? 1 : -1, dy: clamp(-dpitch / 45, -0.8, 0.8) };
  }

  function update(pose) {
    if (!target) return;
    if (target.dead || target.retired) return clear();
    const vr = viewRect(pose);
    if (PAA.book.inView(target)) {
      if (!pose.moving) { // wait for the view to settle, then open it
        const m = target;
        clear();
        PAA.app.openMark(m);
      } else if (chip) chip.classList.add('hide');
      return;
    }
    if (!chip) return;
    chip.classList.remove('hide');
    const b = bearing(pose, vr);
    const hw = vr.w / 2 - MARGIN - w / 2, hh = vr.h / 2 - MARGIN - h / 2;
    const k = Math.min(Math.abs(b.dx) > 1e-6 ? hw / Math.abs(b.dx) : Infinity, Math.abs(b.dy) > 1e-6 ? hh / Math.abs(b.dy) : Infinity);
    let px = vr.x + vr.w / 2 + b.dx * (isFinite(k) ? k : 0);
    const py = vr.y + vr.h / 2 + b.dy * (isFinite(k) ? k : 0);
    // Google's Share and Close buttons sit in the top right corner of the picture: keep the chip off them
    if (vr.w >= 600 && py - h / 2 < vr.y + 56 && px + w / 2 > vr.x + vr.w - 270) px = vr.x + vr.w - 272 - w / 2;
    // and off Google's search box at the top left (about 400 x 60 px)
    if (vr.w >= 700 && py - h / 2 < vr.y + 62 && px - w / 2 < vr.x + 404) px = vr.x + 406 + w / 2;
    chip.style.transform = 'translate3d(' + (px - w / 2) + 'px,' + (py - h / 2) + 'px,0)';
    const deg = Math.atan2(b.dy, b.dx) * 180 / Math.PI;
    arrow.style.transform = 'rotate(' + deg.toFixed(1) + 'deg)';
  }

  /* keepMs: how long the chip stays (default 6 s; a mark found on arrival at a saved address keeps it for 30 s, the view may need putting right first) */
  function point(m, keepMs) {
    clear();
    if (!PAA.layer.ensure()) return;
    target = m;
    chip = document.createElement('div');
    chip.className = 'edge hide';
    PAA.layer.glass(chip, 'pill');
    chip.insertAdjacentHTML('beforeend', ARROW);
    arrow = chip.querySelector('svg');
    const label = document.createElement('span');
    label.textContent = PAA.clip(m.a.say || m.a.note || 'Here', 26);
    chip.appendChild(label);
    chip.addEventListener('click', (e) => { e.stopPropagation(); clear(); });
    PAA.layer.pane().appendChild(chip);
    PAA.layer.flash(chip);
    w = chip.offsetWidth;
    h = chip.offsetHeight;
    update(P.getPose());
    timer = setTimeout(clear, keepMs || SHOW_MS);
  }

  PAA.finder = {
    point: point,
    clear: clear,
    active: () => !!target,
    el: () => chip,
    init() { PAA.layer.addFrameHook(update); },
  };
})();
