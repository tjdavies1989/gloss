/* Gloss: hover (flow E). Our layer is click-through, captions included, so hovering is worked out from pointer
   positions: when the pointer rests inside a mark's on-screen quadrilateral for about 150 ms (no button down, view at
   rest), that mark's ticks and caption show. They matter where they are otherwise hidden: in Dots mode, and on a mark whose English is drawn
   over its sign (stage 3: its caption is out of the way at rest). The caption is
   what he presses (press.js finds it by its rectangle), so the mark stays hovered while the pointer is on its caption
   and for a moment after it leaves, and the caption lights up (.hot) as the only sign that it is pressable.
   Nothing here takes pointer events: it listens, it never swallows. */
(function () {
  'use strict';
  const PAA = self.PAA;
  const P = self.PAAPose;

  const REST_MS = 150;
  const LEAVE_MS = 250;

  let last = null; // the pointer, from the latest move on the scene
  let restT = 0, leaveT = 0;
  let cur = null; // the hovered mark
  let capOver = null; // the mark whose caption the pointer is on

  /* is (x, y) inside the convex quadrilateral pts? (either winding) */
  function inQuad(pts, x, y) {
    let pos = false, neg = false;
    for (let i = 0; i < 4; i++) {
      const a = pts[i], b = pts[(i + 1) % 4];
      const c = (b.x - a.x) * (y - a.y) - (b.y - a.y) * (x - a.x);
      if (c > 0) pos = true;
      else if (c < 0) neg = true;
    }
    return !(pos && neg);
  }

  function area(pts) {
    let s = 0;
    for (let i = 0; i < 4; i++) {
      const a = pts[i], b = pts[(i + 1) % 4];
      s += a.x * b.y - b.x * a.y;
    }
    return Math.abs(s) / 2;
  }

  /* is any mark quiet at rest (Dots, or showing its English over the sign)? Then a pointer that rests on one wakes it (rest() picks the mark) */
  function quietMarks() {
    if (PAA.prefs.density === 'dots') return true;
    return PAA.layer.all().some((m) => m.qNow || m.crowd);
  }

  function cancelLeave() {
    clearTimeout(leaveT);
    leaveT = 0;
  }

  function clear() {
    cancelLeave();
    clearTimeout(restT);
    if (cur) {
      const m = cur;
      cur = null;
      if (!m.dead) m.setHover(false);
    }
  }

  function scheduleLeave() {
    if (leaveT || !cur) return;
    leaveT = setTimeout(() => {
      leaveT = 0;
      if (capOver && capOver === cur) return;
      clear();
    }, LEAVE_MS);
  }

  function rest() {
    restT = 0;
    if (!last || PAA.prefs.density === 'off') return;
    if (P.getPose().moving) return;
    let best = null, bestA = Infinity;
    PAA.layer.all().forEach((m) => {
      if (m === cur || !(m.qNow || m.crowd) || !m.vis.tick || m.dead) return; // only marks that are quiet right now (or whose caption has no room) need hovering
      if (!inQuad(m.pts, last.x, last.y)) return;
      const a = area(m.pts);
      if (a < bestA) { bestA = a; best = m; }
    });
    if (!best) return;
    if (cur && cur !== best) cur.setHover(false);
    cur = best;
    cancelLeave();
    best.setHover(true);
  }

  /* the pointer is (not) on this mark's caption */
  function setCapOver(m) {
    if (m === capOver) return;
    const prev = capOver;
    capOver = m;
    if (prev) {
      prev.capEl.classList.remove('hot');
      if (cur === prev) scheduleLeave();
    }
    if (m) {
      m.capEl.classList.add('hot');
      if ((m.qNow || m.crowd) && PAA.prefs.density !== 'off') {
        if (cur && cur !== m) cur.setHover(false);
        cur = m;
        m.setHover(true);
      }
      cancelLeave();
    }
  }

  function onMove(e) {
    if (!e.isTrusted) return;
    if (PAA.layer.inOurs(e)) { setCapOver(null); return; }
    if (e.buttons) { // dragging: the view is about to move
      last = null;
      setCapOver(null);
      clear();
      return;
    }
    last = { x: e.clientX, y: e.clientY };
    setCapOver(PAA.press.capAt(last.x, last.y));
    if (cur) {
      if (inQuad(cur.pts, last.x, last.y)) cancelLeave();
      else scheduleLeave();
    }
    clearTimeout(restT);
    restT = setTimeout(rest, REST_MS);
  }

  PAA.hover = {
    init() {
      addEventListener('pointermove', onMove, { capture: true, passive: true });
      addEventListener('pointerdown', (e) => { if (e.isTrusted && !PAA.layer.inOurs(e)) { last = null; clear(); } }, { capture: true, passive: true });
      PAA.layer.addFrameHook((pose) => {
        if (pose.moving && capOver) setCapOver(null);
        if (pose.moving && cur) clear();
        else if (!pose.moving && last && !cur && !restT && quietMarks()) restT = setTimeout(rest, REST_MS); // the view settled under a resting pointer
      });
      // the pointer left the window in one jump (no move inside the page to say so): nothing is hovered any more
      document.documentElement.addEventListener('mouseleave', () => { last = null; setCapOver(null); clear(); }, { passive: true });
      document.documentElement.addEventListener('pointerleave', () => { last = null; setCapOver(null); clear(); }, { passive: true });
    },
    current: () => cur,
    clear: clear,
  };
})();
