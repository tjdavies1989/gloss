/* Gloss: one mark. What the owner pointed at, drawn as
     - four corner ticks (or a ring for a point) in the WORLD layer, warped onto the true projected
       quadrilateral every frame with PAAPose.quadToMatrix3d, and
     - a caption or the open card (or the "Reading" chip) in the TOP layer, hanging from the projected
       edge of the mark, upright, moved rigidly with its anchor.
   The mark holds a saved record (data model v2, see BUILD-NOTES.txt) plus a little run-time state.

   Per frame (place) it only writes transforms and class flags. Where the card goes (side, caret, collisions)
   is decided in layout(), which runs when something opens or changes and when the view settles. */
(function () {
  'use strict';
  const PAA = self.PAA;
  const P = self.PAAPose;
  const Place = self.PAAPlace;

  const POINT_RING = 36; // px, the ring drawn for an Option-click
  const LEADER_MIN_LEFT = 6; // px of hairline worth drawing after it has been cut short by a label
  /* Where the segment (x, y) + t * (dx, dy), t from 0 to 1, leaves the rectangle r (grown 2 px): the t to start the line from, or 0 when it does not cross it. */
  function leaveT(x, y, dx, dy, r) {
    let a = 0, b = 1;
    const lo = [r.x - 2 - x, r.y - 2 - y], hi = [r.x + r.w + 2 - x, r.y + r.h + 2 - y], d = [dx, dy];
    for (let i = 0; i < 2; i++) {
      if (Math.abs(d[i]) < 1e-9) { if (lo[i] > 0 || hi[i] < 0) return 0; continue; }
      let t0 = lo[i] / d[i], t1 = hi[i] / d[i];
      if (t0 > t1) { const q = t0; t0 = t1; t1 = q; }
      if (t0 > a) a = t0;
      if (t1 < b) b = t1;
      if (a >= b) return 0;
    }
    return b;
  }
  const LEADER_MIN = 14; // px a caption may be pushed from its place before it gets a leader line
  const SIDE_CLASS = { right: '', left: 'left', below: 'below', above: 'above', inside: 'below' };
  const ANCHOR = { right: 'r', left: 'l', below: 'b', above: 't', inside: 'b' };

  function el(tag, cls, text) {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== undefined) e.textContent = text;
    return e;
  }
  function icon(path) {
    const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    s.setAttribute('viewBox', '0 0 24 24');
    const p = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    p.setAttribute('d', path);
    s.appendChild(p);
    return s;
  }
  const ICON_TRASH = 'M4 7h16M10 11v6M14 11v6M6 7l1 12a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-12M9 7V4h6v3';
  const ICON_RETRY = 'M20 11a8 8 0 1 0-2.3 5.7M20 5v6h-6';
  const ICON_ASK = 'M21 12a8 8 0 0 1-11.6 7.1L4 20l1.1-4.5A8 8 0 1 1 21 12z';
  const ICON_MORE = 'M5 12h.01M12 12h.01M19 12h.01';
  const ICON_COPY = 'M9 9h10v10H9zM5 15V5h10';
  const ICON_PIN = 'M12 21s-6-5.6-6-10a6 6 0 1 1 12 0c0 4.4-6 10-6 10zM12 11.5a1.8 1.8 0 1 0 0-3.6 1.8 1.8 0 0 0 0 3.6z';
  const ICON_OVERLAY = 'M4 18l4.5-12L13 18M5.7 14h5.6M15 10h5M15 14h5';
  const ICON_GEAR = 'M4 7h9M17 7h3M4 17h3M11 17h9M15 5v4M9 15v4';
  const ICON_PEN = 'M4 20h4L19 9l-4-4L4 16v4zM13.5 6.5l4 4';
  const ICON_SPARK = 'M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9zM19 16l.8 2.2L22 19l-2.2.8L19 22l-.8-2.2L16 19l2.2-.8z';
  const FU_PLACEHOLDER = 'Ask a follow-up…';

  class Mark {
    /* rec: a record (new or restored). opts: { open } */
    constructor(rec, opts) {
      opts = opts || {};
      this.rec = rec;
      this.id = rec.id;
      this.state = rec.a ? 'done' : 'capturing'; // capturing | thinking | compose | done | error
      this.open = !!opts.open;
      this.a = rec.a ? Object.assign({}, rec.a) : { say: '', orig: '', read: '', note: '', unsure: '', lines: [], structured: true };
      this.raw = rec.a ? rec.a.raw || '' : '';
      this.err = '';
      this.busy = false; // a capture or an ask is in flight
      this.retired = false;
      this.dead = false;
      this.far = opts.far || null; // a mark seen from another panorama (far.js): { at (this panorama), yaw, pitch, dist, small, dim, occluded, low }
      this.isPoint = rec.kind === 'point' && !this.far; // (seen from elsewhere every mark is a ring, whatever it was)
      const s = rec.screen || { w: 40, h: 40 };
      this.w = Math.max(20, this.isPoint ? POINT_RING : s.w);
      this.h = Math.max(20, this.isPoint ? POINT_RING : s.h);
      this.dirArr = rec.dirs && !this.far ? [rec.dirs.tl, rec.dirs.tr, rec.dirs.br, rec.dirs.bl] : null;
      this.pts = [{ x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }];
      this.ax = 0;
      this.ay = 0;
      this.capOff = { a: 'b', dx: 0, dy: 0, dy0: 0 };
      this.cardOff = { a: 'r', dx: 0, dy: 0 };
      this.side = 'right';
      this.caret = 18;
      this.nocaret = false;
      this.laidKind = ''; // what layout() last placed: 'cap' | 'chip' | 'card'
      this.covered = false; // one of Google's own controls sits on our anchor (or, for a caption, on its edge)
      this.hidByCard = false; // the open card of another mark covers this caption
      this.crowd = false; // no room for this caption without lying on others (layer.layoutAll): hidden until the pointer rests on its mark
      this.vis = { tick: null, cap: null, card: null };
      this.fixedKey = '';
      this.renderQueued = false;
      this.hov = false; // the pointer rests on it (flow E)
      this.qNow = false; // ticks quiet right now (Dots mode)
      this.dotNow = false; // caption shrunk to its dot right now (Dots mode)
      this.askOpen = false; // the follow-up field is showing
      this.menuOpen = false;
      this.menuUp = false;
      this.fuPending = null; // { q, text, err }: the follow-up being answered now
      this.followBottom = false;
      this.sk = ''; // which skeleton the card holds: 'compose' | 'chip' | 'full'
      this.actsKey = '';
      this.fadeOut = false;
      this.fuQueue = []; // follow-ups typed while one is still being answered: asked one after the other
      this.capShown = false; // the caption has been on screen (its glint played)
      this.glinting = false; // the card's glint is running (class "appear")
      this.ov = null; // stage 3: the English drawn over the sign (overlay.js)
      this.capNone = false; // the caption is hidden because the overlay shows (it comes back on hover)
      this.beadNow = false; // ... or shrunk to a bead at the mark's corner (there is a note or a doubt, or Dots)
      this.ovSeen = false; // a label of it is on screen (the caption is out of the way only then)
      this.cull = false; // geometry() said no only because the mark's own rectangle is off screen or behind the camera
      this.rp = null; // stage 4: the repaint's state in this page { state: 'idle' | 'working' | 'failed' | 'refused', ... } (patch.js)
      this.pt = null; // ... and what is drawn of it: the patch in the world layer, the badge, the progress chip
      this.build();
      if (PAA.overlay) PAA.overlay.attach(this, true);
      if (PAA.patch) PAA.patch.attach(this, true);
    }

    /* ---------------- DOM ---------------- */

    build() {
      const L = PAA.layer;
      L.ensure();
      this.tick = el('div', 'mark hide');
      if (this.isPoint) this.tick.classList.add('point');
      for (let i = 0; i < 4; i++) this.tick.appendChild(el('i'));
      this.tick.style.width = this.w + 'px';
      this.tick.style.height = this.h + 'px';
      L.stage().appendChild(this.tick);

      // a caption is click-through: a press on it is found by press.js, hover by hover.js (the wheel and an Option-drag pass through)
      this.capPos = el('div', 'pos hide');
      this.leadEl = el('i', 'lead'); // the hairline from the mark to a caption that was pushed away from it
      this.capEl = el('div', 'cap');
      L.glass(this.capEl, 'pill');
      this.capSpan = el('span');
      this.capEl.appendChild(this.capSpan);
      // the hairline has a wrapper of its own that comes before every caption in the layer: a pushed caption's hairline runs under the
      // caption it passes, never through its words (each .pos is its own stacking layer, so CSS alone cannot put it underneath)
      this.leadPos = el('div', 'pos hide');
      this.leadPos.appendChild(this.leadEl);
      this.capPos.appendChild(this.capEl);
      L.pane().prepend(this.leadPos);
      L.pane().appendChild(this.capPos);

      this.cardPos = null; // built when first needed
      this.cardEl = null;
      this.renderTick();
      this.renderCap();
    }

    ensureCard() {
      if (this.cardEl) return;
      this.cardPos = el('div', 'pos cardpos hide');
      this.cardEl = el('div', 'card');
      this.cardEl.addEventListener('pointerdown', (e) => {
        if (this.menuOpen && !(e.target.closest && e.target.closest('.menu, .more'))) this.setMenu(false);
      });
      // the open card tilts a few degrees towards the pointer while the pointer is over it
      this.cardEl.addEventListener('pointerenter', (e) => PAA.layer.tilt(this.cardEl, e));
      this.cardEl.addEventListener('pointermove', (e) => PAA.layer.tilt(this.cardEl, e));
      this.cardEl.addEventListener('pointerleave', () => PAA.layer.untilt(this.cardEl));
      this.cardPos.appendChild(this.cardEl);
      PAA.layer.pane().appendChild(this.cardPos);
    }

    destroy() {
      this.dead = true;
      if (PAA.patch) PAA.patch.detach(this);
      if (PAA.overlay) PAA.overlay.detach(this);
      if (this.cardEl) PAA.layer.sunOff(this.cardEl);
      if (this.vis.cap) { this.vis.cap = false; PAA.layer.capCount(-1); }
      if (self.PAAGlass) { PAAGlass.forget(this.capEl); PAAGlass.forget(this.cardEl); }
      if (this.tick) this.tick.remove();
      if (this.capPos) this.capPos.remove();
      if (this.leadPos) this.leadPos.remove();
      if (this.cardPos) this.cardPos.remove();
    }

    /* ---------------- what to show ---------------- */

    hasText() {
      const a = this.a;
      return !!(a.say || a.note || a.orig);
    }

    /* 'chip' (the Reading chip), 'card' (the open card) or 'cap' (the caption). */
    viewKind() {
      const s = this.state;
      if (s === 'capturing' || (s === 'thinking' && !this.hasText())) return 'chip';
      if (s === 'compose' || s === 'error' && this.open) return 'card';
      return this.open ? 'card' : 'cap';
    }

    thinking() {
      return this.state === 'capturing' || (this.state === 'thinking' && !this.hasText());
    }

    renderTick() {
      this.tick.classList.toggle('thinking', this.thinking() || !!(this.rp && this.rp.state === 'working')); // (the glint loops while a repaint is made, too)
    }

    capText() {
      const a = this.a;
      if (this.state === 'error') return 'Could not read this';
      return a.say || a.note || a.orig || '…';
    }

    renderCap() {
      const a = this.a;
      const c = this.capEl;
      const span = this.capSpan;
      const text = this.capText();
      if (span.textContent !== text) span.textContent = text;
      c.title = text;
      c.classList.toggle('thing', !(a.orig || (a.lines && a.lines.length)));
      c.classList.toggle('noted', !!a.note && a.structured !== false && this.state !== 'error');
      c.classList.toggle('doubt', !!a.unsure && a.structured !== false && this.state !== 'error'); // (a bead that says the reading is doubtful goes amber)
      c.classList.toggle('err', this.state === 'error');
    }

    cardClass() {
      const kind = this.viewKind();
      let c = 'card lg'; // glass (see layer.glass)
      if (kind === 'chip') c += ' thinking nocaret pill';
      else {
        c += ' tilt';
        if (this.state === 'compose') c += ' compose';
        const s = SIDE_CLASS[this.side];
        if (s) c += ' ' + s;
        if (this.nocaret) c += ' nocaret';
      }
      if (this.popping) c += ' pop';
      if (this.glinting) c += ' appear';
      return c;
    }

    fmtMeta() {
      const st = this.rec.stats;
      if (!st) return '';
      const parts = [];
      if (typeof st.ms === 'number') parts.push((st.ms / 1000).toFixed(1) + ' s');
      // the cost is recorded with every note but shown only when the person asks for it in Settings (PAA.prefs.showCost, off by default)
      if (typeof st.cost === 'number' && PAA.prefs && PAA.prefs.showCost) parts.push('$' + (st.cost < 0.01 ? st.cost.toFixed(4) : st.cost.toFixed(3)));
      return parts.join(' · ');
    }

    /* the card's glint: class "appear" for the length of the animation (cardClass keeps it through the re-renders in between) */
    glint() {
      this.glinting = true;
      clearTimeout(this.glintT);
      this.glintT = setTimeout(() => {
        this.glinting = false;
        if (this.cardEl) this.cardEl.classList.remove('appear');
      }, 1000);
    }

    button(label, path, act) {
      const b = el('button', '');
      b.type = 'button';
      b.dataset.act = act;
      b.appendChild(icon(path));
      if (label) b.appendChild(document.createTextNode(label));
      b.addEventListener('click', (e) => {
        e.stopPropagation();
        PAA.app.action(this, act);
      });
      return b;
    }

    /* a small Settings button for an amber error that is about a key (a failed follow-up, a refused repaint); the same action as the error card's own */
    settingsLink() {
      const r = el('button', 'retry', 'Settings');
      r.type = 'button';
      r.dataset.act = 'settings';
      r.addEventListener('click', (e) => {
        e.stopPropagation();
        PAA.app.action(this, 'settings');
      });
      return r;
    }

    lineList() {
      return (this.a.lines || []).filter((l) => l.o || l.t);
    }

    /* Rebuilds the card's contents from the current answer. Cheap; called at most once per animation frame while streaming.
       The follow-up field is never rebuilt (typing must survive a render). */
    renderCard() {
      const kind = this.viewKind();
      if (kind === 'cap') {
        if (this.cardEl) this.cardEl.className = 'card lg';
        this.cardKind = 'cap'; // so that opening the card again is an opening: the glint crosses it and it pops in
        return;
      }
      this.ensureCard();
      const card = this.cardEl;
      const prevKind = this.cardKind;
      this.cardKind = kind;
      if (prevKind !== kind) this.glint(); // the card (or the Reading chip) opens: the glint crosses it once
      if (this.state === 'compose') {
        if (!card.querySelector('input')) {
          card.textContent = '';
          PAA.layer.glass(card);
          const row = el('div', 'ask');
          const input = el('input');
          input.type = 'text';
          input.placeholder = 'Ask about this…';
          input.spellcheck = false;
          input.autocomplete = 'off';
          row.appendChild(input);
          card.append(row, el('div', 'keys', 'Enter to ask. Esc to cancel.'));
          this.input = input;
        }
        this.sk = 'compose';
        card.className = this.cardClass();
        return;
      }
      this.input = null;
      if (kind === 'chip') {
        card.textContent = '';
        PAA.layer.glass(card);
        const dots = el('span', 'dots');
        dots.append(el('b'), el('b'), el('b'));
        card.append(dots, el('span', 'lbl', 'Reading'));
        this.sk = 'chip';
        card.className = this.cardClass();
        return;
      }
      // the full card: body (the answer, then the follow-up exchanges), the follow-up field, the action row
      if (this.sk !== 'full') this.buildFull();
      this.renderBody();
      this.cAsk.classList.toggle('hidden', !this.askOpen || this.state !== 'done');
      this.renderActs();
      if (prevKind !== kind) {
        this.popping = true;
        setTimeout(() => {
          this.popping = false;
          if (this.cardEl) this.cardEl.classList.remove('pop');
        }, 200);
      }
      card.className = this.cardClass();
    }

    buildFull() {
      const card = this.cardEl;
      card.textContent = '';
      PAA.layer.glass(card);
      this.cBody = el('div', 'body');
      this.cBody.addEventListener('scroll', () => {
        const b = this.cBody;
        this.followBottom = b.scrollHeight - b.scrollTop - b.clientHeight < 24;
      }, { passive: true });
      this.cAsk = el('div', 'ask hidden');
      if (!this.fuInput) {
        const input = el('input');
        input.type = 'text';
        input.placeholder = FU_PLACEHOLDER;
        input.spellcheck = false;
        input.autocomplete = 'off';
        this.fuInput = input;
      }
      this.cAsk.appendChild(this.fuInput);
      this.cActs = el('div', 'acts');
      card.append(this.cBody, this.cAsk, this.cActs);
      this.sk = 'full';
      this.actsKey = '';
    }

    /* what goes above the answer in the card: nothing for a mark on this panorama; far.js puts the picture of what was asked about there */
    bodyHead(body) {}

    fuBlock(q, a) {
      const d = el('div', 'fu');
      d.appendChild(el('div', 'q', q));
      d.appendChild(el('div', 'a', a));
      return d;
    }

    renderBody() {
      const body = this.cBody;
      const keep = body.scrollTop;
      body.textContent = '';
      const a = this.a;
      this.bodyHead(body);
      if (this.state === 'error') {
        body.appendChild(el('div', 'unsure err', this.err || 'Something went wrong.'));
      } else if (a.structured === false) {
        body.appendChild(el('div', 'plain', a.note));
      } else {
        const asked = this.rec.q || (this.question && this.question !== PAA.DEFAULT_QUESTION ? this.question : '');
        if (asked) body.appendChild(el('div', 'asked', asked)); // his own question, muted, above the answer
        if (a.say) body.appendChild(el('div', 'say', a.say));
        const lines = this.lineList();
        if (lines.length >= 2) {
          const grid = el('div', 'lines');
          lines.forEach((l) => {
            grid.appendChild(el('b', '', l.o));
            grid.appendChild(el('span', '', l.t));
          });
          body.appendChild(grid);
        } else {
          if (a.orig) body.appendChild(el('div', 'orig', a.orig));
          if (a.read) body.appendChild(el('div', 'read', a.read));
        }
        if (a.note) body.appendChild(el('div', 'note', a.note));
        if (a.unsure) body.appendChild(el('div', 'unsure', a.unsure));
        if (PAA.patch) PAA.patch.renderBody(this, body); // a repaint that was refused, or did not pass its check, says so here
      }
      // follow-ups: a muted question line and a plain answer, a hairline between, no bubbles
      (this.rec.fu || []).forEach((f) => body.appendChild(this.fuBlock(f.q, f.a)));
      const p = this.fuPending;
      if (p) {
        const d = el('div', p.err ? 'fu err' : 'fu');
        d.appendChild(el('div', 'q', p.q));
        if (p.err) {
          d.appendChild(el('div', 'a', p.err));
          if (p.settings) d.appendChild(this.settingsLink());
          const r = el('button', 'retry', 'Retry');
          r.type = 'button';
          r.dataset.act = 'fu-retry';
          r.addEventListener('click', (e) => {
            e.stopPropagation();
            PAA.ask.followUp(this, p.q, true);
          });
          d.appendChild(r);
        } else if (!p.text) {
          const w = el('div', 'a waiting');
          const dots = el('span', 'dots');
          dots.append(el('b'), el('b'), el('b'));
          w.appendChild(dots);
          d.appendChild(w);
        } else d.appendChild(el('div', 'a', p.text));
        body.appendChild(d);
      }
      // questions typed while one was still being answered: shown waiting, asked in turn
      this.fuQueue.forEach((q) => {
        const d = el('div', 'fu queued');
        d.appendChild(el('div', 'q', q));
        if (p && p.err) d.appendChild(el('div', 'a', 'Waiting for the question above to be asked again.')); // (no spinner: nothing is happening until he retries or asks something else)
        else {
          const w = el('div', 'a waiting');
          const dots = el('span', 'dots');
          dots.append(el('b'), el('b'), el('b'));
          w.appendChild(dots);
          d.appendChild(w);
        }
        body.appendChild(d);
      });
      body.scrollTop = this.followBottom ? body.scrollHeight : keep;
    }

    /* The action row: Overlay and Repaint (hidden until their stages), Ask, and "more". A failed ask has Retry and Dismiss. */
    renderActs() {
      const done = this.state === 'done';
      const lines = this.lineList().length;
      const meta = this.state === 'done' ? this.fmtMeta() : '';
      const ovn = PAA.overlay ? PAA.overlay.available(this) : 0;
      const ovOn = ovn && PAA.overlay.shown(this);
      const rpKey = PAA.patch ? PAA.patch.key(this) : '';
      const key = [this.state, this.errSettings ? 1 : 0, done ? 1 : 0, lines, this.askOpen ? 1 : 0, this.menuOpen ? this.menuUp ? 'u' : 'd' : 0, meta, this.canGo() ? 1 : 0, !!this.orig2(), ovn, ovOn ? 1 : 0, rpKey].join('|');
      if (key === this.actsKey) return;
      this.actsKey = key;
      const acts = this.cActs;
      acts.textContent = '';
      if (this.state === 'error') {
        if (this.errSettings) { // a key problem (no key, a key that was refused, the shared key that ran out): the way to the settings is on the card
          const st = this.button('Settings', ICON_GEAR, 'settings');
          st.classList.add('on');
          acts.appendChild(st);
        }
        if (!this.noRetry) {
          const retry = this.button('Retry', ICON_RETRY, 'retry');
          retry.classList.add('on');
          acts.appendChild(retry);
        }
        acts.appendChild(this.button('Dismiss', ICON_TRASH, 'delete'));
        return;
      }
      if (this.canGo()) { // seen from another panorama: the way back to where it was asked is the main thing this card offers
        const go = this.button('Go to where I asked', ICON_PIN, 'goto');
        go.classList.add('on');
        acts.appendChild(go);
      }
      if (ovn) { // English drawn over the sign: lit while it shows (stage 3; only when at least one line can be drawn)
        const ov = this.button('Overlay', ICON_OVERLAY, 'overlay');
        if (ovOn) ov.classList.add('on');
        acts.appendChild(ov);
      }
      if (lines && !this.far && PAA.patch && PAA.patch.offered(this)) { // stage 4: AI repaint (the label and the lit state say where it is: patch.js)
        const rb = this.button(PAA.patch.label(this), ICON_PEN, 'repaint');
        PAA.patch.wireButton(this, rb);
        acts.appendChild(rb);
      }
      if (done) {
        const ask = this.button('Ask', ICON_ASK, 'ask');
        if (this.askOpen) ask.classList.add('on');
        acts.appendChild(ask);
      }
      acts.appendChild(el('span', 'sp'));
      const more = this.button('', ICON_MORE, 'more');
      more.classList.add('more');
      more.title = 'More';
      if (this.menuOpen) more.classList.add('open');
      acts.appendChild(more);
      if (this.menuOpen) acts.appendChild(this.buildMenu(meta));
    }

    /* the original text, when there is some to copy */
    orig2() {
      const a = this.a;
      const lines = this.lineList();
      if (lines.length >= 2) return lines.map((l) => l.o).join('\n');
      return a.orig || '';
    }

    translation() {
      const lines = this.lineList();
      if (lines.length >= 2) return lines.map((l) => l.t).join('\n');
      return this.a.say || this.a.note || '';
    }

    /* "Go to where I asked": only when this card is seen from another panorama (stage 2) */
    canGo() {
      const pose = P.getPose();
      return !!(this.rec.pano && this.rec.view && this.rec.view.url && pose.panoId && pose.panoId !== this.rec.pano.id);
    }

    buildMenu(meta) {
      const menu = el('div', this.menuUp ? 'menu up' : 'menu');
      PAA.layer.glass(menu, 'flat'); // inside the card's own glass: a nested backdrop filter would only see the card
      const item = (label, path, act, cls) => {
        const b = this.button(label, path, act);
        if (cls) b.classList.add(cls);
        menu.appendChild(b);
      };
      item('Copy translation', ICON_COPY, 'copy-t');
      if (this.orig2()) item('Copy original', ICON_COPY, 'copy-o');
      if (PAA.patch && PAA.patch.hasPatch(this)) { // stage 4
        item('Repaint again', ICON_PEN, 'repaint-again');
        item('Remove repaint', ICON_TRASH, 'repaint-remove');
      }
      item('Delete', ICON_TRASH, 'delete', 'danger');
      const rmeta = PAA.patch ? PAA.patch.costText(this) : ''; // stage 4: what the repaint cost, under the answer's own time and cost
      if (meta) menu.appendChild(el('div', 'meta', (rmeta ? 'Answer: ' : '') + meta));
      if (rmeta) menu.appendChild(el('div', rmeta && meta ? 'meta rp' : 'meta', 'Repaint: ' + rmeta));
      return menu;
    }

    setMenu(on) {
      if (this.menuOpen === on) return;
      if (on && this.cardEl) {
        const r = this.cardEl.getBoundingClientRect();
        this.menuUp = window.innerHeight - r.bottom < 200; // not enough room below the card: open upward
      }
      this.menuOpen = on;
      this.actsKey = '';
      if (this.sk === 'full') this.renderActs();
    }

    toggleAsk() {
      if (this.state !== 'done') return;
      this.askOpen = !this.askOpen;
      this.setMenu(false);
      this.render();
      if (this.askOpen && this.fuInput) this.fuInput.focus();
    }

    /* A follow-up changed (sent, streaming, finished): re-render, keep the newest exchange in view */
    fuChanged() {
      this.followBottom = true;
      this.renderSoon();
    }

    /* Re-render everything that depends on state or text, then ask the layer to place it. A streamed chunk that only
       made the text longer (same state, same kind of thing shown) re-places just this mark; anything else gets the full
       layout pass. */
    render(streamed) {
      if (this.dead) return;
      this.renderTick();
      this.renderCap();
      this.renderCard();
      const sig = this.state + '|' + this.viewKind();
      const same = sig === this.renderSig;
      this.renderSig = sig;
      if (streamed && same) PAA.layer.layoutMark(this);
      else PAA.layer.requestLayout();
    }

    /* streaming: coalesce to one render per frame */
    renderSoon() {
      if (this.renderQueued || this.dead) return;
      this.renderQueued = true;
      const run = () => {
        if (!this.renderQueued) return;
        this.renderQueued = false;
        this.render(true);
      };
      requestAnimationFrame(run);
      setTimeout(run, 80); // rAF does not run in a hidden tab
    }

    setState(state, err) {
      this.state = state;
      this.err = err || '';
      PAA.layer.changed();
      this.render();
    }

    setOpen(open) {
      if (this.open === open) return;
      this.open = open;
      this.laidKind = '';
      if (!open) {
        this.menuOpen = false;
        this.askOpen = false;
        this.fadeOut = this.vis.card; // a card that was showing fades out in 100 ms
      }
      this.render();
    }

    setHover(on) {
      if (this.hov === on) return;
      this.hov = on;
      this.renderCap();
      PAA.layer.trackNow();
      PAA.layer.requestLayout(0);
    }

    /* density (flow K): Dots hides the ticks and shrinks the caption to its dot until the pointer rests on the mark */
    /* Stage 3: a mark whose English is drawn over the sign (a label of it is on screen) keeps its ticks quiet and its caption out of the way at
       rest (hover or an open card brings them back): the caption is hidden, or, when there is a note or a doubt to find (or in Dots), shrunk to
       a bead at the mark's corner. When no label is on screen (zoomed far out, off to the side) the mark is as it was before: its caption shows. */
    applyDensity() {
      const d = PAA.prefs.density;
      const rest = this.state === 'done' && !this.open && !this.hov;
      const ovOn = rest && !!PAA.overlay && PAA.overlay.seen(this);
      const pat = rest && !!PAA.patch && PAA.patch.seen(this); // a repaint showing keeps the ticks quiet (the caption stays: the badge hangs beside it)
      const dots = d === 'dots' && rest;
      const noted = (!!this.a.note || !!this.a.unsure) && this.a.structured !== false;
      const quiet = dots || ovOn || pat;
      const dot = dots || (ovOn && noted);
      let changed = false;
      if (quiet !== this.qNow) {
        this.qNow = quiet;
        this.tick.classList.toggle('quiet', quiet);
      }
      if (dot !== this.dotNow) {
        this.dotNow = dot;
        this.capEl.classList.toggle('dot', dot);
        changed = true;
      }
      const bead = ovOn && dot;
      if (bead !== this.beadNow) {
        this.beadNow = bead;
        changed = true;
      }
      this.capNone = ovOn && !dot;
      return changed;
    }

    /* the overlay showed or hid (overlay.js): the caption, the ticks and the action row follow */
    ovChanged(quiet) {
      this.actsKey = '';
      if (quiet || this.dead) return;
      this.render();
      PAA.layer.trackNow();
      PAA.layer.requestLayout(0);
    }

    /* focus the field as soon as the card is on screen (place() does it) */
    focusInput() {
      this.wantFocus = true;
      PAA.layer.requestLayout();
    }

    /* ---------------- geometry ---------------- */

    /* this.pts for the mark as it is on screen now: projected from its directions, or its fixed screen rectangle. false when it cannot be drawn. */
    fill() {
      if (this.dirArr) return this.project();
      this.fixedPts();
      return true;
    }

    /* Fills this.pts with the four corners on screen. false when it cannot be drawn (behind the camera). */
    project() {
      const d = this.dirArr;
      for (let i = 0; i < 4; i++) {
        const p = P.dirToScreen(d[i].yaw, d[i].pitch);
        if (!p || p.behind) return false;
        this.pts[i].x = p.x;
        this.pts[i].y = p.y;
      }
      return true;
    }

    /* the direction of the mark's centre (compass degrees), or null for a screen-fixed mark */
    centerDir() {
      return this.dirArr ? this.rec.dirs.c : null;
    }

    fixedPts() {
      const s = this.rec.screen;
      const p = this.pts;
      p[0].x = s.x; p[0].y = s.y;
      p[1].x = s.x + s.w; p[1].y = s.y;
      p[2].x = s.x + s.w; p[2].y = s.y + s.h;
      p[3].x = s.x; p[3].y = s.y + s.h;
    }

    bbox() {
      const p = this.pts;
      const x0 = Math.min(p[0].x, p[1].x, p[2].x, p[3].x), x1 = Math.max(p[0].x, p[1].x, p[2].x, p[3].x);
      const y0 = Math.min(p[0].y, p[1].y, p[2].y, p[3].y), y1 = Math.max(p[0].y, p[1].y, p[2].y, p[3].y);
      return { x: x0, y: y0, w: x1 - x0, h: y1 - y0 };
    }

    anchorXY(a) {
      const p = this.pts;
      if (a === 'tr') { this.ax = p[1].x; this.ay = p[1].y; }
      else if (a === 'b') { this.ax = (p[2].x + p[3].x) / 2; this.ay = (p[2].y + p[3].y) / 2; }
      else if (a === 't') { this.ax = (p[0].x + p[1].x) / 2; this.ay = (p[0].y + p[1].y) / 2; }
      else if (a === 'r') { this.ax = (p[1].x + p[2].x) / 2; this.ay = (p[1].y + p[2].y) / 2; }
      else { this.ax = (p[0].x + p[3].x) / 2; this.ay = (p[0].y + p[3].y) / 2; }
    }

    /* Layout runs in three steps so a pass over many marks never mixes reads and writes (that would force a
       browser layout per mark): measure() only reads, decide() is pure, apply() only writes.
       It decides where the caption / chip / card sits relative to its anchor and runs when something opens or
       changes and when the view settles, never per frame. */

    /* step 1 (reads): the mark on screen and the size of whatever hangs from it. false when it cannot be placed. */
    measure() {
      this.applyDensity();
      if (!this.fill()) return false;
      const kind = this.viewKind();
      this.mKind = kind;
      const e = kind === 'cap' ? this.capEl : this.cardEl;
      this.mW = e ? e.offsetWidth : 0;
      this.mH = e ? e.offsetHeight : 0;
      return true;
    }

    /* step 2 (pure): placement. Returns what it takes up on screen ({kind, rect, dir}) for collision handling. */
    decide(f) {
      const bb = this.bbox();
      const kind = this.mKind;
      const size = { w: this.mW, h: this.mH };
      const nw = Math.max(20, Math.round((Math.hypot(this.pts[1].x - this.pts[0].x, this.pts[1].y - this.pts[0].y) + Math.hypot(this.pts[2].x - this.pts[3].x, this.pts[2].y - this.pts[3].y)) / 2));
      const nh = Math.max(20, Math.round((Math.hypot(this.pts[3].x - this.pts[0].x, this.pts[3].y - this.pts[0].y) + Math.hypot(this.pts[2].x - this.pts[1].x, this.pts[2].y - this.pts[1].y)) / 2));
      this.pend = { kind: kind, nw: nw, nh: nh };
      if (kind === 'card') {
        const c = Place.placeCard(bb, size, f.vr, { avoid: f.cardAvoid });
        this.anchorXY(ANCHOR[c.side]);
        Object.assign(this.pend, { side: c.side, caret: c.caret, nocaret: c.nocaret, a: ANCHOR[c.side], dx: c.x - this.ax, dy: c.y - this.ay });
        return { kind: 'card', rect: { x: c.x, y: c.y, w: size.w, h: size.h } };
      }
      if (this.beadNow) { // the bead of a mark that shows its English: centred on the mark's top right corner
        this.anchorXY('tr');
        Object.assign(this.pend, { a: 'tr', dx: -size.w / 2, dy: -size.h / 2 });
        return { kind: 'cap', rect: { x: this.ax - size.w / 2, y: this.ay - size.h / 2, w: size.w, h: size.h }, dir: -1 };
      }
      const c = Place.placeCaption(bb, size, f.vr, this.capGap ? { gap: this.capGap } : undefined); // (a far mark hangs its caption a little away, on a leader)
      const a = c.side === 'above' ? 't' : 'b';
      this.anchorXY(a);
      Object.assign(this.pend, { a: a, dx: c.x - this.ax, dy: c.y - this.ay });
      return { kind: 'cap', rect: { x: c.x, y: c.y, w: size.w, h: size.h }, dir: c.side === 'above' ? -1 : 1 };
    }

    /* step 3 (writes) */
    apply() {
      const p = this.pend;
      if (!p) return;
      this.pend = null;
      this.laidKind = p.kind;
      // same stretch of the picture as the mark has on screen right now, so the ticks stay crisp after a zoom
      if (this.dirArr && !this.isPoint && (Math.abs(p.nw - this.w) > 2 || Math.abs(p.nh - this.h) > 2)) {
        this.w = p.nw;
        this.h = p.nh;
        this.tick.style.width = p.nw + 'px';
        this.tick.style.height = p.nh + 'px';
      }
      if (PAA.overlay) PAA.overlay.rebase(this); // at rest: laid out again at the size it has now, if he zoomed
      if (p.kind === 'card') {
        this.side = p.side;
        this.caret = p.caret;
        this.nocaret = p.nocaret;
        this.cardEl.className = this.cardClass();
        this.cardEl.style.setProperty('--caret', p.caret + 'px');
        this.cardOff.a = p.a;
        this.cardOff.dx = p.dx;
        this.cardOff.dy = p.dy;
      } else {
        this.capOff.a = p.a;
        this.capOff.dx = p.dx;
        this.capOff.dy0 = p.dy;
        this.capOff.dy = p.dy;
      }
    }

    /* all three at once (first placement after something opened or changed) */
    layout(f) {
      if (!this.measure()) return null;
      const r = this.decide(f);
      this.apply();
      return r;
    }

    /* the layer found a collision: shift this caption */
    shiftCap(dy) {
      this.capOff.dy = this.capOff.dy0 + dy;
      this.drawLeader();
    }

    /* A caption pushed more than LEADER_MIN px from its natural place gets a hairline back to the mark's edge (the anchor,
       which is where the caption hangs from): from the anchor to the caption's near edge. Part of the caption's wrapper,
       so it moves with it. */
    drawLeader() {
      const o = this.capOff;
      const shift = o.dy - o.dy0;
      const on = this.mKind === 'cap' && this.mW > 0 && (this.softLead || Math.abs(shift) > LEADER_MIN); // (a far mark's caption always hangs on one)
      if (this.leadOn !== on) {
        this.leadOn = on;
        this.leadEl.style.display = on ? 'block' : 'none';
        if (on) this.leadPos.style.transform = this.capPos.style.transform; // from now on it follows the caption each frame
      }
      if (!on) return;
      // the wrapper's origin is the caption's top-left; the anchor is at (-dx, -dy) from it
      const ex = o.dx + this.mW / 2;
      const ey = (o.a === 't' ? o.dy + this.mH : o.dy); // the edge of the caption that faces the mark, relative to the anchor
      const len = Math.hypot(ex, ey);
      // the hairline lives in the top layer and the English labels in the world layer, so it would be drawn over their type: it starts where it
      // leaves the last label it crosses, and is dropped if less than LEADER_MIN_LEFT px would remain (at-rest layout pass only, never per frame)
      let t0 = 0;
      const labels = PAA.layer.labels();
      for (let i = 0; i < labels.length; i++) {
        const t = leaveT(this.ax, this.ay, ex, ey, labels[i]);
        if (t > t0) t0 = t;
      }
      const s = this.leadEl.style;
      if (len * (1 - t0) < LEADER_MIN_LEFT) { s.display = 'none'; this.leadClipped = true; return; }
      if (this.leadClipped) { s.display = 'block'; this.leadClipped = false; }
      s.left = (-o.dx + t0 * ex) + 'px';
      s.top = (-o.dy + t0 * ey) + 'px';
      s.width = len * (1 - t0) + 'px';
      s.transform = 'rotate(' + Math.atan2(ey, ex) + 'rad)';
    }

    /* the caption's rectangle on screen while it shows (for press.js and hover.js), else null */
    capRect() {
      if (!this.vis.cap || this.mKind !== 'cap' || this.mW <= 0) return null;
      return { x: this.ax + this.capOff.dx, y: this.ay + this.capOff.dy, w: this.mW, h: this.mH };
    }

    /* ---------------- every frame ---------------- */

    shouldShow(f) {
      if (this.retired || this.dead) return false;
      if (this.dirArr) return !f.hideWorld && !!this.rec.pano && f.pose.panoId === this.rec.pano.id;
      return true;
    }

    setVis(which, on) {
      if (this.vis[which] === on) return;
      const was = !!this.vis[which];
      this.vis[which] = on;
      const node = which === 'tick' ? this.tick : which === 'cap' ? this.capPos : this.cardPos;
      if (!node) return;
      if (which === 'card') {
        if (on) PAA.layer.sunOn(this.cardEl); else PAA.layer.sunOff(this.cardEl);
        node.classList.toggle('fade', !on && this.fadeOut);
        if (on) this.fadeOut = false;
      }
      if (which === 'cap' && was !== !!on) PAA.layer.capCount(on ? 1 : -1); // (null -> false is not a change)
      if (on && which === 'cap' && !this.capShown) { // the caption shows for the first time: the glint crosses it once
        this.capShown = true;
        PAA.layer.flash(this.capEl);
      }
      node.classList.toggle('hide', !on);
      if (which === 'cap') this.leadPos.classList.toggle('hide', !on);
    }

    hideAll() {
      if (this.pt) PAA.patch.hide(this);
      if (this.ov) PAA.overlay.hide(this);
      this.ovSeen = false;
      this.setVis('tick', false);
      this.setVis('cap', false);
      this.setVis('card', false);
    }

    /* the labels, every frame; when none is on screen any more (or one comes back) the caption and the ticks follow in the same frame */
    placeOverlay(f) {
      if (!this.ov) return;
      PAA.overlay.place(this, f);
      const seen = PAA.overlay.seen(this);
      if (seen !== this.ovSeen) {
        this.ovSeen = seen;
        if (this.applyDensity()) PAA.layer.requestLayout(0);
      }
    }

    /* the mark itself on screen (its ticks): false when nothing of it can be drawn now (hidden, off screen, behind the camera). */
    geometry(f) {
      this.cull = false;
      if (!this.dirArr && this.rec.view && this.rec.view.url !== location.href) { this.retire(); return false; } // flow L: the view changed
      if (!this.shouldShow(f) || PAA.prefs.density === 'off') return false;
      if (this.applyDensity()) PAA.layer.requestLayout(0); // the caption changed size
      const vr = f.vr;
      if (this.dirArr) {
        if (!this.project()) { this.cull = true; return false; }
        const p = this.pts;
        const x0 = Math.min(p[0].x, p[1].x, p[2].x, p[3].x), x1 = Math.max(p[0].x, p[1].x, p[2].x, p[3].x);
        const y0 = Math.min(p[0].y, p[1].y, p[2].y, p[3].y), y1 = Math.max(p[0].y, p[1].y, p[2].y, p[3].y);
        // off screen (with a margin so ticks do not pop at the edge): nothing to draw
        if (x1 < vr.x - 40 || x0 > vr.x + vr.w + 40 || y1 < vr.y - 40 || y0 > vr.y + vr.h + 40) { this.cull = true; return false; }
        const m = P.quadToMatrix3d(this.dirArr, this.w, this.h);
        if (m === P.HIDDEN_MATRIX) { this.cull = true; return false; }
        this.tick.style.transform = 'translate(' + -f.ox + 'px,' + -f.oy + 'px) ' + m;
      } else {
        this.fixedPts();
        const key = f.ox + ',' + f.oy;
        if (key !== this.fixedKey) {
          this.fixedKey = key;
          this.tick.style.transform = 'translate(' + (this.rec.screen.x - f.ox) + 'px,' + (this.rec.screen.y - f.oy) + 'px)';
        }
      }
      return true;
    }

    place(f) {
      if (this.dead) return;
      if (!this.geometry(f)) {
        // A point's ring (or a box) can be off screen while labels the model found round it are not (a crop is wider than its ring): the labels
        // cull themselves one by one, so they are placed whenever the mark is merely out of view and not hidden for another reason.
        const keep = this.cull && ((this.ov && this.ov.show) || this.pt);
        if (keep) {
          this.setVis('tick', false);
          this.setVis('cap', false);
          this.setVis('card', false);
          if (this.ov && this.ov.show) this.placeOverlay(f);
          if (this.pt) PAA.patch.place(this, f, false); // (the patch is bigger than the mark: it may be on screen while the mark's own rectangle is not)
        } else this.hideAll();
        return;
      }
      const vr = f.vr;
      this.setVis('tick', true);
      this.placeOverlay(f);
      if (this.pt) PAA.patch.place(this, f, true);

      const kind = this.viewKind();
      if (kind !== this.laidKind) this.layout(f); // first placement after something opened or changed
      const showCap = kind === 'cap';
      const off = kind === 'card' ? this.cardOff : this.capOff; // the "Reading" chip hangs where the caption will
      const node = showCap ? this.capPos : this.cardPos;
      this.anchorXY(off.a);
      const inside = this.ax >= vr.x && this.ax <= vr.x + vr.w && this.ay >= vr.y && this.ay <= vr.y + vr.h;
      const ok = inside && !this.covered && !(showCap && this.hidByCard) && node;
      this.setVis('cap', showCap && !!ok && !this.capNone && !(this.crowd && !this.hov));
      this.setVis('card', !showCap && !!ok);
      if (ok) {
        const tf = 'translate3d(' + (this.ax + off.dx) + 'px,' + (this.ay + off.dy) + 'px,0)';
        node.style.transform = tf;
        if (showCap && this.leadOn) this.leadPos.style.transform = tf; // (only while the hairline shows: one style write less per caption per frame)
        if (this.wantFocus && this.input && !showCap) { // flow C: the field is focused the moment the card shows
          this.wantFocus = false;
          this.input.focus();
        }
      }
    }

    /* Where Google's controls must not be, for the layer's cover check (screen px): the anchor and, for a caption, its four
       corners (pulled in 2 px) and its centre. A hidden-because-covered mark is asked from where it would hang. null when
       nothing shows. */
    coverPoints() {
      if (!(this.vis.cap || this.vis.card || this.covered)) return null;
      const pts = [{ x: this.ax, y: this.ay }];
      if (this.viewKind() === 'cap' && this.mKind === 'cap' && this.mW > 0) {
        const o = this.capOff;
        const x0 = this.ax + o.dx + 2, y0 = this.ay + o.dy + 2, x1 = x0 + this.mW - 4, y1 = y0 + this.mH - 4;
        pts.push({ x: x0, y: y0 }, { x: x1, y: y0 }, { x: x1, y: y1 }, { x: x0, y: y1 }, { x: (x0 + x1) / 2, y: (y0 + y1) / 2 });
      }
      return pts;
    }

    /* something is still being made for this mark (an ask or a follow-up, or its repaint): it must not be removed, and its page must not be left, before it is done */
    occupied() {
      return this.busy || !!(this.rp && this.rp.state === 'working');
    }

    setCovered(c) {
      if (this.covered === c) return false;
      this.covered = c;
      return true;
    }

    /* Flow L: the view changed, this screen-fixed mark leaves the screen. It stays saved. */
    retire() {
      this.retired = true;
      this.hideAll();
      if (!this.occupied()) PAA.layer.remove(this);
    }

    /* what the harness and the layer can see */
    debug() {
      const r = (n) => {
        if (!n) return null;
        const b = n.getBoundingClientRect();
        return { x: b.x, y: b.y, w: b.width, h: b.height };
      };
      return {
        id: this.id,
        state: this.state,
        retired: this.retired,
        busy: this.busy,
        open: this.open,
        kind: this.viewKind(),
        side: this.side,
        vis: Object.assign({}, this.vis),
        covered: this.covered,
        hov: this.hov,
        quiet: this.qNow,
        crowd: this.crowd,
        dot: this.dotNow,
        askOpen: this.askOpen,
        menuOpen: this.menuOpen,
        fuQueue: this.fuQueue.slice(),
        fuPending: this.fuPending ? { q: this.fuPending.q, len: (this.fuPending.text || '').length, err: this.fuPending.err || '' } : null,
        tick: r(this.tick),
        cap: r(this.capEl),
        capText: this.capEl.textContent,
        card: this.cardEl ? r(this.cardEl) : null,
        cardText: this.cardEl ? this.cardEl.innerText : null,
        cardClass: this.cardEl ? this.cardEl.className : null,
        buttons: this.cardEl ? Array.from(this.cardEl.querySelectorAll('button')).map((b) => ({ act: b.dataset.act, rect: r(b) })) : [],
        fuInput: this.fuInput && this.sk === 'full' ? { rect: r(this.fuInput), value: this.fuInput.value, focused: PAA.layer.activeElement() === this.fuInput, visible: this.askOpen } : null,
        input: this.input ? { rect: r(this.input), value: this.input.value, focused: PAA.layer.activeElement() === this.input } : null,
        a: { say: this.a.say, orig: this.a.orig, read: this.a.read, note: this.a.note, unsure: this.a.unsure, lines: (this.a.lines || []).length, structured: this.a.structured },
        err: this.err,
        busy: this.busy,
        rec: Object.assign({}, this.rec, { thumb: this.rec.thumb ? this.rec.thumb.length : 0 }),
        pts: this.pts.map((p) => ({ x: p.x, y: p.y })),
        ov: PAA.overlay ? PAA.overlay.debug(this) : null,
        rp: PAA.patch ? PAA.patch.debug(this) : null,
        capNone: this.capNone,
        bead: this.beadNow,
      };
    }
  }

  PAA.Mark = Mark;
  PAA.POINT_RING = POINT_RING;
})();
