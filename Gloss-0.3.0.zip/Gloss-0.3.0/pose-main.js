/* pose-main.js — Gloss v0.2, MAIN world, run_at document_start.
 *
 * Captures the view-projection matrix Google Maps Street View draws its panorama with, once per
 * animation frame, and hands it to the isolated-world module (pose.js) as a DOM event.
 *
 * How it finds the matrix (no reliance on minified names):
 *  - wraps uniformMatrix4fv / useProgram / drawArrays / drawElements / viewport on the WebGL1 and
 *    WebGL2 prototypes, so every context (including ones created later) is covered;
 *  - a program becomes a panorama candidate when it uploads a "camera at origin" perspective matrix
 *    (translation column = (0,0,c<0,0), rows 2 and 3 parallel) — the 3D cursor/arrow programs never do;
 *  - among candidates the one with the most draw calls wins (the tile program);
 *  - all matrices that program uploads during one task are batched and posted in a microtask, i.e.
 *    right after Maps' requestAnimationFrame callback returns and before the frame is painted, so an
 *    overlay positioned from them lands in the same composited frame as the panorama.
 * Every wrapper calls the original first-class and swallows its own errors: it can never break Maps.
 * If Google moves rendering off the main thread, nothing is posted and pose.js stays in rest-only mode.
 */
(() => {
  const G = Symbol.for('paa.pose.main');
  if (window[G]) return;
  window[G] = 1;

  const EVT_FRAME = 'paa-pose-frame';
  const EVT_URL = 'paa-pose-url';
  const now = () => performance.now();
  const progInfo = new WeakMap(); // WebGLProgram -> { id, draws, origin }
  const curProg = new WeakMap(); // context -> current WebGLProgram
  const ctxViewport = new WeakMap(); // context -> [x,y,w,h]
  let seq = 0;
  let pano = null; // { prog, info, ctx }
  let lastPano = null;
  let batch = null; // { mats: [], ctx }
  let stats = { frames: 0, us: 0 };

  const info = (p) => {
    let i = progInfo.get(p);
    if (!i) { i = { id: ++seq, draws: 0, origin: false }; progInfo.set(p, i); }
    return i;
  };
  const isOriginPerspective = (m) =>
    Math.abs(m[12]) < 1e-6 && Math.abs(m[13]) < 1e-6 && Math.abs(m[15]) < 1e-6 && m[14] < 0 &&
    Math.abs(m[3] * m[6] - m[7] * m[2]) + Math.abs(m[3] * m[10] - m[11] * m[2]) < 1e-3 * (Math.abs(m[3]) + Math.abs(m[7]) + Math.abs(m[11]) + 1e-9) * (Math.abs(m[2]) + Math.abs(m[6]) + Math.abs(m[10]) + 1e-9);

  function flush() {
    const t0 = now();
    const b = batch; batch = null;
    if (!b || !b.mats.length) return;
    try {
      const c = b.ctx.canvas;
      if (c && c.getAttribute && c.getAttribute('data-paa-pano') !== '1') {
        document.querySelectorAll('canvas[data-paa-pano]').forEach((e) => e.removeAttribute('data-paa-pano'));
        c.setAttribute('data-paa-pano', '1');
      }
      const vp = b.vp || ctxViewport.get(b.ctx) || [0, 0, c.width, c.height];
      const detail = JSON.stringify({ t: t0, mats: b.mats, vp, cw: c.width, ch: c.height });
      document.dispatchEvent(new CustomEvent(EVT_FRAME, { detail }));
    } catch (e) { /* never break Maps */ }
    stats.frames++; stats.us += (now() - t0) * 1000;
  }

  function onMatrix(ctx, args) {
    const p = curProg.get(ctx); if (!p) return;
    let v = args[2]; if (!v) return;
    const off = args[3] | 0;
    if (off || v.length !== 16) v = Array.prototype.slice.call(v, off, off + 16);
    const i = info(p);
    if (!i.origin && isOriginPerspective(v)) i.origin = true;
    if (!i.origin) return;
    if (!pano || (pano.prog !== p && i.draws > pano.info.draws)) { pano = { prog: p, info: i, ctx }; lastPano = p; }
    if (pano.prog !== p) return;
    const m = Array.prototype.map.call(v, (x) => +x);
    if (!batch) { batch = { mats: [], ctx, vp: ctxViewport.get(ctx) }; queueMicrotask(flush); } // viewport in effect for the panorama (split view draws the map elsewhere)
    const last = batch.mats[batch.mats.length - 1];
    if (!last || last.some((x, k) => x !== m[k])) batch.mats.push(m);
  }

  const wrap = (proto) => {
    if (!proto || proto.__paaWrapped) return;
    Object.defineProperty(proto, '__paaWrapped', { value: true });
    const uP = proto.useProgram;
    proto.useProgram = function (p) { try { curProg.set(this, p); } catch (e) {} return uP.apply(this, arguments); };
    const uM = proto.uniformMatrix4fv;
    proto.uniformMatrix4fv = function () { try { onMatrix(this, arguments); } catch (e) {} return uM.apply(this, arguments); };
    const vp = proto.viewport;
    proto.viewport = function (x, y, w, h) { try { ctxViewport.set(this, [x, y, w, h]); } catch (e) {} return vp.apply(this, arguments); };
    for (const fn of ['drawArrays', 'drawElements']) {
      const o = proto[fn];
      proto[fn] = function () { try { const p = curProg.get(this); if (p) info(p).draws++; } catch (e) {} return o.apply(this, arguments); };
    }
  };
  try { wrap(window.WebGLRenderingContext && WebGLRenderingContext.prototype); } catch (e) {}
  try { wrap(window.WebGL2RenderingContext && WebGL2RenderingContext.prototype); } catch (e) {}

  // Exact timestamps for address changes (Maps only rewrites the address ~350 ms after motion stops).
  for (const fn of ['pushState', 'replaceState']) {
    try {
      const o = history[fn];
      history[fn] = function () {
        const r = o.apply(this, arguments);
        try { document.dispatchEvent(new CustomEvent(EVT_URL, { detail: JSON.stringify({ t: now(), how: fn, href: location.href }) })); } catch (e) {}
        return r;
      };
    } catch (e) {}
  }
  // pose.js asks for a re-detect when the matrix disagrees with the address (e.g. locked onto a map program)
  document.addEventListener('paa-pose-reset', () => { pano = null; try { if (lastPano) progInfo.delete(lastPano); } catch (e) {} });
  // Cost probe for measurement scripts (not used by the extension).
  document.addEventListener('paa-pose-main-stats', () => {
    document.dispatchEvent(new CustomEvent('paa-pose-main-stats-result', { detail: JSON.stringify({ frames: stats.frames, us: stats.us, panoProg: pano && pano.info.id, draws: pano && pano.info.draws }) }));
  });
})();
