/* Gloss: the two layers and the per-frame tracking loop.

   WORLD layer: non-interactive visuals that belong to the picture (a mark's corner ticks; later overlays and
   patches). pointer-events none, a closed shadow root mounted right after canvas[data-paa-pano] so Google's own
   cards and buttons stay above it; falls back to a fixed layer on <html> when there is no panorama canvas.
   TOP layer: everything he can click (captions, cards; later dock and notebook). A closed shadow root on <html>
   at the top z-index, pointer-events none on the container and auto only on those elements.

   Tracking: PAAPose.onPose calls track() on every frame the camera moved (live) and once at rest; marks are
   placed synchronously inside that callback (an rAF of our own would add a frame of lag). Rules from the pose
   research: hide while flying between panoramas (transition / panoPending) or when a mark belongs to another
   panorama; when there is no per-frame pose (live false) hide on pointerdown, wheel or arrow keys and show
   again only on an address update that arrives with no input for 300 ms and no key or button held;
   always use pose.canvasRect, the picture may not fill the window.
   With no known camera (pose.panoId null: localhost, the flat map, Yandex) marks are fixed to the screen. */
(function () {
  'use strict';
  const PAA = self.PAA;
  const P = self.PAAPose;

  const marks = new Map(); // id -> Mark (the live ones: shown now, in flight, or on this panorama)
  let topHost = null, topRoot = null, pane = null, clipEl = null;
  let worldHost = null, worldRoot = null, stageEl = null, worldPane = null;
  let worldMode = ''; // 'scene' (after the canvas) | 'fixed' (on <html>)
  let canvas = null;
  let drawEl = null;
  let capturing = false;
  let restHidden = false;
  let lastPano = null;
  let wasMoving = false;
  let layoutTimer = 0;
  let lastCover = 0;
  let coverTimer = 0;
  let lastClip = '';
  let lastPaneClip = '';
  const org = { l: 0, t: 0, w: 0, h: 0, dirty: true, key: '' }; // the world host's rectangle, measured only when it can have changed
  let originWatch = null;
  let onPano = null;
  const hooks = []; // called after every track(), with the pose (see addFrameHook)
  let changedTimer = 0;
  const stats = { n: 0, ms: 0, max: 0 };
  const frame = { pose: null, ox: 0, oy: 0, vr: { x: 0, y: 0, w: 0, h: 0 }, hideWorld: false, avoid: null, cardAvoid: null };

  const el = (tag, cls) => {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    return e;
  };

  /* ---------------- building and mounting ---------------- */

  const SHIELD = ['pointerdown', 'pointerup', 'mousedown', 'mouseup', 'click', 'dblclick', 'contextmenu', 'wheel', 'touchstart', 'touchend'];

  function build() {
    topHost = el('div');
    topHost.setAttribute('style', 'all: initial; position: fixed; inset: 0; z-index: 2147483647; pointer-events: none;');
    topRoot = topHost.attachShadow({ mode: 'closed' });
    const ts = el('style');
    ts.textContent = PAA.css;
    // The top layer is cut to the picture (split view, side panel) WITHOUT clip-path: a clip-path on an ancestor makes the glass's backdrop
    // blur see nothing of the street. clipEl is sized and placed over the picture with overflow hidden; pane (the coordinate space of
    // everything inside: window pixels) is pulled back by the picture's corner. See fillFrame.
    clipEl = el('div', 'clip');
    clipEl.setAttribute('style', 'position: absolute; left: 0; top: 0; width: 100%; height: 100%; overflow: hidden; pointer-events: none;');
    pane = el('div', 'paa');
    clipEl.appendChild(pane);
    topRoot.append(ts, clipEl);
    // Presses on our elements never reach page listeners that run later in the bubble phase. (The capture phase
    // is left alone on purpose: our own window-level handlers need to see everything first.)
    SHIELD.forEach((t) => topHost.addEventListener(t, (e) => e.stopPropagation()));
    // pressing a button or caption must not steal the keyboard focus from Street View
    pane.addEventListener('mousedown', (e) => {
      if (e.target && e.target.closest && e.target.closest('button, .cap, .dock, .row, .seg b, .gear, .edge, .badge, .progress')) e.preventDefault();
    });

    pane.addEventListener('wheel', onWheelOverUs, { passive: false });

    worldHost = el('div');
    worldRoot = worldHost.attachShadow({ mode: 'closed' });
    const ws = el('style');
    ws.textContent = PAA.css;
    worldPane = el('div', 'paa');
    stageEl = el('div', 'stage');
    worldPane.appendChild(stageEl);
    worldRoot.append(ws, worldPane);
    // the world host's rectangle is read when it may have changed (resize of it, the window, the picture's own rectangle), not per frame
    try { originWatch = new ResizeObserver(() => { org.dirty = true; }); originWatch.observe(worldHost); } catch (e) { /* the key below still catches a moved picture */ }
  }

  /* The wheel over a card, the dock or the notebook still zooms Street View: our element is on top, so the wheel is
     passed on to whatever is underneath, as a copy of the event (Maps accepts it: checked live). The one exception is a
     list that can scroll (a long card's text, the notebook's rows): that scrolls itself and Street View stays put.
     A caption is click-through, so the wheel over one simply reaches Street View. */
  function onWheelOverUs(e) {
    if (!e.isTrusted) return;
    const sc = e.target && e.target.closest ? e.target.closest('.body, .rows') : null;
    if (sc && sc.scrollHeight > sc.clientHeight + 1) return;
    e.preventDefault();
    const under = document.elementsFromPoint(e.clientX, e.clientY).find((x) => x !== topHost && x !== worldHost);
    if (!under) return;
    under.dispatchEvent(new WheelEvent('wheel', {
      bubbles: true, cancelable: true, composed: true, view: window,
      clientX: e.clientX, clientY: e.clientY, screenX: e.screenX, screenY: e.screenY,
      deltaX: e.deltaX, deltaY: e.deltaY, deltaZ: e.deltaZ, deltaMode: e.deltaMode,
      ctrlKey: e.ctrlKey, shiftKey: e.shiftKey, altKey: e.altKey, metaKey: e.metaKey,
    }));
    startMotion(e, true); // the same bookkeeping as a wheel on the scene
    viewChanged();
  }

  /* The world host sits right after the panorama canvas; Maps may swap the canvas, so this is checked on every
     frame (two cheap property reads) and re-mounted when needed. */
  function mountWorld() {
    if (!worldHost) return;
    const c = canvas && canvas.isConnected ? canvas : (canvas = document.querySelector('canvas[data-paa-pano]'));
    if (c && c.parentNode) {
      if (worldMode === 'scene' && worldHost.isConnected && worldHost.previousElementSibling === c) return;
      worldHost.setAttribute('style', 'all: initial; position: absolute; left: 0; top: 0; width: 100%; height: 100%; pointer-events: none; overflow: hidden;');
      if (capturing) worldHost.style.visibility = 'hidden'; // a re-mount during a screenshot must not bring the layer back
      c.after(worldHost);
      worldMode = 'scene';
      org.dirty = true;
      lastClip = '';
    } else if (worldMode !== 'fixed' || !worldHost.isConnected) {
      worldHost.setAttribute('style', 'all: initial; position: fixed; inset: 0; z-index: 2147483000; pointer-events: none; overflow: hidden;');
      if (capturing) worldHost.style.visibility = 'hidden';
      document.documentElement.appendChild(worldHost);
      worldMode = 'fixed';
      org.dirty = true;
      lastClip = '';
    }
  }

  function ensure() {
    if (!document.documentElement) return false;
    if (!topHost) build();
    if (!topHost.isConnected) document.documentElement.appendChild(topHost);
    mountWorld();
    return true;
  }

  function inOurs(e) {
    if (!topHost || typeof e.composedPath !== 'function') return false;
    const path = e.composedPath();
    return path.indexOf(topHost) >= 0 || (worldHost && path.indexOf(worldHost) >= 0);
  }

  /* Both layers are hidden for the screenshot, and only for that: nothing of ours may be in a captured image. Hiding the hosts is
     not enough: an element of ours that has its own visibility (a card in its 100 ms closing fade, which transitions
     visibility) shows through a hidden ancestor. So the layers also get the class "capturing", which forces visibility hidden and
     kills transitions and animations for everything inside, with !important (see extensions.css). */
  /* While Option is held our cards and the notebook let the pointer through: Option is "ask about what is under the pointer", and what
     is under the pointer may be hidden by a card (gesture.js calls this on Option going down and up). */
  let altOn = false;
  function setAlt(on) {
    on = !!on;
    if (on === altOn) return;
    altOn = on;
    if (pane) pane.classList.toggle('alt', on);
  }

  /* Hide both layers for a screenshot, for as long as ANYONE who asked still holds it: returns a release (call it once; calling it again does nothing).
     An ask's capture and a repaint's can overlap, and the first one's screenshot must not bring our layers back while the other's is still to be taken. */
  let capHolds = 0;
  function holdCapture() {
    capHolds++;
    setCapturing(true);
    let released = false;
    return function release() {
      if (released) return;
      released = true;
      capHolds = Math.max(0, capHolds - 1);
      if (!capHolds) setCapturing(false);
    };
  }

  function setCapturing(on) {
    capturing = on;
    ensure();
    const v = on ? 'hidden' : '';
    if (topHost) topHost.style.visibility = v;
    if (worldHost) worldHost.style.visibility = v;
    if (pane) pane.classList.toggle('capturing', on);
    if (worldPane) worldPane.classList.toggle('capturing', on);
  }

  /* A glass surface (see design/glass.css, design/glass.js). It gets the class "lg" ("pill" for the small ones: captions, the dock,
     the Reading chip, buttons) and the three helper children in this order: <i class="core"></i> (the frosted, tinted middle),
     <i class="rim"></i> (the bevel with its iridescent edge) and <i class="sheen"></i> (the glare and the glint). They are put first,
     so the content that follows lies on top of them. Call again after the element's children were cleared. kind: 'pill', 'flat'
     (glass without refraction: something that sits inside another glass surface, like the more menu) or nothing (a slab). */
  function glass(e, kind) {
    e.classList.add('lg');
    if (kind === 'pill') e.classList.add('pill');
    if (kind === 'flat') e.classList.add('flat');
    const core = el('i', 'core'), rim = el('i', 'rim'), sheen = el('i', 'sheen');
    e.insertBefore(sheen, e.firstChild);
    e.insertBefore(rim, e.firstChild);
    e.insertBefore(core, e.firstChild);
    e.__sheen = sheen;
    sheen.style.setProperty('--sun', sunPx + 'px');
    if (kind !== 'flat' && self.PAAGlass && !e.__fit) { // refraction: fitted when it has a size, and again when the size changes
      e.__fit = true;
      PAAGlass.watch(e, { root: topRoot });
    }
    return e;
  }

  /* Light that belongs to the world: the glare on a big slab slides a little as he turns, as if a fixed sun lit it. Only the
     elements registered with sunOn() are moved (the dock, the notebook, the open cards: a handful), and only when the shift has
     changed by a third of a pixel: one custom property on one child each, no layout, nothing per caption. */
  const SUN_AMP = 80;  // px the glare may slide either way
  const SUN_AZ = 60;   // the compass bearing of the sun
  let sunPx = 0;
  const sunSet = new Set();
  function sunOn(e) { if (!e) return; sunSet.add(e); sunUpdate(P.getPose().heading); if (e.__sheen) e.__sheen.style.setProperty('--sun', sunPx.toFixed(1) + 'px'); }
  function sunOff(e) { if (e) sunSet.delete(e); }
  function sunUpdate(heading) {
    if (typeof heading !== 'number') return;
    const px = -SUN_AMP * Math.sin((heading - SUN_AZ) * Math.PI / 180);
    if (Math.abs(px - sunPx) < 0.35) return;
    sunPx = px;
    const v = px.toFixed(1) + 'px';
    for (const e of sunSet) if (e.__sheen) e.__sheen.style.setProperty('--sun', v);
  }

  /* The open card tilts a few degrees towards the pointer while the pointer is over it (custom properties --tx, --ty; the CSS class
     "tilt" turns them into a transform and is switched off under prefers-reduced-motion). The tilt is full a little way in from the
     edge and falls to nothing AT the edge (TILT_EDGE px), so the edge the pointer is on never moves out from under it. The card's
     place is read from its wrapper (a 0 x 0 box at the card's corner, which the tilt does not move) and its layout size, once per
     animation frame while the pointer moves, so it is never stale after the card moved or grew. */
  const TILT_DEG = 6;
  const TILT_EDGE = 14;
  const still = self.matchMedia ? matchMedia('(prefers-reduced-motion: reduce)') : { matches: false };
  function tilt(e, ev) {
    if (still.matches) return;
    e.__tp = { x: ev.clientX, y: ev.clientY };
    if (e.__tf) return;
    e.__tf = requestAnimationFrame(() => {
      e.__tf = 0;
      const p = e.__tp, host = e.parentNode;
      if (!p || !host) return;
      const o = host.getBoundingClientRect(), w = e.offsetWidth, h = e.offsetHeight;
      if (!w || !h) return;
      const lx = p.x - o.left, ly = p.y - o.top;
      const fade = Math.max(0, Math.min(1, Math.min(lx, w - lx, ly, h - ly) / TILT_EDGE));
      const px = Math.max(0, Math.min(1, lx / w)), py = Math.max(0, Math.min(1, ly / h));
      e.style.setProperty('--tx', ((0.5 - py) * 2 * TILT_DEG * fade).toFixed(2) + 'deg');
      e.style.setProperty('--ty', ((px - 0.5) * 2 * TILT_DEG * fade).toFixed(2) + 'deg');
    });
  }
  function untilt(e) {
    e.__tp = null;
    if (e.__tf) { cancelAnimationFrame(e.__tf); e.__tf = 0; }
    e.style.setProperty('--tx', '0deg');
    e.style.setProperty('--ty', '0deg');
  }

  /* How much glass the captions get (see extensions.css and BUILD-NOTES section 9): 'full' (refraction), 'lite' (the slab look over a plain
     blur), 'flat' (no blur and a denser core). Cards, the dock and the notebook always have the refraction. */
  let fxMode = 'full';
  function setFx(mode) {
    if (mode === fxMode || !pane) return;
    fxMode = mode;
    pane.classList.toggle('fx-lite', mode === 'lite');
    pane.classList.toggle('fx-flat', mode === 'flat');
  }
  /* Marks tell us when a caption starts or stops showing. With many showing at once the refraction on every one of them is more than the
     GPU does at 60 frames a second (live-1a s10: 39 captions, every third frame missed; the same 39 with the plain blur: 2 misses in 400), so
     above CAPS_LITE showing captions all captions go 'lite' (the same slab, a plain blur behind it) and come back below CAPS_LITE - 4. The
     slabs (cards, notebook, dock) keep the refraction: there are only ever a few. */
  const CAPS_LITE = 30;
  let capsShown = 0;
  function capCount(d) {
    capsShown = Math.max(0, capsShown + d);
    if (capsShown > CAPS_LITE) setFx('lite');
    else if (capsShown <= CAPS_LITE - 4 && fxMode === 'lite') setFx('full');
  }

  /* The glint crosses a surface once (class "appear", removed again after the animation). */
  function flash(e) {
    if (!e) return;
    e.classList.add('appear');
    clearTimeout(e.__flash);
    e.__flash = setTimeout(() => e.classList.remove('appear'), 1000);
  }

  /* ---------------- the drawing outline (screen space, while the button is down) ---------------- */

  const drawing = {
    show(g) {
      if (!ensure()) return;
      if (!drawEl) {
        drawEl = el('div', 'mark drawing hide');
        for (let i = 0; i < 4; i++) drawEl.appendChild(el('i'));
        pane.appendChild(drawEl);
      }
      const point = !!g.point;
      drawEl.classList.toggle('point', point);
      drawEl.classList.remove('hide');
      const s = drawEl.style;
      if (point) {
        const d = PAA.POINT_RING;
        s.left = g.x - d / 2 + 'px'; s.top = g.y - d / 2 + 'px'; s.width = d + 'px'; s.height = d + 'px';
      } else {
        s.left = g.x + 'px'; s.top = g.y + 'px'; s.width = g.w + 'px'; s.height = g.h + 'px';
      }
    },
    hide() {
      if (drawEl) drawEl.classList.add('hide');
    },
  };

  /* ---------------- the per-frame loop ---------------- */

  function intersectRect(cr, iw, ih) {
    const x = Math.max(0, cr.x), y = Math.max(0, cr.y);
    return { x: x, y: y, w: Math.max(0, Math.min(iw, cr.x + cr.width) - x), h: Math.max(0, Math.min(ih, cr.y + cr.height) - y) };
  }

  function fillFrame(pose) {
    const f = frame;
    f.pose = pose;
    const cr = pose.canvasRect;
    const ckey = cr ? cr.x + ',' + cr.y + ',' + cr.width + ',' + cr.height : '';
    if (org.dirty || ckey !== org.key) { // (a moved or resized picture, or a re-mounted host)
      const r = worldHost.getBoundingClientRect();
      org.l = r.left; org.t = r.top; org.w = r.width; org.h = r.height; org.dirty = false; org.key = ckey;
    }
    f.ox = org.l;
    f.oy = org.t;
    const iw = window.innerWidth, ih = window.innerHeight;
    const known = !!pose.panoId;
    const v = known && cr ? intersectRect(cr, iw, ih) : { x: 0, y: 0, w: iw, h: ih };
    f.vr.x = v.x; f.vr.y = v.y; f.vr.w = v.w; f.vr.h = v.h;
    // where Google's own controls sit (bottom right: compass, zoom, map type; bottom left: the mini map; top right: the dock's place
    // under Share): cards keep clear of them
    f.avoid = known && v.w >= 600 && v.h >= 420
      ? [{ x: v.x + v.w - 66, y: v.y + v.h - 172, w: 66, h: 160 }, { x: v.x + v.w - 136, y: v.y + v.h - 52, w: 136, h: 40 }, { x: v.x + 8, y: v.y + v.h - 132, w: 240, h: 124 },
         { x: v.x + v.w - 150, y: v.y + 74, w: 150, h: 56 }]
      : null;
    // an open notebook is where a card must not go either (a narrow window put the card under it): its strip under the dock, right-aligned, as tall as its CSS allows
    f.cardAvoid = f.avoid;
    if (f.avoid && PAA.book && PAA.book.isOpen()) f.cardAvoid = f.avoid.concat([{ x: v.x + v.w - 314, y: v.y + 130, w: 314, h: Math.max(150, Math.min(v.h * 0.6, v.h - 318)) }]);
    f.hideWorld = !known || !!pose.transition || !!pose.panoPending || restHidden; // (capturing hides the hosts themselves, so the marks do not flicker when they come back)
    // clip the world layer and the top layer to the picture when it does not fill the window (split view, side panel)
    const full = v.x < 1.5 && v.y < 1.5 && v.w > iw - 1.5 && v.h > ih - 1.5;
    const clip = full ? '' : 'inset(' + (v.y - org.t) + 'px ' + (org.l + org.w - v.x - v.w) + 'px ' + (org.t + org.h - v.y - v.h) + 'px ' + (v.x - org.l) + 'px)';
    if (clip !== lastClip) { lastClip = clip; stageEl.style.clipPath = clip; }
    // the top layer: a box over the picture with overflow hidden; the pane inside it keeps window coordinates
    const pkey = full ? iw + 'x' + ih : v.x + ',' + v.y + ',' + v.w + ',' + v.h + ',' + iw + 'x' + ih;
    if (pkey !== lastPaneClip) {
      lastPaneClip = pkey;
      const c = clipEl.style, p = pane.style;
      if (full) {
        c.left = '0'; c.top = '0'; c.width = '100%'; c.height = '100%';
        p.left = '0'; p.top = '0'; p.width = '100%'; p.height = '100%';
      } else {
        c.left = v.x + 'px'; c.top = v.y + 'px'; c.width = v.w + 'px'; c.height = v.h + 'px';
        p.left = -v.x + 'px'; p.top = -v.y + 'px'; p.width = iw + 'px'; p.height = ih + 'px';
      }
    }
    return f;
  }

  function track(pose) {
    // a new panorama (or none): the app loads/unloads saved marks
    const pid = pose.panoId || null;
    if (pid !== lastPano) {
      lastPano = pid;
      if (onPano) { try { onPano(pid); } catch (e) { console.warn('[PAA] onPano', e); } }
    }
    if (!topHost) return;
    // the clip of both layers follows the picture even with no marks (the outline, notebook and hint live in the top layer)
    mountWorld();
    const f = fillFrame(pose);
    if (marks.size) {
      for (const m of marks.values()) m.place(f);
      // one more pass when the view comes to rest: placement, collisions, cover check (never per frame)
      const rest = pose.live ? !pose.moving : true;
      if (rest && wasMoving) requestLayout(30);
      wasMoving = !rest;
    }
    if (sunSet.size) sunUpdate(pose.heading);
    for (let i = 0; i < hooks.length; i++) hooks[i](pose); // the dock's box, the edge chip, hover: after the marks moved
  }

  function onPose(pose) {
    const t0 = performance.now();
    try {
      // rest-only fallback: an address update that arrives with no input for 300 ms ends the hidden phase
      if (!pose.live && restHidden && pose.settled && idle()) {
        restHidden = false;
        clearTimeout(startMotion.safety);
        requestLayout(30);
      }
      track(pose);
    } catch (e) {
      console.warn('[PAA] track', e);
    }
    const dt = performance.now() - t0;
    stats.n++; stats.ms += dt; if (dt > stats.max) stats.max = dt;
  }
  P.onPose(onPose);

  /* Re-run placement now (after something changed while the view is at rest, or on a page with no pose events). */
  function trackNow() {
    onPose(P.getPose());
  }

  /* ---------------- layout pass: when something opens or changes, and when the view settles ---------------- */

  function requestLayout(delay) {
    if (layoutTimer) return;
    layoutTimer = setTimeout(layoutAll, delay == null ? 0 : delay);
  }

  const inMotion = (pose) => !!(pose.live && pose.moving);

  function layoutAll() {
    layoutTimer = 0;
    if (!ensure() || !marks.size) return;
    const pose = P.getPose();
    if (inMotion(pose)) return; // never while the view moves (cards would flip sides mid-pan): the settle pass in track() runs this
    const t0 = performance.now();
    const f = fillFrame(pose);
    const list = [];
    for (const m of marks.values()) if (m.shouldShow(f)) list.push(m);
    // 1. reads only (sizes), 2. pure placement + caption collisions, 3. writes only: no layout thrash
    const ok = list.filter((m) => m.measure());
    const bookR = PAA.book && PAA.book.rect ? PAA.book.rect() : null; // (a read, with the other reads) the open notebook
    const caps = [];
    const obstacles = [];
    const byKey = new Map();
    ok.forEach((m) => {
      const r = m.decide(f);
      if (r.kind === 'card') obstacles.push(r.rect);
      else if (!m.capNone) { // (a caption that is hidden because the mark shows its English takes no room: it pushes nobody away)
        // (the one under the pointer first, then the marks asked here, then soft anchors; within each, top to bottom: the pushes stay shortest that way)
        caps.push({ key: m.id, x: r.rect.x, y: r.rect.y, w: r.rect.w, h: r.rect.h, dir: r.dir, bead: m.beadNow, keep: m.hov, prio: m.hov ? -1 : m.far ? 1 : 0 });
        byKey.set(m.id, m);
      }
    });
    if (bookR) obstacles.push(bookR); // a caption under the open notebook is hidden like one under an open card (it used to show half under the slab), and the others keep off it
    // English drawn over signs: a caption keeps off the labels it is not part of (one mark's caption over another's label hid the label)
    const labels = [];
    if (PAA.overlay) for (const m of marks.values()) PAA.overlay.rects(m, labels);
    labels.forEach((r) => { r.lab = true; });
    lastLabels = labels; // (a caption's leader line passes behind them: Mark.drawLeader)
    ok.forEach((m) => m.apply());
    // a caption the open card covers is hidden while the card is open; the rest are pushed apart where they collide
    const free = caps.filter((c) => {
      const hid = obstacles.some((o) => PAA.Place.intersects(c, o, 0));
      byKey.get(c.key).hidByCard = hid;
      return !hid;
    });
    const crowded = {};
    const shifts = free.length > 1 || (free.length && (obstacles.length || labels.length)) ? PAA.Place.resolveCaptions(free, obstacles.concat(labels), crowded) : {};
    free.forEach((c) => { const m = byKey.get(c.key); m.crowd = !!crowded[c.key]; m.shiftCap(shifts[c.key] || 0); });
    for (const m of marks.values()) m.place(f);
    checkCovered(false);
    const dt = performance.now() - t0;
    stats.layouts = (stats.layouts || 0) + 1; stats.layoutMs = (stats.layoutMs || 0) + dt; if (dt > (stats.layoutMax || 0)) stats.layoutMax = dt;
  }

  /* One mark's own card or caption changed size (an answer streaming in): re-measure and re-place only that mark. No
     collision pass, no cover check, nothing while the view moves: the full pass runs when the answer is complete and
     when the view settles. A caption keeps the shift the last full pass gave it. */
  let lastLabels = []; // the English labels showing at the last full layout pass (screen rectangles)

  function layoutMark(m) {
    if (!ensure() || m.dead) return;
    const pose = P.getPose();
    if (inMotion(pose)) return;
    const f = fillFrame(pose);
    if (!m.shouldShow(f)) return;
    const shift = m.capOff.dy - m.capOff.dy0;
    if (!m.measure()) return;
    m.decide(f);
    m.apply();
    if (m.mKind === 'cap') m.shiftCap(shift);
    m.place(f);
  }

  /* ---------------- Google's own controls over our anchor ---------------- */

  /* Is one of Google's controls on this point? The topmost elements at the point are walked until the panorama
     canvas (or the page) is reached; anything in between that is not a scene-sized wrapper is a control. */
  function coveredAt(x, y) {
    const c = canvas && canvas.isConnected ? canvas : null;
    if (!c) return false; // no panorama: nothing of Google's is "over the picture"
    const list = document.elementsFromPoint(x, y);
    const vr = frame.vr;
    for (let i = 0; i < list.length; i++) {
      const e = list[i];
      if (e === topHost || e === worldHost) continue;
      if (e === c || e === document.body || e === document.documentElement) return false;
      const b = e.getBoundingClientRect();
      if (b.width * b.height >= 0.85 * vr.w * vr.h) continue; // a scene-sized wrapper, not a control
      return true;
    }
    return false;
  }

  /* At rest, and at most every 150 ms (a call that comes too soon is made once more when the 150 ms are up): a caption
     or card with one of Google's controls on its anchor, or a caption with one on its edge, is hidden until it is clear. */
  function checkCovered(force) {
    if (!marks.size || !topHost) return;
    if (inMotion(P.getPose())) return; // the settle pass asks again
    const now = performance.now();
    if (!force && now - lastCover < 150) {
      if (!coverTimer) coverTimer = setTimeout(() => { coverTimer = 0; checkCovered(true); }, 155 - (now - lastCover));
      return;
    }
    lastCover = now;
    let changed = false;
    for (const m of marks.values()) {
      const pts = m.coverPoints();
      if (!pts) continue;
      const was = m.covered;
      if (m.setCovered(pts.some((q) => coveredAt(q.x, q.y))) && was !== m.covered) changed = true;
    }
    if (changed) for (const m of marks.values()) m.place(frame);
  }

  /* ---------------- input watchers (observe only, never swallow) ---------------- */

  let moved = false, lastInput = 0, buttons = 0;
  const keys = new Set();
  const idle = () => !keys.size && !buttons && performance.now() - lastInput > 300;

  // rest-only mode: hide the moment the view starts moving, show again at the next quiet address update
  function startMotion(e, isMove) {
    lastInput = performance.now();
    if (e.altKey || !marks.size) return;
    const pose = P.getPose();
    if (pose.live || !pose.panoId) return;
    if (!restHidden) { restHidden = true; moved = false; trackNow(); }
    if (isMove) moved = true;
    clearTimeout(startMotion.click);
    clearTimeout(startMotion.safety);
    startMotion.safety = setTimeout(() => { restHidden = false; trackNow(); requestLayout(30); }, 8000); // never stay hidden forever
  }

  // flow L: with no known camera a mark is fixed to the screen until the view changes
  function viewChanged() {
    if (!marks.size) return;
    if (P.getPose().panoId) return;
    for (const m of Array.from(marks.values())) if (!m.dirArr) m.retire();
  }

  let downAt = null;
  function watchPointer(e) {
    if (!e.isTrusted || inOurs(e)) return;
    if (e.type === 'pointerdown') {
      buttons = e.buttons;
      downAt = { x: e.clientX, y: e.clientY };
      startMotion(e, false);
    } else if (e.type === 'pointermove') {
      buttons = e.buttons;
      if (e.buttons) {
        lastInput = performance.now();
        if (restHidden) moved = true;
        if (downAt && !e.altKey && Math.hypot(e.clientX - downAt.x, e.clientY - downAt.y) > 5) viewChanged();
      }
    } else if (e.type === 'pointerup') {
      buttons = e.buttons;
      lastInput = performance.now();
      downAt = null;
      if (restHidden && !moved) startMotion.click = setTimeout(() => { if (!moved) { restHidden = false; trackNow(); } }, 500);
    }
  }
  ['pointerdown', 'pointermove', 'pointerup'].forEach((t) => addEventListener(t, watchPointer, { capture: true, passive: true }));
  addEventListener('wheel', (e) => { if (e.isTrusted && !inOurs(e)) { startMotion(e, true); viewChanged(); } }, { capture: true, passive: true });
  // Only a scroll that moves the page or the picture counts (the document, or something that holds the panorama): not the scrolling of
  // Google's own side panel or of a list on the page.
  addEventListener('scroll', (e) => {
    const t = e.target;
    const page = t === document || t === document.documentElement || t === document.body;
    const holds = !page && t && t.contains && ((worldHost && t.contains(worldHost)) || (canvas && t.contains(canvas)));
    if (!page && !holds) return;
    org.dirty = true;
    viewChanged();
  }, { capture: true, passive: true });
  addEventListener('keydown', (e) => {
    if (!e.isTrusted || inOurs(e)) return;
    if (/^Arrow|^[wasd+-]$/.test(e.key)) { keys.add(e.code); startMotion(e, true); } // by e.code: keyup can report another e.key (a held Shift)
  }, true);
  addEventListener('keyup', (e) => { if (keys.delete(e.code)) lastInput = performance.now(); }, true);
  addEventListener('blur', () => { keys.clear(); buttons = 0; });
  addEventListener('resize', () => {
    org.dirty = true;
    viewChanged();
    setTimeout(() => { trackNow(); requestLayout(30); }, 60);
  });

  /* ---------------- the registry ---------------- */

  const layer = {
    ensure: ensure,
    stage: () => stageEl,
    pane: () => pane,
    inOurs: inOurs,
    glass: glass,
    sunOn: sunOn,
    sunOff: sunOff,
    tilt: tilt,
    untilt: untilt,
    flash: flash,
    setFx: setFx,
    fx: () => fxMode,
    capCount: capCount,
    activeElement: () => (topRoot ? topRoot.activeElement : null),
    setCapturing: setCapturing,
    holdCapture: holdCapture,
    setAlt: setAlt,
    drawing: drawing,
    requestLayout: requestLayout,
    layoutNow: () => { clearTimeout(layoutTimer); layoutAll(); }, // a batch of marks that just arrived: one measure/decide/apply pass, not one per mark
    layoutMark: layoutMark,
    labels: () => lastLabels,
    trackNow: trackNow,
    checkCovered: checkCovered,
    setPanoHandler(fn) { onPano = fn; },
    /* fn(pose) runs at the end of every tracking pass, marks or no marks (must be cheap: no layout reads) */
    addFrameHook(fn) { hooks.push(fn); },
    /* the set of marks, or one of their states, changed: the dock's count follows */
    changed() {
      if (changedTimer) return;
      changedTimer = setTimeout(() => {
        changedTimer = 0;
        if (PAA.dock) PAA.dock.refresh();
        if (PAA.overlay) PAA.overlay.dedupe(); // marks came or went: two answers about one sign draw one set of labels
      }, 0);
    },
    lastPano: () => lastPano,
    avoid: () => frame.avoid || [],
    add(m) { marks.set(m.id, m); layer.changed(); },
    get(id) { return marks.get(id) || null; },
    all() { return Array.from(marks.values()); },
    remove(m) {
      marks.delete(m.id);
      m.destroy();
      layer.changed();
    },
    stats: stats,
    debug() {
      return {
        worldMode: worldMode,
        worldRect: worldHost ? worldHost.getBoundingClientRect().toJSON() : null,
        restHidden: restHidden,
        stats: { n: stats.n, ms: stats.ms, max: stats.max, layouts: stats.layouts || 0, layoutMs: stats.layoutMs || 0, layoutMax: stats.layoutMax || 0 },
        marks: Array.from(marks.values()).map((m) => m.debug()),
      };
    },
  };
  PAA.layer = layer;
  PAA.Place = self.PAAPlace;
  PAA.Geo = self.PAAGeo;
})();
