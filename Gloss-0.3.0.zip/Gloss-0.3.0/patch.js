/* Gloss: AI repaint (stage 4), the page's part: press Repaint on a card and the sign comes back in English, painted in its own style.

   What the worker does (repaint-worker.js): the image model letters the exact English that Haiku read, Haiku reads the result back, the picture outside the
   text is compared with the original, one automatic retry; a result that fails is never returned as a picture. What this file does:
     - decides WHAT to repaint (plan): the stored crop when it holds the whole sign with a margin and has a shape the image model can output, else a fresh
       screenshot of the sign as it is on screen now, cut with a margin to such a shape (the sign must be in view); else says why not, in the card
     - while it runs: the reading glint on the mark, a progress chip under its caption (Repainting / Checking / Trying again, a bar, seconds, a cancel)
     - the patch: the result, warped onto the picture's corner directions every frame in the WORLD layer exactly like an overlay label (four projections, one
       matrix, one transform write: no layout, no measuring, no frame of our own), with a feathered edge (made in the worker), under the ticks and labels
     - the badge "AI repaint" beside the caption: pressing and holding it shows the original (the patch hides while it is held); the card's Repaint button
       toggles the patch off and on (the picture is kept), and held for a moment it compares too
     - the record: rec.repaint = { v, on, dirs (the patch's four corner directions), size (CSS px, its base size), img {w, h}, source, lines, stats, spent }, the
       picture itself under its own storage key (store.js), loaded again when the mark is restored. Never drawn from another panorama (a far mark has none),
       never in a picture we capture (both layers are hidden for the screenshot). A mark with a patch showing draws no overlay labels (overlay.js asks on()). */
(function () {
  'use strict';
  const PAA = self.PAA;
  const P = self.PAAPose;
  const R = self.PAARepaint;
  const Geo = self.PAAGeo;

  const BADGE_W = 100, BADGE_H = 26; // fixed sizes: nothing is measured per frame
  const CHIP_W = 252, CHIP_H = 32;
  const CAP_H = 32; // a caption's height (design/glass.css)
  const HOLD_MS = 320; // a press on the card's Repaint button held this long compares with the original
  const GUARD_MS = 200000; // a run that has not ended by now is cancelled (two tries of the slowest image call are about 100 s)
  const SWITCHED = 'You switched tab before the picture was taken. Try again.';

  const el = (tag, cls, text) => {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== undefined) e.textContent = text;
    return e;
  };
  function icon(path, fill) {
    const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    s.setAttribute('viewBox', '0 0 24 24');
    const p = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    p.setAttribute('d', path);
    if (fill) p.setAttribute('fill', 'currentColor');
    s.appendChild(p);
    return s;
  }
  const ICON_SPARK = 'M12 2.5l2.1 5.9 5.9 2.1-5.9 2.1-2.1 5.9-2.1-5.9L4 10.5l5.9-2.1zM19 15.5l.9 2.4 2.4.9-2.4.9-.9 2.4-.9-2.4-2.4-.9 2.4-.9z';
  const ICON_X = 'M6 6l12 12M18 6L6 18';

  /* what the card says when it will not, or could not (plain, short; "try again" is the button) */
  const MSG = {
    cut: 'Part of the writing is cut off or unclear, so a repaint would leave old and new lettering side by side. Ask again with the whole sign in the box.',
    nothing: 'Nothing to repaint here: the writing is already in Latin letters, or has no translation.',
    edge: 'The sign runs off the edge of the picture. Turn the view so all of it shows, then try again.',
    big: 'The sign fills too much of the picture to repaint with its surroundings. Zoom out a little, then try again.',
    small: 'The sign is too small on screen to repaint. Zoom in on it, then try again.',
    away: 'The sign has to be in view to repaint it. Turn to face it, then try again.',
    nocam: 'Repainting needs Street View with a known camera: this page has none.',
    old: 'This note does not know where its lines are (it was made by an older version). Ask again, then repaint.',
    shape: 'Could not frame the sign for the image model. Try again.',
    moved: 'The view moved before the picture was taken. Try again.',
    controls: 'The sign is too close to one of Google\'s own buttons or cards, and a repaint would copy it. Turn the view so the sign sits clear of them, then try again.',
    wait: 'An answer is still being written. Press Repaint when it is done.',
  };

  /* ---------- state of a mark's repaint ---------- */
  function rpOf(m) {
    return m.rp || (m.rp = { state: 'idle', msg: '', problems: [], phase: 'paint', t0: 0, port: null, timer: 0, guard: 0, cost: 0, ms: 0, cap: null });
  }
  function ptOf(m) {
    return m.pt || (m.pt = {
      el: null, img: null, dirs: null, bw: 0, bh: 0, pts: [{ x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }], vis: false, glinted: false, showing: false, held: false, loaded: false, loading: false,
      badge: null, chip: null, badgeVis: false, chipVis: false, bx: NaN, by: NaN, cx: NaN, cy: NaN,
    });
  }
  const has = (m) => !!(m.rec && m.rec.repaint && m.rec.repaint.dirs);
  /* the patch picture is here and decoded (it can be drawn); has(m) without it means it is still being loaded from the worker, or that loading it failed */
  const hasPatch = (m) => has(m) && !!(m.pt && m.pt.el && m.pt.loaded);
  /* the patch is wanted on screen: it exists in the record and was not switched off. (Not "on screen now": the overlay must not flicker when the patch scrolls out.) */
  const on = (m) => has(m) && m.rec.repaint.on !== false;
  const working = (m) => !!(m.rp && m.rp.state === 'working');

  function save(m) {
    if (m.state === 'done' && !m.dead) PAA.store.save(m.rec).catch((e) => console.warn('[PAA] save failed', e));
  }

  /* ---------- the patch in the world layer ---------- */
  function setVis(pt, vis, instant) {
    if (pt.vis === vis) return;
    pt.vis = vis;
    pt.el.classList.toggle('now', !vis && instant !== false);
    pt.el.classList.toggle('vis', vis);
    if (vis && !pt.glinted) {
      pt.glinted = true;
      pt.el.classList.add('glint'); // the light crosses it once as it appears
      setTimeout(() => pt.el && pt.el.classList.remove('glint'), 1500);
    }
  }

  function build(m, img) {
    const pt = ptOf(m);
    const rp = m.rec.repaint;
    if (pt.el) pt.el.remove();
    const e = el('div', 'patch');
    const im = new Image();
    im.alt = '';
    im.draggable = false;
    im.decoding = 'async';
    im.src = img.url;
    const g = el('i', 'g'); // the glint
    e.append(im, g);
    pt.bw = rp.size[0];
    pt.bh = rp.size[1];
    e.style.width = pt.bw + 'px';
    e.style.height = pt.bh + 'px';
    pt.dirs = [rp.dirs.tl, rp.dirs.tr, rp.dirs.br, rp.dirs.bl];
    pt.el = e;
    pt.img = im;
    pt.glinted = false;
    pt.vis = false;
    PAA.layer.stage().prepend(e); // under the ticks and the labels
    ensureBadge(m);
  }

  /* the picture of a restored mark (or of the repaint that has just passed): asked from the worker, which keeps it under its own key */
  async function load(m, quiet) {
    const pt = ptOf(m);
    if (pt.loading) return;
    pt.loading = true;
    try {
      let img = await PAA.store.patch(m.id);
      if (m.dead) return;
      const tok = has(m) && m.rec.repaint.img ? m.rec.repaint.img.t : null;
      if (img && typeof tok === 'number' && typeof img.t === 'number' && img.t !== tok) { // a picture that is not the one this record describes (a run that was cancelled as it finished): not drawn on the wrong corners
        img = null;
        if (!working(m)) PAA.store.unpatch(m.id).catch(() => {}); // and not kept (about 200 KB) until the note is deleted
      }
      if (!img || !has(m)) { // the picture is gone (storage cleared): the record forgets the repaint
        if (has(m)) { m.rec.repaint = null; save(m); }
        dropPatch(m);
        if (PAA.overlay && m.ov) PAA.overlay.refresh(m);
        m.actsKey = '';
        if (!quiet && !m.dead) m.render();
        return;
      }
      build(m, img);
      try { await pt.img.decode(); } catch (e) { /* it draws when it has loaded */ } // (no blank frame when it first shows)
      if (m.dead || !pt.el) return;
      pt.loaded = true;
      if (PAA.overlay && m.ov) PAA.overlay.refresh(m);
      m.actsKey = '';
      if (!m.dead) { m.render(); PAA.layer.trackNow(); PAA.layer.requestLayout(0); }
    } catch (e) {
      console.warn('[PAA] repaint picture', e);
    } finally {
      pt.loading = false;
      if (!pt.loaded && has(m) && !m.dead) { m.actsKey = ''; m.render(); } // (the card's button says "loading", or offers to load it again)
    }
  }

  function attach(m, quiet) {
    if (m.far || !has(m)) return;
    ptOf(m);
    load(m, quiet);
  }

  function dropPatch(m) {
    const pt = m.pt;
    if (!pt) return;
    if (pt.el) { pt.el.remove(); pt.el = null; pt.img = null; }
    pt.vis = false;
    pt.showing = false;
    pt.loaded = false;
    pt.held = false;
    if (pt.badge) {
      if (self.PAAGlass) PAAGlass.forget(pt.badge.el);
      pt.badge.pos.remove();
      pt.badge = null;
      pt.badgeVis = false;
    }
  }

  function dropChip(m) {
    const pt = m.pt;
    if (!pt || !pt.chip) return;
    clearInterval(m.rp && m.rp.timer);
    if (self.PAAGlass) PAAGlass.forget(pt.chip.el);
    pt.chip.pos.remove();
    pt.chip = null;
    pt.chipVis = false;
  }

  function detach(m) {
    if (m.rp && m.rp.state === 'working') stopRun(m, true);
    dropChip(m);
    dropPatch(m);
    m.pt = null;
  }

  /* ---------- the badge: AI repaint, hold to see the original ---------- */
  function ensureBadge(m) {
    const pt = ptOf(m);
    if (pt.badge) return;
    const pos = el('div', 'pos hide');
    const b = el('div', 'badge');
    PAA.layer.glass(b, 'pill');
    b.append(icon(ICON_SPARK, true));
    const t = el('span', '', 'AI repaint');
    b.appendChild(t);
    b.title = 'Made by an AI image model and checked. Press and hold to see the original.';
    const release = () => hold(m, false);
    b.addEventListener('pointerdown', (e) => {
      if (e.button !== 0) return;
      try { b.setPointerCapture(e.pointerId); } catch (x) { /* the release below also comes through the window */ }
      hold(m, true);
    });
    b.addEventListener('pointerup', release);
    b.addEventListener('pointercancel', release);
    b.addEventListener('lostpointercapture', release);
    pos.appendChild(b);
    PAA.layer.pane().appendChild(pos);
    pt.badge = { pos: pos, el: b, text: t };
  }

  /* compare: the patch is hidden while it is held (a press on the badge, or on the card's button for a moment) */
  function hold(m, held) {
    const pt = m.pt;
    if (!pt || pt.held === held) return;
    pt.held = held;
    if (pt.badge) {
      pt.badge.el.classList.toggle('cmp', held);
      pt.badge.text.textContent = held ? 'Original' : 'AI repaint';
    }
    if (pt.el) setVis(pt, pt.showing && !held, false);
  }
  addEventListener('blur', () => {
    PAA.layer.all().forEach((m) => { if (m.pt && m.pt.held) hold(m, false); });
  });

  /* ---------- the progress chip ---------- */
  function ensureChip(m) {
    const pt = ptOf(m);
    if (pt.chip) return;
    const pos = el('div', 'pos hide');
    const c = el('div', 'progress');
    PAA.layer.glass(c, 'pill');
    const lbl = el('span', 'lbl', 'Repainting');
    const bar = el('u');
    bar.appendChild(el('i'));
    const sec = el('span', 'sec', '0 s');
    const x = el('button', 'x');
    x.type = 'button';
    x.title = 'Cancel';
    x.appendChild(icon(ICON_X));
    x.addEventListener('click', (e) => { e.stopPropagation(); cancel(m); });
    c.append(lbl, bar, sec, x);
    pos.appendChild(c);
    PAA.layer.pane().appendChild(pos);
    pt.chip = { pos: pos, el: c, lbl: lbl, bar: bar, sec: sec, x: x };
  }

  const PHASE = { paint: 'Repainting', check: 'Checking', retry: 'Trying again' };
  /* the bar is an estimate, not a measurement: it fills towards the end of each phase (the image call is about 28 s, the check about 8 s) */
  function tickChip(m) {
    const rp = m.rp, pt = m.pt;
    if (!rp || !pt || !pt.chip) return;
    const t = (performance.now() - rp.t0) / 1000;
    const ph = rp.phase;
    const base = ph === 'check' ? 0.72 : ph === 'retry' ? 0.18 : 0;
    const span = ph === 'check' ? 0.22 : ph === 'retry' ? 0.5 : 0.7;
    const pt0 = rp.phaseT ? (performance.now() - rp.phaseT) / 1000 : t;
    const p = Math.min(0.97, base + span * (1 - Math.exp(-pt0 / (ph === 'check' ? 6 : 22))));
    pt.chip.lbl.textContent = PHASE[ph] || 'Repainting';
    pt.chip.sec.textContent = Math.floor(t) + ' s';
    pt.chip.bar.style.setProperty('--p', p.toFixed(3));
  }

  /* ---------- the badge and the chip hang beside and under the caption (every frame: a transform each) ---------- */
  const anchor = { x: 0, y: 0 };
  /* the middle of the mark's bottom edge (or its top edge, when the caption hangs above): where the caption hangs from */
  function capAnchor(m) {
    const p = m.pts;
    if (m.capOff.a === 't') { anchor.x = (p[0].x + p[1].x) / 2; anchor.y = (p[0].y + p[1].y) / 2; }
    else { anchor.x = (p[2].x + p[3].x) / 2; anchor.y = (p[2].y + p[3].y) / 2; }
  }
  const cl = (v, lo, hi) => (v < lo ? lo : v > hi ? hi : v);
  function setPos(pt, which, on) {
    const key = which + 'Vis';
    if (pt[key] === on) return;
    pt[key] = on;
    pt[which].pos.classList.toggle('hide', !on);
  }

  function dock(m, f, atCaption) {
    const pt = m.pt, vr = f.vr;
    const showBadge = !!(pt.badge && pt.showing);
    const showChip = !!(pt.chip && working(m));
    if (!showBadge && !showChip) { if (pt.badgeVis) setPos(pt, 'badge', false); if (pt.chipVis) setPos(pt, 'chip', false); return; }
    let cx, cy, up = false, chipX, chipY; // cx, cy: the caption's top left corner (or where it would be); chipX, chipY: the chip's top left corner
    if (atCaption) {
      capAnchor(m);
      up = m.capOff.a === 't';
      const shown = m.vis.cap && !m.capNone && m.capOff.a !== 'tr'; // (a mark that shows its English has no caption at rest: the chip then hangs from the mark itself)
      cx = shown ? anchor.x + m.capOff.dx : anchor.x - 44;
      cy = shown ? anchor.y + m.capOff.dy : up ? anchor.y - 8 - CAP_H : anchor.y + 8;
      chipX = shown ? cx : anchor.x - CHIP_W / 2;
      chipY = shown ? (up ? cy - 6 - CHIP_H : cy + CAP_H + 6) : up ? anchor.y - 8 - CHIP_H : anchor.y + 8;
    } else { // the mark's own rectangle is off screen (a point's patch is bigger than its ring): hang from the patch's bottom left corner
      cx = pt.pts[3].x;
      cy = pt.pts[3].y + 6;
      chipX = cx;
      chipY = cy + CAP_H;
    }
    if (showBadge) {
      const x = cl(cx - BADGE_W - 6, vr.x + 4, vr.x + vr.w - BADGE_W - 4), y = cl(cy + (CAP_H - BADGE_H) / 2, vr.y + 4, vr.y + vr.h - BADGE_H - 4);
      if (x !== pt.bx || y !== pt.by) { pt.bx = x; pt.by = y; pt.badge.pos.style.transform = 'translate3d(' + x + 'px,' + y + 'px,0)'; }
      setPos(pt, 'badge', true);
    } else setPos(pt, 'badge', false);
    if (showChip) {
      const x = cl(chipX, vr.x + 4, vr.x + vr.w - CHIP_W - 4), y = cl(chipY, vr.y + 4, vr.y + vr.h - CHIP_H - 4);
      if (x !== pt.cx || y !== pt.cy) { pt.cx = x; pt.cy = y; pt.chip.pos.style.transform = 'translate3d(' + x + 'px,' + y + 'px,0)'; }
      setPos(pt, 'chip', true);
    } else setPos(pt, 'chip', false);
  }

  /* every frame (Mark.place): the patch onto the picture, then what hangs from the caption. atCaption: the mark's own rectangle is on screen (m.pts is this frame's) */
  function place(m, f, atCaption) {
    const pt = m.pt;
    if (!pt) return;
    let ok = false;
    if (pt.el && pt.loaded && on(m)) { // (not before the picture is decoded: no empty glowing pane)
      const d = pt.dirs, p = pt.pts, vr = f.vr;
      ok = true;
      for (let k = 0; k < 4; k++) {
        const s = P.dirToScreen(d[k].yaw, d[k].pitch);
        if (!s || s.behind) { ok = false; break; }
        p[k].x = s.x;
        p[k].y = s.y;
      }
      if (ok) {
        const x0 = Math.min(p[0].x, p[1].x, p[2].x, p[3].x), x1 = Math.max(p[0].x, p[1].x, p[2].x, p[3].x);
        const y0 = Math.min(p[0].y, p[1].y, p[2].y, p[3].y), y1 = Math.max(p[0].y, p[1].y, p[2].y, p[3].y);
        if (x1 < vr.x - 40 || x0 > vr.x + vr.w + 40 || y1 < vr.y - 40 || y0 > vr.y + vr.h + 40) ok = false;
      }
      if (ok) {
        const mt = P.quadToMatrix3d(d, pt.bw, pt.bh);
        if (mt === P.HIDDEN_MATRIX) ok = false;
        else pt.el.style.transform = 'translate(' + -f.ox + 'px,' + -f.oy + 'px) ' + mt;
      }
    }
    const was = pt.showing;
    pt.showing = ok;
    if (pt.el) setVis(pt, ok && !pt.held, true);
    if (was !== ok && PAA.layer) PAA.layer.requestLayout(0); // ticks go quiet / come back with it
    dock(m, f, atCaption);
  }

  /* the mark is hidden (off screen, another panorama, Off, a flight) */
  function hide(m) {
    const pt = m.pt;
    if (!pt) return;
    if (pt.el) setVis(pt, false, true);
    pt.showing = false;
    if (pt.badgeVis) setPos(pt, 'badge', false);
    if (pt.chipVis) setPos(pt, 'chip', false);
  }

  const seen = (m) => !!(m.pt && m.pt.showing);

  /* the window rectangle of the repaint showing at this point (a quadrilateral, like a label), or null: press.js opens the card on a still click, as it does on a label */
  function hitAt(m, x, y) {
    const pt = m.pt;
    if (!pt || !pt.showing || !pt.vis || pt.held || !PAA.overlay) return null;
    return PAA.overlay.inQuad(pt.pts, x, y) ? PAA.overlay.boundsOf(pt.pts) : null;
  }

  /* ---------- planning: what to repaint ---------- */
  function pictureRect(pose) {
    const cr = pose.canvasRect;
    const iw = window.innerWidth, ih = window.innerHeight;
    if (!cr) return { x: 0, y: 0, w: iw, h: ih };
    const x = Math.max(0, cr.x), y = Math.max(0, cr.y);
    return { x: x, y: y, w: Math.max(0, Math.min(iw, cr.x + cr.width) - x), h: Math.max(0, Math.min(ih, cr.y + cr.height) - y) };
  }

  /* Google's own buttons and cards that are drawn over the picture (our layers are hidden for a screenshot, theirs are not): a crop that took one in would
     give the patch a frozen copy of it, gliding over the street. The layer knows the bottom and right ones (the zoom and compass, the mini map, Share's place);
     the address card at the top left and the attribution bar along the bottom are added here. Only a full-size view has them in these places. */
  function controlRects(vr) {
    const a = PAA.layer.avoid ? PAA.layer.avoid().slice() : [];
    if (vr.w >= 600 && vr.h >= 420) {
      a.push({ x: vr.x, y: vr.y, w: 400, h: 84 });
      a.push({ x: vr.x + vr.w - 200, y: vr.y, w: 200, h: 74 });
      a.push({ x: vr.x, y: vr.y + vr.h - 26, w: vr.w, h: 26 });
    }
    return a;
  }

  /* the lines as the repaint sees them: the model's own box (a hint) and whether it ran off the picture it saw */
  function linesOf(m) {
    return (m.a.lines || []).map((l, i) => ({ i: i, o: l.o || '', t: l.t || '', b: Array.isArray(l.b) ? l.b : null, spill: !!l.spill, dirs: l.dirs || null })).filter((l) => l.t);
  }

  /* the size of the picture the answer was read from (what the lines' boxes are in), or null for a record that has none */
  function csOf(m) {
    const c = (m.rec.cam && m.rec.cam.cs) || (m.rec.overlay && m.rec.overlay.cs) || m.cropSize;
    return Array.isArray(c) && c.length === 2 && c[0] > 0 && c[1] > 0 ? c : null;
  }

  /* The stored crop is used as it is when it has a shape the image model can output (the lines were already found to lie inside it with a margin). */
  function planStored(m, L) {
    const cam = m.rec.cam;
    if (!cam || !cam.cs || !cam.ref || !Array.isArray(cam.c) || cam.c.length !== 4 || !cam.c.every(Boolean)) return null;
    if (R.pickRatio(cam.cs[0], cam.cs[1]).off > R.SHAPE_TOL) return null;
    return { mode: 'stored', quad: { tl: cam.c[0], tr: cam.c[1], br: cam.c[2], bl: cam.c[3] }, base: [cam.ref[0], cam.ref[1]], lines: L };
  }

  /* A fresh picture of the sign as it is on screen now, with a margin and the right shape. Needs the sign in view. */
  function planFresh(m, L) {
    const pose = P.getPose();
    if (!m.dirArr || !m.rec.pano || pose.panoId !== m.rec.pano.id || pose.transition || pose.panoPending) return { refuse: 'away' };
    if (!m.project()) return { refuse: 'away' };
    const boxes = [];
    let u = null;
    const grow = (x0, y0, x1, y1) => {
      if (!u) u = { x0: x0, y0: y0, x1: x1, y1: y1 };
      else { u.x0 = Math.min(u.x0, x0); u.y0 = Math.min(u.y0, y0); u.x1 = Math.max(u.x1, x1); u.y1 = Math.max(u.y1, y1); }
    };
    for (let i = 0; i < L.length; i++) {
      const d = L[i].dirs;
      if (!d) { boxes[i] = null; continue; }
      const pts = [d.tl, d.tr, d.br, d.bl].map((q) => (q ? P.dirToScreen(q.yaw, q.pitch) : null));
      if (pts.some((q) => !q || q.behind)) return { refuse: 'away' };
      boxes[i] = [Math.min(pts[0].x, pts[1].x, pts[2].x, pts[3].x), Math.min(pts[0].y, pts[1].y, pts[2].y, pts[3].y), Math.max(pts[0].x, pts[1].x, pts[2].x, pts[3].x), Math.max(pts[0].y, pts[1].y, pts[2].y, pts[3].y)];
      grow(boxes[i][0], boxes[i][1], boxes[i][2], boxes[i][3]);
    }
    if (!m.isPoint) { const bb = m.bbox(); grow(bb.x, bb.y, bb.x + bb.w, bb.y + bb.h); }
    if (!u) return { refuse: 'old' };
    const vr = pictureRect(pose);
    const rect = R.planCrop({ x: u.x0, y: u.y0, w: u.x1 - u.x0, h: u.y1 - u.y0 }, vr, { avoid: controlRects(vr) });
    if (rect.refuse) return { refuse: rect.refuse };
    const lines = L.map((l, i) => ({ i: l.i, o: l.o, t: l.t, spill: l.spill, b: boxes[i] ? [boxes[i][0] - rect.x, boxes[i][1] - rect.y, boxes[i][2] - rect.x, boxes[i][3] - rect.y] : null }));
    const a = R.assess(lines, rect.w, rect.h, { edgeMargin: 0.01 }); // (planCrop has seen to the margin: a sign near the picture's edge is not "cut off")
    if (a.cut.length) return { refuse: 'cut' };
    if (!a.paint.length) return { refuse: 'nothing' };
    return { mode: 'fresh', rect: rect, lines: lines, a: a };
  }

  /* what to do: { mode: 'stored' | 'fresh', ... } or { refuse: key of MSG }.
     First, was the writing whole when it was read? A line that is an ellipsis, whose box ran off the picture the model saw, or whose box touches that picture's edge was
     cut off by the box he drew: the model read part of it, and a bigger picture would show writing it never read, left in its own script beside the new English. That is
     refused (a margin is for context, never for more writing). Then: the stored crop if it has a shape the model can output, else a fresh picture with a margin and the
     right shape, which needs the sign in view. */
  function plan(m) {
    const L = linesOf(m);
    if (!L.length) return { refuse: 'nothing' };
    if (!m.dirArr) return { refuse: 'nocam' };
    if (R.cutNote(m.a.unsure)) return { refuse: 'cut' }; // the model itself says part of the writing is cut off, whether or not it left that line out of LINES
    const cs = csOf(m);
    const a0 = cs ? R.assess(L, cs[0], cs[1]) : R.assess(L.map((l) => Object.assign({}, l, { b: null })), 1, 1); // (no picture size: only the ellipsis and spill rules)
    if (a0.cut.length) return { refuse: 'cut' };
    if (!a0.paint.length) return { refuse: 'nothing' };
    return planStored(m, L) || planFresh(m, L);
  }

  /* ---------- running ---------- */
  /* our layers come back (the screenshot is taken, or the run ended): what this run was holding hidden, no more (an ask's capture holds its own) */
  function releaseCap(rp) {
    const r = rp.cap;
    rp.cap = null;
    if (r) r();
  }

  function stopRun(m, quiet) {
    const rp = m.rp;
    if (!rp) return;
    clearInterval(rp.timer);
    clearTimeout(rp.guard);
    rp.timer = 0;
    releaseCap(rp);
    const port = rp.port;
    rp.port = null;
    if (port) { try { port.disconnect(); } catch (e) { /* closed */ } } // the worker's fetches are aborted by this
    if (rp.state === 'working') rp.state = 'idle';
    if (m.pt && m.pt.chipVis) setPos(m.pt, 'chip', false);
    if (!quiet && !m.dead) {
      dropChip(m);
      m.actsKey = '';
      m.render();
      PAA.layer.trackNow();
      PAA.ask.leaveIfElsewhere(m);
    }
  }

  function cancel(m) {
    if (!working(m)) return;
    rpOf(m).msg = '';
    stopRun(m, false);
  }

  /* ended without a picture: the card opens and says why */
  function ended(m, state, msg, problems, settings) {
    const rp = rpOf(m);
    stopRun(m, true);
    rp.state = state;
    rp.settings = !!settings; // the message is about a key: the card shows a Settings button with it
    rp.msg = msg || '';
    rp.problems = problems || [];
    dropChip(m);
    m.actsKey = '';
    if (m.dead) return;
    m.render();
    PAA.layer.trackNow();
    if (m.retired || (m.rec.pano && m.rec.pano.id !== PAA.layer.lastPano())) { PAA.ask.leaveIfElsewhere(m); return; }
    PAA.app.openMark(m);
    PAA.layer.requestLayout(0);
  }

  /* trying again with the same note cannot change these (a different box, or another page, could): the card says why and the button stays quiet */
  const FINAL = ['cut', 'nothing', 'nocam', 'old'];
  function refuse(m, why, extra) {
    rpOf(m).final = FINAL.indexOf(why) >= 0;
    ended(m, 'refused', MSG[why] || String(extra || why), []);
  }

  async function start(m) {
    if (!m || m.dead || m.far || m.state !== 'done') return;
    const rp = rpOf(m);
    if (rp.state === 'working') return;
    if (m.busy) return refuse(m, 'wait'); // an answer or a follow-up is still being written: say so, never do nothing
    const pl = plan(m);
    if (pl.refuse) return refuse(m, pl.refuse);
    rp.state = 'working';
    rp.final = false;
    rp.phase = 'paint';
    rp.phaseT = performance.now();
    rp.t0 = performance.now();
    rp.msg = '';
    rp.problems = [];
    const token = rp.t0;
    const alive = () => !m.dead && rp.state === 'working' && rp.t0 === token;
    ensureChip(m);
    tickChip(m);
    rp.timer = setInterval(() => tickChip(m), 250);
    rp.guard = setTimeout(() => { if (alive()) ended(m, 'refused', 'This took too long and was stopped. Try again.', []); }, GUARD_MS);
    m.actsKey = '';
    m.setOpen(false); // the card gets out of the way: the sign is what he watches
    m.render();
    PAA.layer.trackNow();
    PAA.layer.requestLayout(0);

    let cur = pl, quad = pl.quad || null;
    try {
      await PAA.store.save(m.rec); // the worker keeps the picture only for a note that is saved (a deleted one must leave nothing behind)
      if (!alive()) return;
      if (cur.mode === 'fresh') {
        await PAA.ask.shotSlot(); // the screenshot rate limit, and a view that has come to rest
        if (!alive()) return;
        rp.cap = PAA.layer.holdCapture(); // nothing of ours may be in the picture (until the worker says the screenshot is taken)
        try {
          await PAA.ask.nextFrames(2);
          if (document.visibilityState !== 'visible') throw new Error(SWITCHED);
          cur = planFresh(m, linesOf(m)); // the view as it is at this moment
          if (cur.refuse) throw Object.assign(new Error(MSG[cur.refuse]), { key: cur.refuse });
          const r = cur.rect;
          const c = [P.screenToDir(r.x, r.y), P.screenToDir(r.x + r.w, r.y), P.screenToDir(r.x + r.w, r.y + r.h), P.screenToDir(r.x, r.y + r.h)];
          if (!c.every(Boolean)) throw Object.assign(new Error(MSG.moved), { key: 'moved' });
          const rd = (d) => Geo.roundDir(d);
          quad = { tl: rd(c[0]), tr: rd(c[1]), br: rd(c[2]), bl: rd(c[3]) };
        } catch (e) {
          releaseCap(rp);
          throw e;
        }
      }
      if (!alive()) { releaseCap(rp); return; }
      const job = {
        id: m.id,
        source: cur.mode,
        lines: cur.lines.map((l) => ({ i: l.i, o: l.o, t: l.t, b: cur.mode === 'stored' ? l.b : null, cb: cur.mode === 'fresh' ? l.b : null, spill: l.spill })),
        css: cur.mode === 'fresh' ? { w: cur.rect.w, h: cur.rect.h } : null,
        gesture: cur.mode === 'fresh' ? { rect: { x: cur.rect.x, y: cur.rect.y, w: cur.rect.w, h: cur.rect.h }, iw: window.innerWidth } : null,
      };
      let port;
      try {
        port = chrome.runtime.connect({ name: 'repaint' });
      } catch (e) {
        throw new Error(PAA.extGone(e) ? PAA.RELOAD_MSG : 'Could not reach the extension: ' + e.message);
      }
      rp.port = port;
      port.onMessage.addListener((msg) => {
        if (rp.port !== port) return;
        if (msg.type === 'shot') {
          releaseCap(rp);
        } else if (msg.type === 'phase') {
          rp.phase = msg.phase;
          rp.phaseT = performance.now();
          tickChip(m);
        } else if (msg.type === 'done') {
          rp.port = null;
          try { port.disconnect(); } catch (e) { /* closed */ }
          finish(m, msg.result, cur, quad);
        }
      });
      port.onDisconnect.addListener(() => {
        if (rp.port !== port) return;
        rp.port = null;
        const le = chrome.runtime.lastError;
        if (alive()) ended(m, 'refused', le ? le.message : 'Connection to the extension was lost.', []);
      });
      port.postMessage({ type: 'repaint', job: job });
      setTimeout(() => { if (rp.port === port) releaseCap(rp); }, 10000); // never leave our layers hidden
    } catch (e) {
      releaseCap(rp);
      if (!alive()) return; // cancelled (or deleted) meanwhile: nothing to say
      ended(m, 'refused', (e && e.message) || String(e), []);
    }
  }

  /* the worker answered */
  async function finish(m, res, pl, quad) {
    const rp = rpOf(m);
    if (m.dead || rp.state !== 'working') return;
    const spentNow = (res.stats && res.stats.cost) || 0;
    if (!res.ok && spentNow > 0 && has(m)) { // a failed "Repaint again": the money is spent on a note that keeps its repaint, so it goes in the record's own total
      const r = m.rec.repaint;
      r.spent = Math.round((((typeof r.spent === 'number' ? r.spent : r.stats && r.stats.cost) || 0) + spentNow) * 1e6) / 1e6;
      save(m);
    } else rp.cost += spentNow;
    rp.ms = (res.stats && res.stats.ms) || 0;
    if (!res.ok) {
      rp.tries = (res.tries || []).length;
      if (res.kind === 'check') return ended(m, 'failed', '', res.problems || []);
      if (res.kind === 'refused') return refuse(m, res.why === 'cut' ? 'cut' : res.why === 'nothing' ? 'nothing' : 'shape');
      return ended(m, 'refused', res.message || 'The repaint could not be made.', [], res.settings);
    }
    const prev = has(m) ? m.rec.repaint : null;
    const dirs = pl.mode === 'stored' ? pl.quad : quad;
    const base = pl.mode === 'stored' ? pl.base : [pl.rect.w, pl.rect.h];
    m.rec.repaint = {
      v: 1, on: true, dirs: dirs, size: [Math.round(base[0] * 100) / 100, Math.round(base[1] * 100) / 100], img: res.patch, t: Date.now(), source: pl.mode, ratio: res.ratio,
      lines: res.lines, stats: { ms: res.stats.ms, cost: res.stats.cost, model: res.stats.model, quality: res.stats.quality, tries: res.stats.tries, calls: res.stats.calls },
      spent: Math.round((rp.cost + (prev && prev.spent ? prev.spent : prev && prev.stats ? prev.stats.cost : 0)) * 1e6) / 1e6,
    };
    rp.cost = 0; // (it is in the record now)
    rp.state = 'idle';
    stopRun(m, true);
    dropChip(m);
    dropPatch(m);
    m.pt.glinted = false;
    save(m);
    await load(m, false); // the picture comes from the worker's storage; it appears with a glint
    PAA.ask.leaveIfElsewhere(m);
  }

  /* ---------- the card ---------- */
  function offered(m) {
    return m.state === 'done' && !m.far;
  }
  function label(m) {
    const s = m.rp ? m.rp.state : 'idle';
    if (s === 'working') return 'Repainting';
    if (s === 'refused' && m.rp.final) return 'Repaint';
    if (s === 'failed' || s === 'refused') return 'Try again';
    return 'Repaint';
  }
  function key(m) {
    return [m.rp ? m.rp.state : 'idle', m.rp && m.rp.final ? 1 : 0, has(m) ? (on(m) ? 2 : 1) : 0, m.pt && m.pt.loaded ? 1 : 0, m.pt && m.pt.loading ? 1 : 0].join(',');
  }
  /* lit: the patch is showing, or a try again is what the card asks for */
  function wireButton(m, btn) {
    const s = m.rp ? m.rp.state : 'idle';
    if (s === 'working') { btn.classList.add('busy'); btn.disabled = true; btn.title = 'Repainting: the chip under the sign has a cancel'; return; }
    if (s === 'refused' && m.rp.final) { btn.classList.add('busy'); btn.disabled = true; btn.title = m.rp.msg; return; } // (the reason is in the card; trying again would only say it again)
    if (s === 'failed' || s === 'refused') { btn.classList.add('on'); return; }
    if (has(m) && !hasPatch(m)) { // its picture is being loaded from the worker (or could not be: pressing then asks for it again, it does not repaint)
      btn.classList.add('busy');
      btn.title = 'Loading the repaint that was saved with this note';
      if (m.pt && m.pt.loading) btn.disabled = true;
      return;
    }
    if (hasPatch(m)) {
      if (on(m)) btn.classList.add('on');
      btn.title = 'Press to show or hide the repaint. Press and hold to compare with the original.';
      btn.addEventListener('pointerdown', (e) => {
        if (e.button !== 0) return;
        clearTimeout(m.rpHoldT);
        m.rpHoldT = setTimeout(() => { m.rpHoldT = 0; if (on(m)) { m.rpSwallow = true; hold(m, true); } }, HOLD_MS);
      });
      const up = (e) => {
        clearTimeout(m.rpHoldT);
        m.rpHoldT = 0;
        if (m.pt && m.pt.held && m.rpSwallow) hold(m, false);
        if (e && e.type !== 'pointerup') m.rpSwallow = false; // slid off the button (or the press was cancelled): no click follows, and the next real press must not be taken for the end of a hold
      };
      btn.addEventListener('pointerup', up);
      btn.addEventListener('pointercancel', up);
      btn.addEventListener('pointerleave', up);
    } else btn.title = 'Paint the English over the sign, in its own style (about 25 to 30 s' + (PAA.prefs && PAA.prefs.showCost ? ', 2 to 5 cents' : '') + ')';
  }

  /* the button was pressed */
  function click(m) {
    if (m.rpSwallow) { m.rpSwallow = false; return; } // it was a hold (a compare), not a press
    const s = m.rp ? m.rp.state : 'idle';
    if (s === 'working') return;
    if (s === 'refused' && m.rp.final) return;
    if (s === 'failed' || s === 'refused') { m.rp.state = 'idle'; return start(m); }
    if (hasPatch(m)) return toggle(m);
    if (has(m)) return void attach(m, false); // the saved picture did not load: ask for it again (never a new paid repaint for a picture that is already stored)
    return start(m);
  }

  /* show or hide the patch (the picture is kept) */
  function toggle(m) {
    if (!has(m)) return;
    const r = m.rec.repaint;
    r.on = !on(m);
    const pt = ptOf(m);
    if (r.on) pt.glinted = false; // the light crosses it again each time it comes back
    if (PAA.overlay && m.ov) PAA.overlay.refresh(m);
    m.actsKey = '';
    m.render();
    PAA.layer.trackNow();
    PAA.layer.requestLayout(0);
    save(m);
  }

  function remove(m) {
    if (!has(m)) return;
    m.rec.repaint = null;
    PAA.store.unpatch(m.id).catch((e) => console.warn('[PAA] unpatch failed', e));
    dropPatch(m);
    if (PAA.overlay && m.ov) PAA.overlay.refresh(m);
    m.actsKey = '';
    m.render();
    PAA.layer.trackNow();
    PAA.layer.requestLayout(0);
    save(m);
  }

  /* what the card says about a repaint that did not happen or did not pass: an amber block under the answer */
  function renderBody(m, body) {
    const rp = m.rp;
    if (!rp) return;
    if (rp.state === 'failed') {
      const box = el('div', 'unsure err rp');
      const t = el('div', 'rpt');
      t.appendChild(el('div', 'rph', 'The repaint did not pass its check, so it is not shown.'));
      (rp.problems || []).forEach((p) => t.appendChild(el('div', 'rpl', p.charAt(0).toUpperCase() + p.slice(1))));
      box.appendChild(t);
      body.appendChild(box);
    } else if (rp.state === 'refused') {
      const box = el('div', 'unsure err rp', rp.msg);
      if (rp.settings && m.settingsLink) box.appendChild(m.settingsLink());
      body.appendChild(box);
    }
  }

  /* the more menu's second line: what the repaint cost (this one, and all of them when there were failed tries or earlier ones) */
  function costText(m) {
    const r = has(m) ? m.rec.repaint : null;
    const parts = [];
    const money = !!(PAA.prefs && PAA.prefs.showCost); // costs are shown only when asked for in Settings; the time always is
    if (r && r.stats) {
      if (typeof r.stats.ms === 'number') parts.push((r.stats.ms / 1000).toFixed(1) + ' s');
      if (money && typeof r.stats.cost === 'number') parts.push('$' + (r.stats.cost < 0.01 ? r.stats.cost.toFixed(4) : r.stats.cost.toFixed(3)));
      if (r.stats.tries > 1) parts.push('second try');
      if (money && typeof r.spent === 'number' && typeof r.stats.cost === 'number' && r.spent > r.stats.cost + 0.0005) parts.push('$' + r.spent.toFixed(3) + ' in all');
      return parts.join(' · ');
    }
    if (m.rp && m.rp.cost > 0) return money ? 'not shown · $' + (m.rp.cost < 0.01 ? m.rp.cost.toFixed(4) : m.rp.cost.toFixed(3)) + ' spent' : 'not shown';
    return '';
  }

  function debug(m) {
    const rp = m.rp, pt = m.pt;
    if (!rp && !pt && !has(m)) return null;
    const rect = (n) => { if (!n) return null; const b = n.getBoundingClientRect(); return { x: b.x, y: b.y, w: b.width, h: b.height }; };
    return {
      state: rp ? rp.state : 'idle', phase: rp ? rp.phase : null, msg: rp ? rp.msg : '', problems: rp ? rp.problems : [], spent: rp ? rp.cost : 0,
      has: has(m), on: on(m), rec: has(m) ? { on: m.rec.repaint.on, source: m.rec.repaint.source, ratio: m.rec.repaint.ratio, size: m.rec.repaint.size, img: m.rec.repaint.img, stats: m.rec.repaint.stats, spent: m.rec.repaint.spent, lines: m.rec.repaint.lines } : null,
      patch: pt && pt.el ? { vis: pt.vis, showing: pt.showing, held: pt.held, rect: rect(pt.el), opacity: getComputedStyle(pt.el).opacity, pts: pt.pts.map((q) => ({ x: q.x, y: q.y })), cls: pt.el.className,
        img: pt.img ? { w: pt.img.naturalWidth, h: pt.img.naturalHeight, complete: pt.img.complete } : null, bw: pt.bw, bh: pt.bh } : null,
      badge: pt && pt.badge ? { vis: pt.badgeVis, rect: rect(pt.badge.el), text: pt.badge.text.textContent, cmp: pt.badge.el.classList.contains('cmp') } : null,
      chip: pt && pt.chip ? { vis: pt.chipVis, rect: rect(pt.chip.el), text: pt.chip.lbl.textContent, sec: pt.chip.sec.textContent, bar: pt.chip.bar.style.getPropertyValue('--p'), cancel: rect(pt.chip.x) } : null,
    };
  }

  PAA.patch = {
    attach: attach, detach: detach, place: place, hide: hide, seen: seen, hitAt: hitAt, on: on, has: has, hasPatch: hasPatch, working: working,
    start: start, cancel: cancel, click: click, toggle: toggle, remove: remove, hold: hold,
    offered: offered, label: label, key: key, wireButton: wireButton, renderBody: renderBody, costText: costText, plan: plan, debug: debug, MSG: MSG,
  };
})();
