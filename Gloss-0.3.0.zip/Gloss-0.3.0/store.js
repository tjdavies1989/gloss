/* Gloss: the saved marks. Runs in the service worker ONLY (the page never touches chrome.storage
   for marks: it sends messages, see store-client.js). Pure apart from the storage area handed in, so the
   node tests drive it with a fake.

   Layout in chrome.storage.local (all keys start with "paa:", settings keys do not):
     paa:index           [{ id, pano, lat, lng, wlat, wlng, t, say }]  newest first; the only thing listings read (wlat, wlng: the mark's world point, or null)
     paa:m:<id>          the mark record (data model v2, see BUILD-NOTES.txt), thumbnail included
     paa:i:<id>:crop     { url, w, h, t }   image 1 as sent to the model (needed for follow-ups)
     paa:i:<id>:ctx      { url }            image 2 as sent
     paa:i:<id>:rp       { url, w, h, t }   stage 4: the AI repaint that passed its check (a WebP with a feathered edge), under its own key
     paa:pending         { <id>: t }        images written before their mark was saved (so abandoned ones can be swept)

   The worker is stateless between messages: every call reads what it needs from storage. Writes are
   serialised through one promise chain so two tabs cannot lose each other's index update. */
(function (root) {
  'use strict';

  const PREFIX = 'paa:';
  const KEY = {
    index: PREFIX + 'index',
    pending: PREFIX + 'pending',
    mark: (id) => PREFIX + 'm:' + id,
    crop: (id) => PREFIX + 'i:' + id + ':crop',
    ctx: (id) => PREFIX + 'i:' + id + ':ctx',
    patch: (id) => PREFIX + 'i:' + id + ':rp',
  };
  const SAY_MAX = 140;
  const ORPHAN_MS = 60 * 60 * 1000; // unsaved images older than this are swept

  function clip(s, n) {
    s = String(s || '');
    return s.length <= n ? s : s.slice(0, n - 1) + '…';
  }

  /* One compact row for the index: id, panorama id, position (of the panorama, and of the mark itself when it has a world point), time, SAY. */
  function indexEntry(rec) {
    const a = rec.a || {};
    const w = rec.world;
    return {
      id: rec.id,
      pano: rec.pano ? rec.pano.id : null,
      lat: rec.pano && typeof rec.pano.lat === 'number' ? rec.pano.lat : null,
      lng: rec.pano && typeof rec.pano.lng === 'number' ? rec.pano.lng : null,
      wlat: w && typeof w.lat === 'number' ? w.lat : null,
      wlng: w && typeof w.lng === 'number' ? w.lng : null,
      t: rec.createdAt,
      say: clip(a.say || a.note || '', SAY_MAX),
    };
  }

  /* Insert or replace by id, keep newest first. Returns a new array. */
  function upsertIndex(index, entry) {
    const out = (index || []).filter((e) => e.id !== entry.id);
    out.push(entry);
    out.sort((x, y) => y.t - x.t);
    return out;
  }

  function create(area, opts) {
    const rowOf = (opts && opts.rowOf) || indexEntry;
    let chain = Promise.resolve();
    function locked(fn) {
      const p = chain.then(fn);
      chain = p.catch(() => {});
      return p;
    }
    async function getOne(key) {
      const r = await area.get(key);
      return r[key];
    }
    async function readIndex() {
      return (await getOne(KEY.index)) || [];
    }
    async function setPending(id, on) {
      const p = (await getOne(KEY.pending)) || {};
      if (on) p[id] = Date.now();
      else delete p[id];
      await area.set({ [KEY.pending]: p });
    }

    return {
      KEY,

      /* list({pano}) -> full records of that panorama, oldest first.
         list({}) or list() -> the index rows, newest first (the notebook reads these). */
      list(q) {
        return locked(async () => {
          const index = await readIndex();
          if (!q || !q.pano) return { index };
          const ids = index.filter((e) => e.pano === q.pano).map((e) => e.id);
          if (!ids.length) return { records: [] };
          const got = await area.get(ids.map(KEY.mark));
          const records = ids.map((id) => got[KEY.mark(id)]).filter(Boolean);
          records.sort((x, y) => x.createdAt - y.createdAt);
          return { records };
        });
      },

      /* The latest saved marks from anywhere, newest first, as notebook rows (thumbnail and second line included). */
      recent(limit) {
        return locked(async () => {
          const top = (await readIndex()).slice(0, limit || 20);
          if (!top.length) return { rows: [] };
          const got = await area.get(top.map((e) => KEY.mark(e.id)));
          return { rows: top.map((e) => got[KEY.mark(e.id)]).filter(Boolean).map(rowOf) };
        });
      },

      /* Saved marks near a position, nearest first, that are not on the panorama q.pano: the notebook's Nearby section and the soft anchors
         shown from other panoramas. q = { lat, lng, radius (m, default 150), pano, limit (default 12), worldOnly, full }.
         A mark's position is its world point when it has one, else the panorama it was asked in (marks from user photo spheres, old imagery
         and South Korea have no world point: they are still found, "asked from 80 m east"). Each row is the notebook row of the record
         (rowOf) plus d (metres), b (compass bearing from the query position), world (has a world point), sub ("80 m east") and, with
         full, rec (the whole record, which a soft anchor is built from). */
      nearby(q) {
        return locked(async () => {
          q = q || {};
          const geo = opts && opts.geo;
          if (!geo || typeof q.lat !== 'number' || typeof q.lng !== 'number') return { rows: [] };
          const radius = q.radius > 0 ? q.radius : 150;
          const cand = [];
          for (const e of await readIndex()) {
            if (q.pano && e.pano === q.pano) continue;
            const w = typeof e.wlat === 'number' && typeof e.wlng === 'number';
            if (q.worldOnly && !w) continue;
            const db = geo.distBearing(q.lat, q.lng, w ? e.wlat : e.lat, w ? e.wlng : e.lng);
            if (db && db.d <= radius) cand.push({ e: e, db: db, w: w });
          }
          cand.sort((a, b) => a.db.d - b.db.d);
          const top = cand.slice(0, q.limit > 0 ? q.limit : 12);
          if (!top.length) return { rows: [] };
          const got = await area.get(top.map((c) => KEY.mark(c.e.id)));
          const rows = [];
          top.forEach((c) => {
            const rec = got[KEY.mark(c.e.id)];
            if (!rec) return;
            const row = rowOf(rec);
            row.d = c.db.d;
            row.b = c.db.b;
            row.world = c.w;
            row.sub = (c.w ? '' : 'asked from ') + geo.distText(c.db.d) + ' ' + geo.compassWord(c.db.b);
            if (q.full) row.rec = rec;
            rows.push(row);
          });
          return { rows: rows };
        });
      },

      get(id) {
        return locked(async () => ({ record: (await getOne(KEY.mark(id))) || null }));
      },

      /* Writes the record and its index row in one storage call, and clears the "pending images" flag. */
      save(rec) {
        return locked(async () => {
          if (!rec || !rec.id) throw new Error('save: no id');
          const index = upsertIndex(await readIndex(), indexEntry(rec));
          const pending = (await getOne(KEY.pending)) || {};
          delete pending[rec.id];
          await area.set({ [KEY.mark(rec.id)]: rec, [KEY.index]: index, [KEY.pending]: pending });
          return { ok: true };
        });
      },

      /* Delete a mark for good: record, index row and both images. */
      remove(id) {
        return locked(async () => {
          const index = (await readIndex()).filter((e) => e.id !== id);
          await area.remove([KEY.mark(id), KEY.crop(id), KEY.ctx(id), KEY.patch(id)]);
          const pending = (await getOne(KEY.pending)) || {};
          delete pending[id];
          await area.set({ [KEY.index]: index, [KEY.pending]: pending });
          return { ok: true };
        });
      },

      putImages(id, crop, ctx) {
        return locked(async () => {
          await area.set({ [KEY.crop(id)]: { url: crop.url, w: crop.w, h: crop.h, t: Date.now() }, [KEY.ctx(id)]: { url: ctx.url } });
          await setPending(id, true);
        });
      },

      getImages(id) {
        return locked(async () => {
          const got = await area.get([KEY.crop(id), KEY.ctx(id)]);
          return { crop: got[KEY.crop(id)] || null, ctx: got[KEY.ctx(id)] || null };
        });
      },

      /* Stage 4: the repaint of a saved mark, under its own key. Written only while the mark still exists (a note deleted while its repaint was being
         made must not leave a picture behind); returns false when it does not. */
      putPatch(id, img) {
        return locked(async () => {
          if (!(await getOne(KEY.mark(id)))) return false;
          await area.set({ [KEY.patch(id)]: { url: img.url, w: img.w, h: img.h, t: img.t || Date.now() } });
          return true;
        });
      },

      getPatch(id) {
        return locked(async () => ({ patch: (await getOne(KEY.patch(id))) || null }));
      },

      removePatch(id) {
        return locked(async () => {
          await area.remove([KEY.patch(id)]);
          return { ok: true };
        });
      },

      /* A mark that was never saved (cancelled, or failed and dismissed): drop its images. A saved mark is left alone. */
      discard(id) {
        return locked(async () => {
          const rec = await getOne(KEY.mark(id));
          if (rec) return { ok: true, kept: true };
          await area.remove([KEY.crop(id), KEY.ctx(id)]);
          await setPending(id, false);
          return { ok: true };
        });
      },

      /* Sweep images whose mark was never saved and never discarded (tab closed mid-ask). */
      gc(now) {
        return locked(async () => {
          const pending = (await getOne(KEY.pending)) || {};
          const dead = Object.keys(pending).filter((id) => (now || Date.now()) - pending[id] > ORPHAN_MS);
          if (!dead.length) return { swept: 0 };
          const keys = [];
          dead.forEach((id) => {
            keys.push(KEY.crop(id), KEY.ctx(id));
            delete pending[id];
          });
          await area.remove(keys);
          await area.set({ [KEY.pending]: pending });
          return { swept: dead.length };
        });
      },

      stats() {
        return locked(async () => {
          const index = await readIndex();
          const bytes = area.getBytesInUse ? await area.getBytesInUse(null) : 0;
          return { count: index.length, bytes };
        });
      },

      /* "Delete all saved notes": everything under paa:, settings stay. */
      clear() {
        return locked(async () => {
          // getKeys() lists keys without loading the images (Chrome 130+); older Chrome falls back to loading everything
          const all = area.getKeys ? await area.getKeys() : Object.keys(await area.get(null));
          const keys = all.filter((k) => k.indexOf(PREFIX) === 0);
          if (keys.length) await area.remove(keys);
          return { removed: keys.length };
        });
      },
    };
  }

  const API = { KEY, indexEntry, upsertIndex, create, SAY_MAX };
  root.PAAStore = API;
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
})(typeof self !== 'undefined' ? self : globalThis);
