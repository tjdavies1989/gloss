/* Gloss: snapping a model's box to the ink, and reading the sign's colours (stage 3). Pure: no DOM, no Chrome. Loaded by the
   service worker (importScripts) and by node tests.

   The model's LINES boxes are approximate (median overlap with the true text box 0.58; bottoms run short; about 9 % on the wrong
   line). The text is where the contrast energy is, so each edge is pulled to the tight extent of the high-contrast pixels within a
   small margin (6 % of the box size: see DEFAULTS), never into a neighbouring line's box. Then, from the same pixels: the colour of the sign
   round the text (the median of a thin band just outside the box) and the colour of the lettering itself (when it clearly differs).

   img = { data: Uint8ClampedArray | Uint8Array, width, height, channels: 3 | 4 }   (RGB or RGBA, row by row)
   box = [x0, y0, x1, y1] in pixels of that image.

   analyse(img, boxes, opts) is the one call the worker makes: for every box { sb (the snapped box, or the model's own when snapping
   found nothing better), moved (true when it changed), bg [r,g,b] | null, fg [r,g,b] | null, ang (the lettering's tilt in degrees | null) }. */
(function (root) {
  'use strict';

  const DEFAULTS = {
    margin: 0.06, // how far an edge may GROW outward, as a share of the box's own size (an edge may shrink inward as far as the ink goes).
                  // The brief said 30 %: measured on the evalset it made the median overlap WORSE (0.57 -> 0.54: it grabbed the sign's border and
                  // the neighbouring clutter); 6 % made it better (0.57 -> 0.65). See test/snap-eval.mjs and BUILD-NOTES.
    inkRel: 0.35, // a pixel is ink when its edge energy is above this share of the box's own strong energy (and above inkMin)
    inkMin: 14, // ... and above this (mean channel difference over two pixels, 0 to 255)
    rowRel: 0.2, // a row is inky when its ink count is at least this share of the box's typical row count (and above rowMin)
    rowMin: 2,
    gapY: 0.05, // an inky stretch continues across a gap of this many line heights (at least 2 px)
    gapX: 0.3, // across the words of one line: this many line heights
    minKeep: 0.3, // never shrink a side to less than this share of the box
    pad: 0.06, // breathing room round the ink, as a share of the line height (at least 1 px)
    bandMax: 8, // the thin band for the sign's colour: at most this many px
  };

  const clamp = (v, lo, hi) => (v < lo ? lo : v > hi ? hi : v);
  const area = (b) => Math.max(0, b[2] - b[0]) * Math.max(0, b[3] - b[1]);
  function inter(a, b) {
    return area([Math.max(a[0], b[0]), Math.max(a[1], b[1]), Math.min(a[2], b[2]), Math.min(a[3], b[3])]);
  }
  const overlapX = (a, b) => Math.min(a[2], b[2]) - Math.max(a[0], b[0]);
  const overlapY = (a, b) => Math.min(a[3], b[3]) - Math.max(a[1], b[1]);

  /* edge energy of a region, as a Float32Array (w x h): the mean over the colour channels of |c(x+1,y) - c(x-1,y)| + |c(x,y+1) - c(x,y-1)| */
  function energy(img, x0, y0, x1, y1) {
    const W = img.width, H = img.height, ch = img.channels || 4, d = img.data;
    const w = x1 - x0, h = y1 - y0;
    const out = new Float32Array(w * h);
    for (let y = 0; y < h; y++) {
      const yy = y0 + y;
      const ya = Math.max(0, yy - 1), yb = Math.min(H - 1, yy + 1);
      for (let x = 0; x < w; x++) {
        const xx = x0 + x;
        const xa = Math.max(0, xx - 1), xb = Math.min(W - 1, xx + 1);
        const i1 = (yy * W + xa) * ch, i2 = (yy * W + xb) * ch, i3 = (ya * W + xx) * ch, i4 = (yb * W + xx) * ch;
        out[y * w + x] = (Math.abs(d[i1] - d[i2]) + Math.abs(d[i1 + 1] - d[i2 + 1]) + Math.abs(d[i1 + 2] - d[i2 + 2]) +
          Math.abs(d[i3] - d[i4]) + Math.abs(d[i3 + 1] - d[i4 + 1]) + Math.abs(d[i3 + 2] - d[i4 + 2])) / 3;
      }
    }
    return out;
  }

  const percentile = (arr, p) => {
    if (!arr.length) return 0;
    const s = Array.prototype.slice.call(arr).sort((a, b) => a - b);
    return s[Math.min(s.length - 1, Math.floor(p * s.length))];
  };

  /* The search region round a box: the box plus the margin, inside the picture, and never reaching into a neighbouring line's box.
     A neighbour above, below, left or right (it must share some of the other axis) limits that side to the half way point between
     the two boxes' centres, but a side never has to move inward because of a neighbour: boxes that already overlap keep their edge. */
  function searchRegion(b, others, W, H, o) {
    const bw = b[2] - b[0], bh = b[3] - b[1];
    const mx = o.margin * bw, my = o.margin * bh;
    const R = [Math.max(0, Math.floor(b[0] - mx)), Math.max(0, Math.floor(b[1] - my)), Math.min(W, Math.ceil(b[2] + mx)), Math.min(H, Math.ceil(b[3] + my))];
    const cx = (b[0] + b[2]) / 2, cy = (b[1] + b[3]) / 2;
    for (const q of others) {
      if (!q) continue;
      const qcx = (q[0] + q[2]) / 2, qcy = (q[1] + q[3]) / 2;
      if (overlapX(b, q) > 0.15 * Math.min(bw, q[2] - q[0])) {
        if (qcy > cy) R[3] = Math.min(R[3], Math.max(Math.ceil(b[3]), Math.floor((cy + qcy) / 2)));
        else if (qcy < cy) R[1] = Math.max(R[1], Math.min(Math.floor(b[1]), Math.ceil((cy + qcy) / 2)));
      }
      if (overlapY(b, q) > 0.15 * Math.min(bh, q[3] - q[1])) {
        if (qcx > cx) R[2] = Math.min(R[2], Math.max(Math.ceil(b[2]), Math.floor((cx + qcx) / 2)));
        else if (qcx < cx) R[0] = Math.max(R[0], Math.min(Math.floor(b[0]), Math.ceil((cx + qcx) / 2)));
      }
    }
    return R;
  }

  /* The extent of the inky entries of a profile [lo, hi) that belongs to the box [blo, bhi): from the first inky entry inside the box to
     the last, then outward across gaps of at most `gap` entries (so a letter's descender or the next word is taken, a separate clutter
     is not). null when the box holds no ink. */
  function extent(inky, lo, hi, blo, bhi, gap) {
    let first = -1, last = -1;
    for (let i = Math.max(lo, blo); i < Math.min(hi, bhi); i++) if (inky[i - lo]) { if (first < 0) first = i; last = i; }
    if (first < 0) return null;
    let a = first, b = last;
    for (let i = first - 1, g = 0; i >= lo && g <= gap; i--) { if (inky[i - lo]) { a = i; g = 0; } else g++; }
    for (let i = last + 1, g = 0; i < hi && g <= gap; i++) { if (inky[i - lo]) { b = i; g = 0; } else g++; }
    return [a, b + 1];
  }

  /* One box snapped to the ink. Returns { box, moved }. */
  function refineBox(img, b, others, opts) {
    const o = Object.assign({}, DEFAULTS, opts || {});
    const W = img.width, H = img.height;
    const orig = [clamp(Math.round(b[0]), 0, W), clamp(Math.round(b[1]), 0, H), clamp(Math.round(b[2]), 0, W), clamp(Math.round(b[3]), 0, H)];
    const bw = orig[2] - orig[0], bh = orig[3] - orig[1];
    const keep = { box: orig, moved: false };
    if (bw < 6 || bh < 6) return keep;
    const R = searchRegion(orig, others || [], W, H, o);
    const rw = R[2] - R[0], rh = R[3] - R[1];
    if (rw < 6 || rh < 6) return keep;
    const E = energy(img, R[0], R[1], R[2], R[3]);
    // a neighbouring line's box is not ours: its lettering is not ink for this box (the model's boxes can overlap a little)
    for (const q of others || []) {
      if (!q) continue;
      const qx0 = Math.max(R[0], Math.round(q[0]) - 1), qx1 = Math.min(R[2], Math.round(q[2]) + 1), qy0 = Math.max(R[1], Math.round(q[1]) - 1), qy1 = Math.min(R[3], Math.round(q[3]) + 1); // (the energy of a pixel looks one pixel either way)
      for (let y = qy0; y < qy1; y++) for (let x = qx0; x < qx1; x++) E[(y - R[1]) * rw + (x - R[0])] = 0;
    }
    // what counts as ink is judged against the box's own strong edges (text is the strongest thing in it)
    const inside = [];
    for (let y = Math.max(R[1], orig[1]); y < Math.min(R[3], orig[3]); y++) {
      for (let x = Math.max(R[0], orig[0]); x < Math.min(R[2], orig[2]); x++) inside.push(E[(y - R[1]) * rw + (x - R[0])]);
    }
    if (!inside.length) return keep;
    const strong = percentile(inside, 0.92);
    const thr = Math.max(o.inkMin, o.inkRel * strong);
    if (strong < o.inkMin * 1.5) return keep; // nothing in the box stands out from its background: nothing to snap to
    let top = orig[1], bottom = orig[3], left = orig[0], right = orig[2];
    for (let pass = 0; pass < 2; pass++) {
      // rows: ink pixels per row across the columns of the current box (plus the margin on both sides)
      const cx0 = Math.max(R[0], pass ? left : orig[0]), cx1 = Math.min(R[2], pass ? right : orig[2]);
      const cnt = new Float32Array(rh);
      for (let y = 0; y < rh; y++) {
        let c = 0;
        for (let x = cx0; x < cx1; x++) if (E[y * rw + (x - R[0])] > thr) c++;
        cnt[y] = c;
      }
      const inRows = [];
      for (let y = Math.max(R[1], top); y < Math.min(R[3], bottom); y++) inRows.push(cnt[y - R[1]]);
      const typical = percentile(inRows, 0.75);
      const rowThr = Math.max(o.rowMin, o.rowRel * typical);
      const inky = new Uint8Array(rh);
      for (let y = 0; y < rh; y++) inky[y] = cnt[y] >= rowThr ? 1 : 0;
      const gy = Math.max(2, Math.round(o.gapY * bh));
      const ry = extent(inky, R[1], R[3], pass ? top : orig[1], pass ? bottom : orig[3], gy);
      if (!ry) return keep;
      top = ry[0];
      bottom = ry[1];
      // columns: ink pixels per column within the rows found
      const colCnt = new Float32Array(rw);
      for (let x = 0; x < rw; x++) {
        let c = 0;
        for (let y = top; y < bottom; y++) if (E[(y - R[1]) * rw + x] > thr) c++;
        colCnt[x] = c;
      }
      const colThr = Math.max(1, 0.12 * (bottom - top));
      const colInky = new Uint8Array(rw);
      for (let x = 0; x < rw; x++) colInky[x] = colCnt[x] >= colThr ? 1 : 0;
      const gx = Math.max(3, Math.round(o.gapX * (bottom - top)));
      const rx = extent(colInky, R[0], R[2], orig[0], orig[2], gx);
      if (!rx) return keep;
      left = rx[0];
      right = rx[1];
    }
    const lh = bottom - top;
    const pd = Math.max(1, Math.round(o.pad * lh));
    const out = [clamp(left - pd, R[0], W), clamp(top - pd, R[1], H), clamp(right + pd, 0, R[2]), clamp(bottom + pd, 0, R[3])];
    if (out[2] - out[0] < o.minKeep * bw || out[3] - out[1] < o.minKeep * bh) return keep;
    const moved = out.some((v, i) => Math.abs(v - orig[i]) >= 1);
    return { box: out, moved: moved };
  }

  /* ---------- colours ---------- */

  const median = (arr) => {
    const s = Array.prototype.slice.call(arr).sort((a, b) => a - b);
    return s.length ? s[s.length >> 1] : 0;
  };

  /* median colour of the thin band just outside the box (a gap of 1 px, then the band), leaving out the pixels that lie in other lines' boxes */
  function bandColor(img, b, others, opts) {
    const o = Object.assign({}, DEFAULTS, opts || {});
    const W = img.width, H = img.height, ch = img.channels || 4, d = img.data;
    const bh = b[3] - b[1];
    const t = clamp(Math.round(bh * 0.15), 2, o.bandMax);
    const x0 = Math.max(0, b[0] - 1 - t), y0 = Math.max(0, b[1] - 1 - t), x1 = Math.min(W, b[2] + 1 + t), y1 = Math.min(H, b[3] + 1 + t);
    const rs = [], gs = [], bs = [];
    for (let y = y0; y < y1; y++) {
      for (let x = x0; x < x1; x++) {
        if (x >= b[0] - 1 && x < b[2] + 1 && y >= b[1] - 1 && y < b[3] + 1) continue; // the box and its 1 px gap
        let skip = false;
        for (let k = 0; k < others.length; k++) {
          const q = others[k];
          if (q && x >= q[0] && x < q[2] && y >= q[1] && y < q[3]) { skip = true; break; }
        }
        if (skip) continue;
        const i = (y * W + x) * ch;
        rs.push(d[i]); gs.push(d[i + 1]); bs.push(d[i + 2]);
      }
    }
    if (rs.length < 12) return null;
    return [median(rs), median(gs), median(bs)];
  }

  /* the colour of the sign's face inside the box: the median of the pixels that are NOT ink. Returns { color, share } (share = how much of the
     box that is), or null when there are too few. */
  function insideColor(img, b) {
    const W = img.width, ch = img.channels || 4, d = img.data;
    const E = energy(img, b[0], b[1], b[2], b[3]);
    const w = b[2] - b[0];
    const rs = [], gs = [], bs = [];
    for (let y = b[1]; y < b[3]; y++) {
      for (let x = b[0]; x < b[2]; x++) {
        if (E[(y - b[1]) * w + (x - b[0])] > DEFAULTS.inkMin) continue;
        const i = (y * W + x) * ch;
        rs.push(d[i]); gs.push(d[i + 1]); bs.push(d[i + 2]);
      }
    }
    if (rs.length < 20) return null;
    return { color: [median(rs), median(gs), median(bs)], share: rs.length / Math.max(1, (b[2] - b[0]) * (b[3] - b[1])) };
  }

  const dist = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2]);

  /* the dominant colour of the lettering: the median of the pixels inside the box that are far from the background colour, when there
     are enough of them and they are clearly different. null otherwise (the label then picks black or white for contrast). */
  function inkColor(img, b, bg) {
    if (!bg) return null;
    const W = img.width, ch = img.channels || 4, d = img.data;
    const far = [];
    let n = 0;
    for (let y = b[1]; y < b[3]; y++) {
      for (let x = b[0]; x < b[2]; x++) {
        n++;
        const i = (y * W + x) * ch;
        const p = [d[i], d[i + 1], d[i + 2]];
        const dd = dist(p, bg);
        if (dd >= 70) far.push({ p: p, dd: dd });
      }
    }
    if (n < 20 || far.length < Math.max(8, 0.05 * n)) return null;
    far.sort((a, b2) => b2.dd - a.dd);
    const top = far.slice(0, Math.max(6, Math.round(far.length * 0.5))); // the farthest half: not the anti-aliased edges
    return [median(top.map((f) => f.p[0])), median(top.map((f) => f.p[1])), median(top.map((f) => f.p[2]))];
  }

  /* How far the lettering in the box is tilted, in degrees (positive = the line runs downhill to the right). Read from where the lettering sits in
     each column: the centre of the lettering's pixels in every column across the box, and the least squares line through those centres (weighted by
     how many pixels the column has), so tall letters do not hide a slope (the principal axis does: a short word of tall letters reads half its
     slope). The lettering's pixels are the ones that lie beyond the lettering's own colour on the way from the sign's colour (bg, fg: `ink` and
     `analyse` have them); without both colours, the strongest edges stand in (which a busy sign face confuses). null when there is too little to
     say. A level line reads near 0 (95 % of real level lines under 5 degrees); a sign seen at a slant reads 10 or more. The label is always level,
     so ovfit.js refuses a tilted line. */
  function tilt(img, b, bg, fg) {
    const w = b[2] - b[0], h = b[3] - b[1];
    if (w < 8 || h < 6) return null;
    const ch = img.channels || 4, d = img.data, W = img.width;
    let hit;
    if (bg && fg && dist(bg, fg) > 40) {
      const v = [fg[0] - bg[0], fg[1] - bg[1], fg[2] - bg[2]], vv = v[0] * v[0] + v[1] * v[1] + v[2] * v[2];
      hit = (x, y) => { const i = ((b[1] + y) * W + b[0] + x) * ch; return ((d[i] - bg[0]) * v[0] + (d[i + 1] - bg[1]) * v[1] + (d[i + 2] - bg[2]) * v[2]) / vv > 0.8; };
    } else {
      const E = energy(img, b[0], b[1], b[2], b[3]);
      const thr = Math.max(DEFAULTS.inkMin, DEFAULTS.inkRel * percentile(E, 0.92));
      hit = (x, y) => E[y * w + x] > thr;
    }
    let n = 0, sw = 0, sx = 0, sy = 0, cols = 0;
    const cy = new Float32Array(w), cw = new Float32Array(w);
    for (let x = 0; x < w; x++) {
      let c = 0, s = 0;
      for (let y = 0; y < h; y++) if (hit(x, y)) { c++; s += y; }
      if (c >= 2) { cy[x] = s / c; cw[x] = c; sw += c; sx += c * x; sy += c * cy[x]; cols++; n += c; }
    }
    if (n < 40 || cols < 0.3 * w) return null;
    const mx = sx / sw, my = sy / sw;
    let sxx = 0, sxy = 0;
    for (let x = 0; x < w; x++) if (cw[x]) { sxx += cw[x] * (x - mx) * (x - mx); sxy += cw[x] * (x - mx) * (cy[x] - my); }
    if (sxx < 1e-6) return null;
    return (Math.atan2(sxy, sxx) * 180) / Math.PI;
  }

  /* ---------- the one call ---------- */
  function analyse(img, boxes, opts) {
    const bx = boxes.map((b) => (b ? [Math.round(b[0]), Math.round(b[1]), Math.round(b[2]), Math.round(b[3])] : null));
    const snapped = bx.map((b, i) => {
      if (!b) return null;
      const r = refineBox(img, b, bx.filter((q, j) => j !== i), opts);
      return { box: r.box, moved: r.moved };
    });
    const sbs = snapped.map((s) => (s ? s.box : null));
    return snapped.map((s, i) => {
      if (!s) return null;
      const others = sbs.filter((q, j) => j !== i);
      // the sign's colour: the band just outside the box, which is the sign's face when the box hugs the lettering. When the box takes in the
      // sign's edge or trim, that band is the wall or the roof beyond it (Kani Doraku: a dark roof round a cream sign), and the face is what
      // lies between the letters: where the two disagree clearly and the box is mostly face, the inside wins.
      let bg = bandColor(img, s.box, others, opts);
      const face = insideColor(img, s.box);
      if (face && (!bg || (face.share >= 0.3 && dist(bg, face.color) > 45))) bg = face.color;
      const fg = inkColor(img, s.box, bg);
      return { sb: s.box, moved: s.moved, bg: bg, fg: fg, ang: tilt(img, s.box, bg, fg) };
    });
  }

  const API = { analyse: analyse, tilt: tilt, refineBox: refineBox, bandColor: bandColor, inkColor: inkColor, insideColor: insideColor, energy: energy, DEFAULTS: DEFAULTS };
  root.PAASnap = API;
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
})(typeof self !== 'undefined' ? self : globalThis);
