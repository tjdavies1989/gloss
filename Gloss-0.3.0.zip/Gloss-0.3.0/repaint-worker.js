/* Gloss: AI repaint (stage 4), the service worker's part. Classic script (importScripts, after shared.js and repaint-core.js).

   run(job, deps) does one repaint from start to finish and never shows (never even returns the picture of) a result that failed its check:
     1. the picture to repaint (deps.source(): the stored crop, or a fresh screenshot cut to the shape the page planned) and the lines to paint
     2. refuse before spending anything when the writing is cut off or there is nothing to paint (PAARepaint.assess)
     3. the image model letters the English (one call, about 28 s, about 4 cents), Haiku reads the result back blind (and, in parallel at the start, the
        original, so English that was already on the sign is not mistaken for something invented), and the picture outside the text boxes is compared
        with the original; one automatic retry with the firm instruction when any of that fails
     4. a result that passed is feathered into a patch (WebP with alpha) and stored under the mark's own key; the page warps it onto the sign.
   Two providers: the image model is on OpenRouter (deps.openrouter), the read-backs are Claude Haiku on the Anthropic API (deps.anthropic): each { key, source }.
   Everything is cancelled by deps.signal (the page closed the port: the cancel button, a deleted mark, a closed tab). Costs are the real usage.cost of each
   call, summed. Nothing here touches the DOM; the only browser APIs are fetch, createImageBitmap and OffscreenCanvas. */
(function (root) {
  'use strict';
  const R = root.PAARepaint;
  const PAA = root.PAA;

  const IMAGES = 'https://openrouter.ai/api/v1/images';
  const IMAGE_TIMEOUT = 240000; // ms (the experiment's slowest run was 37 s)
  const MAX_TRIES = 2; // the first attempt and one automatic retry with the firm instruction

  const cancelled = () => { const e = new Error('cancelled'); e.name = 'AbortError'; return e; };

  async function blobToDataUrl(blob) {
    const bytes = new Uint8Array(await blob.arrayBuffer());
    let bin = '';
    for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
    return 'data:' + (blob.type || 'image/jpeg') + ';base64,' + btoa(bin);
  }
  const bitmapOf = async (url) => createImageBitmap(await (await fetch(url)).blob());

  /* a bitmap as a JPEG data URL at w x h */
  async function jpegUrl(bmp, w, h, quality) {
    const cv = new OffscreenCanvas(w, h);
    const cx = cv.getContext('2d');
    cx.imageSmoothingQuality = 'high';
    cx.drawImage(bmp, 0, 0, w, h);
    return blobToDataUrl(await cv.convertToBlob({ type: 'image/jpeg', quality: quality }));
  }

  /* the pixels of a bitmap at w x h (for the pixel check) */
  function pixelsOf(bmp, w, h) {
    const cv = new OffscreenCanvas(w, h);
    const cx = cv.getContext('2d', { willReadFrequently: true });
    cx.imageSmoothingQuality = 'high';
    cx.drawImage(bmp, 0, 0, w, h);
    return { w: w, h: h, ch: 4, data: cx.getImageData(0, 0, w, h).data };
  }

  /* ---------- the picture to repaint, cut from a screenshot (a fresh capture) ----------
     g: { rect: {x, y, w, h} CSS px, iw (window.innerWidth) }. The rectangle has one of the shapes the image model outputs; it is cut at the screen's own
     resolution, reduced when its long side is over INPUT_MAX and enlarged (smoothly, at most 4 times) when it is under INPUT_MIN: the model re-draws the whole picture at its own size. */
  async function cutSource(shotUrl, g) {
    const bmp = await bitmapOf(shotUrl);
    try {
      const k = bmp.width / g.iw;
      const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));
      const sx = clamp(Math.round(g.rect.x * k), 0, bmp.width - 1);
      const sy = clamp(Math.round(g.rect.y * k), 0, bmp.height - 1);
      const sw = clamp(Math.round(g.rect.w * k), 1, bmp.width - sx);
      const sh = clamp(Math.round(g.rect.h * k), 1, bmp.height - sy);
      const sz = R.sendSize(sw, sh);
      const cv = new OffscreenCanvas(sz[0], sz[1]);
      const cx = cv.getContext('2d');
      cx.imageSmoothingQuality = 'high';
      cx.drawImage(bmp, sx, sy, sw, sh, 0, 0, sz[0], sz[1]);
      return { url: await blobToDataUrl(await cv.convertToBlob({ type: 'image/jpeg', quality: 0.92 })), w: sz[0], h: sz[1] };
    } finally {
      bmp.close();
    }
  }

  /* ---------- the image model ---------- */
  function errText(raw) {
    try {
      const j = JSON.parse(raw);
      return (j.error && (j.error.message || JSON.stringify(j.error))) || raw;
    } catch (e) {
      return raw;
    }
  }

  /* One image edit through OpenRouter (POST /api/v1/images; checked against GET /api/v1/images/models on 14 Nov: aspect_ratio, quality, input_references).
     o.openrouter: { key, source }. Returns { dataUrl, cost, ms }. A failure is an Error with a plain message (the shared key that ran out says so, with settings: true). */
  async function imageCall(o) {
    const f = o.fetchImpl || fetch;
    const body = {
      model: o.model || R.IMAGE_MODEL,
      prompt: o.prompt,
      n: 1,
      quality: o.quality || R.QUALITY,
      aspect_ratio: o.ratio,
      input_references: [{ type: 'image_url', image_url: { url: o.input } }],
    };
    if (o.signal && o.signal.aborted) throw cancelled();
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), IMAGE_TIMEOUT);
    const onAbort = () => ctl.abort();
    if (o.signal) o.signal.addEventListener('abort', onAbort);
    const t0 = Date.now();
    try {
      let res;
      try {
        res = await f(IMAGES, {
          method: 'POST', signal: ctl.signal, referrerPolicy: 'no-referrer',
          headers: { Authorization: 'Bearer ' + o.openrouter.key, 'Content-Type': 'application/json', 'X-Title': 'Gloss' },
          body: JSON.stringify(body),
        });
      } catch (e) {
        if (o.signal && o.signal.aborted) throw cancelled();
        if (e && e.name === 'AbortError') throw new Error('The image model took too long. Try again.');
        throw new Error('Network error: ' + ((e && e.message) || e));
      }
      let raw;
      try {
        raw = await res.text();
      } catch (e) {
        if (o.signal && o.signal.aborted) throw cancelled();
        throw new Error('The image model took too long. Try again.');
      }
      if (!res.ok) throw PAAProviders.failure('openrouter', res.status, errText(raw).slice(0, 400), o.openrouter.source);
      let j;
      try { j = JSON.parse(raw); } catch (e) { throw new Error('The image model sent something unreadable.'); }
      const d = j.data && j.data[0];
      if (!d || !d.b64_json) throw new Error('The image model sent no picture' + (j.error ? ': ' + errText(JSON.stringify(j)).slice(0, 200) : '.'));
      const mime = d.media_type || (d.b64_json.indexOf('/9j/') === 0 ? 'image/jpeg' : d.b64_json.indexOf('UklGR') === 0 ? 'image/webp' : 'image/png');
      const u = j.usage || {};
      return { dataUrl: 'data:' + mime + ';base64,' + d.b64_json, cost: typeof u.cost === 'number' ? u.cost : 0, ms: Date.now() - t0 };
    } finally {
      clearTimeout(timer);
      if (o.signal) o.signal.removeEventListener('abort', onAbort);
    }
  }

  /* ---------- the read-back ---------- */
  const READBACK = 'You are a careful transcriber. List every piece of readable text in this image that is written in English or Latin letters or digits (signs, boards, labels, phone numbers), verbatim, exactly as spelled, including any misspellings, in reading order. Do not correct, complete or guess. Ignore text you cannot read. Reply with ONE JSON array of strings and nothing else.';

  /* Haiku reads the English / Latin text off a picture, blind (it is not told what should be there). Returns { got: [strings] | null, cost }. */
  async function readBack(url, o) {
    const r = await PAAProviders.streamChat({
      apiKey: o.anthropic.key, keySource: o.anthropic.source, model: PAA.DEFAULT_MODEL, signal: o.signal, fetchImpl: o.fetchImpl,
      prompt: { system: READBACK, messages: [{ role: 'user', content: [{ type: 'text', text: 'Transcribe the English/Latin text.' }, PAA.imageBlock(url)] }] },
    });
    let got = null;
    const s = r.text;
    const a = s.indexOf('['), z = s.lastIndexOf(']');
    if (a >= 0 && z > a) { try { got = JSON.parse(s.slice(a, z + 1)).map(String); } catch (e) { got = null; } }
    return { got: got, cost: r.cost || 0 };
  }

  /* A second, narrower look. The read-back is blind and small text is read differently each time, so a piece that is flagged ("text nobody asked for", a "new"
     number, a number that is "gone") is put to Haiku as a plain yes / no question about the picture it is supposed to be on or in: is there writing like it there (it may be a misreading of small, blurred text)?
     Returns { flags: [bool] (one per item; all false when the answer cannot be read), cost }. */
  const PRESENT = 'You are a careful reader. Each item below is a piece of text that someone else read, from a picture like this one, in small, partly hidden or blurred writing: it may be misspelled or only part of a word. For each item say true if this image contains writing that the item plausibly is (a reading, or a misreading, of it), anywhere in the picture, and false if there is nothing like it. Reply with ONE JSON array of true or false, one per item in the same order, and nothing else.';
  async function presentIn(url, items, o) {
    const r = await PAAProviders.streamChat({
      apiKey: o.anthropic.key, keySource: o.anthropic.source, model: PAA.DEFAULT_MODEL, signal: o.signal, fetchImpl: o.fetchImpl,
      prompt: { system: PRESENT, messages: [{ role: 'user', content: [{ type: 'text', text: 'Items:\n' + items.map((t, i) => (i + 1) + '. ' + JSON.stringify(t)).join('\n') }, PAA.imageBlock(url)] }] },
    });
    let flags = items.map(() => false);
    const a = r.text.indexOf('['), z = r.text.lastIndexOf(']');
    if (a >= 0 && z > a) { try { const v = JSON.parse(r.text.slice(a, z + 1)); if (Array.isArray(v) && v.length === items.length) flags = v.map((x) => x === true); } catch (e) { /* none confirmed */ } }
    return { flags: flags, cost: r.cost || 0 };
  }

  /* ---------- the patch: the result with a feathered edge ----------
     The result at its own size (the model draws at about 1536 px: the lettering is crisper than the screenshot it came from), the outer 6 % of the short
     side fading to nothing so the patch settles into the picture. WebP keeps the alpha at a fraction of a PNG's size. */
  async function makePatch(bmp) {
    const w = bmp.width, h = bmp.height;
    const f = R.featherPx(w, h);
    const cv = new OffscreenCanvas(w, h);
    const cx = cv.getContext('2d');
    cx.drawImage(bmp, 0, 0);
    const mask = new OffscreenCanvas(w, h);
    const mc = mask.getContext('2d');
    mc.filter = 'blur(' + f / 2 + 'px)';
    mc.fillStyle = '#fff';
    mc.fillRect(f, f, w - 2 * f, h - 2 * f);
    cx.globalCompositeOperation = 'destination-in';
    cx.drawImage(mask, 0, 0);
    return { url: await blobToDataUrl(await cv.convertToBlob({ type: 'image/webp', quality: 0.92 })), w: w, h: h };
  }

  /* ---------- one repaint ----------
     job: { id, source: 'stored' | 'fresh', lines: [{i, o, t, b | cb, spill}], css: {w, h} (fresh: the CSS size of the rectangle the cb boxes are in), unreadable }
     deps: { anthropic: { key, source }, openrouter: { key, source }, signal, fetchImpl, phase(name), source() -> { url, w, h }, save(patch) -> Promise }
     Returns { ok: true, patch: {w, h}, stats, check, lines } | { ok: false, kind: 'refused' | 'check' | 'error', why, message, problems, stats, tries }. */
  async function run(job, deps) {
    const acc = {};
    try {
      return await runOnce(job, deps, acc);
    } catch (e) { // money already spent on this run is not lost with it: the error carries the stats so far
      // (the first read of the original is usually still on its way when an image call fails: give it a moment to be counted)
      if (acc.pending) await Promise.race([acc.pending.catch(() => {}), new Promise((r) => setTimeout(r, 4000))]);
      if (e && typeof e === 'object' && acc.stats) e.stats = acc.stats();
      throw e;
    }
  }

  async function runOnce(job, deps, acc) {
    const t0 = Date.now();
    const signal = deps.signal;
    const phase = deps.phase || (() => {});
    const guard = () => { if (signal && signal.aborted) throw cancelled(); };
    const spend = { cost: 0, calls: 0 };
    const stats = () => ({ ms: Date.now() - t0, cost: Math.round(spend.cost * 1e6) / 1e6, calls: spend.calls, model: R.IMAGE_MODEL, quality: R.QUALITY, tries: tries.length });
    const tries = [];
    acc.stats = stats;
    const common = { anthropic: deps.anthropic, openrouter: deps.openrouter, signal: signal, fetchImpl: deps.fetchImpl };

    const src = await deps.source();
    guard();
    // the boxes in the pixels of the picture
    const k = job.source === 'fresh' && job.css ? src.w / job.css.w : 1;
    const lines = job.lines.map((l) => {
      const raw = l.b || l.cb;
      const b = raw ? raw.map((v) => v * k) : null;
      return { i: l.i, o: l.o, t: l.t, b: b, spill: !!l.spill };
    });
    const a = R.assess(lines, src.w, src.h);
    if (a.cut.length) return { ok: false, kind: 'refused', why: 'cut', problems: [], stats: stats(), cut: a.cut };
    if (!a.paint.length) return { ok: false, kind: 'refused', why: 'nothing', problems: [], stats: stats() };
    const ratio = R.pickRatio(src.w, src.h);
    if (ratio.off > R.SHAPE_TOL) return { ok: false, kind: 'refused', why: 'shape', problems: [], stats: stats() };

    // what is sent: the picture itself (a screenshot cut is already at most INPUT_MAX; a stored crop is reduced when it is bigger)
    const sz = R.inputSize(src.w, src.h);
    const bmp = await bitmapOf(src.url);
    let input = src.url;
    try {
      if (sz[0] !== src.w || sz[1] !== src.h) input = await jpegUrl(bmp, sz[0], sz[1], 0.92);
    } catch (e) {
      bmp.close();
      throw e;
    }
    const sk = sz[0] / src.w;
    const paint = a.paint.map((e) => ({ b: e.b ? e.b.map((v) => v * sk) : null, o: e.o, t: e.t }));
    const wsz = R.workSize(sz[0], sz[1]);
    const orig = pixelsOf(bmp, wsz[0], wsz[1]);
    bmp.close();
    const boxesWork = paint.filter((e) => e.b).map((e) => e.b.map((v) => v * (wsz[0] / sz[0])));
    const unreadable = job.unreadable ? String(job.unreadable).slice(0, 160) : '';

    // what the ORIGINAL says in English / Latin letters, read while the image model works
    // (its cost is counted when it comes back, not when the first check needs it: an image call that fails first must not hide a call that was paid)
    // A key problem seen by this read-back (the Claude key ran out) ends the run at once: the image model is told to stop, so a picture is not paid for that could never be checked.
    const stopImage = new AbortController();
    const imageSignal = signal ? (() => { const c = new AbortController(); signal.addEventListener('abort', () => c.abort()); stopImage.signal.addEventListener('abort', () => c.abort()); return c.signal; })() : stopImage.signal;
    let keyFail = null;
    const baseline = readBack(input, common).catch((e) => {
      if (signal && signal.aborted) return Promise.reject(cancelled());
      if (e && e.settings) { keyFail = e; stopImage.abort(); }
      return { got: null, cost: (e && e.cost) || 0, err: e }; // (a reply cut off at max_tokens was paid for: e.cost; it only means "no baseline")
    }).then((r) => { spend.cost += r.cost || 0; spend.calls++; return r; });
    baseline.catch(() => {}); // (an abort is raised where it is awaited; this only keeps a run that ends before that quiet)
    acc.pending = baseline;
    const baseOnce = () => baseline;

    // A read-back that was cut off at max_tokens ends the run with that message (a second image call would be paid for nothing: the check never saw the picture), but what the
    // cut-off call cost is still counted.
    const counted = async (p) => {
      try { return await p; } catch (e) { if (e && e.cost) { spend.cost += e.cost; spend.calls++; } throw e; }
    };

    let problems = [];
    let last = null;
    for (let attempt = 0; attempt < MAX_TRIES; attempt++) {
      guard();
      phase(attempt ? 'retry' : 'paint');
      const instruction = R.buildInstruction(paint, { width: sz[0], height: sz[1], firm: attempt > 0, problems: problems.slice(0, 6), unreadable: unreadable });
      let img;
      try {
        img = await imageCall(Object.assign({ prompt: instruction, ratio: ratio.name, input: input }, common, { signal: imageSignal }));
      } catch (e) {
        if (keyFail && !(signal && signal.aborted)) throw keyFail;
        throw e;
      }
      spend.cost += img.cost;
      spend.calls++;
      guard();
      phase('check');
      const t1 = Date.now();
      const rb = await bitmapOf(img.dataUrl);
      const rec = { attempt: attempt, imageMs: img.ms, imageCost: img.cost, problems: [] };
      if (root.__paaKeep) (root.__paaLast = root.__paaLast || []).push({ attempt: attempt, instruction: instruction, dataUrl: img.dataUrl, rec: rec }); // (a test hook: the harness sets __paaKeep to look at what came back)
      try {
        if (!R.frameOk(sz[0], sz[1], rb.width, rb.height)) {
          rec.problems.push('the picture came back re-framed (' + rb.width + ' x ' + rb.height + ' for ' + sz[0] + ' x ' + sz[1] + ')');
        } else {
          const res = pixelsOf(rb, wsz[0], wsz[1]);
          const px = R.pixelCheck(orig, res, boxesWork);
          rec.pixel = px;
          const rsz = R.inputSize(rb.width, rb.height);
          const resJpeg = await jpegUrl(rb, rsz[0], rsz[1], 0.9);
          const back = await counted(readBack(resJpeg, common));
          spend.cost += back.cost;
          spend.calls++;
          const base = await baseOnce();
          rec.baselineFailed = !base.got;
          rec.baseline = base.got;
          let ev = R.evaluate(paint, back.got, base.got || []);
          // text flagged as invented (or a number as new) that is in fact on the ORIGINAL, small enough for the blind read-back to have missed it, is not an invention
          if (!ev.ok && ev.wordsOk && (ev.extra.length || ev.newDigits.length)) {
            const items = ev.extra.concat(ev.newDigits);
            const pr = await counted(presentIn(input, items, common));
            spend.cost += pr.cost; spend.calls++;
            const found = items.filter((x, i) => pr.flags[i]);
            if (found.length) { rec.confirmed = found; ev = R.evaluate(paint, back.got, (base.got || []).concat(found)); }
          }
          // and a number flagged as gone that is in fact still on the RESULT
          if (!ev.ok && ev.wordsOk && ev.missingDigits.length) {
            const pr = await counted(presentIn(resJpeg, ev.missingDigits, common));
            spend.cost += pr.cost; spend.calls++;
            const found = ev.missingDigits.filter((x, i) => pr.flags[i]);
            if (found.length) { rec.confirmedPresent = found; ev = R.evaluate(paint, back.got.concat(found), base.got || []); }
          }
          rec.words = ev.wordsOk; rec.digits = ev.digitsOk; rec.noExtra = ev.noExtra; rec.got = ev.got;
          if (!ev.ok) rec.problems.push.apply(rec.problems, R.explain(ev, paint));
          if (!px.inked) rec.problems.push('the lettering was not repainted (the picture inside the text boxes hardly changed)');
          if (!px.ok && px.inked) {
            if (px.blob > R.BLOB_MAX) rec.problems.push('part of the picture outside the lettering was changed (a block of it differs by ' + px.blob + ' grey levels)');
            else rec.problems.push('the picture outside the lettering changed too much (grey ' + px.mad + ', colour ' + px.col + ')');
          }
        }
        rec.ok = rec.problems.length === 0;
        rec.checkMs = Date.now() - t1;
        tries.push(rec);
        if (rec.ok) {
          const patch = await makePatch(rb);
          patch.t = Date.now(); // the token that ties the stored picture to the record (rec.repaint.img.t): the page checks it when it loads the picture
          guard();
          const saved = await deps.save(patch);
          if (saved === false) return { ok: false, kind: 'error', why: 'gone', message: 'This note was deleted while its repaint was being made.', problems: [], stats: stats(), tries: tries };
          return { ok: true, patch: { w: patch.w, h: patch.h, t: patch.t }, stats: stats(), tries: tries, lines: paint.map((e) => ({ o: e.o, t: e.t })), source: job.source, ratio: ratio.name, input: sz };
        }
        problems = rec.problems;
        last = rec;
      } finally {
        rb.close();
      }
    }
    return { ok: false, kind: 'check', why: 'check', problems: last ? last.problems : problems, stats: stats(), tries: tries };
  }

  root.PAARun = { run: run, cutSource: cutSource, imageCall: imageCall, readBack: readBack, presentIn: presentIn, makePatch: makePatch, MAX_TRIES: MAX_TRIES };
})(typeof self !== 'undefined' ? self : globalThis);
