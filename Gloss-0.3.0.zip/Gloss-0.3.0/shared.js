/* Gloss: code shared by the service worker, the content script and the node tests.
   Loaded three ways: importScripts('shared.js') in the worker, listed in the manifest before the other
   content scripts, and require() from node. Plain classic script, no modules.
   The prompts themselves live in prompts.js (generated from design/*.txt). */
(function (root) {
  'use strict';

  const DEFAULT_MODEL = 'claude-haiku-5-5'; // the model id on the Anthropic API (no date suffix)
  const DEFAULT_QUESTION =
    'What is this? If it is writing, what does it say and what does it mean here?';
  const POINT_NOTE =
    'They clicked a single spot instead of drawing a box. Image 1 is a crop centred on that spot, ' +
    'and the marker on image 2 shows the thing they mean.';
  /* A backstop, not a tuning knob (the model never sees it). Thinking counts towards it: 2000 cut dense boards off, 4000 held in every real run but the longest reply seen was
     2,998 tokens, so the 0.3.0 fix round raised it to 8000 (about 40 s of silent thinking at most, under the stall timer in providers.js). A reply that still hits it is an error, never a saved answer. */
  const MAX_TOKENS = 8000;

  /* Dollars per million tokens (Anthropic's price list, 14 Nov 2026) and the cache multipliers. Thinking is billed as output. Haiku 5.5 costs more for a prompt over 100K
     tokens; a Gloss ask is about 3K, so the second row is there only so the number is never wrong. A model that is not in this table has no cost shown. */
  const PRICES = { 'claude-haiku-5-5': { inUsd: 0.10, outUsd: 0.50, bigInUsd: 0.50, bigOutUsd: 2.50, bigAbove: 100000 } };
  const CACHE_WRITE = 1.25; // x the input price, 5-minute cache entry
  const CACHE_READ = 0.10; // x the input price

  /* ---------- location from the page URL ---------- */

  function num(s) {
    const n = parseFloat(s);
    return Number.isFinite(n) ? n : null;
  }

  function validLatLng(lat, lng) {
    return lat !== null && lng !== null && Math.abs(lat) <= 90 && Math.abs(lng) <= 180;
  }

  /* Google Maps:  /maps/@LAT,LNG,3a,75y,90h,90t/data=...   (3a = Street View, y = fov, h = heading, t = tilt)
                    /maps/@LAT,LNG,17z/...                    (z = plain map, not Street View)
                    ?map_action=pano&viewpoint=LAT,LNG&heading=H&fov=F  (the "api=1" URL form)
     Yandex Maps:   ?ll=LNG,LAT  &panorama[point]=LNG,LAT  &panorama[direction]=HEADING,PITCH
     Never throws; returns {} when nothing parses. */
  function parseLocation(urlString) {
    const out = {};
    let u;
    try {
      u = new URL(urlString);
    } catch (e) {
      return out;
    }
    try {
      const host = u.hostname;
      if (/(^|\.)yandex\./.test(host)) {
        const p = u.searchParams;
        const pt = (p.get('panorama[point]') || '').split(',');
        const ll = (p.get('ll') || '').split(',');
        const dir = (p.get('panorama[direction]') || '').split(',');
        // Yandex orders coordinates longitude first.
        if (pt.length >= 2 && validLatLng(num(pt[1]), num(pt[0]))) {
          out.lat = num(pt[1]);
          out.lng = num(pt[0]);
          out.streetView = true;
        } else if (ll.length >= 2 && validLatLng(num(ll[1]), num(ll[0]))) {
          out.lat = num(ll[1]);
          out.lng = num(ll[0]);
          out.streetView = false;
        }
        if (dir.length >= 1 && num(dir[0]) !== null) out.heading = num(dir[0]);
        if (dir.length >= 2 && num(dir[1]) !== null) out.tilt = num(dir[1]);
        return out;
      }

      const m = u.pathname.match(/@(-?\d+(?:\.\d+)?),(-?\d+(?:\.\d+)?)((?:,[^,/]+)*)/);
      if (m && validLatLng(num(m[1]), num(m[2]))) {
        out.lat = num(m[1]);
        out.lng = num(m[2]);
        out.streetView = false;
        for (const tok of m[3].split(',').filter(Boolean)) {
          const t = tok.match(/^(-?\d+(?:\.\d+)?)([a-z])$/);
          if (!t) continue;
          const v = num(t[1]);
          if (t[2] === 'a') out.streetView = true;
          else if (t[2] === 'y') out.fov = v;
          else if (t[2] === 'h') out.heading = v;
          else if (t[2] === 't') out.tilt = v;
          else if (t[2] === 'z') out.zoom = v;
        }
      }
      const vp = (u.searchParams.get('viewpoint') || '').split(',');
      if (out.lat === undefined && vp.length >= 2 && validLatLng(num(vp[0]), num(vp[1]))) {
        out.lat = num(vp[0]);
        out.lng = num(vp[1]);
        out.streetView = u.searchParams.get('map_action') === 'pano';
        if (num(u.searchParams.get('heading')) !== null) out.heading = num(u.searchParams.get('heading'));
        if (num(u.searchParams.get('fov')) !== null) out.fov = num(u.searchParams.get('fov'));
      }
    } catch (e) {
      /* best effort only */
    }
    return out;
  }

  function round(n, d) {
    const f = Math.pow(10, d);
    return Math.round(n * f) / f;
  }

  /* Shorten to at most about n characters, cutting at a sentence end if one falls in the last
     third, else at a word boundary, and mark the cut with an ellipsis. */
  function clip(s, n) {
    s = String(s || '');
    if (s.length <= n) return s;
    let cut = s.slice(0, n);
    const floor = Math.floor(n * 0.66);
    let end = -1;
    const re = /[.!?。！？]["')\]”’]?(?=\s|$)/g;
    let m;
    while ((m = re.exec(cut))) end = m.index + m[0].length;
    if (end >= floor) {
      cut = cut.slice(0, end);
    } else {
      // Only cut at a space if the next character is not mid-word.
      const sp = cut.search(/\s\S*$/);
      if (sp >= floor && /\S/.test(s.charAt(n))) cut = cut.slice(0, sp);
      else if (/[\ud800-\udbff]$/.test(cut)) cut = cut.slice(0, -1); // never split a surrogate pair
    }
    return cut.replace(/\s+$/, '') + '…';
  }

  /* Where in the world this is, and nothing else. Never the page title (on Google Maps it is often a
     photographer's name) and never a person's name. info: { loc, host }; kind: 'box' | 'point' */
  function buildContextText(info, kind) {
    info = info || {};
    const loc = info.loc || {};
    const lines = [];
    if (typeof loc.lat === 'number' && typeof loc.lng === 'number') {
      let s =
        (loc.streetView ? 'Street View camera position' : 'Map position (not necessarily where the camera is)') +
        ': latitude ' + round(loc.lat, 5) + ', longitude ' + round(loc.lng, 5);
      if (typeof loc.heading === 'number') s += '; facing heading ' + round(loc.heading, 0) + ' degrees (0 = north, 90 = east)';
      if (typeof loc.fov === 'number') s += '; field of view ' + round(loc.fov, 0) + ' degrees';
      lines.push(s + '.');
    } else {
      lines.push('No coordinates could be read from the page address.');
    }
    if (info.host) lines.push('Site: ' + info.host);
    if (kind === 'point') lines.push('', POINT_NOTE);
    return lines.join('\n');
  }

  /* The first user message. Its LAST line states the size of image 1 as actually sent: the model answers
     boxes in pixels of that image, so the number has to be right (research/format/NOTES.txt). */
  function firstUserText(info, kind, question, cropSize) {
    let t =
      buildContextText(info, kind) +
      '\n\nImage 1 (crop) and image 2 (whole view, spot outlined) follow.\n\nTheir question: ' + question;
    if (cropSize && cropSize[0] > 0 && cropSize[1] > 0) t += '\n\nImage 1 is ' + cropSize[0] + ' x ' + cropSize[1] + ' pixels.';
    return t;
  }

  /* A picture as the Anthropic API takes it: a base64 block. The pictures are held as data URLs (JPEG almost always). */
  function imageBlock(dataUrl) {
    const m = /^data:([^;,]+);base64,([\s\S]*)$/.exec(String(dataUrl || ''));
    if (!m) throw new Error('A picture for this note is not readable. Ask again.');
    return { type: 'image', source: { type: 'base64', media_type: m[1], data: m[2] } };
  }

  /* The system prompt as ONE cacheable block (the same text every time, so a second ask reads it from the cache when it is long enough to be cached at all),
     then everything that differs per ask: the user turn with the words and the two pictures, in that order. Returns { system, messages }.
     opts: { info, kind, images: [cropDataUrl, contextDataUrl], cropSize: [w, h], question, turns }
     turns: [{q, a}] completed exchanges about THIS thing. With none, this is the first ask and gets the answer-card prompt; with some, it is a follow-up and
     gets the follow-up prompt (plain prose) and the earlier exchanges replayed. */
  function buildPrompt(opts) {
    const prompts = root.PAAPrompts || {};
    const turns = opts.turns || [];
    const first = turns.length ? turns[0].q : opts.question;
    const content = [
      { type: 'text', text: firstUserText(opts.info, opts.kind, first, opts.cropSize) },
      imageBlock(opts.images[0]),
      imageBlock(opts.images[1]),
    ];
    const messages = [{ role: 'user', content: content }];
    turns.forEach(function (t, i) {
      messages.push({ role: 'assistant', content: t.a || '(no answer)' }); // the API refuses an empty text block
      messages.push({ role: 'user', content: i + 1 < turns.length ? turns[i + 1].q : opts.question });
    });
    return {
      system: [{ type: 'text', text: turns.length ? prompts.followup : prompts.ask, cache_control: { type: 'ephemeral' } }],
      messages: messages,
    };
  }

  /* The first answer as the plain text a follow-up replays as "the assistant's earlier reply". */
  function cardText(a) {
    a = a || {};
    return [a.say, a.orig && 'Text: ' + a.orig, a.note].filter(Boolean).join('\n');
  }

  /* The address that opens the place a mark was asked at: the saved one, except where it has no camera values. In South Korea the address carries only the
     panorama id, and Maps opens it looking straight down with 15 degrees of field of view (a smear of road). There the same panorama is opened through the
     documented link form with the heading, pitch and field of view the mark was asked with. */
  function goUrl(rec) {
    const v = (rec && rec.view) || {};
    const url = v.url || null;
    if (!url || !/\/@\/data=/.test(url)) return url; // only the form with no camera values ("/@/data=...") is rewritten; anything else as saved
    if (!rec.pano || !rec.pano.id || typeof v.heading !== 'number' || typeof v.pitch !== 'number' || typeof v.fov !== 'number') return url;
    const clamp = function (x, lo, hi) { return Math.max(lo, Math.min(hi, x)); };
    return 'https://www.google.com/maps/@?api=1&map_action=pano&pano=' + encodeURIComponent(rec.pano.id) + '&heading=' + round(((v.heading % 360) + 360) % 360, 1) +
      '&pitch=' + round(clamp(v.pitch, -90, 90), 1) + '&fov=' + round(clamp(v.fov, 10, 100), 1);
  }

  /* One notebook row for a saved record: what the dock's notebook lists (thumbnail, SAY, a second line, age). */
  function rowOf(rec) {
    const a = rec.a || {};
    const first = (a.lines || []).find(function (l) { return l && l.o; });
    const nfu = (rec.fu || []).length;
    const sub = nfu
      ? nfu + (nfu === 1 ? ' follow-up' : ' follow-ups')
      : String(a.orig || (first && first.o) || a.note || '').replace(/\s+/g, ' ').trim();
    return {
      id: rec.id,
      pano: rec.pano ? rec.pano.id : null,
      lat: rec.pano && typeof rec.pano.lat === 'number' ? rec.pano.lat : null,
      lng: rec.pano && typeof rec.pano.lng === 'number' ? rec.pano.lng : null,
      t: rec.createdAt,
      say: clip(a.say || a.note || '', 140),
      sub: clip(sub, 70),
      thumb: rec.thumb || null,
      url: goUrl(rec),
      fu: nfu,
    };
  }

  /* The request body of a Messages call. Nothing about thinking or effort is sent: Haiku 5.5 thinks adaptively by default and that default is kept (thinking off
     invents readings, research/format/NOTES.txt). No sampling parameters either: any of them is a 400 on this model. prompt: { system, messages } from buildPrompt
     (or the same shape for the repaint's read-backs). The SDK adds stream: true when the call is made with messages.stream(). */
  function buildRequestBody(model, prompt) {
    return {
      model: model || DEFAULT_MODEL,
      max_tokens: MAX_TOKENS,
      system: prompt.system,
      messages: prompt.messages,
    };
  }

  /* What a call cost, in dollars, from the usage block: fresh input, cache writes, cache reads and output (thinking included). null when the model has no price here. */
  /* Has a key's end date passed? iso is "YYYY-MM-DD" (the day it stops working); true from the day after, in the viewer's own time. now: a Date (tests). */
  function keyEnded(iso, now) {
    const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso || '');
    if (!m) return false;
    return (now || new Date()).getTime() >= new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]) + 1).getTime();
  }

  function costOf(model, usage) {
    const p = PRICES[model];
    if (!p || !usage) return null;
    const inp = usage.input_tokens || 0;
    const w = usage.cache_creation_input_tokens || 0;
    const r = usage.cache_read_input_tokens || 0;
    const out = usage.output_tokens || 0;
    const big = inp + w + r > p.bigAbove;
    const pin = big ? p.bigInUsd : p.inUsd;
    const pout = big ? p.bigOutUsd : p.outUsd;
    const usd = (inp * pin + w * pin * CACHE_WRITE + r * pin * CACHE_READ + out * pout) / 1e6;
    return Math.round(usd * 1e7) / 1e7;
  }

  const PAA = {
    DEFAULT_MODEL: DEFAULT_MODEL,
    DEFAULT_QUESTION: DEFAULT_QUESTION,
    MAX_TOKENS: MAX_TOKENS,
    PRICES: PRICES,
    CACHE_WRITE: CACHE_WRITE,
    CACHE_READ: CACHE_READ,
    clip: clip,
    parseLocation: parseLocation,
    buildContextText: buildContextText,
    firstUserText: firstUserText,
    imageBlock: imageBlock,
    buildPrompt: buildPrompt,
    cardText: cardText,
    rowOf: rowOf,
    goUrl: goUrl,
    buildRequestBody: buildRequestBody,
    costOf: costOf,
    keyEnded: keyEnded,
  };
  root.PAA = PAA;
  if (typeof module !== 'undefined' && module.exports) module.exports = PAA;
})(typeof self !== 'undefined' ? self : globalThis);
