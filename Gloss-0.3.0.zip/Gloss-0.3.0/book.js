/* Gloss: the notebook. Opens under the dock. Sections: Here (marks on this panorama, live), Nearby (saved marks within
   150 m that are not on this panorama, nearest first, with "80 m east"; it stays hidden when there are none) and Recent (the
   latest 20 from anywhere). Each row: thumbnail, SAY, a second line, age. Footer: Labels / Dots / Off and Settings.
   A Here row opens that mark's card (flow J: with an arrow chip at the screen edge when the mark is off screen); a Nearby row does the
   same when the mark is drawn from here (a soft anchor, far.js) and opens the saved address when it is not; a Recent row opens the saved address. */
(function () {
  'use strict';
  const PAA = self.PAA;
  const P = self.PAAPose;

  const RECENT_MAX = 20;
  const NEARBY_M = 150;
  const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

  let open = false;
  let bookEl = null, rowsEl = null;
  let recent = [], nearby = [];
  let fetchSeq = 0;

  const el = (tag, cls, text) => {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== undefined) e.textContent = text;
    return e;
  };

  /* now, 2 m, 3 h, Tue, 12 Nov */
  function ageText(t, now) {
    const s = Math.max(0, ((now || Date.now()) - t) / 1000);
    if (s < 60) return 'now';
    if (s < 3600) return Math.floor(s / 60) + ' m';
    if (s < 86400) return Math.floor(s / 3600) + ' h';
    const d = new Date(t);
    if (s < 6 * 86400) return DAYS[d.getDay()];
    return d.getDate() + ' ' + MONTHS[d.getMonth()];
  }

  /* the marks that belong to what is on screen now, newest first */
  function hereMarks() {
    const pid = PAA.layer.lastPano();
    return PAA.layer.all()
      .filter((m) => m.state === 'done' && !m.retired && !m.dead && !m.far && (m.dirArr ? !!m.rec.pano && m.rec.pano.id === pid : true))
      .sort((a, b) => b.rec.createdAt - a.rec.createdAt);
  }

  function rowEl(r, onClick, ageNow) {
    const d = el('div', 'row');
    const th = el('div', r.thumb ? 'th' : 'th none');
    if (r.thumb) th.style.backgroundImage = 'url("' + r.thumb + '")';
    const t = el('div', 't');
    t.appendChild(el('b', '', r.say || 'Saved note'));
    t.appendChild(el('span', '', r.sub || ''));
    d.append(th, t, el('em', '', r.age != null ? r.age : ageText(r.t, ageNow)));
    d.addEventListener('click', (e) => { e.stopPropagation(); onClick(d); });
    return d;
  }

  function seg() {
    const s = el('span', 'seg');
    [['labels', 'Labels'], ['dots', 'Dots'], ['off', 'Off']].forEach((x) => {
      const b = el('b', PAA.prefs.density === x[0] ? 'on' : '', x[1]);
      b.dataset.density = x[0];
      b.addEventListener('click', (e) => { e.stopPropagation(); PAA.prefs.setDensity(x[0]); });
      s.appendChild(b);
    });
    return s;
  }

  function render() {
    if (!open || !bookEl) return;
    const keep = rowsEl ? rowsEl.scrollTop : 0;
    bookEl.textContent = '';
    PAA.layer.glass(bookEl);
    rowsEl = el('div', 'rows');
    const now = Date.now();
    const here = hereMarks();
    const hereIds = new Set(here.map((m) => m.id));
    const section = (title) => rowsEl.appendChild(el('h4', '', title));
    if (here.length) {
      section('Here');
      here.forEach((m) => rowsEl.appendChild(rowEl(PAA.rowOf(m.rec), () => goHere(m), now)));
    }
    const near = nearby.filter((r) => !hereIds.has(r.id));
    if (near.length) {
      section('Nearby');
      near.forEach((r) => rowsEl.appendChild(rowEl(r, (row) => goNearby(r, row), now)));
    }
    const nearIds = new Set(near.map((r) => r.id));
    const rec = recent.filter((r) => !hereIds.has(r.id) && !nearIds.has(r.id)).slice(0, RECENT_MAX); // a note is listed once: under Here, else Nearby, else Recent
    if (rec.length) {
      section('Recent');
      rec.forEach((r) => rowsEl.appendChild(rowEl(r, (row) => goTo(r, () => holdRow(row)), now)));
    }
    if (!here.length && !near.length && !rec.length) rowsEl.appendChild(el('div', 'empty', 'Nothing saved yet. Hold ⌥ and drag over anything, and the answer stays here.'));
    const foot = el('div', 'foot');
    const gear = el('span', 'gear', 'Settings');
    gear.addEventListener('click', (e) => {
      e.stopPropagation();
      try { chrome.runtime.sendMessage({ type: 'openOptions' }); } catch (err) { /* extension gone */ }
    });
    foot.append(seg(), gear);
    bookEl.append(rowsEl, foot);
    rowsEl.scrollTop = keep;
  }

  /* Recent and Nearby come from the store; fetched each time the notebook opens (the service worker keeps nothing) */
  async function fetchRows() {
    const seq = ++fetchSeq;
    const pose = P.getPose();
    try {
      const [rec, near] = await Promise.all([
        PAA.store.recent(RECENT_MAX + 4),
        PAA.store.nearby({ pano: pose.panoId, lat: pose.lat, lng: pose.lng, radius: NEARBY_M }),
      ]);
      if (seq !== fetchSeq) return;
      recent = rec;
      nearby = near;
    } catch (e) {
      if (seq !== fetchSeq) return;
      recent = [];
      nearby = [];
    }
    render();
    PAA.layer.requestLayout(0); // it has grown with its rows: a caption now under it is hidden (layer.layout)
  }

  function openBook() {
    if (open) return;
    const box = PAA.dock.box();
    if (!box) return;
    open = true;
    PAA.dock.hideHint();
    bookEl = el('div', 'book');
    box.appendChild(bookEl);
    PAA.layer.sunOn(bookEl);
    PAA.layer.flash(bookEl);
    render();
    fetchRows();
    PAA.dock.refresh();
    PAA.layer.requestLayout(0); // an open card keeps off the notebook
  }

  function closeBook() {
    if (!open) return;
    open = false;
    fetchSeq++;
    if (bookEl) { PAA.layer.sunOff(bookEl); if (self.PAAGlass) PAAGlass.forget(bookEl); bookEl.remove(); }
    bookEl = null;
    rowsEl = null;
    PAA.dock.refresh();
    PAA.layer.requestLayout(0);
  }

  /* is this mark inside the picture right now? */
  function inView(m) {
    const d = m.centerDir();
    if (!d) return true; // screen-fixed
    const p = P.dirToScreen(d.yaw, d.pitch);
    const pose = P.getPose();
    const cr = pose.canvasRect;
    if (!p || p.behind || !cr) return false;
    return p.x > cr.x + 24 && p.x < cr.x + cr.width - 24 && p.y > cr.y + 24 && p.y < cr.y + cr.height - 24;
  }

  function goHere(m) {
    closeBook();
    if (PAA.prefs.density === 'off') PAA.prefs.setDensity('labels'); // he asked to see it
    PAA.layer.trackNow();
    if (inView(m)) PAA.app.openMark(m);
    else PAA.finder.point(m);
  }

  /* A Nearby row: if the mark is drawn from here (a soft anchor), the arrow chip shows the way to it and its card opens when it is in view;
     otherwise (no world point, too far, out of the 120 m, another kind of panorama) the saved address opens. */
  function goNearby(r, row) {
    const m = PAA.layer.get(r.id);
    if (m && m.far && !m.dead && P.getPose().panoId === m.far.at) {
      closeBook();
      if (PAA.prefs.density === 'off') PAA.prefs.setDensity('labels');
      PAA.layer.trackNow();
      if (inView(m)) PAA.app.openMark(m);
      else PAA.finder.point(m);
    } else goTo(r, () => holdRow(row));
  }

  /* An answer that is still being written (a new ask, a follow-up) is lost when the page is left: it is only saved when it is finished. So the jump to a
     saved address waits for every unfinished answer (at most HOLD_MAX_MS), after telling the caller once (onHold) so the button or row can say so. A repaint takes
     25 to 100 s, so it is not waited for: it is cancelled at once (its image call has most likely not returned, so little or nothing is spent). A second press on a
     row while one is waiting leaves at once, but only after HOLD_OVERRIDE_MS (a double click is not a decision to lose the answer). */
  const HOLD_MAX_MS = 40000;
  const HOLD_OVERRIDE_MS = 1500;
  let holding = 0;
  let holdSince = 0;
  const unfinished = () => PAA.layer.all().some((m) => m.busy && !m.dead);

  function holdRow(row) {
    const em = row && row.querySelector('em');
    if (em) em.textContent = 'finishing…';
  }

  /* the saved address: the page loads there and the marks come back by themselves; the card opens on arrival */
  function goTo(r, onHold) {
    if (!r.url) return;
    if (holding) { // a second press while it waits: ignored at first (a double click), a decision to leave after a moment
      if (Date.now() - holdSince < HOLD_OVERRIDE_MS) return;
      clearInterval(holding); holding = 0; return leave(r);
    }
    if (PAA.patch) PAA.layer.all().forEach((m) => { if (!m.dead && PAA.patch.working(m)) PAA.patch.cancel(m); });
    if (!unfinished()) return leave(r);
    if (onHold) onHold();
    const t0 = Date.now();
    holdSince = t0;
    holding = setInterval(() => {
      if (unfinished() && Date.now() - t0 < HOLD_MAX_MS) return;
      clearInterval(holding);
      holding = 0;
      leave(r);
    }, 150);
  }

  function leave(r) {
    try { sessionStorage.setItem('paaOpen', r.id); } catch (e) { /* private mode */ }
    closeBook();
    location.href = r.url;
  }

  PAA.book = {
    isOpen: () => open,
    open: openBook,
    close: closeBook,
    toggle: () => (open ? closeBook() : openBook()),
    refresh: render,
    hereMarks: hereMarks,
    inView: inView,
    goTo: goTo,
    holding: () => !!holding,
    ageText: ageText,
    el: () => bookEl,
    rect: () => { if (!open || !bookEl) return null; const r = bookEl.getBoundingClientRect(); return r.width && r.height ? { x: r.left, y: r.top, w: r.width, h: r.height } : null; }, // where it is on screen (a layout read: call it with the other reads)
  };
})();
