/* Gloss: the panorama metadata the Maps page loads for itself, kept for the last few panoramas. Isolated world.

   capture-main.js (MAIN world, document_start) hands the raw text of every photometa response to this file as a DOM event; the text is
   parsed once by world.js (PAAWorld.parseMeta: position, elevation, capture heading, depth map, nearby panoramas) and only the parsed
   result is kept, for the last KEEP panoramas (about 4 MB: the depth map is 128 KB each). The raw text is dropped at once.
   No request of ours is needed in the normal case: the page asks for every panorama it shows.

   The one exception: the page's response was missed (the extension was reloaded under an open tab, or Maps loaded the panorama
   from its own cache). need(id) then makes the page's own single same-origin request, ONCE per panorama id for the life of the page, and
   only when something asks for it (an ask, a saved mark to place, a saved mark nearby): never ahead of need, never in a loop. */
(function () {
  'use strict';
  const PAA = self.PAA;
  const W = self.PAAWorld;

  const KEEP = 30;
  const FETCH_MS = 5000; // the one request is given up after this long
const WAIT_MS = 2500; // need() lets the page's own response arrive for this long before it makes the one request itself

  const cache = new Map(); // panoId -> parsed metadata; the most recently stored is last
  const asked = new Set(); // ids for which the fallback request was made (once each)
  const pending = new Map(); // id -> the need() in progress
  const listeners = new Set();
  const stats = { events: 0, parsed: 0, junk: 0, fetches: 0, fetchFailed: 0, parseMs: 0, maxParseMs: 0, bytes: 0 };

  function put(meta) {
    cache.delete(meta.panoId);
    cache.set(meta.panoId, meta);
    while (cache.size > KEEP) cache.delete(cache.keys().next().value);
    listeners.forEach((fn) => {
      try { fn(meta); } catch (e) { console.warn('[PAA] meta listener', e); }
    });
  }

  function ingest(text, how) {
    const t0 = performance.now();
    const meta = W.parseMeta(text);
    const ms = performance.now() - t0;
    stats.parseMs += ms;
    if (ms > stats.maxParseMs) stats.maxParseMs = ms;
    stats.bytes += text.length;
    if (!meta || typeof meta.lat !== 'number' || typeof meta.lng !== 'number') { stats.junk++; return null; }
    meta.via = how;
    stats.parsed++;
    put(meta);
    return meta;
  }

  /* The parse (5 to 7 ms) runs after the page's own handler has returned, not inside it: it must not cost the flight animation a frame.
     need() does not care: it waits for the metadata anyway. */
  document.addEventListener('paa:photometa', (ev) => {
    const text = ev.detail;
    if (typeof text !== 'string') return;
    stats.events++;
    setTimeout(() => ingest(text, 'page'), 0);
  });

  /* The page's own single request for one panorama, from the page's own origin. Once per id, never again. */
  async function fallback(id, type) {
    if (asked.has(id)) return cache.get(id) || null;
    asked.add(id);
    stats.fetches++;
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), FETCH_MS); // a stalled request must not leave need() waiting for ever
    try {
      // from the page's own origin: the content scripts also run on regional hosts (google.com.au, google.co.jp ...), where www.google.com is cross-origin
      const res = await fetch(W.metaUrl(id, type === 10 ? 10 : 2, undefined, undefined, location.origin), { credentials: 'include', signal: ctl.signal });
      if (!res.ok) { stats.fetchFailed++; return null; }
      const meta = ingest(await res.text(), 'fetch');
      return meta && meta.panoId === id ? meta : cache.get(id) || null;
    } catch (e) {
      stats.fetchFailed++;
      return null;
    } finally {
      clearTimeout(timer);
    }
  }

  /* The metadata of a panorama, or null. Resolves at once when it is held; otherwise waits WAIT_MS for the page's own response and then
     makes the one request. type: 2 official (default), 10 user photo sphere. Several callers share one wait. */
  function need(id, type) {
    if (!id) return Promise.resolve(null);
    const have = cache.get(id);
    if (have) return Promise.resolve(have);
    const going = pending.get(id);
    if (going) return going;
    const p = new Promise((resolve) => {
      let done = false;
      let timer = 0;
      const finish = (m) => {
        if (done) return;
        done = true;
        clearTimeout(timer);
        listeners.delete(onMeta);
        pending.delete(id);
        resolve(m || cache.get(id) || null);
      };
      const onMeta = (m) => { if (m.panoId === id) finish(m); };
      listeners.add(onMeta);
      timer = setTimeout(() => fallback(id, type).then(finish, () => finish(null)), WAIT_MS);
    });
    pending.set(id, p);
    return p;
  }

  PAA.meta = {
    get: (id) => cache.get(id) || null,
    need: need,
    /* fn(meta) whenever metadata arrives (from the page or from our one request); returns an unsubscribe function */
    onMeta(fn) { listeners.add(fn); return () => listeners.delete(fn); },
    ids: () => Array.from(cache.keys()),
    size: () => cache.size,
    stats: stats,
    ingest: ingest, // for tests
    forget: (id) => cache.delete(id), // for tests: as if the page's own response had been missed
    KEEP: KEEP,
  };

  // where the address carries no camera values the pose module calibrates itself from this metadata (pose.js, calibrateFromMeta)
  if (self.PAAPose) {
    self.PAAPose.setMetaSource({ get: PAA.meta.get, need: need });
    listeners.add((m) => self.PAAPose.metaArrived(m));
  }
})();
