/* Gloss: the shared keys built into this copy. Loaded by the service worker only (importScripts), never by a page or a content script.
   They are stored turned round and base64-encoded so that tools which scan files for keys in plain text do not match them. That is NOT protection:
   anyone who has this file can read them. Both keys are limited and stop working on the date below. A person can put their own keys in Settings.
   This file is gitignored. Never print its values (not in logs, tests, error messages or notes): check them by length only (anthropic 106, openrouter 73). */
self.PAA_BUNDLED_KEYS = (() => {
  const d = (s) => atob(s).split("").reverse().join("");
  return {
    anthropic: d("QUFRUDlxSkF3dkJ0ZFZjb0t1aEVqaUtwX0tRMEFIRWRtZGhtRnA2NkM1dHU5Tnpyek9HSDFxdjZmRWpVaTNzTjdZQndWalBtOHhXUlpCd0E2S2ZaX3FHbGJlOV9aRDEtcnN1LXRuYS1rcw=="),      // reading: every text and vision call (Claude Haiku 5.5, straight to the Anthropic API)
    openrouter: d("ZTc1NWIyYjUzZjU0MDcwZGM5NWUwMTA1ZDZmY2NmNjZhNGE0ZTdmNWY4MjY4YWE5YzdhNzAwZjRmYmIxYzllMi0xdi1yby1rcw=="),     // painting only: the image model for Repaint
    expires: "2026-12-14",          // both keys end on this day (the OpenRouter one at 09:15 UTC)
    openrouterLimitUsd: 20,
  };
})();
