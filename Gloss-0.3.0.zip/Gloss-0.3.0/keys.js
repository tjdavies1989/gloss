/* Gloss: keyboard shielding and the Esc rules.
   Key events typed in a card's field are retargeted to our host element (the shadow root is closed), so to the
   page they look like keys pressed on the document. Google Maps listens for shortcuts in the CAPTURE phase on
   window/document, which runs before anything inside our layer: a listener in the card would be too late
   ('.', '!', '?' stole focus to Maps' search box). We run at document_start, so our window capture listeners
   come first: for events from our layer they stop every other listener (stopImmediatePropagation) but never
   preventDefault, so typing, paste, selection, arrows and IME still work in the field. Because the event then
   never reaches the field's own listeners, Enter-to-send and Esc are handled here.

   Esc: mid-drag it cancels the drawing; with a menu, a card or the notebook open it closes that and is swallowed; otherwise it
   goes to Maps untouched (Esc in Street View exits it). After one of our own Esc actions, an Esc that would now go to Maps is
   swallowed for 700 ms instead, so a double press does not throw him out of Street View (an Esc that still has something of ours
   to close, a menu and then its card, is not held up). */
(function () {
  'use strict';
  const PAA = self.PAA;

  const ESC_QUIET = 700; // ms
  let escUntil = 0;

  function block(e) {
    e.preventDefault();
    e.stopImmediatePropagation();
  }

  const ownEsc = (e) => { // one of our own Esc actions: swallow the press, and for 700 ms an Esc that would otherwise reach Maps
    block(e);
    escUntil = performance.now() + ESC_QUIET;
  };

  function onKey(e) {
    if (!e.isTrusted) return; // synthetic events are the page's own business
    const ours = PAA.layer.inOurs(e);
    if (e.type === 'keydown' && e.key === 'Escape' && !(ours && e.isComposing)) {
      if (PAA.gesture.active()) {
        ownEsc(e);
        PAA.gesture.cancel(true); // the button is still down; swallow its release
        return;
      }
      const m = PAA.app.openCard();
      if (m) {
        ownEsc(e);
        PAA.app.escape(m);
        return;
      }
      if (PAA.book.isOpen()) { // the notebook: Esc closes it
        ownEsc(e);
        PAA.book.close();
        return;
      }
      if (performance.now() < escUntil) { // nothing of ours left to close, but one of our Esc actions was just done: not this one
        block(e);
        return;
      }
      if (PAA.finder.active()) PAA.finder.clear(); // the arrow chip goes too, and Esc still reaches Maps
    }
    if (e.type === 'keyup' && e.key === 'Escape' && performance.now() < escUntil) block(e); // the release of a swallowed press
    if (!ours) return;
    e.stopImmediatePropagation();
    if (e.type === 'keydown' && e.key === 'Enter' && !e.shiftKey && !e.isComposing && e.keyCode !== 229) { // Enter that confirms an IME composition must not send
      const f = PAA.app.activeField(); // the compose field, or a card's follow-up field
      if (f) {
        e.preventDefault();
        f.submit();
      }
    }
  }

  PAA.keys = {
    init() {
      // keys, and the text-entry events that follow them (the page does not need to see what is typed in a card)
      ['keydown', 'keypress', 'keyup', 'beforeinput', 'input', 'textInput', 'compositionstart', 'compositionupdate',
       'compositionend', 'paste', 'copy', 'cut'].forEach((t) => window.addEventListener(t, onKey, { capture: true }));
    },
  };
})();
