/* Gloss: AI repaint (stage 4), the pure part. No DOM, no Chrome, no network: loaded by the page (what to repaint, what shape of picture), by the
   service worker (the instruction, the checks) and by the node tests, which run it on the repaint experiment's saved results.

   The idea (research/repaint/NOTES.txt): Haiku reads the sign and supplies the exact English; an image model only does the LETTERING; Haiku then
   reads the result back blind and the picture outside the text is compared with the original. A result that fails is never shown.

   What lives here:
     paintable / assess     which LINES entries may be painted, and which make the crop "cut off" (then it is not repainted: leftover old writing
                            beside new English is worse than nothing)
     buildInstruction       the lettering job, worded exactly as in the experiment (the unit test compares it with the experiment's saved prompts)
     pickRatio / planCrop   the picture sent for repainting must contain the whole sign with a margin AND have a shape the image model can output
     evaluate / explain     the read-back check (words, digits, nothing invented) and its reasons in plain words
     pixelCheck             the picture outside the text boxes did not change much (experiment: mean grey difference and colour drift)
   The model's boxes are HINTS only: never a mask. */
(function (root) {
  'use strict';

  const IMAGE_MODEL = 'openai/gpt-image-2.6-sunburst'; // measured best of four (experiment): good in 5 of 6 cases, 28 s, about 4 cents
  const QUALITY = 'medium';
  /* the shapes the image model can output (GET /api/v1/images/models, 14 Nov: aspect_ratio enum) */
  const RATIOS = [['1:1', 1], ['3:2', 3 / 2], ['2:3', 2 / 3], ['4:3', 4 / 3], ['3:4', 3 / 4], ['16:9', 16 / 9], ['9:16', 9 / 16], ['21:9', 21 / 9]];
  const SHAPE_TOL = 0.03; // a stored crop is used as it is only when its shape is within 3 % of one of those (the experiment's crops matched exactly)
  const EDGE_MARGIN = 0.03; // a line of writing whose box comes closer than this (of the short side) to the picture's edge is cut off
  const INPUT_MAX = 1536; // long side of the picture sent to the image model (it outputs about this size; a bigger one only slows it)
  const INPUT_MIN = 768; // a fresh picture smaller than this on its long side is enlarged to it (at most 4 times): the model draws at its own size from what it is given
  const WORK = 128; // long side of the pictures the pixel check compares
  const GROW = 0.35; // the text boxes are grown by this before the pixel check leaves them out (as in the experiment)
  const MAD_MAX = 15; // mean grey difference outside the text, 0 to 255 (experiment: good results 2.6 to 13.7, the one that changed the board's colours 18.3)
  const COL_MAX = 8.4; // mean colour drift outside the text (good results 0.5 to 8.0; changed colours 8.6 to 20)
  const BLOB_MAX = 20; // the largest mean grey difference of any window of a fifth of the picture's long side, outside the text (good saved results 2 to 12, a rejected one 27; a live result that painted a pale block over the wall: 50 and more)
  const INSIDE_MIN = 6; // the mean grey difference INSIDE the text boxes must be at least this, and ... (saved good results 11.4 to 44; the scene given back unchanged is about as different there as anywhere)
  const INSIDE_GAIN = 1.5; // ... this much more than outside them (the 12 saved results, good or not: 2.2 to 36 more)
  const FRAME_TOL = 0.04; // the result's shape against the picture's: more than 4 % off means it was re-framed

  const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));

  /* ---------------------------------------------------------------- text */
  function normalise(s) {
    return String(s || '')
      .normalize('NFKD').replace(/[̀-ͯ]/g, '').normalize('NFKC').toLowerCase()
      .replace(/[‘’]/g, "'").replace(/[“”]/g, '"')
      .replace(/[^\p{L}\p{N}]+/gu, ' ').trim().replace(/\s+/g, ' ');
  }

  const NON_LATIN = /[\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}\p{Script=Hangul}\p{Script=Cyrillic}\p{Script=Greek}\p{Script=Arabic}\p{Script=Hebrew}\p{Script=Thai}\p{Script=Devanagari}]/u;
  const GAP = /(…|\.\.\.|\[hidden\]|\?\?)/;

  /* The text to paint. The model often adds a gloss, "Tanima (shop name)": the image model paints everything it is given, so brackets are removed
     unless the original itself has brackets. */
  function paintText(e) {
    let t = String(e.t || '');
    if (!/[(（]/.test(e.o || '')) t = t.replace(/\s*[(（][^)）]*[)）]/g, '');
    t = t.replace(/\s+/g, ' ').trim();
    return t || String(e.t || '').trim();
  }

  /* Lines worth painting (the experiment's rule, unchanged). Dropped: no translation; translation equals the original; the original has no non-Latin
     letters (digits, phone numbers, URLs, English: nothing to translate, and repainting them only risks changing them); a gap or a guess in it ("..."
     or an ellipsis: the model would paint the gap); and, with hints.edgeMargin, a piece whose box touches the picture's edge (cut off). */
  function paintable(lines, hints) {
    hints = hints || {};
    const W = hints.width, H = hints.height;
    const m = hints.edgeMargin && W && H ? hints.edgeMargin * Math.min(W, H) : 0;
    const inside = (b) => !m || (b[0] >= m && b[1] >= m && b[2] <= W - m && b[3] <= H - m);
    return (lines || []).filter((e) => inside(e.b)).map((e) => ({ b: e.b, o: e.o, t: paintText(e) }))
      .filter((e) => e.t && normalise(e.t) !== normalise(e.o) && NON_LATIN.test(e.o || '') && !GAP.test(e.o + ' ' + e.t));
  }

  /* What a mark's LINES come to for repainting: { paint: [{i, b, o, t}], cut: [{i, why}], left: n }.
     Every line in another script that would have to be painted but cannot be makes the picture "cut off" (cut): its old writing would stay beside the
     new English, so the caller refuses rather than repaints badly. Lines that need no repainting (already Latin, nothing to translate) are just left.
     lines carry b (the box in the pixels of a picture w x h; null: no box, painted without a position hint), optional spill (the model's box ran off the
     picture it saw, so its text was cut off then); opts.edgeMargin (of the short side). */
  function assess(lines, w, h, opts) {
    opts = opts || {};
    const m = (opts.edgeMargin == null ? EDGE_MARGIN : opts.edgeMargin) * Math.min(w, h);
    const paint = [], cut = [];
    let left = 0;
    (lines || []).forEach((e, i) => {
      const o = e.o || '';
      const t = paintText(e);
      if (!t || !NON_LATIN.test(o) || normalise(t) === normalise(o)) { left++; return; }
      if (GAP.test(o + ' ' + t)) { cut.push({ i: i, why: 'fragment' }); return; }
      if (e.spill) { cut.push({ i: i, why: 'spill' }); return; }
      const b = Array.isArray(e.b) && e.b.length === 4 && e.b.every(Number.isFinite) ? e.b : null;
      if (b && (b[0] < m || b[1] < m || b[2] > w - m || b[3] > h - m)) { cut.push({ i: i, why: 'edge' }); return; }
      paint.push({ i: i, b: b, o: o, t: t });
    });
    return { paint: paint, cut: cut, left: left };
  }

  /* ---------------------------------------------------------------- the instruction */
  function place(b, W, H) {
    const cx = (b[0] + b[2]) / 2 / W, cy = (b[1] + b[3]) / 2 / H;
    const h = cx < 0.34 ? 'left' : cx > 0.66 ? 'right' : 'centre';
    const v = cy < 0.34 ? 'upper' : cy > 0.66 ? 'lower' : 'middle';
    return v + ' ' + h;
  }
  const pct = (v, n) => Math.round((v / n) * 100) + '%';

  /* lines: [{b,o,t}]. hints: { width, height (of the picture sent), keep: [texts that must stay], unreadable: 'short note', firm, problems: [reasons from a
     failed check], noBoxes }. The wording is the experiment's (sun-med): the unit test holds it to the saved prompts. */
  function buildInstruction(lines, hints) {
    hints = hints || {};
    lines = paintable(lines, hints);
    const W = hints.width || 0, H = hints.height || 0;
    const L = [];
    L.push('This is a photo of a real street scene. Do a LETTERING JOB ONLY: replace the written text listed below with the exact English given, and change nothing else in the picture.');
    L.push('');
    if (hints.noBoxes) L.push('Text to replace (' + lines.length + ' piece' + (lines.length > 1 ? 's' : '') + '); find each piece by what it says now:');
    else L.push('Text to replace (' + lines.length + ' piece' + (lines.length > 1 ? 's' : '') + '). Boxes are approximate hints, [left, top, right, bottom]' + (W ? ' in pixels of this ' + W + 'x' + H + ' image' : '') + '; find each piece by what it says now:');
    lines.forEach((e, i) => {
      let where = '';
      if (!hints.noBoxes && Array.isArray(e.b)) {
        const b = e.b.map(Math.round);
        where = 'Box [' + b.join(', ') + ']';
        if (W && H) where += ', ' + place(b, W, H) + ' of the image, from ' + pct(b[0], W) + ' to ' + pct(b[2], W) + ' across and ' + pct(b[1], H) + ' to ' + pct(b[3], H) + ' down';
        where += '. ';
      }
      L.push((i + 1) + '. ' + where + 'Now reads: "' + (e.o || '(original text)') + '". Paint exactly: "' + e.t + '"');
    });
    L.push('');
    L.push('Rules:');
    L.push('- Paint each piece of English exactly as spelled between the quotation marks: same letters, same digits, same punctuation, nothing added, nothing missing. Do not correct, complete or embellish it.');
    L.push('- First remove the old lettering cleanly (restore the sign surface behind it), then letter the English in the same style as the original: same kind of font, weight, colour, outline, shadow, slant, perspective, wear, blur and lighting, so it looks painted by the same sign-maker. Keep it where the old lettering was. If the English is longer or shorter, change the letter size or wrap to fit; do not resize the sign.');
    L.push('- Everything else stays exactly as in the input, pixel for pixel: the sign itself, its frame and background, all objects, people, other signs, sky, colours, grain, blur, framing and aspect ratio.');
    L.push('- Any other text (including text already in English or Latin letters, numbers, phone numbers, tiny text, blurred text, or text not listed above) must stay exactly as it is. Do not invent, translate, sharpen or "fix" it.');
    if (hints.keep && hints.keep.length) L.push('- These existing texts must stay exactly as they are: ' + hints.keep.map((s) => '"' + s + '"').join(', ') + '.');
    if (hints.unreadable) L.push('- Leave alone (cannot be read): ' + hints.unreadable + '.');
    if (hints.firm) {
      L.push('');
      L.push('STRICT RETRY. A previous attempt failed the check' + (hints.problems && hints.problems.length ? ': ' + hints.problems.join('; ') : '') + '. Spell every listed English text letter by letter exactly as given, and do not touch anything outside the listed boxes. If you cannot letter a piece exactly, leave that piece as it was rather than guessing.');
    }
    L.push('');
    L.push('Return the full edited image at the same framing.');
    return L.join('\n');
  }

  /* ---------------------------------------------------------------- the shape of the picture */
  /* the output shape closest to w / h: { name: '3:2', ratio: 1.5, off: how far w / h is from it (0.02 = 2 %) } */
  function pickRatio(w, h) {
    const ar = w / h;
    let best = null;
    RATIOS.forEach((r) => {
      const off = Math.abs(ar / r[1] - 1);
      if (!best || off < best.off) best = { name: r[0], ratio: r[1], off: off };
    });
    return best;
  }

  /* The picture to repaint, in screen pixels: it must contain content (the sign: the mark's rectangle and its lines of writing, {x, y, w, h}) with a margin,
     have exactly one of the shapes above, and lie inside the picture rectangle vr. Tries a roomy margin first, then tighter ones. Returns
     { x, y, w, h, ratio: '3:2', margin } or { refuse: 'edge' | 'big' | 'small' } (edge: the sign runs off the picture; big: no room for it with a margin;
     small: it is too small on screen to repaint, zoom in). */
  function planCrop(content, vr, opts) {
    opts = opts || {};
    const c = content;
    const eps = 2; // px
    if (!(c.w > 0 && c.h > 0)) return { refuse: 'small' };
    if (c.x < vr.x + eps || c.y < vr.y + eps || c.x + c.w > vr.x + vr.w - eps || c.y + c.h > vr.y + vr.h - eps) return { refuse: 'edge' };
    if (Math.max(c.w, c.h) < (opts.minContent || 40)) return { refuse: 'small' };
    const margins = opts.margins || [0.16, 0.11, 0.07, 0.04];
    const clear = Math.max(2, 0.02 * Math.min(c.w, c.h)); // the content stays this far from the new edge
    const avoid = opts.avoid || []; // Google's own buttons and cards drawn over the picture: a crop that includes one would carry a frozen copy of it
    const hits = (r, a) => r.x < a.x + a.w && r.x + r.w > a.x && r.y < a.y + a.h && r.y + r.h > a.y;
    let blocked = false;
    for (let k = 0; k < margins.length; k++) {
      const g = margins[k] * (c.w + c.h) / 2;
      const gx = c.x - g, gy = c.y - g, gw = c.w + 2 * g, gh = c.h + 2 * g;
      const r = pickRatio(gw, gh);
      let w = gw, h = gh;
      if (gw / gh < r.ratio) w = gh * r.ratio; else h = gw / r.ratio; // grow the short side to the shape
      if (w > vr.w || h > vr.h) continue;
      let x = gx + gw / 2 - w / 2, y = gy + gh / 2 - h / 2;
      x = clamp(x, vr.x, vr.x + vr.w - w); // slide it back inside the picture
      y = clamp(y, vr.y, vr.y + vr.h - h);
      if (c.x < x + clear || c.y < y + clear || c.x + c.w > x + w - clear || c.y + c.h > y + h - clear) continue; // sliding cost the margin
      if (Math.min(w, h) < (opts.minSide || 56)) return { refuse: 'small' };
      if (avoid.some((a) => hits({ x: x, y: y, w: w, h: h }, a))) { blocked = true; continue; } // a tighter margin may clear it
      return { x: x, y: y, w: w, h: h, ratio: r.name, margin: margins[k] };
    }
    return { refuse: blocked ? 'controls' : 'big' };
  }

  /* the size a picture of w x h is sent at: its long side at most INPUT_MAX */
  function inputSize(w, h) {
    const k = Math.min(1, INPUT_MAX / Math.max(w, h));
    return [Math.max(1, Math.round(w * k)), Math.max(1, Math.round(h * k))];
  }

  /* the size a FRESH picture is cut at: reduced when over INPUT_MAX, enlarged (at most 4 times, same shape) when under INPUT_MIN */
  function sendSize(w, h) {
    const long = Math.max(w, h);
    const k = long > INPUT_MAX ? INPUT_MAX / long : long < INPUT_MIN ? Math.min(4, INPUT_MIN / long) : 1;
    return [Math.max(1, Math.round(w * k)), Math.max(1, Math.round(h * k))];
  }

  /* ---------------------------------------------------------------- the read-back check */
  function sim(a, b) { // 1 - edit distance / longer length
    const m = a.length, n = b.length;
    if (!m || !n) return 0;
    let prev = [];
    for (let j = 0; j <= n; j++) prev[j] = j;
    for (let i = 1; i <= m; i++) {
      const cur = [i];
      for (let j = 1; j <= n; j++) cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
      prev = cur;
    }
    return 1 - prev[n] / Math.max(m, n);
  }

  /* per intended line: 'exact' (a read piece equals it after normalising case and punctuation), 'joined' (found across neighbouring pieces: the reader
     split or merged lines differently), 'joined-loose', or 'none' */
  const LOOSE_MIN = 7; // letters: only a line this long may be found with the spaces left out, across other text
  function compare(lines, got) {
    const gotN = got.map(normalise).filter(Boolean);
    const joined = gotN.join(' ');
    const joinedC = joined.replace(/ /g, '');
    return lines.map((e) => {
      const want = normalise(e.t);
      let status = 'none';
      if (gotN.indexOf(want) >= 0) status = 'exact';
      else if (want && (' ' + joined + ' ').indexOf(' ' + want + ' ') >= 0) status = 'joined';
      else if (want && want.replace(/ /g, '').length >= LOOSE_MIN && joinedC.indexOf(want.replace(/ /g, '')) >= 0) status = 'joined-loose'; // (not for a short line: "bar" is inside "barber")
      return { want: e.t, status: status };
    });
  }

  /* The check on what was read back from the result. got: strings (null: the read-back could not be parsed). baselineTexts: the English / Latin text that
     was already on the ORIGINAL (read back the same way): expected to be there, so neither missing nor new. Rules (research/repaint/NOTES.txt): (1) every
     intended line is read back; (2) every digit run of 3+ on the original is still there and no new one has appeared; (3) no read piece of 6+ letters that
     resembles neither an intended line nor anything on the original (short fragments of blurred background text are read differently each time). */
  /* Street View's own watermark ("© 2023 Google") is on every picture, faint: the image model can sharpen it enough to be read back where the original's
     read-back missed it, and the reader sometimes mistakes it for something else ("© 2023 Getty Images"). It is not an invention and not a changed number:
     any piece with a copyright sign, Google or Getty in it, or a bare year, is left out of both read-backs. */
  const watermark = (s) => {
    const n = normalise(s);
    return /[©]|\(c\)/i.test(String(s)) || /\b(google|getty)\b/.test(n) || /^(19|20)\d\d$/.test(n);
  };

  function evaluate(lines, got, baselineTexts) {
    // (a piece that is, or is part of, a line that was asked for is never taken for the watermark: a sign that says "Since 1923" or "Google Store")
    const wanted = lines.map((e) => normalise(e.t)).filter(Boolean);
    const isWatermark = (s) => { const n = normalise(s); return watermark(s) && !(n && !/[©]|\(c\)/i.test(String(s)) && wanted.some((w) => (' ' + w + ' ').indexOf(' ' + n + ' ') >= 0)); };
    const base = (baselineTexts || []).filter((s) => !isWatermark(s));
    if (got) got = got.filter((s) => !isWatermark(s));
    if (!got) return { ok: false, wordsOk: false, digitsOk: false, noExtra: false, per: [], got: [], extra: [], missingDigits: [], newDigits: [] };
    const per = compare(lines, got);
    const wordsOk = per.every((p) => p.status !== 'none');
    const digitRuns = (arr) => (arr.join(' ').match(/\d{3,}/g) || []);
    const wantDigits = digitRuns(base.concat(lines.map((e) => e.t)));
    const gotDigits = digitRuns(got);
    const missingDigits = wantDigits.filter((d) => gotDigits.indexOf(d) < 0);
    const newDigits = gotDigits.filter((d) => wantDigits.indexOf(d) < 0);
    const digitsOk = missingDigits.length === 0 && newDigits.length === 0;
    const known = lines.map((e) => normalise(e.t)).concat(base.map(normalise)).filter(Boolean);
    const extra = got.filter((g) => {
      const n = normalise(g);
      if (n.replace(/ /g, '').length < 6) return false;
      return !known.some((k) => k.indexOf(n) >= 0 || n.indexOf(k) >= 0 || sim(k, n) >= 0.55);
    });
    const noExtra = extra.length === 0;
    return { ok: wordsOk && digitsOk && noExtra, wordsOk: wordsOk, digitsOk: digitsOk, noExtra: noExtra, per: per, got: got, extra: extra, missingDigits: missingDigits, newDigits: newDigits };
  }

  /* why a check failed, in plain words (shown in the card, and told to the image model on the retry) */
  function explain(ev, lines) {
    const out = [];
    if (!ev.got || (!ev.got.length && !ev.per.length)) { out.push('the result could not be read back'); return out; }
    ev.per.forEach((p) => {
      if (p.status !== 'none') return;
      const want = normalise(p.want);
      let best = null, bs = 0;
      (ev.got || []).forEach((g) => { const s = sim(want, normalise(g)); if (s > bs) { bs = s; best = g; } });
      out.push(best && bs >= 0.4 ? 'should say "' + p.want + '", reads "' + best + '"' : 'could not find "' + p.want + '" in the result');
    });
    if (ev.missingDigits.length) out.push('digits lost: ' + ev.missingDigits.join(', '));
    if (ev.newDigits.length) out.push('digits that were not there: ' + ev.newDigits.join(', '));
    ev.extra.forEach((x) => out.push('text that was not asked for: "' + x + '"'));
    return out;
  }

  /* ---------------------------------------------------------------- the pixel check */
  /* a, b: { w, h, ch (3 or 4), data } the original and the result at the same small size (WORK px long side). boxes: [[x0, y0, x1, y1]] in those pixels (the
     text boxes: hints, grown by GROW on every side and left out). Mean grey difference and mean colour drift over everything else, and the BLOTCH: the largest mean
     grey difference of any window (a fifth of the long side, half overlapping, at least half of it outside the text boxes): means over the whole picture let a block the
     image model painted over a wall through (a live result: a pale rectangle, +70 grey, 5 % of the picture). weak: the boxes (grown) cover nearly all of the picture, so
     there is too little left to judge by (the read-back still runs). */
  function pixelCheck(a, b, boxes) {
    const w = a.w, h = a.h;
    const mask = new Uint8Array(w * h).fill(1);
    (boxes || []).forEach((bx) => {
      const dx = (bx[2] - bx[0]) * GROW, dy = (bx[3] - bx[1]) * GROW;
      const x0 = Math.max(0, Math.floor(bx[0] - dx)), y0 = Math.max(0, Math.floor(bx[1] - dy));
      const x1 = Math.min(w, Math.ceil(bx[2] + dx)), y1 = Math.min(h, Math.ceil(bx[3] + dy));
      for (let y = y0; y < y1; y++) mask.fill(0, y * w + x0, y * w + x1);
    });
    // INSIDE the text boxes themselves (not grown): the lettering must have been repainted there, so the picture must differ there (an image model that gave the scene back unchanged)
    const inner = new Uint8Array(w * h);
    (boxes || []).forEach((bx) => {
      const x0 = Math.max(0, Math.floor(bx[0])), y0 = Math.max(0, Math.floor(bx[1])), x1 = Math.min(w, Math.ceil(bx[2])), y1 = Math.min(h, Math.ceil(bx[3]));
      for (let y = y0; y < y1; y++) inner.fill(1, y * w + x0, y * w + x1);
    });
    let ni = 0, si = 0;
    for (let i = 0; i < w * h; i++) {
      if (!inner[i]) continue;
      const pa = i * (a.ch || 4), pb = i * (b.ch || 4);
      si += Math.abs((0.299 * a.data[pa] + 0.587 * a.data[pa + 1] + 0.114 * a.data[pa + 2]) - (0.299 * b.data[pb] + 0.587 * b.data[pb + 1] + 0.114 * b.data[pb + 2]));
      ni++;
    }
    const inside = ni ? si / ni : -1; // -1: no box to look in
    let n = 0, sad = 0;
    const sa = [0, 0, 0], sb = [0, 0, 0];
    const ca = a.ch || 4, cb = b.ch || 4;
    const diff = new Float32Array(w * h); // signed grey difference (a - b), where it counts
    for (let i = 0; i < w * h; i++) {
      if (!mask[i]) continue;
      const pa = i * ca, pb = i * cb;
      const la = 0.299 * a.data[pa] + 0.587 * a.data[pa + 1] + 0.114 * a.data[pa + 2];
      const lb = 0.299 * b.data[pb] + 0.587 * b.data[pb + 1] + 0.114 * b.data[pb + 2];
      diff[i] = la - lb;
      sad += Math.abs(diff[i]);
      for (let k = 0; k < 3; k++) { sa[k] += a.data[pa + k]; sb[k] += b.data[pb + k]; }
      n++;
    }
    const inkedOk = (mad) => inside < 0 || (inside >= INSIDE_MIN && inside - mad >= INSIDE_GAIN);
    if (n < 0.06 * w * h) return { ok: inkedOk(0), weak: true, mad: 0, col: 0, blob: 0, frac: n / (w * h), inside: Math.round(inside * 10) / 10, inked: inkedOk(0) };
    const mad = sad / n;
    const col = (Math.abs(sa[0] - sb[0]) + Math.abs(sa[1] - sb[1]) + Math.abs(sa[2] - sb[2])) / 3 / n;
    const cell = Math.max(8, Math.round(Math.max(w, h) / 5)), step = Math.max(4, cell >> 1);
    let blob = 0;
    for (let cy = 0; cy < h; cy += step) {
      for (let cx = 0; cx < w; cx += step) {
        const x1 = Math.min(w, cx + cell), y1 = Math.min(h, cy + cell);
        let cn = 0, cs = 0;
        for (let y = cy; y < y1; y++) for (let x = cx; x < x1; x++) { const i = y * w + x; if (mask[i]) { cn++; cs += diff[i]; } }
        if (cn >= 0.5 * (x1 - cx) * (y1 - cy) && cn >= 0.5 * cell * cell * 0.5) blob = Math.max(blob, Math.abs(cs / cn));
      }
    }
    return { ok: mad <= MAD_MAX && col <= COL_MAX && blob <= BLOB_MAX && inkedOk(mad), inked: inkedOk(mad), weak: false, mad: Math.round(mad * 10) / 10, col: Math.round(col * 10) / 10, blob: Math.round(blob * 10) / 10, frac: n / (w * h), inside: Math.round(inside * 10) / 10 };
  }

  /* the size the pixel check compares at, for a picture w x h */
  function workSize(w, h) {
    const s = WORK / Math.max(w, h);
    return [Math.max(1, Math.round(w * s)), Math.max(1, Math.round(h * s))];
  }

  /* The model's own UNSURE note says the writing is cut off ("Top line is cut off at the top edge."): the lines it gave are then not the whole sign, whether or not
     it left the cut line out of LINES (live: 4 of 6 asks of one box did). A false alarm costs nothing (the repaint is refused before any money is spent). */
  const CUT_NOTE = /cut[\s-]?off|cropped|truncated|clipped|\bedge\b|runs? off|partly (visible|hidden|out)|partially (visible|hidden|out)/i;
  const cutNote = (s) => CUT_NOTE.test(String(s || ''));

  /* did the result keep the picture's shape? */
  function frameOk(w, h, rw, rh) {
    return Math.abs(rw / rh / (w / h) - 1) <= FRAME_TOL;
  }

  /* the feathered edge of the patch: this many pixels of a w x h picture fade out */
  function featherPx(w, h) {
    return Math.max(2, Math.round(Math.min(w, h) * 0.06));
  }

  const API = {
    IMAGE_MODEL: IMAGE_MODEL, QUALITY: QUALITY, RATIOS: RATIOS, SHAPE_TOL: SHAPE_TOL, EDGE_MARGIN: EDGE_MARGIN, INPUT_MAX: INPUT_MAX, INPUT_MIN: INPUT_MIN, WORK: WORK, MAD_MAX: MAD_MAX, INSIDE_MIN: INSIDE_MIN, INSIDE_GAIN: INSIDE_GAIN, COL_MAX: COL_MAX, BLOB_MAX: BLOB_MAX, FRAME_TOL: FRAME_TOL,
    normalise: normalise, paintText: paintText, paintable: paintable, assess: assess, buildInstruction: buildInstruction, pickRatio: pickRatio, planCrop: planCrop, inputSize: inputSize, sendSize: sendSize,
    compare: compare, cutNote: cutNote, evaluate: evaluate, explain: explain, sim: sim, pixelCheck: pixelCheck, workSize: workSize, frameOk: frameOk, featherPx: featherPx, NON_LATIN: NON_LATIN,
  };
  root.PAARepaint = API;
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
})(typeof self !== 'undefined' ? self : globalThis);
