/* Gloss: the two model providers, as the service worker uses them. Classic script (importScripts, after shared.js and vendor/anthropic-sdk.js); the node tests
   load it too. Nothing here touches the DOM, and no page or content script ever loads it: it is where the KEYS are handled.

   Anthropic (reading: the first answer, follow-ups, the repaint's read-backs): every text or vision call goes straight to the Anthropic Messages API, model
   claude-haiku-5-5, streamed, through the official SDK (vendor/anthropic-sdk.js, the global PAAAnthropic). OpenRouter (painting): the repaint's image model only
   (repaint-worker.js). A key is never sent to the other provider.

   Which key: for each provider separately, the person's own key from Settings (chrome.storage.local anthropicKey / openrouterKey) if there is one, otherwise the
   shared key built into this copy (keys.bundled.js, self.PAA_BUNDLED_KEYS), otherwise none.
   Every failure becomes a plain sentence with no key in it; a key problem says so and carries settings: true, so the card offers its Settings button. */
(function (root) {
  'use strict';
  const PAA = root.PAA;

  const STORAGE = { anthropic: 'anthropicKey', openrouter: 'openrouterKey' };
  const NAME = { anthropic: 'Anthropic', openrouter: 'OpenRouter' };
  const MODEL_RE = /^claude-[a-z0-9][a-z0-9.-]*$/i; // a model id on the Anthropic API ("anthropic/claude-haiku-5.5", the old OpenRouter form, is not one)

  /* ---------- which key ---------- */

  const pick = (own, builtin) => {
    own = String(own || '').trim();
    if (own) return { key: own, source: 'own' };
    return builtin ? { key: String(builtin), source: 'builtin' } : { key: '', source: 'none' };
  };

  /* stored: the chrome.storage.local values { anthropicKey, openrouterKey, model }; bundled: self.PAA_BUNDLED_KEYS (or undefined).
     Returns { anthropic: { key, source }, openrouter: { key, source }, model } with source 'own' | 'builtin' | 'none'; model is the stored one only with an own Anthropic key.
     The keys stay in the worker. */
  function choose(stored, bundled) {
    stored = stored || {};
    bundled = bundled || {};
    const anthropic = pick(stored.anthropicKey, bundled.anthropic);
    const model = String(stored.model || '').trim();
    return {
      anthropic: anthropic,
      openrouter: pick(stored.openrouterKey, bundled.openrouter),
      /* The model setting belongs to the person's OWN Anthropic key. The shared key always reads with the default (Haiku 5.5): it has an end date but no dollar limit,
         and anyone with a copy of Gloss could otherwise point it at a model that costs forty times as much. */
      model: anthropic.source === 'own' && MODEL_RE.test(model) ? model : PAA.DEFAULT_MODEL,
    };
  }

  /* Version 0.2 kept one OpenRouter key in "apiKey" and the OpenRouter-form model id in "model". Once: an apiKey that starts sk-or- becomes openrouterKey (an
     sk-ant- one becomes anthropicKey; neither is overwritten if already set) and apiKey is removed; a stored model that is not a Claude id on the Anthropic API
     is removed (the default is used). Safe to run on every read: with nothing to migrate it only reads. Returns the values read, after the change. */
  async function loadStored(area) {
    const s = await area.get(['apiKey', 'anthropicKey', 'openrouterKey', 'model']);
    const set = {};
    const drop = [];
    if ('apiKey' in s) {
      const old = String(s.apiKey || '').trim();
      if (/^sk-or-/.test(old) && !String(s.openrouterKey || '').trim()) set.openrouterKey = old;
      else if (/^sk-ant-/.test(old) && !String(s.anthropicKey || '').trim()) set.anthropicKey = old;
      drop.push('apiKey');
    }
    if (typeof s.model === 'string' && s.model.trim() && !MODEL_RE.test(s.model.trim())) drop.push('model');
    if (Object.keys(set).length) await area.set(set);
    if (drop.length) await area.remove(drop);
    const out = Object.assign({}, s, set);
    drop.forEach((k) => delete out[k]);
    return out;
  }

  /* What the settings page may know: where each key comes from, and whether this copy has a shared one at all (so it can say what emptying the field would do). Never a key. */
  function status(choice, bundled) {
    bundled = bundled || {};
    return {
      anthropic: { source: choice.anthropic.source, builtin: !!bundled.anthropic },
      openrouter: { source: choice.openrouter.source, builtin: !!bundled.openrouter },
      expires: bundled.expires || null,
      openrouterLimitUsd: typeof bundled.openrouterLimitUsd === 'number' ? bundled.openrouterLimitUsd : null,
      model: choice.model,
    };
  }

  /* ---------- plain-language failures ---------- */

  /* A key must never be in a message: anything that looks like one is blanked, in whatever the provider sent back. */
  const scrub = (s) => String(s == null ? '' : s).replace(/\bsk-(?:ant|or)-[A-Za-z0-9_\-]+/g, '[key]').replace(/Bearer\s+\S+/gi, 'Bearer [key]');

  /* status: the HTTP status (0 / undefined for a network failure); detail: what the provider said; source: 'own' | 'builtin' (the key that failed).
     Returns { message, settings } - settings is true for a key problem, and then the card shows its Settings button. */
  function explain(provider, status, detail, source) {
    const P = NAME[provider] || 'The provider';
    const shared = source === 'builtin';
    const low = String(detail || '').toLowerCase();
    const credit = status === 402 || (status === 400 && /credit|billing|balance|insufficient/.test(low));
    // an organisation's usage / spend limit comes as a 400 too ("You have reached your specified API usage limits. You will regain access on ...")
    const limit = status === 400 && /usage limit|spend(ing)? limit|regain access|quota/.test(low);
    const add = 'Add your own ' + P + ' key in Settings' + (provider === 'openrouter' ? ' (it is only used for Repaint).' : '.');
    if (shared && (status === 401 || status === 403 || credit || limit)) {
      return { message: 'The shared key built into Gloss has expired or run out. ' + add, settings: true };
    }
    if (status === 401) return { message: P + ' did not accept your key. Check it in Settings.', settings: true };
    if (limit) return { message: 'Your ' + P + ' account has reached its usage limit. Raise the limit with ' + P + ', or use another key in Settings.', settings: true };
    if (credit) return { message: 'Your ' + P + ' account is out of credit. Add credit with ' + P + ', or use another key in Settings.', settings: true };
    if (status === 403) return { message: P + ' says your key is not allowed to do this' + (provider === 'openrouter' ? ' (it may have reached its limit)' : '') + '. Check it in Settings.', settings: true };
    if (status === 429) {
      if (shared) return { message: 'The shared key built into Gloss is being used a lot right now (everyone who got this copy shares it). Wait a moment and try again, or ' + add.charAt(0).toLowerCase() + add.slice(1), settings: true };
      return { message: P + ' is limiting how fast this key can ask. Wait a moment, then try again.', settings: false };
    }
    if (status === 529) return { message: P + ' is overloaded right now. Try again in a moment.', settings: false };
    if (status >= 500) return { message: P + ' had a problem on its side (HTTP ' + status + '). Try again in a moment.', settings: false };
    const d = PAA.clip(scrub(detail), 300);
    return { message: P + ' refused the request' + (status ? ' (HTTP ' + status + ')' : '') + (d ? ': ' + d : '.'), settings: false };
  }

  function failure(provider, status, detail, source) {
    const x = explain(provider, status, detail, source);
    const e = new Error(x.message);
    e.settings = x.settings;
    e.status = status || 0;
    e.provider = provider;
    e.keySource = source;
    return e;
  }

  const cancelled = () => { const e = new Error('cancelled'); e.name = 'AbortError'; return e; };

  /* ---------- Anthropic, through the SDK ---------- */

  const STREAM_ERROR_STATUS = { overloaded_error: 529, rate_limit_error: 429, authentication_error: 401, billing_error: 402, permission_error: 403, api_error: 500, not_found_error: 404 };

  /* the SDK's error, as { status, detail }: the status of the reply, or the one that goes with an error the stream reported part-way */
  function readSdkError(e) {
    const body = e && e.error && typeof e.error === 'object' ? e.error : null;
    const inner = body && body.error && typeof body.error === 'object' ? body.error : body;
    const type = inner && inner.type;
    const status = (e && e.status) || STREAM_ERROR_STATUS[type] || 0;
    const detail = (inner && typeof inner.message === 'string' && inner.message) || (e && e.message) || '';
    return { status: status, detail: detail };
  }

  /* The SDK client. dangerouslyAllowBrowser: a service worker's request carries an Origin header, which the API refuses unless the browser-access header is
     sent (the SDK sends it with this option). fetch is looked up at CALL time, so a test that replaces self.fetch (or passes fetchImpl) sees every request. */
  function makeClient(apiKey, o) {
    o = o || {};
    const Anthropic = root.PAAAnthropic;
    if (!Anthropic) throw new Error('The Anthropic library did not load. Reload the extension.');
    return new Anthropic({
      apiKey: apiKey,
      dangerouslyAllowBrowser: true,
      maxRetries: typeof o.maxRetries === 'number' ? o.maxRetries : 2,
      timeout: o.timeout || undefined,
      fetchOptions: { referrerPolicy: 'no-referrer' },
      fetch: (url, init) => (o.fetchImpl || root.fetch)(url, init),
    });
  }

  const IDLE_MS = 60000; // a stream that sends no event at all for this long is dead (the longest silence seen in a real ask: 6.2 s of thinking; 8000 tokens of it would be about 40 s)
  const LOST = /network|terminated|failed to fetch|fetch failed|load failed|socket|connection|ECONN|ERR_[A-Z_]+/i; // how a browser words a connection that broke part-way

  /* One streamed Messages call. opts: { apiKey, keySource, model, prompt: { system, messages }, signal, fetchImpl, idleMs, onDelta(text), onFirst() }
     Returns { text, usage, cost, model, stop }; cost in dollars from the usage block (PAA.costOf). Throws an Error with a plain message (settings: true when it
     is a key problem); an abort throws an Error named AbortError. Three ends that are not an answer all throw, so nothing half-finished is ever saved: the model
     declined (refusal: true), the reply hit max_tokens (cutOff: true, cost: what that call cost), and the stream stopped sending (a stall timer aborts it). */
  async function streamChat(opts) {
    const model = opts.model || PAA.DEFAULT_MODEL;
    const client = makeClient(opts.apiKey, { fetchImpl: opts.fetchImpl });
    let text = '';
    let first = true;
    let started = false; // an event has arrived: the reply was under way
    let stalled = false;
    // the SDK's timeout covers the wait for the headers, not the body: a connection that stays open and goes quiet needs a timer of our own
    const ctl = new AbortController();
    const outer = opts.signal;
    const onOuter = () => ctl.abort();
    if (outer) { if (outer.aborted) ctl.abort(); else outer.addEventListener('abort', onOuter); }
    const gone = new Promise((_, reject) => { if (ctl.signal.aborted) reject(cancelled()); else ctl.signal.addEventListener('abort', () => reject(cancelled())); });
    gone.catch(() => {}); // (it is only ever raced: this keeps a rejection that nobody is waiting for any more quiet)
    let timer = null;
    const arm = () => { clearTimeout(timer); timer = setTimeout(() => { stalled = true; ctl.abort(); }, opts.idleMs || IDLE_MS); };
    try {
      arm();
      const stream = client.messages.stream(PAA.buildRequestBody(model, opts.prompt), { signal: ctl.signal });
      stream.on('streamEvent', () => { started = true; arm(); });
      stream.on('text', (piece) => {
        if (!piece) return;
        if (first && opts.onFirst) opts.onFirst();
        first = false;
        text += piece;
        if (opts.onDelta) opts.onDelta(piece);
      });
      // raced against the abort, so a cancel or a stall ends the call even if the connection under the SDK does not notice the abort at once
      const msg = await Promise.race([stream.finalMessage(), gone]);
      if (msg.stop_reason === 'refusal') { // the model's safety check declined this one: nothing to read, and not a key problem
        const r = new Error('Claude declined to answer this one.');
        r.refusal = true;
        throw r;
      }
      if (msg.stop_reason === 'max_tokens') { // thinking and the reply used up the limit: what came is not a finished answer (a cut-off LINES list, a cut-off JSON array)
        const c = new Error('The answer was cut off before it was finished. Try again.');
        c.cutOff = true;
        c.cost = PAA.costOf(model, msg.usage);
        throw c;
      }
      return { text: text, usage: msg.usage || null, cost: PAA.costOf(model, msg.usage), model: model, stop: msg.stop_reason || null };
    } catch (e) {
      if (stalled) throw new Error('Network error: Anthropic stopped answering. Try again.');
      if ((outer && outer.aborted) || (e && (e.name === 'APIUserAbortError' || e.name === 'AbortError'))) throw cancelled();
      if (e && (e.refusal || e.cutOff)) throw e;
      const name = e && e.name;
      if (name === 'APIConnectionTimeoutError') throw new Error('Network error: the request to Anthropic timed out.');
      if (name === 'APIConnectionError') throw new Error('Network error: ' + ((e.cause && e.cause.message) || e.message || 'could not reach Anthropic') + '.');
      const x = readSdkError(e);
      // an answer from the API (a status, or an error event with a body) is explained as one; a stream that broke part-way is not a refusal
      if (x.status || (e && e.error && typeof e.error === 'object')) throw failure('anthropic', x.status, x.detail, opts.keySource);
      if (started || LOST.test(String((e && e.message) || ''))) throw new Error('Network error: the connection to Anthropic was lost. Try again.');
      throw e;
    } finally {
      clearTimeout(timer);
      if (outer) outer.removeEventListener('abort', onOuter);
    }
  }

  /* ---------- "does this key work?" (the settings page's Check button) ---------- */

  const usd = (n) => '$' + (Number.isInteger(n) ? String(n) : n.toFixed(2));

  /* key: the key to try; source: 'own' | 'builtin' (it only changes the wording). Returns { ok, message } and, for OpenRouter, { usage, limit, left } in dollars. */
  async function checkAnthropic(key, source, o) {
    o = o || {};
    const model = o.model || PAA.DEFAULT_MODEL;
    const who = source === 'builtin' ? 'The built-in shared key' : 'Your key';
    try {
      const client = makeClient(key, { fetchImpl: o.fetchImpl, maxRetries: 0, timeout: 15000 });
      const m = await client.models.retrieve(model);
      return { ok: true, message: who + ' works. ' + ((m && m.display_name) || model) + ' is available to it.' };
    } catch (e) {
      const name = e && e.name;
      if (name === 'APIConnectionTimeoutError' || name === 'APIConnectionError') return { ok: false, message: 'Could not reach Anthropic. Check the connection and try again.' };
      const x = readSdkError(e);
      if (x.status === 404) return { ok: false, message: 'Anthropic accepted the key, but ' + model + ' is not available to it.' };
      return { ok: false, message: explain('anthropic', x.status, x.detail, source).message };
    }
  }

  async function checkOpenRouter(key, source, o) {
    o = o || {};
    const f = o.fetchImpl || root.fetch;
    const who = source === 'builtin' ? 'The built-in shared key' : 'Your key';
    let res;
    try {
      res = await f('https://openrouter.ai/api/v1/key', { method: 'GET', headers: { Authorization: 'Bearer ' + key }, referrerPolicy: 'no-referrer', signal: o.signal });
    } catch (e) {
      return { ok: false, message: 'Could not reach OpenRouter. Check the connection and try again.' };
    }
    let raw = '';
    try { raw = await res.text(); } catch (e) { /* no body */ }
    let j = null;
    try { j = JSON.parse(raw); } catch (e) { /* not JSON */ }
    if (!res.ok) {
      const detail = j && j.error ? (j.error.message || JSON.stringify(j.error)) : raw;
      return { ok: false, message: explain('openrouter', res.status, detail, source).message };
    }
    const d = (j && j.data) || {};
    const out = { ok: true, message: who + ' works.' };
    if (typeof d.usage === 'number') out.usage = d.usage;
    if (typeof d.limit === 'number') out.limit = d.limit;
    if (typeof d.limit_remaining === 'number') out.left = d.limit_remaining;
    if (typeof out.left === 'number' && typeof out.limit === 'number') {
      out.message += ' ' + usd(Math.max(0, out.limit - out.left)) + ' of its ' + usd(out.limit) + ' limit used, ' + usd(Math.max(0, out.left)) + ' left.';
    }
    return out;
  }

  /* A key typed into the wrong field is never sent anywhere: Check would otherwise hand an OpenRouter key to Anthropic, or the reverse (Save refuses it too, in options.js). */
  const WRONG_FIELD = { anthropic: [/^sk-or-/, 'That is an OpenRouter key. It goes in the OpenRouter field.'], openrouter: [/^sk-ant-/, 'That is an Anthropic key. It goes in the Anthropic field.'] };

  async function check(provider, key, source, o) {
    if (!key) return { ok: false, message: 'There is no ' + NAME[provider] + ' key to check.' };
    const w = WRONG_FIELD[provider];
    if (w && w[0].test(key)) return { ok: false, message: w[1] };
    return provider === 'openrouter' ? checkOpenRouter(key, source, o) : checkAnthropic(key, source, o);
  }

  root.PAAProviders = {
    STORAGE: STORAGE,
    choose: choose,
    loadStored: loadStored,
    status: status,
    explain: explain,
    failure: failure,
    scrub: scrub,
    makeClient: makeClient,
    streamChat: streamChat,
    check: check,
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = root.PAAProviders;
})(typeof self !== 'undefined' ? self : globalThis);
