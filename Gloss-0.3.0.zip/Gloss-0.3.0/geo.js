/* Gloss: small pure geometry helpers (no DOM, no Chrome). Loaded in the page and in node.

   planeSnapshot() answers one question exactly: a model box comes back in pixels of the crop; which
   directions in the panorama are those pixels? The answer must use the camera as it was when the screenshot
   was taken, not as it is when the answer arrives seconds later (the owner may have looked around meanwhile).
   So at capture time we freeze the crop rectangle's four corner directions plus the camera's forward axis.
   The crop is a flat rectangle on the camera's image plane (points p with p . forward = 1), so a pixel at
   fraction (fx, fy) of the crop is the bilinear mix of the four corner points on that plane, and its
   direction is that point's direction. Exact for any field of view, with no use of the live camera. */
(function (root) {
  'use strict';
  const D = Math.PI / 180;

  const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
  const enuDir = (yaw, pitch) => [Math.sin(yaw * D) * Math.cos(pitch * D), Math.cos(yaw * D) * Math.cos(pitch * D), Math.sin(pitch * D)];
  function yawPitch(v) {
    const l = Math.sqrt(dot(v, v)) || 1;
    return { yaw: ((Math.atan2(v[0], v[1]) / D) % 360 + 360) % 360, pitch: Math.asin(Math.max(-1, Math.min(1, v[2] / l))) / D };
  }
  const roundDir = (d) => (d ? { yaw: Math.round(d.yaw * 1e5) / 1e5, pitch: Math.round(d.pitch * 1e5) / 1e5 } : null);

  /* corners: [tl, tr, br, bl] each {yaw, pitch} (compass degrees); forward: {heading, pitch} of the camera.
     Returns { dirAt(fx, fy) -> {yaw, pitch} | null } or null when a corner is not clearly in front. */
  function planeSnapshot(corners, forward) {
    if (!corners || corners.length !== 4 || corners.some((c) => !c) || !forward) return null;
    const f = enuDir(forward.heading, forward.pitch);
    const P = [];
    for (let i = 0; i < 4; i++) {
      const v = enuDir(corners[i].yaw, corners[i].pitch);
      const d = dot(v, f);
      if (d < 0.05) return null; // at or behind the image plane: no safe mapping
      P.push([v[0] / d, v[1] / d, v[2] / d]);
    }
    function dirAt(fx, fy) {
      const out = [0, 0, 0];
      for (let k = 0; k < 3; k++) {
        const top = P[0][k] * (1 - fx) + P[1][k] * fx;
        const bot = P[3][k] * (1 - fx) + P[2][k] * fx;
        out[k] = top * (1 - fy) + bot * fy;
      }
      return yawPitch(out);
    }
    return { dirAt: dirAt };
  }

  /* Four corner directions of a model box. b = [x0, y0, x1, y1] in crop pixels (cw x ch). */
  function boxDirs(snap, b, cw, ch) {
    if (!snap || !b || !(cw > 0) || !(ch > 0)) return null;
    const x0 = b[0] / cw, y0 = b[1] / ch, x1 = b[2] / cw, y1 = b[3] / ch;
    return { tl: roundDir(snap.dirAt(x0, y0)), tr: roundDir(snap.dirAt(x1, y0)), br: roundDir(snap.dirAt(x1, y1)), bl: roundDir(snap.dirAt(x0, y1)) };
  }

  /* ---------- where things are on the ground (stage 2: Nearby rows; also loaded in the service worker) ---------- */
  const EARTH = 6371008.8; // metres; a sphere is plenty for distances of a few hundred metres

  /* distance (m) and compass bearing (degrees, 0 = north, 90 = east) from a position to another. null if a number is missing. */
  function distBearing(lat0, lng0, lat1, lng1) {
    if (![lat0, lng0, lat1, lng1].every((v) => typeof v === 'number' && isFinite(v))) return null;
    const n = (lat1 - lat0) * D * EARTH;
    const e = (lng1 - lng0) * D * EARTH * Math.cos(((lat0 + lat1) / 2) * D);
    return { d: Math.hypot(n, e), b: ((Math.atan2(e, n) / D) % 360 + 360) % 360 };
  }

  const WORDS = ['north', 'north-east', 'east', 'south-east', 'south', 'south-west', 'west', 'north-west'];
  function compassWord(bearing) {
    return WORDS[Math.round((((bearing % 360) + 360) % 360) / 45) % 8];
  }

  /* "7 m", "80 m", "135 m" (nearest 5 from 100 m), "1.2 km" */
  function distText(m) {
    if (!(m >= 0)) return '';
    if (m < 100) return Math.round(m) + ' m';
    if (m < 1000) return Math.round(m / 5) * 5 + ' m';
    return (m / 1000).toFixed(1) + ' km';
  }

  const API = { enuDir: enuDir, yawPitch: yawPitch, roundDir: roundDir, planeSnapshot: planeSnapshot, boxDirs: boxDirs, distBearing: distBearing, compassWord: compassWord, distText: distText };
  root.PAAGeo = API;
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
})(typeof self !== 'undefined' ? self : globalThis);
