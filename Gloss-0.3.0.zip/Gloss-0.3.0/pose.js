/* pose.js — Gloss v0.2, isolated-world module (no dependencies).
 *
 * Street View camera pose and projection for google.com/maps.
 *   PAAPose.getPose()  -> { panoId, lat, lng, heading, pitch, fov, hfov, roll, canvasRect, elementRect, live,
 *                           moving, settled, transition, panoPending, source, t }
 *                           canvasRect = where the panorama is drawn (client CSS px); in split view that is only
 *                           the top part of the canvas element (elementRect).
 *   PAAPose.onPose(cb) -> unsubscribe fn; cb(pose) on every frame the pose changed, and once at rest.
 *   PAAPose.screenToDir(x, y)        -> { yaw, pitch } | null      (client CSS px -> compass deg, deg up)
 *   PAAPose.dirToScreen(yaw, pitch)  -> { x, y, visible, behind } | null
 *   PAAPose.quadToMatrix3d(dirs4, w, h, opts) -> CSS 'matrix3d(...)' warping a w x h box (origin 0 0,
 *                           placed at client 0,0) onto the four projected corners (TL, TR, BR, BL).
 *
 * Two sources:
 *  - 'matrix' (live): pose-main.js posts the panorama's view-projection matrix every animation frame.
 *    The matrix lives in the panorama's own model frame; one rotation R (model -> east/north/up) is
 *    calibrated per panorama from the address at rest (heading, tilt), carried across the fly-to-next
 *    transition, and re-checked at every rest. The address only updates ~350 ms after motion stops.
 *  - 'url' (rest-only fallback, live=false): pinhole camera from the address (vertical fov, heading,
 *    tilt = 90 + pitch, no roll) over the canvas rectangle. Used when the hook sees nothing.
 * Address format: /maps/@LAT,LNG,<alt>a,<fovY>y,<heading>h,<tilt>t/data=...!1s<panoId>!2e<0 car|10 user>...
 * heading is omitted when 0; fovY is the VERTICAL field of view.
 * Where the address carries NO camera values (South Korea: /maps/@/data=!3m7!1e1!3m5!1s<panoId>!2e0...) the panorama id is still in it, and the
 * rotation R is calibrated from the panorama's own metadata instead (see calibrateFromMeta): R = Rz(-capture heading) . Rx(capture tilt - 90) . Ry(roll),
 * which matched the address-based rotation to 0.00x degrees in 16 views of 8 panoramas (Tokyo, San Francisco, Moscow). meta.js supplies the metadata
 * (PAAPose.setMetaSource, PAAPose.metaArrived).
 */
(() => {
  if (globalThis.PAAPose) return;
  const D = Math.PI / 180;
  const EVT_FRAME = 'paa-pose-frame', EVT_URL = 'paa-pose-url';

  // ---------- small vector helpers ----------
  const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
  const len = (a) => Math.sqrt(dot(a, a));
  const nrm = (a) => { const l = len(a) || 1; return [a[0] / l, a[1] / l, a[2] / l]; };
  const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
  const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
  const scl = (a, s) => [a[0] * s, a[1] * s, a[2] * s];
  const mulM3 = (M, v) => [dot(M[0], v), dot(M[1], v), dot(M[2], v)]; // M as rows
  const mulM3T = (M, v) => [M[0][0] * v[0] + M[1][0] * v[1] + M[2][0] * v[2], M[0][1] * v[0] + M[1][1] * v[1] + M[2][1] * v[2], M[0][2] * v[0] + M[1][2] * v[1] + M[2][2] * v[2]];
  const enuDir = (yaw, pitch) => [Math.sin(yaw * D) * Math.cos(pitch * D), Math.cos(yaw * D) * Math.cos(pitch * D), Math.sin(pitch * D)];
  const yawPitch = (e) => { const v = nrm(e); return { yaw: ((Math.atan2(v[0], v[1]) / D) % 360 + 360) % 360, pitch: Math.asin(Math.max(-1, Math.min(1, v[2]))) / D }; };
  const angBetween = (a, b) => Math.acos(Math.max(-1, Math.min(1, dot(nrm(a), nrm(b))))) / D;

  // 3x3 products (rows), for the rotation from a panorama's capture heading, tilt and roll
  const mmul = (A, B) => A.map((r) => [0, 1, 2].map((j) => r[0] * B[0][j] + r[1] * B[1][j] + r[2] * B[2][j]));
  const rotZ = (a) => { const c = Math.cos(a), s = Math.sin(a); return [[c, -s, 0], [s, c, 0], [0, 0, 1]]; };
  const rotX = (a) => { const c = Math.cos(a), s = Math.sin(a); return [[1, 0, 0], [0, c, -s], [0, s, c]]; };
  const rotY = (a) => { const c = Math.cos(a), s = Math.sin(a); return [[c, 0, s], [0, 1, 0], [-s, 0, c]]; };
  const rotAngle = (A, B) => { const M = mmul([[A[0][0], A[1][0], A[2][0]], [A[0][1], A[1][1], A[2][1]], [A[0][2], A[1][2], A[2][2]]], B); return Math.acos(Math.max(-1, Math.min(1, (M[0][0] + M[1][1] + M[2][2] - 1) / 2))) / D; };
  /* The rotation from the renderer's model frame to east/north/up for one panorama, from its metadata alone: the model frame is the
     panorama's own (x right, y forward at the capture heading, z up) with the capture tilt and roll applied. null without usable numbers. */
  function metaRotation(m) {
    if (!m || typeof m.heading !== 'number' || typeof m.tilt !== 'number' || typeof m.roll !== 'number') return null;
    const roll = ((m.roll + 180) % 360 + 360) % 360 - 180;
    return mmul(rotZ(-m.heading * D), mmul(rotX((m.tilt - 90) * D), rotY(roll * D)));
  }

  // rows of the 4x4 (column-major) matrix: row i = (m[i], m[4+i], m[8+i]), translation m[12+i]
  const rowsOf = (m) => [0, 1, 2, 3].map((i) => [m[i], m[4 + i], m[8 + i]]);
  const isOrigin = (m) => Math.abs(m[12]) < 1e-6 && Math.abs(m[13]) < 1e-6 && Math.abs(m[15]) < 1e-6;
  // camera axes in model frame, orthonormalised: forward, right, up
  function camAxes(m) {
    const r = rowsOf(m);
    const f = nrm(r[3]);
    const rt = nrm(sub(r[0], scl(f, dot(r[0], f))));
    const up = nrm(sub(sub(r[1], scl(f, dot(r[1], f))), scl(rt, dot(r[1], rt)))); // Gram-Schmidt (keeps handedness as rendered)
    return { f, r: rt, u: up, fy: len(r[1]) / len(r[3]), fx: len(r[0]) / len(r[3]) };
  }
  // ENU camera axes for heading/pitch (no roll)
  function enuAxes(h, p) { const f = enuDir(h, p); const r = [Math.cos(h * D), -Math.sin(h * D), 0]; return { f, r, u: cross(r, f) }; }
  // rotation (rows) taking frame A's axes onto frame B's axes: B = R A  =>  R = Bcols * Acols^T
  function rotFromAxes(A, B) {
    const R = [[0, 0, 0], [0, 0, 0], [0, 0, 0]];
    for (const k of ['f', 'r', 'u']) for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) R[i][j] += B[k][i] * A[k][j];
    return R;
  }
  const axesToEnu = (R, A) => ({ f: mulM3(R, A.f), r: mulM3(R, A.r), u: mulM3(R, A.u) });

  // ---------- address parsing ----------
  function parseUrl(href) {
    const out = { href };
    try {
      const u = new URL(href);
      const m = /@(-?\d+(?:\.\d+)?),(-?\d+(?:\.\d+)?)((?:,[^,/]+)*)/.exec(u.pathname);
      if (!m) { // Street View with no camera values in the address (South Korea): only the panorama id is there
        const q = /\/@\/data=.*!3m\d+!1e1!3m\d+!1s([^!?]+)/.exec(u.pathname + u.search);
        if (q) {
          out.noCam = true; out.panoId = decodeURIComponent(q[1]);
          const k = /!2e(\d+)/.exec(href); if (k) out.kind = k[1] === '0' ? 'car' : k[1] === '10' ? 'user' : k[1];
        }
        return out;
      }
      out.lat = +m[1]; out.lng = +m[2];
      let sv = false;
      for (const tok of m[3].split(',')) {
        const t = /^(-?\d+(?:\.\d+)?)([a-z])$/.exec(tok); if (!t) continue;
        const v = +t[1];
        if (t[2] === 'a') { sv = true; out.alt = v; } else if (t[2] === 'y') out.fov = v; else if (t[2] === 'h') out.heading = v; else if (t[2] === 't') out.tilt = v;
      }
      if (!sv) return out;
      out.pano = true;
      if (out.heading === undefined) out.heading = 0; // omitted when 0
      if (out.tilt === undefined) out.tilt = 90; // assumed default (horizon)
      if (out.fov === undefined) out.fov = 75; // Maps' default when omitted (unverified)
      const p = /!3m\d+!1e1!3m\d+!1s([^!?]+)/.exec(href) || /!1s([^!?]+)/.exec(href);
      if (p) out.panoId = decodeURIComponent(p[1]);
      const k = /!2e(\d+)/.exec(href); if (k) out.kind = k[1] === '0' ? 'car' : k[1] === '10' ? 'user' : k[1];
    } catch (e) {}
    return out;
  }

  // ---------- state ----------
  const S = {
    url: parseUrl(location.href), urlT: performance.now(),
    mat: null, matT: 0, vp: null, cw: 0, ch: 0, hookFrames: 0,
    R: null, Rold: null, calPano: null, calSource: null, calLog: [],
    transition: false, panoPending: false, lastRestAxesEnu: null,
    canvas: null, rect: null, rectT: 0, failures: 0, disabled: false,
    listeners: new Set(), lastPose: null,
    meta: null, // { get(panoId) -> parsed metadata | null, need(panoId, type) } from meta.js
  };

  function findCanvas() {
    let c = document.querySelector('canvas[data-paa-pano]');
    if (!c) { let best = 0; for (const e of document.querySelectorAll('canvas')) { const r = e.getBoundingClientRect(); const a = r.width * r.height; if (a > best) { best = a; c = e; } } }
    return c || null;
  }
  function rect(force) {
    const t = performance.now();
    if (force || !S.rect || !S.canvas || !S.canvas.isConnected || t - S.rectT > 500) {
      const c = findCanvas();
      if (c !== S.canvas) { S.canvas = c; if (c && window.ResizeObserver) { try { S.ro && S.ro.disconnect(); S.ro = new ResizeObserver(() => { S.rectT = 0; }); S.ro.observe(c); } catch (e) {} } }
      if (c) { const r = c.getBoundingClientRect(); S.rect = { x: r.left, y: r.top, width: r.width, height: r.height }; }
      S.rectT = t;
    }
    return S.rect;
  }
  addEventListener('resize', () => { S.rectT = 0; }, true);
  // the part of the canvas the panorama is drawn in (split view draws the map below it), client CSS px
  function viewRect() {
    const rc = rect(); if (!rc) return null;
    if (S.disabled || !S.vp || !S.cw || !S.ch) return rc;
    const [vx, vy, vw, vh] = S.vp;
    return { x: rc.x + vx / S.cw * rc.width, y: rc.y + (1 - (vy + vh) / S.ch) * rc.height, width: vw / S.cw * rc.width, height: vh / S.ch * rc.height };
  }

  // active projection: { rows (4 x vec3), R (model->ENU), vp, cw, ch, source }
  function urlCamera() {
    const u = S.url; const rc = rect(); if (!u.pano || !rc || !rc.width) return null;
    const p = u.tilt - 90, A = enuAxes(u.heading, p), ty = Math.tan(u.fov * D / 2), asp = rc.width / rc.height;
    const rows = [scl(A.r, 1 / (asp * ty)), scl(A.u, 1 / ty), scl(A.f, -1), A.f];
    return { rows, R: [[1, 0, 0], [0, 1, 0], [0, 0, 1]], vp: null, cw: 1, ch: 1, source: 'url' };
  }
  function matrixCamera() {
    if (S.disabled || !S.mat || !S.R) return null;
    return { rows: rowsOf(S.mat), R: S.R, vp: S.vp, cw: S.cw, ch: S.ch, source: 'matrix' };
  }
  const camera = (src) => (src === 'url' ? urlCamera() : src === 'matrix' ? matrixCamera() : matrixCamera() || urlCamera());

  // NDC <-> client CSS px
  function ndcToClient(cam, nx, ny) {
    const rc = rect(); if (!rc) return null;
    let fx = (nx + 1) / 2, fy = (ny + 1) / 2; // fractions of viewport, y up
    if (cam.vp && cam.cw && cam.ch) { fx = (cam.vp[0] + fx * cam.vp[2]) / cam.cw; fy = (cam.vp[1] + fy * cam.vp[3]) / cam.ch; }
    return { x: rc.x + fx * rc.width, y: rc.y + (1 - fy) * rc.height };
  }
  function clientToNdc(cam, x, y) {
    const rc = rect(); if (!rc) return null;
    let fx = (x - rc.x) / rc.width, fy = 1 - (y - rc.y) / rc.height;
    if (cam.vp && cam.cw && cam.ch) { fx = (fx * cam.cw - cam.vp[0]) / cam.vp[2]; fy = (fy * cam.ch - cam.vp[1]) / cam.vp[3]; }
    return { nx: fx * 2 - 1, ny: fy * 2 - 1 };
  }

  function dirToScreen(yaw, pitch, src) {
    const cam = camera(src); if (!cam) return null;
    const d = mulM3T(cam.R, enuDir(yaw, pitch)); // ENU -> model
    const cx = dot(cam.rows[0], d), cy = dot(cam.rows[1], d), cw = dot(cam.rows[3], d);
    const behind = cw <= 1e-9 * len(cam.rows[3]);
    const w = Math.abs(cw) || 1e-12;
    const nx = cx / w, ny = cy / w;
    const p = ndcToClient(cam, nx, ny); if (!p) return null;
    const rc = cam.source === 'url' ? rect() : viewRect();
    p.visible = !behind && p.x >= rc.x && p.x <= rc.x + rc.width && p.y >= rc.y && p.y <= rc.y + rc.height;
    p.behind = behind; p.source = cam.source;
    return p;
  }
  function screenToDir(x, y, src) {
    const cam = camera(src); if (!cam) return null;
    const n = clientToNdc(cam, x, y); if (!n) return null;
    const A = [cam.rows[0], cam.rows[1], cam.rows[3]];
    const d = solve3(A, [n.nx, n.ny, 1]); if (!d) return null;
    const dd = dot(cam.rows[3], d) < 0 ? scl(d, -1) : d;
    const r = yawPitch(mulM3(cam.R, dd)); r.source = cam.source;
    return r;
  }
  function solve3(A, b) { // Cramer
    const det = (M) => M[0][0] * (M[1][1] * M[2][2] - M[1][2] * M[2][1]) - M[0][1] * (M[1][0] * M[2][2] - M[1][2] * M[2][0]) + M[0][2] * (M[1][0] * M[2][1] - M[1][1] * M[2][0]);
    const d0 = det(A); if (Math.abs(d0) < 1e-15) return null;
    const col = (k) => A.map((row, i) => row.map((v, j) => (j === k ? b[i] : v)));
    return [det(col(0)) / d0, det(col(1)) / d0, det(col(2)) / d0];
  }

  const HIDDEN = 'matrix3d(0,0,0,0, 0,0,0,0, 0,0,1,0, -99999,-99999,0,1)'; // collapses the element off-screen
  // Square (0,0)-(w,h) -> quad p[0..3] (TL, TR, BR, BL) as CSS matrix3d. Heckbert's square-to-quad.
  // Returns HIDDEN (not a mirrored/flipped warp) when a corner is behind the camera, unless opts.fallback === 'billboard'.
  function quadToMatrix3d(dirs, w, h, opts) {
    opts = opts || {};
    const pts = dirs.map((d) => dirToScreen(d.yaw, d.pitch, opts.source));
    const hidden = HIDDEN;
    if (pts.some((p) => !p)) return hidden;
    if (pts.some((p) => p.behind)) {
      if (opts.fallback !== 'billboard') return hidden;
      // billboard: unwarped box centred on the mean direction, if that is in front
      const m = nrm(dirs.map((d) => enuDir(d.yaw, d.pitch)).reduce((a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]]));
      const c = yawPitch(m), pc = dirToScreen(c.yaw, c.pitch, opts.source);
      if (!pc || pc.behind) return hidden;
      return `matrix3d(1,0,0,0, 0,1,0,0, 0,0,1,0, ${pc.x - w / 2},${pc.y - h / 2},0,1)`;
    }
    const [p0, p1, p2, p3] = pts;
    const sx = p0.x - p1.x + p2.x - p3.x, sy = p0.y - p1.y + p2.y - p3.y;
    let a, b, c, d, e, f, g, hh;
    if (Math.abs(sx) < 1e-9 && Math.abs(sy) < 1e-9) {
      a = p1.x - p0.x; b = p3.x - p0.x; c = p0.x; d = p1.y - p0.y; e = p3.y - p0.y; f = p0.y; g = 0; hh = 0;
    } else {
      const dx1 = p1.x - p2.x, dx2 = p3.x - p2.x, dy1 = p1.y - p2.y, dy2 = p3.y - p2.y;
      const den = dx1 * dy2 - dx2 * dy1; if (Math.abs(den) < 1e-12) return hidden;
      g = (sx * dy2 - dx2 * sy) / den; hh = (dx1 * sy - sx * dy1) / den;
      a = p1.x - p0.x + g * p1.x; b = p3.x - p0.x + hh * p3.x; c = p0.x;
      d = p1.y - p0.y + g * p1.y; e = p3.y - p0.y + hh * p3.y; f = p0.y;
    }
    // (u,v) in unit square: X = (a u + b v + c)/(g u + hh v + 1), Y = (d u + e v + f)/(g u + hh v + 1)
    // w-positivity over the box (convex quad => linear denominator positive at corners suffices)
    for (const [u, v] of [[0, 0], [1, 0], [1, 1], [0, 1]]) if (g * u + hh * v + 1 <= 1e-6) return hidden;
    const A = a / w, B = b / h, Dd = d / w, E = e / h, Gg = g / w, H = hh / h;
    return `matrix3d(${A},${Dd},0,${Gg}, ${B},${E},0,${H}, 0,0,1,0, ${c},${f},0,1)`;
  }

  // ---------- pose ----------
  // is the camera of the current address usable? (an address with camera values, or one calibrated from the metadata)
  // (during a flight to the next panorama the address still names the old one and the rotation is carried over: the old panorama's id stays, as with an address that has the camera)
  function metaCam(u) { return !!u.noCam && ((S.calSource === 'meta' && S.calPano === u.panoId) || ((S.transition || S.panoPending) && S.metaPano === u.panoId)); }
  function computePose() {
    const u = S.url;
    const mc = metaCam(u);
    const rc = S.mat && !S.disabled ? viewRect() : rect();
    const base = { panoId: u.pano || mc ? u.panoId || null : null, lat: u.lat, lng: u.lng, kind: u.kind, canvasRect: rc, elementRect: rect(), t: performance.now(), transition: S.transition, panoPending: S.panoPending };
    if (mc && S.meta) { const m = S.meta.get(u.panoId); if (m) { base.lat = m.lat; base.lng = m.lng; } }
    const live = !S.disabled && !!S.mat && !!S.R && (!!u.pano || mc);
    if (live) {
      const A = camAxes(S.mat), E = axesToEnu(S.R, A), yp = yawPitch(E.f);
      const moving = performance.now() - S.matT < 150;
      return Object.assign(base, { heading: yp.yaw, pitch: yp.pitch, fov: 2 * Math.atan(1 / A.fy) / D, hfov: 2 * Math.atan(1 / A.fx) / D, roll: Math.asin(Math.max(-1, Math.min(1, E.r[2]))) / D,
        live: true, moving: moving, settled: mc ? !moving : S.urlT > S.matT, source: 'matrix', cal: S.calSource, t: S.matT }); // (no address is written after a move where it has no camera values)
    }
    if (!u.pano) return Object.assign(base, { live: false, moving: false, source: null });
    const asp = rc ? rc.width / rc.height : 16 / 9;
    return Object.assign(base, { heading: u.heading, pitch: u.tilt - 90, fov: u.fov, hfov: 2 * Math.atan(Math.tan(u.fov * D / 2) * asp) / D, roll: 0, live: false, moving: false, settled: true, source: 'url' });
  }
  function emit() {
    const p = computePose(); S.lastPose = p;
    for (const cb of S.listeners) { try { cb(p); } catch (e) { console.warn('[PAAPose] listener', e); } }
  }

  function calibrateFromUrl(reason, tries) {
    const u = S.url; if (!u.pano || !S.mat || S.disabled) return;
    const retry = () => { if ((tries | 0) < 4) { clearTimeout(S.calRetry); S.calRetry = setTimeout(() => { calibrateFromUrl('retry', (tries | 0) + 1); emit(); }, 250); } };
    if (!isOrigin(S.mat)) return retry(); // mid-transition; try again shortly
    if (S.R && performance.now() - S.matT < 200) return retry(); // address written while still moving: don't trust it yet
    const A = camAxes(S.mat), target = enuAxes(u.heading, u.tilt - 90);
    // health check independent of R: fov must match the address (rounded to 0.1 deg)
    const fovM = 2 * Math.atan(1 / A.fy) / D, fovErr = Math.abs(fovM - u.fov);
    const rc = rect(), aspErr = rc ? Math.abs((A.fy / A.fx) - rc.width / rc.height * (S.vp && S.cw ? (S.vp[2] / S.cw) / (S.vp[3] / S.ch) : 1)) : 0;
    const entry = { t: performance.now(), reason, panoId: u.panoId, fovErr, aspErr };
    if (S.R) { const E = axesToEnu(S.R, A); entry.headErr = angBetween(E.f, target.f); entry.rollErr = Math.abs(Math.asin(E.r[2]) / D); entry.prevSource = S.calSource; }
    const samePano = S.calPano && S.calPano === u.panoId && S.calSource === 'url';
    if (fovErr > 0.6 || aspErr > 0.02) { // the matrix we hold is not the panorama camera any more
      S.failures++; entry.fail = true;
      if (S.failures === 1) { S.R = null; S.mat = null; document.dispatchEvent(new CustomEvent('paa-pose-reset')); entry.reset = true; } // re-detect the panorama program once
      if (S.failures >= 3) { S.disabled = true; entry.disabled = true; console.warn('[PAAPose] matrix hook inconsistent with address; rest-only mode'); }
    } else {
      S.failures = 0;
      if (!samePano || entry.headErr === undefined || entry.headErr > 0.05) { S.R = rotFromAxes(A, target); S.calPano = u.panoId; S.calSource = 'url'; entry.recal = true; }
      const mr = S.meta && u.panoId ? metaRotation(S.meta.get(u.panoId)) : null; // how far the metadata's own rotation is from the address-based one (degrees)
      if (mr && S.R) entry.metaDiff = rotAngle(S.R, mr);
    }
    S.panoPending = false;
    S.calLog.push(entry); if (S.calLog.length > 50) S.calLog.shift();
  }

  /* The same job where the address has no camera values: R comes from the panorama's metadata. The panorama id is in the address; the metadata
     arrives with the page's own request for that panorama (meta.js asks for it once itself when it is missing). Nothing here depends on
     where the view is looking, so it needs no rest. */
  function calibrateFromMeta(reason, tries) {
    const u = S.url; if (!u.noCam || !u.panoId || !S.mat || S.disabled) return;
    if (S.calSource === 'meta' && S.calPano === u.panoId) return;
    const meta = S.meta && S.meta.get(u.panoId);
    if (!meta) { if (S.meta && S.meta.need) S.meta.need(u.panoId, u.kind === 'user' ? 10 : 2); return; } // metaArrived() calls us again
    const retry = () => { if ((tries | 0) < 6) { clearTimeout(S.calRetry); S.calRetry = setTimeout(() => { calibrateFromMeta('retry', (tries | 0) + 1); emit(); }, 250); } };
    if (!isOrigin(S.mat)) return retry(); // mid-transition: the matrix is not the new panorama's yet
    const R = metaRotation(meta); if (!R) return;
    const A = camAxes(S.mat), rc = rect();
    const aspErr = rc ? Math.abs((A.fy / A.fx) - rc.width / rc.height * (S.vp && S.cw ? (S.vp[2] / S.cw) / (S.vp[3] / S.ch) : 1)) : 0;
    const entry = { t: performance.now(), reason, panoId: u.panoId, aspErr, source: 'meta', heading: meta.heading, tilt: meta.tilt, roll: meta.roll };
    if (aspErr > 0.02) { // the matrix we hold is not the panorama camera: re-detect the panorama program once, as for the address
      S.failures++; entry.fail = true;
      if (S.failures === 1) { S.R = null; S.mat = null; document.dispatchEvent(new CustomEvent('paa-pose-reset')); entry.reset = true; }
      if (S.failures >= 3) { S.disabled = true; entry.disabled = true; console.warn('[PAAPose] matrix hook inconsistent; rest-only mode'); }
    } else {
      S.failures = 0; S.R = R; S.calPano = u.panoId; S.calSource = 'meta'; S.metaPano = u.panoId; entry.recal = true;
    }
    S.panoPending = false;
    S.calLog.push(entry); if (S.calLog.length > 50) S.calLog.shift();
  }

  function onUrl(href, t) {
    const u = parseUrl(href || location.href);
    S.urlT = t || performance.now();
    if (u.href === S.url.href && !S.panoPending) { emit(); return; } // same address re-written: still a rest signal
    S.url = u;
    rect(true);
    if (u.pano) calibrateFromUrl('url');
    else if (u.noCam) calibrateFromMeta('url');
    else { S.mat = null; S.R = null; S.calPano = null; S.calSource = null; S.metaPano = null; S.transition = false; S.panoPending = false; } // left Street View
    emit();
  }

  function onFrame(msg) {
    if (S.disabled) return;
    const mats = msg.mats; if (!mats || !mats.length) return;
    const cur = mats[mats.length - 1];
    S.hookFrames++;
    const multi = mats.length >= 2;
    const trans = !isOrigin(cur) || multi;
    let landed = false;
    if (trans && S.R) {
      if (!S.transition) { // first frame of a move to another panorama
        S.transition = true; S.panoPending = true; S.Rold = S.R;
        S.carryE = S.mat ? axesToEnu(S.R, camAxes(S.mat)) : null;
      }
      if (multi && S.Rold) S.carryE = axesToEnu(S.Rold, camAxes(mats[0])); // old pano drawn first, same camera
      if (S.carryE) { S.R = rotFromAxes(camAxes(cur), S.carryE); S.calSource = 'carry'; S.calPano = null; }
    } else if (!trans && S.transition) {
      S.transition = false; S.Rold = null; landed = true;
    }
    S.mat = cur; S.matT = msg.t; S.vp = msg.vp; S.cw = msg.cw; S.ch = msg.ch;
    // the first still frame after a flight: where the address has no camera values and the new panorama is not calibrated yet (the address changed
    // mid-flight, and the retries that were started then have run out or were throttled in a background tab), do it now. Once per landing, no timer.
    if (landed && S.url.noCam && S.url.panoId !== S.metaPano) calibrateFromMeta('landed');
    if (!S.R && S.url.pano && !trans) calibrateFromUrl('first-frame');
    else if (!S.R && S.url.noCam && !trans) calibrateFromMeta('first-frame');
    emit();
    clearTimeout(S.settleTimer); S.settleTimer = setTimeout(emit, 160); // one more callback once motion stops
  }

  document.addEventListener(EVT_FRAME, (e) => { try { onFrame(JSON.parse(e.detail)); } catch (err) {} }, true);
  document.addEventListener(EVT_URL, (e) => { try { const d = JSON.parse(e.detail); onUrl(d.href, d.t); } catch (err) {} }, true);
  addEventListener('popstate', () => onUrl(location.href), true);
  setInterval(() => { if (location.href !== S.url.href) onUrl(location.href); }, 250); // fallback when the MAIN-world hook is absent

  globalThis.PAAPose = {
    version: '0.2-spike',
    getPose: () => computePose(),
    onPose(cb) { S.listeners.add(cb); return () => S.listeners.delete(cb); },
    screenToDir: (x, y, src) => screenToDir(x, y, src),
    dirToScreen: (yaw, pitch, src) => dirToScreen(yaw, pitch, src),
    quadToMatrix3d,
    HIDDEN_MATRIX: HIDDEN,
    parseUrl,
    /* meta.js hands over its cache (get, need) and calls metaArrived(meta) for every panorama's metadata as it arrives */
    setMetaSource(src) { S.meta = src; if (S.url.noCam) { calibrateFromMeta('source'); emit(); } },
    metaArrived(m) { if (S.url.noCam && m && S.url.panoId === m.panoId && S.calPano !== m.panoId) { calibrateFromMeta('meta'); emit(); } },
    metaRotation,
    /* degrees between the rotation now in use and the one the current panorama's metadata gives (null when either is missing): the check that
       the two ways of calibrating agree */
    metaDiff() { const m = S.meta && S.url.panoId ? metaRotation(S.meta.get(S.url.panoId)) : null; return m && S.R ? rotAngle(S.R, m) : null; },
    _debug: () => ({ R: S.R, hookFrames: S.hookFrames, calSource: S.calSource, calPano: S.calPano, disabled: S.disabled, failures: S.failures, calLog: S.calLog.slice(-20), url: S.url, mat: S.mat, matT: S.matT, urlT: S.urlT }),
  };
})();
