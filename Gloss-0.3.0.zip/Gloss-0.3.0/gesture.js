/* Gloss: the Option gesture. Option-drag draws a box, Option-click points at a spot, adding Shift
   means "I will type my own question". These behaviours are tested and carried over unchanged from v0.1.1:
   - without Option nothing is touched; the gesture swallows its own pointer/mouse events, nothing else
   - Esc mid-drag cancels the drawing and keeps swallowing events until the button is up (otherwise the
     release clicks through and Maps walks you down the street)
   - a drag past the edge of the picture is clamped to what is on screen; a very thin box is grown
   - window blur cancels
   New in v0.2: the box is clamped to the panorama's own rectangle (pose.canvasRect), a press that starts
   outside the panorama is not ours, and the finished gesture is handed to PAA.ask. */
(function () {
  'use strict';
  const PAA = self.PAA;
  const P = self.PAAPose;

  const MIN_DRAG = 6; // px; less than this is a click, "this thing here"
  const POINT_FRACTION = 0.35; // click crop side as a fraction of the smaller picture dimension
  const MIN_BOX = 48; // very small drags are grown to this many CSS px so the crop is usable

  let g = null; // live gesture {x0,y0,x1,y1,typed}
  let draining = false; // cancelled with the button still down: keep swallowing until it goes up
  let afterUntil = 0; // brief window after release in which stray click-type events are still swallowed
  let onCommit = null;

  const LIVE = new Set([
    'pointerdown', 'pointermove', 'pointerup', 'pointercancel', 'mousedown', 'mousemove', 'mouseup',
    'click', 'auxclick', 'dblclick', 'contextmenu', 'dragstart', 'selectstart',
  ]);
  const AFTER = new Set(['click', 'auxclick', 'dblclick', 'contextmenu']);
  const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));

  function block(e) {
    e.preventDefault();
    e.stopImmediatePropagation();
  }

  /* Where a gesture may happen and be clamped to: the panorama's rectangle when the camera is known, else the window. */
  function bounds() {
    const iw = window.innerWidth, ih = window.innerHeight;
    const pose = P.getPose();
    const cr = pose.panoId && pose.canvasRect;
    if (!cr) return { l: 0, t: 0, r: iw, b: ih };
    return { l: Math.max(0, cr.x), t: Math.max(0, cr.y), r: Math.min(iw, cr.x + cr.width), b: Math.min(ih, cr.y + cr.height) };
  }

  /* Turn a finished gesture into what the ask needs, using the picture as it is right now.
     {kind, rect (the crop, CSS px, inside the picture), markRect (what the mark outlines), point, iw, ih, typed} */
  function planGesture(gs) {
    const b = bounds();
    const iw = window.innerWidth;
    const ih = window.innerHeight;
    const bw = b.r - b.l, bh = b.b - b.t;
    let kind, rect, markRect;
    let point = null;
    if (Math.hypot(gs.x1 - gs.x0, gs.y1 - gs.y0) < MIN_DRAG) {
      kind = 'point';
      point = { x: clamp(gs.x1, b.l, b.r), y: clamp(gs.y1, b.t, b.b) };
      const side = Math.round(POINT_FRACTION * Math.min(bw, bh));
      rect = {
        x: Math.min(Math.max(b.l, point.x - side / 2), Math.max(b.l, b.r - side)),
        y: Math.min(Math.max(b.t, point.y - side / 2), Math.max(b.t, b.b - side)),
        w: Math.min(side, bw),
        h: Math.min(side, bh),
      };
      const d = PAA.POINT_RING;
      markRect = { x: point.x - d / 2, y: point.y - d / 2, w: d, h: d };
    } else {
      kind = 'box';
      // The drag may run past the edge: clamp the corners first, so the box shrinks to what is on screen.
      let x0 = clamp(Math.min(gs.x0, gs.x1), b.l, b.r);
      let x1 = clamp(Math.max(gs.x0, gs.x1), b.l, b.r);
      let y0 = clamp(Math.min(gs.y0, gs.y1), b.t, b.b);
      let y1 = clamp(Math.max(gs.y0, gs.y1), b.t, b.b);
      // A very thin box is grown to MIN_BOX around its centre, then slid back inside the picture.
      if (x1 - x0 < MIN_BOX) {
        const w = Math.min(MIN_BOX, bw);
        x0 = clamp((x0 + x1) / 2 - w / 2, b.l, b.r - w);
        x1 = x0 + w;
      }
      if (y1 - y0 < MIN_BOX) {
        const h = Math.min(MIN_BOX, bh);
        y0 = clamp((y0 + y1) / 2 - h / 2, b.t, b.b - h);
        y1 = y0 + h;
      }
      rect = { x: x0, y: y0, w: x1 - x0, h: y1 - y0 };
      markRect = { x: rect.x, y: rect.y, w: rect.w, h: rect.h };
    }
    return { kind: kind, rect: rect, markRect: markRect, point: point, iw: iw, ih: ih, typed: gs.typed };
  }

  function drawBox() {
    if (!g) return;
    const b = bounds();
    const point = Math.hypot(g.x1 - g.x0, g.y1 - g.y0) < MIN_DRAG;
    if (point) {
      PAA.layer.drawing.show({ point: true, x: clamp(g.x1, b.l, b.r), y: clamp(g.y1, b.t, b.b) });
    } else {
      const x0 = clamp(Math.min(g.x0, g.x1), b.l, b.r), x1 = clamp(Math.max(g.x0, g.x1), b.l, b.r);
      const y0 = clamp(Math.min(g.y0, g.y1), b.t, b.b), y1 = clamp(Math.max(g.y0, g.y1), b.t, b.b);
      PAA.layer.drawing.show({ point: false, x: x0, y: y0, w: x1 - x0, h: y1 - y0 });
    }
  }

  /* commit: the button went up, ask. Otherwise the gesture is cancelled; stillDown says the button is
     still held, so its release must be swallowed too (see `draining`). */
  function endGesture(commit, stillDown) {
    const done = g;
    g = null;
    draining = !commit && !!stillDown;
    afterUntil = performance.now() + 400;
    PAA.layer.drawing.hide();
    if (commit && done && onCommit) onCommit(planGesture(done));
  }

  function onPointerish(e) {
    if (!e.isTrusted) return;
    const t = e.type;
    const now = performance.now();

    if (t === 'pointerdown' || t === 'mousedown') {
      if (g) return block(e); // duplicate of the pointerdown that already began the gesture
      draining = false; // a fresh press: whatever we were draining must have ended without us seeing it
      let mine = e.altKey && e.button === 0 && !PAA.layer.inOurs(e);
      if (mine) {
        const b = bounds(); // a press outside the panorama (side panel, split-view map) is not ours
        if (e.clientX < b.l || e.clientX > b.r || e.clientY < b.t || e.clientY > b.b) mine = false;
      }
      if (!mine) {
        afterUntil = 0; // an ordinary press: its click must reach the page
        return;
      }
      block(e);
      g = { x0: e.clientX, y0: e.clientY, x1: e.clientX, y1: e.clientY, typed: e.shiftKey };
      drawBox();
      return;
    }
    if (draining) {
      // The gesture was cancelled (Esc, window blur) but the button is still down: the release, and the
      // click it would produce, belong to the cancelled gesture and must not reach the page.
      if (!LIVE.has(t)) return;
      block(e);
      const moved = t === 'pointermove' || t === 'mousemove';
      if (t === 'pointerup' || t === 'mouseup' || t === 'pointercancel' || (moved && e.buttons === 0)) {
        draining = false;
        afterUntil = now + 400;
      }
      return;
    }
    if (g) {
      if (!LIVE.has(t)) return;
      block(e);
      if (t === 'pointermove' || t === 'mousemove') {
        if (e.buttons === 0) return endGesture(false, false); // button released outside the window
        g.x1 = e.clientX;
        g.y1 = e.clientY;
        if (e.shiftKey) g.typed = true;
        drawBox();
      } else if (t === 'pointerup' || t === 'mouseup') {
        g.x1 = e.clientX;
        g.y1 = e.clientY;
        if (e.shiftKey) g.typed = true;
        endGesture(true);
      } else if (t === 'pointercancel') {
        endGesture(false, false);
      }
      return;
    }
    if (now < afterUntil && AFTER.has(t) && !PAA.layer.inOurs(e)) block(e);
  }

  PAA.gesture = {
    init(commitFn) {
      onCommit = commitFn;
      LIVE.forEach((t) => window.addEventListener(t, onPointerish, { capture: true, passive: false }));
      window.addEventListener('blur', () => {
        PAA.layer.setAlt(false);
        if (g) endGesture(false, true);
      });
      ['keydown', 'keyup', 'pointermove'].forEach((t) => window.addEventListener(t, (e) => { if (e.isTrusted) PAA.layer.setAlt(e.altKey); }, { capture: true, passive: true }));
    },
    active: () => !!g,
    /* Esc while the button is down */
    cancel: (stillDown) => endGesture(false, stillDown !== false),
    planGesture: planGesture, // exposed for the harness
  };
})();
