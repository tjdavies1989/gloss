/* Gloss: marks seen from other panoramas (stage 2). Pure functions: no DOM, no Chrome, no state. Loaded in the page and in node (the
   unit tests run them on saved metadata). They take the PAAWorld module (world.js) as an argument.

   What the numbers are (research/world/NOTES.txt, measured over 44 pairs in 4 cities):
     - at ask time the depth map of the panorama gives the mark's centre a point in the world (worldPoint);
     - from a neighbouring panorama that point is computed back to a direction (viewFrom): median 1 degree (about 10 px at the default
       zoom) from the real feature, 90 % within 4 degrees, worst about 10 degrees for close things seen at a grazing angle.
   So a mark seen from elsewhere is a SOFT ANCHOR: a small ring where the point should be and a caption on a short leader, never a box.
   A panorama with a coarse depth map (fewer than about 20 planes), a user photo sphere or old imagery (one plane) has no usable depth. */
(function (root) {
  'use strict';
  const D = Math.PI / 180;

  const MAX_DEPTH_M = 200; // a mark farther than this from the panorama it was asked in is not placed: the depth map is not that good out there
  const SHOW_MAX_M = 120; // a mark is shown from another panorama only within this distance
  const SHOW_MIN_M = 2; // closer than this the direction means nothing
  const FAR_FORM_M = 25; // beyond this the caption takes its small form
  const LOW_M = 12; // within this distance, ...
  const GRAZE_COS = 0.42; // ... seen along the wall (the ray less than about 25 degrees from the surface) the point is low confidence

  const r = (v, k) => Math.round(v * k) / k;
  const median = (a) => { const s = a.slice().sort((x, y) => x - y); return s.length % 2 ? s[(s.length - 1) / 2] : (s[s.length / 2 - 1] + s[s.length / 2]) / 2; };
  const enu = (yaw, pitch) => [Math.cos(pitch * D) * Math.sin(yaw * D), Math.cos(pitch * D) * Math.cos(yaw * D), Math.sin(pitch * D)];

  /* Is this panorama's depth map good enough to place things from? Official imagery with walls in its depth map and more than a
     handful of planes. (A user photo sphere has one plane at 3.00 m; 2013 Akihabara and all of South Korea have one plane; a Bangkok
     street under the skytrain had 9 and put signs 19 to 30 m away at 2 to 5 m.) */
  function depthUsable(meta) {
    return !!(meta && meta.official && meta.type === 2 && meta.depth && meta.hasDepth && !meta.coarseDepth);
  }

  /* The world point of a mark: from the panorama it was asked in (its metadata) and its directions as saved (dirs.c = the centre; dirs.tl
     ... for a box). { lat, lng, alt, hag, dist, normal, method: 'depth' }, or null when there is no usable depth there or nothing solid
     at the mark. normal is the unit normal of the surface hit (east/north/up, pointing back to the camera); it lets a later view tell
     whether it looks at the back of that wall. If the centre falls on sky or the edge of the depth map, the distance is the median of
     what lies half way to each corner. */
  function worldPoint(W, meta, dirs) {
    if (!depthUsable(meta) || !dirs || !dirs.c) return null;
    const c = dirs.c;
    let d = W.depthAt(meta, c.yaw, c.pitch);
    let nAt = c;
    if (d == null) {
      const ds = [];
      let first = null;
      ['tl', 'tr', 'br', 'bl'].forEach((k) => {
        const q = dirs[k];
        if (!q) return;
        let dy = ((q.yaw - c.yaw + 540) % 360) - 180; // half way from the centre to the corner (across the compass seam)
        const s = { yaw: (c.yaw + dy / 2 + 360) % 360, pitch: (c.pitch + q.pitch) / 2 };
        const v = W.depthAt(meta, s.yaw, s.pitch);
        if (v != null) { ds.push(v); if (!first) first = s; }
      });
      if (!ds.length) return null;
      d = median(ds);
      nAt = first;
    }
    if (!(d > 0) || d > MAX_DEPTH_M) return null;
    const pt = W.toWorld(meta, c.yaw, c.pitch, d);
    const n = W.surfaceNormal(meta, nAt.yaw, nAt.pitch);
    return {
      lat: r(pt.lat, 1e7), lng: r(pt.lng, 1e7),
      alt: pt.alt == null ? null : r(pt.alt, 100), hag: r(pt.hag, 100),
      dist: r(d, 10),
      normal: n ? n.map((x) => r(x, 1000)) : null,
      method: 'depth',
    };
  }

  /* Where a saved world point is, seen from another panorama (its metadata). Everything the page needs to draw the soft anchor:
       yaw, pitch   compass degrees from this panorama to the point
       dist         metres
       occluded     true: probably hidden (a nearer surface in this panorama's own depth map, or this view looks at the back of the wall the
                    mark sits on); false: probably in view; null: cannot tell (this panorama has no usable depth and no wall normal)
       low          low confidence: within LOW_M and seen along the wall (grazing), so a metre of error is many degrees
       far          beyond FAR_FORM_M: the caption takes its small form
       dim          occluded or low: drawn dimmed, not removed
       show         within SHOW_MIN_M .. SHOW_MAX_M, official panorama only (never to or from a user photo sphere) */
  function viewFrom(W, meta, world) {
    if (!meta || !world || typeof world.lat !== 'number' || typeof world.lng !== 'number' || meta.type !== 2 || !meta.official) return { show: false };
    const f = W.fromWorld(meta, world);
    const out = { yaw: f.yaw, pitch: f.pitch, dist: f.dist, occluded: null, low: false, far: f.dist > FAR_FORM_M, dim: false, show: f.dist >= SHOW_MIN_M && f.dist <= SHOW_MAX_M, cosView: null };
    if (!out.show) return out;
    const n = world.normal;
    if (n && Math.abs(n[2]) < 0.5) { // a wall (a ground hit says nothing about how an object on it faces)
      const v = enu(f.yaw, f.pitch);
      out.cosView = -(v[0] * n[0] + v[1] * n[1] + v[2] * n[2]);
      if (out.dist < LOW_M && out.cosView < GRAZE_COS) out.low = true;
    }
    // this panorama's own depth only when it can be trusted; the wall-normal test needs none
    const mm = depthUsable(meta) ? meta : Object.assign({}, meta, { depth: null });
    out.occluded = W.isOccluded(mm, world, n ? { normal: n } : {});
    out.dim = out.occluded === true || out.low;
    return out;
  }

  const API = { depthUsable: depthUsable, worldPoint: worldPoint, viewFrom: viewFrom, SHOW_MAX_M: SHOW_MAX_M, SHOW_MIN_M: SHOW_MIN_M, FAR_FORM_M: FAR_FORM_M, LOW_M: LOW_M, GRAZE_COS: GRAZE_COS, MAX_DEPTH_M: MAX_DEPTH_M };
  root.PAAAnchor = API;
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
})(typeof self !== 'undefined' ? self : globalThis);
