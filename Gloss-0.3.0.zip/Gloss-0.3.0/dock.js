/* Gloss: the dock, the first-run hint, and the box they live in.
   The dock is the only permanent control: a small glass pill at the top right of the Street View picture, under
   Google's Share button (right 14 px, top 78 px of the picture; the mock). It shows the Gloss logo and a
   count ("4 here"), or only the logo when nothing is saved here. Clicking it opens the notebook (book.js).
   Everything sits in one absolutely placed box that follows the picture's rectangle (pose.canvasRect), so the
   mock's offsets hold when the picture does not fill the window (side panel, split view). The box is only
   moved when the rectangle changes. */
(function () {
  'use strict';
  const PAA = self.PAA;
  const P = self.PAAPose;

  const HINT_SESSIONS = 3; // the hint shows in the first three sessions
  const HINT_MS = 8000;
  const NOTICE_MS = 9000;

  let box = null, dockEl = null, countEl = null, hintEl = null;
  let lastKey = '';
  let hintShown = false, hintTimer = 0;

  const el = (tag, cls, text) => {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== undefined) e.textContent = text;
    return e;
  };

  function mount() {
    if (box && box.isConnected && dockEl) return true;
    if (!PAA.layer.ensure()) return false; // (re-attaches our host if the page removed it)
    const pane = PAA.layer.pane();
    if (!pane) return false;
    if (box && box.parentNode === pane) return true;
    if (dockEl && self.PAAGlass) PAAGlass.forget(dockEl); // (the page removed the old one with its box)
    box = el('div', 'rect');
    dockEl = el('div', 'dock big solo');
    dockEl.setAttribute('role', 'button');
    dockEl.title = 'Gloss: notes from this place';
    PAA.layer.glass(dockEl, 'pill');
    PAA.layer.sunOn(dockEl);
    const logo = el('img', 'logo');
    logo.src = PAA.logoUri; // the Gloss logo (design/brand/gloss.svg, inlined into css.js by test/gen-css.js)
    logo.alt = '';
    logo.draggable = false;
    dockEl.appendChild(logo);
    countEl = el('span');
    dockEl.appendChild(countEl);
    dockEl.addEventListener('click', (e) => {
      e.stopPropagation();
      PAA.book.toggle();
    });
    box.appendChild(dockEl);
    pane.appendChild(box);
    lastKey = '';
    applyRect(P.getPose()); // a page with no camera never sends pose events: size the box now
    refresh();
    return true;
  }

  /* the picture's rectangle inside the window (the whole window when the camera is not known) */
  function rectOf(pose) {
    const iw = window.innerWidth, ih = window.innerHeight;
    const cr = pose && pose.panoId && pose.canvasRect;
    if (!cr) return { x: 0, y: 0, w: iw, h: ih };
    const x = Math.max(0, cr.x), y = Math.max(0, cr.y);
    return { x: x, y: y, w: Math.max(0, Math.min(iw, cr.x + cr.width) - x), h: Math.max(0, Math.min(ih, cr.y + cr.height) - y) };
  }

  function layout(pose) {
    if (!mount()) return;
    applyRect(pose);
  }

  function applyRect(pose) {
    const r = rectOf(pose);
    const key = Math.round(r.x) + ',' + Math.round(r.y) + ',' + Math.round(r.w) + ',' + Math.round(r.h);
    if (key === lastKey) return;
    lastKey = key;
    const s = box.style;
    s.left = r.x + 'px'; s.top = r.y + 'px'; s.width = r.w + 'px'; s.height = r.h + 'px';
  }

  /* the count and the look follow the marks and the density */
  function refresh() {
    if (!dockEl) return;
    const n = PAA.book.hereMarks().length;
    const text = n ? n + ' here' : '';
    if (countEl.textContent !== text) countEl.textContent = text;
    dockEl.classList.toggle('solo', !n);
    dockEl.classList.toggle('off', PAA.prefs.density === 'off');
    dockEl.classList.toggle('open', PAA.book.isOpen());
    PAA.book.refresh();
  }

  /* ---------------- first-run hint (flow P) ---------------- */

  const isMac = /Mac|iPhone|iPad/i.test(navigator.platform || navigator.userAgent || '');

  function hideHint() {
    clearTimeout(hintTimer);
    if (!hintEl) return;
    const h = hintEl;
    hintEl = null;
    h.classList.add('fade');
    setTimeout(() => { if (self.PAAGlass) PAAGlass.forget(h); h.remove(); }, 400);
  }

  function showHint() {
    if (hintShown || !mount()) return;
    hintShown = true;
    PAA.prefs.countHint();
    hintEl = PAA.layer.glass(el('div', 'hint'));
    const t = el('span', 't');
    t.append(el('b', '', 'Gloss'), document.createTextNode(' Hold '), el('kbd', '', isMac ? '⌥' : 'Alt'), document.createTextNode(' and drag over anything'));
    hintEl.appendChild(t);
    box.appendChild(hintEl);
    PAA.layer.flash(hintEl);
    hintTimer = setTimeout(hideHint, HINT_MS);
  }

  /* A short message beside the dock (an answer failed on a panorama he has left, so no card can say so). It uses the hint's glass and goes by itself. */
  function notice(text) {
    if (!mount()) return;
    hideHint();
    hintEl = PAA.layer.glass(el('div', 'hint'));
    hintEl.classList.add('warn');
    hintEl.appendChild(el('span', 't', text));
    box.appendChild(hintEl);
    PAA.layer.flash(hintEl);
    hintTimer = setTimeout(hideHint, NOTICE_MS);
  }

  /* For the first three sessions. A session starts when a picture we can ask about is on screen. */
  function maybeHint(pose) {
    if (hintShown) return;
    PAA.prefs.ready.then(() => {
      if (hintShown) return;
      if (PAA.prefs.hints >= HINT_SESSIONS) { hintShown = true; return; } // quota used up: stop asking (this runs every frame)
      if (PAA.book.isOpen() || PAA.layer.all().length) return;
      showHint();
    });
  }

  PAA.dock = {
    init() {
      mount();
      PAA.layer.addFrameHook((pose) => {
        layout(pose);
        if (pose.panoId) maybeHint(pose);
      });
      addEventListener('resize', () => layout(P.getPose()));
      // a page with no camera (a test page, Yandex): no pose events will announce a picture, so ask once the page is up
      setTimeout(() => { if (!P.getPose().panoId && !/(^|\.)google\./.test(location.hostname)) maybeHint(P.getPose()); }, 1500);
    },
    refresh: refresh,
    layout: () => layout(P.getPose()),
    box: () => (mount() ? box : null),
    hideHint: hideHint,
    notice: notice,
    el: () => dockEl,
  };
})();
