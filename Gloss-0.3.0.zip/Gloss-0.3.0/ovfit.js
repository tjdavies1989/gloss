/* Gloss: English drawn over the sign (stage 3), the pure part: which LINES entries may be drawn over, how big the letters are, what
   colour. No DOM, no Chrome; loaded by the page (overlay.js uses it) and by node tests.

   A label that lands on the wrong line is worse than none, so a line is drawn over only when it passes every gate:
     - it has a box, its four corner directions and a translation that is not just the original again;
     - its box is clearly horizontal: at least 1.3 times wider than tall (vertical text stays in the card), and the lettering in it is not
       tilted by more than 9 degrees (the label is always level: on a sloped sign it would hang off the sign);
     - its text is not a cropped fragment (an ellipsis in the translation or the original: the model read part of a word at the picture's edge);
     - its height in the picture that was sent is at least 18 px (smaller text is where the model's boxes are poor);
     - its box lies wholly inside that picture (the model did not run off the edge: the text is not cut off);
     - it does not overlap another line's box by more than 30 % (two boxes on one spot: one of them is wrong);
     - its translation fits: the largest font that fits the box (two lines allowed, a little padding) is at least 9 px, at the zoom
       the question was asked at.
   If fewer than half of a mark's lines pass, the mark gets no automatic overlay (the lines that do pass can still be drawn when he
   presses Overlay on the card).

   A line is { b, sb, o, t, dirs, sd, bg, fg, ang, spill }: b the model's box (pixels of the picture sent, clamped), sb the box snapped to the
   ink (snap.js), o / t original and translation, dirs / sd the corner directions of b / sb, bg / fg colours [r,g,b] (the sign, the
   lettering) or null, ang the lettering's tilt in degrees or null, spill true when the model's box ran off the picture before it was clamped.
   cs = [w, h] of the picture sent; ref = [w, h] in CSS px of the rectangle that was pictured (what the picture is worth on screen). */
(function (root) {
  'use strict';

  const MIN_RATIO = 1.3;
  const MIN_LINE_H = 18;
  const MAX_OVERLAP = 0.3;
  const MAX_TILT = 10; // degrees: the lettering of a line may lean this much and still be drawn over with a level label (measured on the evalset's 78 wide boxes: 95 % read under 8.6, 2 over 10; the sloped Maid Casino board reads 14.5)
  const MIN_FONT = 9; // CSS px on screen: below this the label hides until he zooms in
  const LINE_H = 1.12; // line height, in fonts
  const SLACK = 0.96; // measured widths may be a little off in the browser: keep 4 % in hand

  /* ---------- colour ---------- */
  const lin = (v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); };
  const luminance = (c) => 0.2126 * lin(c[0]) + 0.7152 * lin(c[1]) + 0.0722 * lin(c[2]);
  function contrast(a, b) {
    const la = luminance(a), lb = luminance(b);
    return (Math.max(la, lb) + 0.05) / (Math.min(la, lb) + 0.05);
  }
  const LIGHT = [255, 255, 255];
  const DARK = [4, 10, 18];
  const GLOSS_LIFT = 0.08; // the gloss lightens the sign's colour a little under the type (measured: +5 to +13 per channel in the middle of a label, where the type sits)
  const mixWhite = (c, k) => [Math.round(c[0] + (255 - c[0]) * k), Math.round(c[1] + (255 - c[1]) * k), Math.round(c[2] + (255 - c[2]) * k)];
  const dist = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2]);
  /* What the type sits on as drawn: light type is judged against the sign's colour lightened by the gloss, dark type (which the gloss helps) against the colour itself. */
  const readsOn = (c, bg) => contrast(c, luminance(c) > luminance(bg) ? mixWhite(bg, GLOSS_LIFT) : bg);

  /* The text colour. The lettering's own colour when it reads on the sign (contrast 4.5 or better as drawn). Otherwise the sign keeps its
     polarity: lettering that was darker than the sign stays dark, lighter stays light, as long as that reads at 3 or better (the text shadow
     helps from there); only when it does not, black or white, whichever reads better. */
  function pickText(bg, fg) {
    if (!bg) return { color: LIGHT, from: 'auto' };
    if (fg && readsOn(fg, bg) >= 4.5) return { color: fg, from: 'ink' };
    const dark = readsOn(DARK, bg), light = readsOn(LIGHT, bg);
    if (fg) {
      const wantDark = luminance(fg) < luminance(bg);
      if ((wantDark ? dark : light) >= 3) return { color: wantDark ? DARK : LIGHT, from: 'polarity' };
    }
    return { color: light >= dark ? LIGHT : DARK, from: 'auto' };
  }

  /* Lines of one board (their sign colours are close) get one text colour, not a grey on one chip and white on the next: the candidate that
     reads best on the worst of them. items: the ok items of plan(). */
  function unifyColors(items) {
    const ok = items.filter((r) => r.ok && r.bg);
    const same = (a, b) => a[0] === b[0] && a[1] === b[1] && a[2] === b[2];
    // decided from the colours as picked per line, then applied together
    const next = ok.map((r) => {
      const peers = ok.filter((q) => dist(q.bg, r.bg) < 40);
      if (peers.length < 2 || peers.every((q) => same(q.color, peers[0].color))) return r.color;
      let best = null, bestV = -1;
      peers.map((q) => q.color).concat([LIGHT, DARK]).forEach((c) => {
        const v = Math.min.apply(null, peers.map((q) => readsOn(c, q.bg)));
        if (v > bestV + 1e-9) { bestV = v; best = c; }
      });
      return best;
    });
    ok.forEach((r, i) => { r.color = next[i]; });
  }

  /* ---------- fitting ---------- */

  /* Break a translation into at most two lines no wider than maxW at font size f. w100(text) = width of the text at 100 px.
     Returns the lines, or null when it cannot be done (a word wider than the box, or more than two lines needed). */
  function wrap(text, maxW, f, w100) {
    const width = (s) => (w100(s) * f) / 100;
    const limit = maxW * SLACK;
    if (width(text) <= limit) return [text];
    const words = text.split(/\s+/).filter(Boolean);
    if (words.length < 2) return null;
    let best = null, bestW = Infinity;
    for (let k = 1; k < words.length; k++) {
      const a = words.slice(0, k).join(' '), b = words.slice(k).join(' ');
      const wa = width(a), wb = width(b), w = Math.max(wa, wb);
      if (wa <= limit && wb <= limit && w < bestW) { best = [a, b]; bestW = w; }
    }
    return best;
  }

  /* The largest font (0.25 px steps) at which the text fits a w x h box with a little padding, in at most two lines.
     Returns { font, lines, lh, padX, padY } or null when not even 4 px fits. */
  function fitText(text, w, h, w100) {
    text = String(text || '').replace(/\s+/g, ' ').trim();
    if (!text || !(w > 0) || !(h > 0)) return null;
    const padY = Math.max(1, Math.round(h * 0.06));
    const padX = Math.max(3, Math.round(h * 0.12));
    const aw = w - 2 * padX, ah = h - 2 * padY;
    if (aw < 4 || ah < 4) return null;
    const fits = (f) => {
      const lines = wrap(text, aw, f, w100);
      return lines && lines.length * LINE_H * f <= ah + 0.01 ? lines : null;
    };
    let lo = 4, hi = Math.max(4, Math.floor((ah / LINE_H) * 4) / 4);
    if (!fits(lo)) return null;
    let bestLines = fits(lo);
    while (hi - lo > 0.25) {
      const mid = Math.round(((lo + hi) / 2) * 4) / 4;
      if (mid <= lo) break;
      const l = fits(mid);
      if (l) { lo = mid; bestLines = l; } else hi = mid;
    }
    if (fits(hi)) { lo = hi; bestLines = fits(hi); }
    return { font: lo, lines: bestLines, lh: LINE_H, padX: padX, padY: padY };
  }

  /* ---------- gates ---------- */
  const area = (b) => Math.max(0, b[2] - b[0]) * Math.max(0, b[3] - b[1]);
  function inter(a, b) {
    return area([Math.max(a[0], b[0]), Math.max(a[1], b[1]), Math.min(a[2], b[2]), Math.min(a[3], b[3])]);
  }
  const norm = (s) => String(s || '').toLowerCase().replace(/[^\p{L}\p{N}]/gu, '');

  const snapped = (l) => !!(l.sb && l.sd); // a snapped box is used with ITS OWN corner directions; without them the model's box and its directions
  const boxOf = (l) => (snapped(l) ? l.sb : l.b) || null;
  const dirsOf = (l) => (snapped(l) ? l.sd : l.dirs) || null;

  /* One line against the gates. others = the drawn boxes of the other lines. Returns { ok, why, ... } (why names the first gate that failed). */
  function gateLine(l, cs, ref, others, w100) {
    const box = boxOf(l);
    if (!box) return { ok: false, why: 'nobox' };
    const dirs = dirsOf(l);
    if (!dirs || !dirs.tl || !dirs.tr || !dirs.br || !dirs.bl) return { ok: false, why: 'nodirs' };
    const t = String(l.t || '').trim();
    if (!t) return { ok: false, why: 'notext' };
    if (l.o && norm(l.o) && norm(l.o) === norm(t)) return { ok: false, why: 'same' }; // already English: nothing to say
    const w = box[2] - box[0], h = box[3] - box[1];
    if (/…|\.{2,}/.test(t) || /…|\.{2,}/.test(String(l.o || ''))) return { ok: false, why: 'fragment' };
    if (!(w >= MIN_RATIO * h)) return { ok: false, why: 'vertical' };
    if (typeof l.ang === 'number' && Math.abs(l.ang) > MAX_TILT) return { ok: false, why: 'rotated' };
    if (h < MIN_LINE_H) return { ok: false, why: 'small' };
    if (l.spill || box[0] < 0 || box[1] < 0 || box[2] > cs[0] || box[3] > cs[1]) return { ok: false, why: 'edge' };
    const a = area(box);
    for (const o of others) if (o && inter(box, o) / Math.min(a, area(o)) > MAX_OVERLAP) return { ok: false, why: 'overlap' };
    // the size the label has on the screen the question was asked on (the base the browser lays the text out at)
    const bw = (w * ref[0]) / cs[0], bh = (h * ref[1]) / cs[1];
    const fit = fitText(t, bw, bh, w100);
    if (!fit || fit.font < MIN_FONT) return { ok: false, why: 'nofit' };
    const colors = pickText(l.bg || null, l.fg || null);
    return { ok: true, why: '', box: box, dirs: dirs, text: t, bw: bw, bh: bh, fit: fit, bg: l.bg || null, color: colors.color, colorFrom: colors.from };
  }

  /* All of a mark's lines. Returns { items: [{ i, ok, why, ... }], pass, total, auto }. total counts every line the card lists
     (one with a box or not); auto is true when at least half of them pass (and one at least). */
  function plan(lines, cs, ref, w100) {
    const list = (lines || []).map((l, i) => ({ l: l, i: i })).filter((x) => x.l && (x.l.o || x.l.t));
    const boxes = list.map((x) => boxOf(x.l));
    const items = list.map((x, k) => {
      const others = boxes.filter((b, j) => j !== k);
      const r = gateLine(x.l, cs, ref, others, w100);
      r.i = x.i;
      return r;
    });
    unifyColors(items);
    const pass = items.filter((r) => r.ok).length;
    return { items: items, pass: pass, total: items.length, auto: pass >= 1 && pass * 2 >= items.length };
  }

  const API = { MAX_TILT: MAX_TILT, readsOn: readsOn, MIN_RATIO: MIN_RATIO, MIN_LINE_H: MIN_LINE_H, MAX_OVERLAP: MAX_OVERLAP, MIN_FONT: MIN_FONT, LINE_H: LINE_H, luminance: luminance, contrast: contrast, pickText: pickText, wrap: wrap, fitText: fitText, gateLine: gateLine, plan: plan };
  root.PAAOvFit = API;
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
})(typeof self !== 'undefined' ? self : globalThis);
