/* Gloss: the size Claude will actually look at. Port of the reference implementation in Anthropic's
   "Coordinates and bounding boxes" doc (vision-coordinates), high-resolution tier = Claude 4.7 and later, including Haiku 5.5:
   max 2576 px long edge AND at most 4784 visual tokens, one token per 28x28 patch.
   Resize the crop to fitSize(w, h) BEFORE sending it so the pixel boxes the model returns map 1:1 onto the image you hold.
   (Measured: a 2576x2576 crop silently became ~1932x1932 and boxes came back in that smaller frame.)
   Works in the service worker (self.PAAFit) and node. */
(function (root) {
  'use strict';
  function tokens(w, h) { return Math.ceil(w / 28) * Math.ceil(h / 28); }
  function roundEven(x) { var f = Math.floor(x); if (x - f !== 0.5) return Math.round(x); return f % 2 === 0 ? f : f + 1; }
  function fitSize(width, height, maxEdge, maxTokens) {
    maxEdge = maxEdge || 2576; maxTokens = maxTokens || 4784;
    function fits(w, h) { return Math.ceil(w / 28) * 28 <= maxEdge && Math.ceil(h / 28) * 28 <= maxEdge && tokens(w, h) <= maxTokens; }
    if (fits(width, height)) return [width, height];
    if (height > width) { var r = fitSize(height, width, maxEdge, maxTokens); return [r[1], r[0]]; }
    var ar = width / height, lo = 1, hi = width;
    while (lo + 1 < hi) { var mid = Math.floor((lo + hi) / 2); if (fits(mid, Math.max(roundEven(mid / ar), 1))) lo = mid; else hi = mid; }
    return [lo, Math.max(roundEven(lo / ar), 1)];
  }
  var API = { fitSize: fitSize, tokens: tokens };
  root.PAAFit = API;
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
})(typeof self !== 'undefined' ? self : globalThis);
