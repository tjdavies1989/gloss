/* Gloss: the few things that are remembered between visits (not marks: those are in store.js).
     density   'labels' | 'dots' | 'off'    how much of the layer shows (flow K)
     hints     how many times the first-run hint has been shown (flow P: the first three sessions)
     overlayAuto  draw English over the text automatically (stage 3; default on; the settings page changes it)
     showCost  show what an answer or a repaint cost in the card's menu (default OFF: the owner's wish, "nobody wants to hear about small fractions of
               a penny"; the cost is always recorded with the note; the settings page changes it)
   Kept by the service worker (key "paaPrefs" in chrome.storage.local, which holds the API key and is closed to content
   scripts: see background.js), so every read and write here is a message. The worker also pushes a change to every
   other tab ('prefs-changed'), which is how a density chosen in one tab reaches the rest. Every call is guarded: the
   page must work when the extension is not there. */
(function () {
  'use strict';
  const PAA = self.PAA;
  const DENSITIES = ['labels', 'dots', 'off'];

  const state = { density: 'labels', hints: 0, overlayAuto: true, showCost: false };
  const listeners = [];
  const ovListeners = [];

  function apply(v) {
    let changed = false;
    if (v && DENSITIES.indexOf(v.density) >= 0 && v.density !== state.density) { state.density = v.density; changed = true; }
    if (v && typeof v.hints === 'number') state.hints = v.hints;
    if (v && typeof v.showCost === 'boolean') state.showCost = v.showCost; // (read when a menu is built: nothing to redraw)
    if (v && typeof v.overlayAuto === 'boolean' && v.overlayAuto !== state.overlayAuto) {
      state.overlayAuto = v.overlayAuto;
      ovListeners.slice().forEach((fn) => { try { fn(state.overlayAuto); } catch (e) { console.warn('[PAA] prefs', e); } });
    }
    if (changed) listeners.slice().forEach((fn) => { try { fn(state.density); } catch (e) { console.warn('[PAA] prefs', e); } });
  }

  function send(msg) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(msg, (r) => {
          void chrome.runtime.lastError;
          resolve(r && !r.error ? r : null);
        });
      } catch (e) {
        resolve(null); // extension gone: the choice lasts until the page closes
      }
    });
  }

  const ready = send({ type: 'prefs', op: 'get' }).then((r) => { if (r) apply(r); });

  try {
    chrome.runtime.onMessage.addListener((msg) => {
      if (msg && msg.type === 'prefs-changed') apply(msg.prefs);
    });
  } catch (e) { /* extension gone */ }

  PAA.prefs = {
    ready: ready,
    get density() { return state.density; },
    get hints() { return state.hints; },
    get overlayAuto() { return state.overlayAuto; },
    get showCost() { return state.showCost; },
    setDensity(d) {
      if (DENSITIES.indexOf(d) < 0 || d === state.density) return;
      apply({ density: d });
      send({ type: 'prefs', op: 'set', patch: { density: d } });
    },
    countHint() {
      state.hints++;
      send({ type: 'prefs', op: 'set', patch: { hints: state.hints } });
    },
    onChange(fn) { listeners.push(fn); },
    onOverlayChange(fn) { ovListeners.push(fn); },
    setShowCost(on) {
      on = !!on;
      if (on === state.showCost) return;
      state.showCost = on;
      send({ type: 'prefs', op: 'set', patch: { showCost: on } });
    },
    setOverlayAuto(on) {
      on = !!on;
      if (on === state.overlayAuto) return;
      apply({ overlayAuto: on });
      send({ type: 'prefs', op: 'set', patch: { overlayAuto: on } });
    },
  };
})();
