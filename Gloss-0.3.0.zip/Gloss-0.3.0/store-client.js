/* Gloss: the page's side of the saved-marks store. The page never touches chrome.storage for marks:
   it sends messages and the service worker (store.js) reads and writes. */
(function () {
  'use strict';
  const PAA = self.PAA;

  const RELOAD_MSG = 'The extension was reloaded or updated. Refresh this page to use it again.';
  const extGone = (e) => /context invalidated/i.test(String((e && e.message) || e));

  function call(msg) {
    return new Promise((resolve, reject) => {
      try {
        chrome.runtime.sendMessage(msg, (r) => {
          const err = chrome.runtime.lastError;
          if (err) return reject(new Error(extGone(err) ? RELOAD_MSG : err.message));
          if (r && r.error) return reject(new Error(r.error));
          resolve(r);
        });
      } catch (e) {
        reject(new Error(extGone(e) ? RELOAD_MSG : String((e && e.message) || e)));
      }
    });
  }

  PAA.RELOAD_MSG = RELOAD_MSG;
  PAA.extGone = extGone;
  PAA.store = {
    /* saved records of one panorama, oldest first */
    listPano: (pano) => call({ type: 'store', op: 'list', pano: pano }).then((r) => (r && r.records) || []),
    /* the latest saved marks from anywhere as notebook rows, newest first */
    recent: (limit) => call({ type: 'store', op: 'recent', limit: limit }).then((r) => (r && r.rows) || []),
    /* saved marks near a position that are not on panorama q.pano, nearest first (rows carry d, b, sub; with q.full also the whole record) */
    nearby: (q) => call({ type: 'store', op: 'nearby', lat: q.lat, lng: q.lng, radius: q.radius, pano: q.pano, limit: q.limit, worldOnly: q.worldOnly, full: q.full }).then((r) => (r && r.rows) || []),
    get: (id) => call({ type: 'store', op: 'get', id: id }).then((r) => (r && r.record) || null),
    save: (record) => call({ type: 'store', op: 'save', record: record }),
    remove: (id) => call({ type: 'store', op: 'remove', id: id }),
    discard: (id) => call({ type: 'store', op: 'discard', id: id }),
    /* stage 3: the worker snaps boxes (pixels of the picture sent for this mark) to the ink and reads the sign's colours */
    snap: (id, boxes) => call({ type: 'snap', id: id, boxes: boxes }),
    /* stage 4: the repaint picture of a mark ({ url, w, h, t } or null), and throwing it away */
    patch: (id) => call({ type: 'store', op: 'patch', id: id }).then((r) => (r && r.patch) || null),
    unpatch: (id) => call({ type: 'store', op: 'unpatch', id: id }),
  };
})();
