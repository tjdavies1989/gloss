/* Gloss: tolerant parser for the short-answer reply format.
   Plain classic script, no dependencies. Works in the browser/service worker (self.PAAParse) and in node (require).

   The reply is up to six labelled lines:
     SAY: ... / ORIG: ... / READ: ... / NOTE: ... / UNSURE: ... / LINES: [{"b":[x0,y0,x1,y1],"o":"..","t":".."}, ...]

   parseReply(text, opts) is pure and cheap: call it again with the whole text so far every time a chunk arrives
   (do not feed it deltas). It never throws. Result:
     { say, orig, read, note, unsure, lines, structured, noteIsFallback, linesTruncated, preface, active }
   - lines: array of {b:[x0,y0,x1,y1]|null, o, t}; only COMPLETE objects (a half-streamed object is held back).
   - structured: false when the reply ignored the format (then everything is in `note`, noteIsFallback = true).
   - linesTruncated: the LINES array was not closed (still streaming, or cut off) or its last object was incomplete.
   - saySynth: true when the first line had no 'SAY:' label and was taken as the answer anyway.
   - active: name of the field currently being written (lowercase) or '' - handy for a typing indicator.
   opts.final = true when the stream has ended (changes nothing but `linesTruncated` semantics stay true if cut off).

   looksOff(result) says whether a finished reply should be retried (see below).

   boxToPixels(b, convention, width, height) turns a model box into integer pixels of the image the box refers to
   (convention: 'px' | 'n1000' | 'frac'), fixing swapped corners and clamping. Returns null when unusable. */
(function (root) {
  'use strict';

  var LABELS = ['SAY', 'ORIG', 'READ', 'NOTE', 'UNSURE', 'LINES'];
  // optional bullet / heading / bold markers, the label, optional bold close, colon (ascii or full width)
  var LABEL_RE = /^[\s>#*_`\-•]*\**_*\s*(SAY|ORIG|READ|NOTE|UNSURE|LINES)\s*\**_*\s*[:：]\s*\**\s*(.*)$/i;
  var EMPTY_RE = /^(none|n\/a|na|nil|null|-+|—|–|\.+|no)$/i;

  function isLabelPrefix(s) {
    // "SA", "ORI" ... a reply that has only just begun; not yet evidence of an unstructured reply
    s = s.replace(/^[\s>#*_`\-•]+/, '').toUpperCase();
    if (!s) return true;
    for (var i = 0; i < LABELS.length; i++) {
      var l = LABELS[i] + ':';
      if (l.indexOf(s) === 0 || s.indexOf(l) === 0) return true;
    }
    return false;
  }

  function cleanValue(v) {
    v = String(v || '');
    v = v.replace(/\*\*/g, '').replace(/(^|\s)__(?=\S)/g, '$1').replace(/^\s*`+|`+\s*$/g, '');
    return v.replace(/[ \t]+/g, ' ').trim();
  }

  /* ---- LINES: pull complete {...} objects out of a possibly truncated JSON array ---- */

  function scanObjects(s) {
    // returns {objs: [string], closed: bool, tail: bool}   tail = an object was started but not finished
    var start = s.indexOf('[');
    var objs = [];
    if (start < 0) return { objs: objs, closed: false, tail: s.indexOf('{') >= 0 };
    var i = start + 1, n = s.length, depth = 0, inStr = false, esc = false, from = -1, closed = false;
    for (; i < n; i++) {
      var c = s.charAt(i);
      if (inStr) {
        if (esc) esc = false;
        else if (c === '\\') esc = true;
        else if (c === '"') inStr = false;
        continue;
      }
      if (c === '"') { inStr = true; continue; }
      if (c === '{') { if (depth === 0) from = i; depth++; continue; }
      if (c === '}') {
        if (depth > 0) { depth--; if (depth === 0 && from >= 0) { objs.push(s.slice(from, i + 1)); from = -1; } }
        continue;
      }
      if (c === ']' && depth === 0) { closed = true; break; }
    }
    return { objs: objs, closed: closed, tail: depth > 0 };
  }

  function num(v) {
    if (typeof v === 'number') return isFinite(v) ? v : null;
    if (typeof v === 'string' && /^\s*-?\d+(\.\d+)?\s*$/.test(v)) return parseFloat(v);
    return null;
  }

  function normObj(o) {
    if (!o || typeof o !== 'object') return null;
    var b = o.b || o.box || o.bbox || o.bounding_box || null;
    var nb = null;
    if (Array.isArray(b) && b.length >= 4) {
      var a = [num(b[0]), num(b[1]), num(b[2]), num(b[3])];
      if (a.every(function (x) { return x !== null; })) nb = a;
    }
    var orig = o.o != null ? o.o : o.orig != null ? o.orig : o.original != null ? o.original : o.src != null ? o.src : '';
    var tr = o.t != null ? o.t : o.tr != null ? o.tr : o.translation != null ? o.translation : o.en != null ? o.en : '';
    return { b: nb, o: String(orig), t: String(tr) };
  }

  function parseObj(str) {
    try { return JSON.parse(str); } catch (e) { /* try repairs */ }
    var r = str.replace(/,\s*([}\]])/g, '$1').replace(/[“”]/g, '"');
    try { return JSON.parse(r); } catch (e) { /* fall through */ }
    r = r.replace(/'/g, '"');
    try { return JSON.parse(r); } catch (e) { return null; }
  }

  function parseLines(raw) {
    var s = String(raw || '').replace(/```[a-z]*/gi, ' ');
    var sc = scanObjects(s);
    var lines = [];
    for (var i = 0; i < sc.objs.length; i++) {
      var ln = normObj(parseObj(sc.objs[i]));
      if (ln && (ln.o || ln.t || ln.b)) lines.push(ln);
    }
    return { lines: lines, truncated: !sc.closed || sc.tail };
  }

  /* ---- main ---- */

  function parseReply(text, opts) {
    var res = {
      say: '', orig: '', read: '', note: '', unsure: '', lines: [],
      structured: false, noteIsFallback: false, linesTruncated: false, preface: '', active: '',
    };
    try {
      text = String(text == null ? '' : text).replace(/\r\n?/g, '\n');
      var rows = text.split('\n');
      var cur = null;
      var acc = { say: [], orig: [], read: [], note: [], unsure: [], lines: [] };
      var pre = [];
      var seen = false;
      var inFence = false;
      for (var i = 0; i < rows.length; i++) {
        var row = rows[i];
        // streaming: a half-written next label ("ORI", "NOT") on the unfinished last row must not flash into the field above
        if (i === rows.length - 1 && !(opts && opts.final) && cur && /^[\s>#*_`\-•]*[A-Za-z]{1,6}:?$/.test(row) && isLabelPrefix(row)) continue;
        var m = LABEL_RE.exec(row);
        // inside a LINES json block a row like `"o": "NOTE: x"` is not at line start so the regex cannot match it;
        // a fenced block is also never a label row
        if (m && !(inFence && cur === 'lines')) {
          cur = m[1].toLowerCase();
          seen = true;
          acc[cur].push(m[2]);
          continue;
        }
        if (/^\s*```/.test(row)) { inFence = !inFence; if (cur === 'lines') continue; }
        if (cur) acc[cur].push(row);
        else pre.push(row);
      }
      if (!seen) {
        var t = text.trim();
        if (!t || (!(opts && opts.final) && isLabelPrefix(t) && t.length < 8 && t.indexOf('\n') < 0)) return res; // nothing yet
        res.structured = false;
        res.noteIsFallback = true;
        res.note = cleanValue(t.replace(/\s*\n\s*/g, ' '));
        return res;
      }
      res.structured = true;
      res.preface = cleanValue(pre.join(' '));
      res.saySynth = false;
      ['say', 'orig', 'read', 'note', 'unsure'].forEach(function (k) {
        var v = cleanValue(acc[k].join(' '));
        if (k !== 'say' && k !== 'orig' && EMPTY_RE.test(v)) v = '';
        res[k] = v;
      });
      // the model sometimes drops the SAY label on the first line: unlabelled text before the first label is the answer
      if (!res.say && res.preface && !acc.say.length) { res.say = res.preface; res.preface = ''; res.saySynth = true; }
      var lp = parseLines(acc.lines.join('\n'));
      res.lines = lp.lines;
      res.linesTruncated = acc.lines.length ? lp.truncated : false;
      res.active = cur || '';
    } catch (e) {
      /* never throw: return what we have */
    }
    return res;
  }


  /* True when a finished reply looks broken enough to retry (e.g. with thinking on): no answer, an answer over 25 words, or the
     model thinking out loud inside a field ("Actually, let me read it carefully...", seen in about 1 in 10 replies with thinking off). */
  var SELF_TALK = /\b(wait|actually|let me|let's|hmm|i need to)\b/i;
  function looksOff(r) {
    if (!r || !r.say) return true;
    if (r.say.split(/\s+/).length > 25) return true;
    return SELF_TALK.test(r.say) || SELF_TALK.test(r.orig);
  }

  /* b: [x0,y0,x1,y1] in the given convention -> integer pixel box in the image of size width x height */
  function boxToPixels(b, convention, width, height) {
    if (!Array.isArray(b) || b.length < 4 || !(width > 0) || !(height > 0)) return null;
    var v = b.slice(0, 4).map(Number);
    if (v.some(function (x) { return !isFinite(x); })) return null;
    var fx = 1, fy = 1;
    if (convention === 'n1000') { fx = width / 1000; fy = height / 1000; }
    else if (convention === 'frac') { fx = width; fy = height; }
    var x0 = v[0] * fx, y0 = v[1] * fy, x1 = v[2] * fx, y1 = v[3] * fy;
    if (x1 < x0) { var t = x0; x0 = x1; x1 = t; }
    if (y1 < y0) { var u = y0; y0 = y1; y1 = u; }
    x0 = Math.max(0, Math.min(width, x0)); x1 = Math.max(0, Math.min(width, x1));
    y0 = Math.max(0, Math.min(height, y0)); y1 = Math.max(0, Math.min(height, y1));
    if (x1 - x0 < 1 || y1 - y0 < 1) return null;
    return [Math.round(x0), Math.round(y0), Math.round(x1), Math.round(y1)];
  }

  var API = { parseReply: parseReply, boxToPixels: boxToPixels, looksOff: looksOff, LABELS: LABELS };
  root.PAAParse = API;
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
})(typeof self !== 'undefined' ? self : globalThis);
