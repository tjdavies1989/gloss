/* world.js — where things are in the world, from Google Maps Street View panorama metadata.
 * No dependencies. Works in a browser (content script) and in node.
 *
 * Input: the raw text (or parsed JSON) of the page's own metadata responses:
 *   GET https://www.google.com/maps/photometa/v1?...pb=...!3m3!1m2!1e<type>!2s<PANOID>...      (by pano id; pano at j[1][0])
 *   GET https://www.google.com/maps/photometa/si/v1?...pb=...!3d<lat>!4d<lng>!2d<radius>...     (search near a point; pano at j[1])
 *
 * Frames
 *   World: local East-North-Up (metres) around a panorama; directions as compass yaw (0 = north, 90 = east) and pitch (+ = up).
 *   Panorama/depth frame: x = right, y = forward (the panorama's own heading), z = up.
 *   Depth planes satisfy n . p = d  (n unit normal pointing away from the camera, d metres).
 *   Depth image: 512 x 256 equirectangular, column 0 = panorama heading - 180 deg, row 0 = straight up; one plane index per pixel, 0 = no surface (sky).
 */
(function (root) {
  'use strict';
  const D2R = Math.PI / 180, R2D = 180 / Math.PI;
  const A_WGS = 6378137, E2 = 0.00669437999014;

  // Orientation convention (see ORIENT in NOTES.txt). The Maps renderer levels each panorama using its capture tilt and roll.
  // world = Rz(-heading) * Rx(tiltSign*(tilt-90)) * Ry(rollSign*roll) * pano
  const ORIENT = { tiltSign: 1, rollSign: 1, useTiltRoll: false };

  function b64ToBytes(s) {
    s = s.replace(/-/g, '+').replace(/_/g, '/'); while (s.length % 4) s += '=';
    if (typeof atob === 'function') { const bin = atob(s); const u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return u; }
    return new Uint8Array(Buffer.from(s, 'base64'));
  }

  function decodeDepth(b64) {
    if (!b64 || typeof b64 !== 'string') return null;
    const b = b64ToBytes(b64); if (b.length < 8) return null;
    const dv = new DataView(b.buffer, b.byteOffset, b.byteLength);
    const headerSize = b[0], numPlanes = dv.getUint16(1, true), w = dv.getUint16(3, true), h = dv.getUint16(5, true), offset = b[7];
    if (headerSize !== 8 || offset !== 8 || b.length !== offset + w * h + numPlanes * 16) return null;
    const indices = b.subarray(offset, offset + w * h);
    const planes = [];
    let p = offset + w * h;
    for (let i = 0; i < numPlanes; i++, p += 16) planes.push({ n: [dv.getFloat32(p, true), dv.getFloat32(p + 4, true), dv.getFloat32(p + 8, true)], d: dv.getFloat32(p + 12, true) });
    return { w, h, numPlanes, indices, planes };
  }

  const g = (o, ...path) => { for (const k of path) { if (o == null) return undefined; o = o[k]; } return o; };
  const isPano = (p) => Array.isArray(p) && Array.isArray(p[1]) && typeof p[1][0] === 'number' && typeof p[1][1] === 'string';

  function findPano(j) {
    if (isPano(g(j, 1))) return j[1];          // photometa/si
    if (isPano(g(j, 1, 0))) return j[1][0];    // photometa/v1
    return null;
  }

  function parseMeta(raw) {
    let j = raw;
    if (typeof raw === 'string') { try { j = JSON.parse(raw.replace(/^\)\]\}'\s*/, '')); } catch (e) { return null; } }
    const p = findPano(j); if (!p) return null;
    const loc = g(p, 5, 0, 1) || [];
    const ori = loc[2] || [];
    const nearbyRaw = g(p, 5, 0, 3, 0) || [];
    const nearby = nearbyRaw.map((n) => ({
      panoId: g(n, 0, 1), type: g(n, 0, 0), lat: g(n, 2, 0, 2), lng: g(n, 2, 0, 3),
      elevation: g(n, 2, 1, 0) ?? null, heading: g(n, 2, 2, 0) ?? null, tilt: g(n, 2, 2, 1) ?? null, roll: g(n, 2, 2, 2) ?? null,
      street: g(n, 3, 2, 0, 0) ?? null,
    }));
    const links = (g(p, 5, 0, 6) || []).map((l) => { const n = nearby[l[0]]; return n ? { panoId: n.panoId, heading: g(l, 1, 3) ?? null, lat: n.lat, lng: n.lng, elevation: n.elevation } : null; }).filter(Boolean);
    const history = (g(p, 5, 0, 8) || []).map((h) => { const n = nearby[h[0]]; return n ? { panoId: n.panoId, year: g(h, 1, 0), month: g(h, 1, 1), lat: n.lat, lng: n.lng } : null; }).filter(Boolean);
    const dateArr = g(p, 6, 7) || [];
    const depthB64 = g(p, 5, 0, 5, 1, 2);
    const depth = decodeDepth(depthB64);
    const meta = {
      panoId: p[1][1], type: p[1][0], official: p[1][0] === 2,
      lat: loc[0] ? loc[0][2] : null, lng: loc[0] ? loc[0][3] : null,
      elevation: g(loc, 1, 0) ?? null, elevation2: g(loc, 1, 2) ?? null,
      heading: ori[0] ?? null, tilt: ori[1] ?? null, roll: ori[2] ?? null,
      country: loc[4] ?? null,
      imageWidth: g(p, 2, 2, 1) ?? null, imageHeight: g(p, 2, 2, 0) ?? null,
      date: dateArr.length ? { year: dateArr[0], month: dateArr[1], day: dateArr[2] ?? null } : null,
      address: (g(p, 3, 2) || []).map((a) => a && a[0]).filter(Boolean),
      links, nearby, history,
      hasDepth: !!depth && depth.planes.some((pl, i) => i > 0 && Math.abs(pl.n[2]) < 0.9), // at least one non-horizontal surface (walls)
      depth,
    };
    // camera height above the ground plane, from the depth planes (largest downward-facing plane)
    if (depth) { const cnt = new Uint32Array(depth.numPlanes); for (const i of depth.indices) cnt[i]++; let best = -1; for (let i = 1; i < depth.numPlanes; i++) if (depth.planes[i].n[2] < -0.95 && (best < 0 || cnt[i] > cnt[best])) best = i; meta.cameraHeight = best > 0 ? depth.planes[best].d : null; meta.depthPlanes = depth.numPlanes - 1; }
    // Measured: a 9-plane map (Bangkok, under the skytrain) put signs 19-30 m away at 2-5 m; good maps had 52-151 planes.
    meta.coarseDepth = meta.hasDepth && meta.depthPlanes < 20;
    return meta;
  }

  // ---------- rotations ----------
  function rotZ(a) { const c = Math.cos(a), s = Math.sin(a); return [[c, -s, 0], [s, c, 0], [0, 0, 1]]; }
  function rotX(a) { const c = Math.cos(a), s = Math.sin(a); return [[1, 0, 0], [0, c, -s], [0, s, c]]; }
  function rotY(a) { const c = Math.cos(a), s = Math.sin(a); return [[c, 0, s], [0, 1, 0], [-s, 0, c]]; }
  function mul(A, B) { return A.map((r) => [0, 1, 2].map((j) => r[0] * B[0][j] + r[1] * B[1][j] + r[2] * B[2][j])); }
  function app(M, v) { return [M[0][0] * v[0] + M[0][1] * v[1] + M[0][2] * v[2], M[1][0] * v[0] + M[1][1] * v[1] + M[1][2] * v[2], M[2][0] * v[0] + M[2][1] * v[1] + M[2][2] * v[2]]; }
  function tr(M) { return [[M[0][0], M[1][0], M[2][0]], [M[0][1], M[1][1], M[2][1]], [M[0][2], M[1][2], M[2][2]]]; }
  // pano frame -> ENU. Heading rotates clockwise (compass), so ENU = Rz(-heading).
  function panoToWorld(meta) {
    let M = rotZ(-(meta.heading || 0) * D2R);
    if (ORIENT.useTiltRoll && meta.tilt != null && meta.roll != null) {
      const roll = ((meta.roll + 180) % 360 + 360) % 360 - 180;
      M = mul(M, mul(rotX(ORIENT.tiltSign * (meta.tilt - 90) * D2R), rotY(ORIENT.rollSign * roll * D2R)));
    }
    return M;
  }
  const dirENU = (yaw, pitch) => [Math.cos(pitch * D2R) * Math.sin(yaw * D2R), Math.cos(pitch * D2R) * Math.cos(yaw * D2R), Math.sin(pitch * D2R)];

  // depth along a world direction (compass yaw, pitch in degrees) from the panorama; metres, or null (sky / no depth)
  function depthAt(meta, yaw, pitch) {
    const dm = meta && meta.depth; if (!dm) return null;
    const v = app(tr(panoToWorld(meta)), dirENU(yaw, pitch)); // pano frame
    const a = Math.atan2(v[0], v[1]); const e = Math.asin(Math.max(-1, Math.min(1, v[2])));
    let X = Math.floor(((a / (2 * Math.PI)) + 0.5) * dm.w); X = ((X % dm.w) + dm.w) % dm.w;
    const Y = Math.min(dm.h - 1, Math.max(0, Math.floor((0.5 - e / Math.PI) * dm.h)));
    const pi = dm.indices[Y * dm.w + X]; if (!pi) return null;
    const pl = dm.planes[pi]; const nv = pl.n[0] * v[0] + pl.n[1] * v[1] + pl.n[2] * v[2];
    if (nv <= 1e-6) return null;
    const t = pl.d / nv; return t > 0 && t < 1e4 ? t : null;
  }
  // plane index along a world direction (for debugging / snapping)
  function planeAt(meta, yaw, pitch) {
    const dm = meta && meta.depth; if (!dm) return null;
    const v = app(tr(panoToWorld(meta)), dirENU(yaw, pitch));
    const a = Math.atan2(v[0], v[1]); const e = Math.asin(Math.max(-1, Math.min(1, v[2])));
    let X = Math.floor(((a / (2 * Math.PI)) + 0.5) * dm.w); X = ((X % dm.w) + dm.w) % dm.w;
    const Y = Math.min(dm.h - 1, Math.max(0, Math.floor((0.5 - e / Math.PI) * dm.h)));
    return dm.indices[Y * dm.w + X];
  }

  function radii(latDeg) { const s = Math.sin(latDeg * D2R); const q = 1 - E2 * s * s; return { M: A_WGS * (1 - E2) / Math.pow(q, 1.5), N: A_WGS / Math.sqrt(q) }; }

  // world point from a panorama + direction + distance (metres). alt is in the panorama's elevation reference (camera level if unknown = 0).
  function toWorld(meta, yaw, pitch, dist) {
    const [e, n, u] = dirENU(yaw, pitch).map((c) => c * dist);
    const { M, N } = radii(meta.lat);
    // alt: metres above sea level (null if this panorama has no elevation, e.g. user photo spheres);
    // hag: height above the ground under the camera (uses the depth map's camera height, else 2.5 m) — used when elevations are missing.
    return { lat: meta.lat + (n / M) * R2D, lng: meta.lng + (e / (N * Math.cos(meta.lat * D2R))) * R2D, alt: meta.elevation != null ? meta.elevation + u : null, hag: (meta.cameraHeight || 2.5) + u };
  }
  // direction and distance from a panorama to a world point
  function fromWorld(meta, pt) {
    const { M, N } = radii(meta.lat);
    const n = (pt.lat - meta.lat) * D2R * M, e = (pt.lng - meta.lng) * D2R * N * Math.cos(meta.lat * D2R);
    const u = (pt.alt != null && meta.elevation != null) ? pt.alt - meta.elevation
      : (pt.hag != null ? pt.hag - (meta.cameraHeight || 2.5) : 0); // no common elevation: assume flat ground
    const hz = Math.hypot(e, n);
    return { yaw: ((Math.atan2(e, n) * R2D) + 360) % 360, pitch: Math.atan2(u, hz) * R2D, dist: Math.hypot(hz, u) };
  }
  // World-frame unit normal (ENU, pointing back towards the camera) of the depth surface hit along a direction, or null.
  function surfaceNormal(meta, yaw, pitch) {
    const pi = planeAt(meta, yaw, pitch); if (!pi) return null;
    const n = app(panoToWorld(meta), meta.depth.planes[pi].n); // plane normal points away from the camera
    return [-n[0], -n[1], -n[2]];
  }
  // Is the point hidden from this panorama? true = hidden behind something nearer (this panorama's depth) or, when opts.normal
  // is given (surfaceNormal() at the point, from the panorama where it was marked), the wall it sits on faces away from us.
  // Measured: catches 5 of 9 hidden cases with 2 false alarms in 25 visible ones; street trees are NOT in Google's depth.
  // null when the panorama has no usable depth there and no normal was given.
  function isOccluded(meta, pt, opts = {}) {
    const { yaw, pitch, dist } = fromWorld(meta, pt);
    if (opts.normal && Math.abs(opts.normal[2]) < 0.5) { // back-face test, walls only (ground hits say nothing about the object)
      const v = dirENU(yaw, pitch); // from viewer to point
      const cosView = -(v[0] * opts.normal[0] + v[1] * opts.normal[1] + v[2] * opts.normal[2]);
      if (cosView < Math.sin((opts.minViewDeg ?? -5) * D2R)) return true; // we would be looking at the back of that wall
    }
    if (!meta.depth) return opts.normal ? false : null;
    const d = depthAt(meta, yaw, pitch);
    if (d == null) return null;
    const margin = Math.max(opts.minMargin ?? 2, (opts.relMargin ?? 0.2) * dist);
    return d < dist - margin;
  }
  // distance between two world points (m)
  function distance(a, b) { const { M, N } = radii(a.lat); const n = (b.lat - a.lat) * D2R * M, e = (b.lng - a.lng) * D2R * N * Math.cos(a.lat * D2R); return Math.hypot(n, e, (b.alt ?? 0) - (a.alt ?? 0)); }

  // Fallback only (when the page's own response was missed, e.g. the extension was reloaded under an open tab): the exact
  // single request the Maps page makes for one panorama. Same-origin from a content script (pass location.origin: the content scripts also run on regional hosts such as google.com.au). type 2 = official, 10 = user sphere.
  const PB_TAIL = '!4m61!1e1!1e2!1e3!1e4!1e5!1e6!1e8!1e12!1e17!2m1!1e1!4m1!1i48!5m1!1e1!5m1!1e2!6m1!1e1!6m1!1e2!9m36!1m3!1e2!2b1!3e2!1m3!1e2!2b0!3e3!1m3!1e3!2b1!3e2!1m3!1e3!2b0!3e3!1m3!1e8!2b0!3e3!1m3!1e1!2b0!3e3!1m3!1e4!2b0!3e3!1m3!1e10!2b1!3e2!1m3!1e10!2b0!3e3!11m2!3m1!4b1';
  function metaUrl(panoId, type = 2, hl = 'en', gl = 'us', origin = 'https://www.google.com') {
    return `${origin}/maps/photometa/v1?authuser=0&hl=${hl}&gl=${gl}&pb=!1m4!1smaps_sv.tactile!11m2!2m1!1b1!2m2!1s${hl}!2s${gl}!3m3!1m2!1e${type}!2s${encodeURIComponent(panoId)}${PB_TAIL}`;
  }

  const api = { metaUrl, parseMeta, decodeDepth, depthAt, planeAt, surfaceNormal, toWorld, fromWorld, isOccluded, distance, ORIENT, _panoToWorld: panoToWorld };
  if (typeof module === 'object' && module.exports) module.exports = api; else root.PAAWorld = api;
})(typeof self !== 'undefined' ? self : this);
