/* Gloss: asking. A finished gesture becomes a mark; the mark gets its picture (capture port), then its
   answer (ask port), streamed into the card as it arrives, then it is saved.

   Flow: begin(plan) -> mark in its "Reading" state -> queue -> capture (both layers hidden for the screenshot,
   and only for that) -> request() -> deltas parsed with PAAParse into the card -> finalize() -> store.save.
   Asks queue as in v0.1.1: a second gesture made while the first is still being captured waits its turn, and an
   earlier answer keeps streaming while collapsed.
   Images live in the service worker's storage under the mark's id; the page only keeps the thumbnail. */
(function () {
  'use strict';
  const PAA = self.PAA;
  const P = self.PAAPose;
  const Parse = self.PAAParse;
  const Geo = self.PAAGeo;

  const MIN_SHOT_GAP = 600; // ms; captureVisibleTab is limited to about 2 calls a second
  const REST_WAIT = 700; // ms; wait this long at most for a coasting view to stop before the screenshot
  const SETTLE_WAIT = 1500; // ms; wait this long at most for a flight to the next panorama to end (and the address to catch up)
  const SWITCHED = 'You switched tab before the picture was taken. Try again.';

  const queue = [];
  let busy = false;
  let lastShot = 0;

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const r5 = (n) => Math.round(n * 1e5) / 1e5;
  const rd = (d) => (d ? { yaw: r5(d.yaw), pitch: r5(d.pitch) } : null);

  function uuid() {
    if (self.crypto && crypto.randomUUID) return crypto.randomUUID();
    return 'm' + Date.now().toString(36) + Math.random().toString(36).slice(2, 10);
  }

  function nextFrames(n) {
    return new Promise((resolve) => {
      const t = setTimeout(resolve, 300); // rAF does not run in a hidden tab; do not hang
      (function step(i) {
        if (i === 0) {
          clearTimeout(t);
          resolve();
        } else requestAnimationFrame(() => step(i - 1));
      })(n);
    });
  }

  /* ---------------- the record ---------------- */

  function cornerDirs(rect, centre) {
    const s = (x, y) => P.screenToDir(x, y);
    const tl = s(rect.x, rect.y), tr = s(rect.x + rect.w, rect.y), br = s(rect.x + rect.w, rect.y + rect.h), bl = s(rect.x, rect.y + rect.h);
    const c = centre ? s(centre.x, centre.y) : s(rect.x + rect.w / 2, rect.y + rect.h / 2);
    if (![tl, tr, br, bl, c].every(Boolean)) return null;
    return { tl: rd(tl), tr: rd(tr), br: rd(br), bl: rd(bl), c: rd(c) };
  }

  /* Location context for the model: coordinates, heading and field of view only. Never the page title. */
  function infoFor(pose) {
    const loc = PAA.parseLocation(location.href);
    if (pose.panoId && typeof pose.heading === 'number') {
      loc.heading = Math.round(pose.heading * 10) / 10;
      if (typeof pose.fov === 'number') loc.fov = Math.round(pose.fov * 10) / 10;
    }
    return { loc: loc, host: location.hostname };
  }

  /* screenOnly: a record that belongs to the screen, not to a panorama (used for the "still moving" message) */
  function newRecord(plan, screenOnly) {
    const pose = P.getPose();
    const known = !!pose.panoId;
    const s = plan.markRect;
    const rec = {
      id: uuid(),
      v: 2,
      createdAt: Date.now(),
      kind: plan.kind,
      pano: known ? { id: pose.panoId, type: pose.kind || null, lat: pose.lat == null ? null : pose.lat, lng: pose.lng == null ? null : pose.lng } : null,
      view: { url: location.href, heading: known ? r5(pose.heading) : null, pitch: known ? r5(pose.pitch) : null, fov: known ? r5(pose.fov) : null },
      dirs: null,
      screen: { x: s.x, y: s.y, w: s.w, h: s.h, vw: window.innerWidth, vh: window.innerHeight },
      world: null, // the mark's point in the world (stage 2): set from the panorama's depth map as soon as its metadata is at hand (far.js world())
      q: null,
      a: null,
      fu: [],
      stats: null,
      thumb: null,
      overlay: null, // stage 3
      repaint: null, // stage 4
    };
    if (screenOnly) {
      rec.pano = null;
    } else if (known) {
      rec.dirs = cornerDirs(s, plan.point);
      if (!rec.dirs) rec.pano = null; // the camera could not place it: treat the page as having none (screen-fixed)
    }
    return rec;
  }

  /* ---------------- begin ---------------- */

  /* A gesture made while the view flies to the next panorama, or just after it arrived (the address still names the old
     one for a moment), cannot be pinned to a panorama yet. After a landing the picture is still, so wait for the address
     and go on. A gesture made mid-flight pointed at a picture that no longer exists: say so, on a card that belongs to the
     screen (a card pinned to a panorama would never show). */
  async function begin(plan) {
    let p = P.getPose();
    if (p.transition || p.panoPending) {
      const flying = p.transition;
      const t0 = performance.now();
      while (performance.now() - t0 < SETTLE_WAIT) {
        await sleep(40);
        p = P.getPose();
        if (!p.transition && !p.panoPending) break;
      }
      if (flying || p.transition || p.panoPending) return start(plan, 'The view was still moving. Try again.');
    }
    start(plan, null);
  }

  function start(plan, stillMoving) {
    if (PAA.prefs.density === 'off') PAA.prefs.setDensity('labels'); // asking while everything is hidden would show nothing
    PAA.dock.hideHint();
    PAA.book.close();
    const rec = newRecord(plan, !!stillMoving);
    const mark = new PAA.Mark(rec, { open: true });
    mark.plan = plan;
    mark.info = infoFor(P.getPose());
    PAA.layer.add(mark);
    if (!stillMoving && rec.pano) mark.worldReady = PAA.far.world(rec).catch(() => null); // the point in the world, ready long before the answer is
    PAA.app.collapseOthers(mark); // a new ask collapses the previous card to its caption
    if (stillMoving) {
      mark.noRetry = true; // Retry would crop the wrong picture: the card only offers Dismiss
      fail(mark, stillMoving);
      return;
    }
    mark.busy = true;
    mark.render();
    queue.push(mark);
    pump();
  }

  async function pump() {
    if (busy) return;
    busy = true;
    try {
      while (queue.length) {
        const m = queue.shift();
        if (m.dead) continue;
        try {
          await capture(m);
        } catch (e) {
          fail(m, 'Could not capture the page: ' + ((e && e.message) || e));
          continue;
        }
        if (m.dead) continue;
        if (m.plan.typed) {
          m.busy = false;
          m.setState('compose');
          PAA.app.openMark(m); // (closes any card another ask opened while this one was being captured)
          m.focusInput(); // the field takes the keyboard the moment the card is on screen
        } else {
          request(m, PAA.DEFAULT_QUESTION);
        }
      }
    } catch (e) {
      console.error('Gloss:', e);
    } finally {
      busy = false;
    }
  }

  /* ---------------- capture ---------------- */

  async function untilRest() {
    const t0 = performance.now();
    while (P.getPose().moving && performance.now() - t0 < REST_WAIT) await sleep(40);
  }

  /* The crop rectangle for the screenshot, from the view as it is right now. Normally what was drawn; if the view
     moved since the mouse button went up (a second ask queued behind a first, a coasting view), the mark's own
     box is projected again so the crop still shows what he pointed at. null when that is impossible. */
  function captureGesture(m) {
    const plan = m.plan;
    let rect = plan.rect;
    let point = plan.point;
    if (m.dirArr) {
      const pose = P.getPose();
      if (pose.panoId !== m.rec.pano.id || pose.transition || pose.panoPending) return null;
      if (!m.project()) return null;
      const b = m.bbox();
      const mr = plan.markRect;
      if (Math.abs(b.x - mr.x) > 1.5 || Math.abs(b.y - mr.y) > 1.5 || Math.abs(b.w - mr.w) > 1.5 || Math.abs(b.h - mr.h) > 1.5) {
        const cr = pose.canvasRect;
        const vr = cr ? { l: Math.max(0, cr.x), t: Math.max(0, cr.y), r: Math.min(window.innerWidth, cr.x + cr.width), b: Math.min(window.innerHeight, cr.y + cr.height) } : { l: 0, t: 0, r: window.innerWidth, b: window.innerHeight };
        if (m.isPoint) {
          const c = P.dirToScreen(m.rec.dirs.c.yaw, m.rec.dirs.c.pitch);
          if (!c || c.behind || c.x < vr.l || c.x > vr.r || c.y < vr.t || c.y > vr.b) return null;
          point = { x: c.x, y: c.y };
          rect = { x: Math.min(Math.max(vr.l, c.x - plan.rect.w / 2), vr.r - plan.rect.w), y: Math.min(Math.max(vr.t, c.y - plan.rect.h / 2), vr.b - plan.rect.h), w: plan.rect.w, h: plan.rect.h };
        } else {
          const x0 = Math.max(vr.l, b.x), y0 = Math.max(vr.t, b.y), x1 = Math.min(vr.r, b.x + b.w), y1 = Math.min(vr.b, b.y + b.h);
          if (x1 - x0 < 8 || y1 - y0 < 8) return null;
          rect = { x: x0, y: y0, w: x1 - x0, h: y1 - y0 };
        }
      }
    }
    return { kind: plan.kind, rect: rect, point: point, iw: window.innerWidth, ih: window.innerHeight };
  }

  /* Freeze how crop pixels map to directions, with the camera as it is at the moment of the screenshot.
     Used later, when the model's boxes arrive, to give every LINES entry its four corner directions. */
  function freezeSnapshot(m, g) {
    const pose = P.getPose();
    if (!m.dirArr || !pose.panoId || typeof pose.heading !== 'number') return null;
    const r = g.rect;
    const s = (x, y) => P.screenToDir(x, y);
    const corners = [s(r.x, r.y), s(r.x + r.w, r.y), s(r.x + r.w, r.y + r.h), s(r.x, r.y + r.h)];
    const fwd = { heading: pose.heading, pitch: pose.pitch };
    m.snapCam = { c: corners.map((c) => Geo.roundDir(c)), f: { heading: Math.round(fwd.heading * 1e5) / 1e5, pitch: Math.round(fwd.pitch * 1e5) / 1e5 } }; // saved with the answer: see refineOverlay
    return Geo.planeSnapshot(corners, fwd);
  }

  /* The rate limit for screenshots (2 a second) and a view that has come to rest: an ask's capture and a repaint's both wait here, one after the other. */
  let slotChain = Promise.resolve(); // (two screenshots asked for at once are taken one after the other, never at the same time)
  function shotSlot() {
    const p = slotChain.then(async () => {
      const gap = MIN_SHOT_GAP - (performance.now() - lastShot);
      if (gap > 0) await sleep(gap);
      await untilRest();
      lastShot = performance.now();
    });
    slotChain = p.catch(() => {});
    return p;
  }

  async function capture(m) {
    await shotSlot(); // the rate limit and a view at rest, in line with a repaint's own screenshot (never two at once)
    const release = PAA.layer.holdCapture(); // nothing of ours may be in the picture (until our screenshot is taken: a repaint's may be waiting too)
    let g;
    try {
      await nextFrames(2);
      if (document.visibilityState !== 'visible') throw new Error(SWITCHED); // the screenshot takes whichever tab is showing: not ours any more
      g = captureGesture(m);
      if (!g) throw new Error('The view moved before the picture was taken. Try again.');
      m.snap = freezeSnapshot(m, g);
    } catch (e) {
      release(); // whatever went wrong, the layers must come back
      throw e;
    }
    m.gesture = g;
    lastShot = performance.now();
    return new Promise((resolve, reject) => {
      let finished = false;
      let port;
      const end = (err) => {
        if (finished) return;
        finished = true;
        release();
        if (err) reject(err);
        else resolve();
        try { port.disconnect(); } catch (e) { /* already closed */ }
      };
      try {
        port = chrome.runtime.connect({ name: 'capture' });
      } catch (e) {
        end(new Error(PAA.extGone(e) ? PAA.RELOAD_MSG : e.message));
        return;
      }
      const timer = setTimeout(() => end(new Error('No response from the extension.')), 25000);
      port.onMessage.addListener((msg) => {
        if (msg.type === 'shot') release(); // screenshot taken: show our layers again
        else if (msg.type === 'prepared') {
          clearTimeout(timer);
          m.cropSize = msg.cropSize;
          m.rec.thumb = msg.thumb;
          m.prepared = true;
          end(null);
        } else if (msg.type === 'error') {
          clearTimeout(timer);
          end(new Error(msg.message));
        }
      });
      port.onDisconnect.addListener(() => {
        clearTimeout(timer);
        const le = chrome.runtime.lastError;
        end(new Error(le ? le.message : 'Connection to the extension was lost.'));
      });
      port.postMessage({ type: 'capture', id: m.id, gesture: g });
    });
  }

  /* ---------------- the answer ---------------- */

  function fromParsed(res) {
    return {
      say: res.say,
      orig: res.orig,
      read: res.read,
      note: res.note,
      unsure: res.unsure,
      lines: res.lines,
      structured: res.structured,
    };
  }

  function request(m, question) {
    m.question = question;
    m.raw = '';
    m.a = { say: '', orig: '', read: '', note: '', unsure: '', lines: [], structured: true };
    m.busy = true;
    m.setState('thinking');
    let port;
    try {
      port = chrome.runtime.connect({ name: 'ask' });
    } catch (e) {
      fail(m, PAA.extGone(e) ? PAA.RELOAD_MSG : 'Could not reach the extension: ' + e.message);
      return;
    }
    m.port = port;
    port.onMessage.addListener((msg) => {
      if (m.port !== port) return;
      if (msg.type === 'delta') {
        m.raw += msg.text;
        m.a = fromParsed(Parse.parseReply(m.raw));
        m.renderSoon();
      } else if (msg.type === 'done') {
        m.port = null;
        try { port.disconnect(); } catch (e) { /* closed */ }
        finalize(m, msg);
      } else if (msg.type === 'error') {
        m.port = null;
        try { port.disconnect(); } catch (e) { /* closed */ }
        fail(m, msg.message, msg.settings);
      }
    });
    port.onDisconnect.addListener(() => {
      if (m.port !== port) return; // we closed it ourselves
      m.port = null;
      const le = chrome.runtime.lastError;
      fail(m, le ? le.message : 'Connection to the extension was lost.');
    });
    port.postMessage({ type: 'ask', id: m.id, question: question, info: m.info, kind: m.rec.kind, turns: [] });
  }

  function finalize(m, done) {
    if (m.dead) return;
    const raw = m.raw;
    if (!raw.trim()) return fail(m, 'The model returned an empty answer.');
    const res = Parse.parseReply(raw, { final: true });
    if (res.structured && !res.say && !res.note && !res.orig) return fail(m, 'The model returned an empty answer.');
    const cs = m.cropSize || [0, 0];
    const lines = (res.structured ? res.lines : []).map((l) => {
      const b = l.b ? Parse.boxToPixels(l.b, 'px', cs[0], cs[1]) : null; // pixels of image 1 as sent
      const line = { b: b, o: l.o, t: l.t, dirs: b && m.snap ? Geo.boxDirs(m.snap, b, cs[0], cs[1]) : null };
      if (b && spilled(l.b, cs)) line.spill = true; // the model's box ran off the picture (clamped above): the text is probably cut off
      return line;
    });
    const a = { say: res.say, orig: res.orig, read: res.read, note: res.note, unsure: res.unsure, lines: lines, structured: res.structured, raw: raw };
    m.a = a;
    m.rec.a = a;
    m.rec.q = m.question === PAA.DEFAULT_QUESTION ? null : m.question;
    if (m.snapCam && cs[0] && g0(m)) m.rec.cam = { c: m.snapCam.c, f: m.snapCam.f, cs: [cs[0], cs[1]], ref: g0(m) }; // enough to snap again if the first try fails
    m.rec.stats = { ms: done.ms == null ? null : done.ms, cost: typeof done.cost === 'number' ? done.cost : null, model: done.model || null };
    m.busy = false;
    m.setState('done');
    // Saved at once: the answer must never wait for the metadata. If the world point is still being worked out, it is saved again when it
    // arrives (unless the mark was deleted in the meantime: store.save is an upsert and would bring it back).
    const pointPending = !m.rec.world && m.worldReady;
    PAA.store.save(m.rec).catch((e) => console.warn('[PAA] save failed', e));
    if (pointPending) {
      m.worldReady.then((w) => { if (w && !m.dead) PAA.store.save(m.rec).catch((e) => console.warn('[PAA] save failed', e)); });
    }
    refineOverlay(m); // stage 3: snap the boxes to the ink, read the colours, then the English may be drawn over the sign
    leaveIfElsewhere(m);
  }

  const g0 = (m) => (m.gesture && m.gesture.rect ? [m.gesture.rect.w, m.gesture.rect.h] : null); // the size in CSS px of the pictured rectangle

  /* does the model's raw box (pixels of the picture sent) run more than 2 px off the picture? */
  function spilled(b, cs) {
    const v = b.slice(0, 4).map(Number);
    if (v.some((x) => !isFinite(x))) return false;
    return Math.min(v[0], v[2]) < -2 || Math.min(v[1], v[3]) < -2 || Math.max(v[0], v[2]) > cs[0] + 2 || Math.max(v[1], v[3]) > cs[1] + 2;
  }

  /* Stage 3. The worker snaps every LINES box to the ink in the picture that was sent and reads the sign's colour and the lettering's (snap.js); the
     corner directions of the snapped box come from the camera frozen at the screenshot (m.snap), so they are exact whatever he did meanwhile. The
     answer was saved before this started; it is saved again with the overlay's data unless the note was deleted meanwhile (store.save is an upsert).
     The picture was taken with both layers hidden, so none of this can ever be in an image sent. The frozen camera is saved with the answer (rec.cam), so a
     snap that did not finish (worker killed, extension reloaded, timeout) is tried again when the panorama is next opened (ask.restore). */
  async function refineOverlay(m, cam) {
    // cam: a saved record being tried again (the extension was reloaded or the worker killed between the answer and the snap, or the snap failed):
    // the frozen camera, the picture's size and the pictured rectangle come from the record instead of the capture
    const cs = cam ? cam.cs : m.cropSize;
    const ref = cam ? cam.ref : m.gesture && m.gesture.rect ? [m.gesture.rect.w, m.gesture.rect.h] : null;
    const snap = cam ? Geo.planeSnapshot(cam.c, cam.f) : m.snap;
    const lines = m.a.lines || [];
    if (!cs || !ref || !snap || !lines.some((l) => l.b && l.t)) return;
    let r;
    try {
      r = await Promise.race([PAA.store.snap(m.id, lines.map((l) => l.b)), sleep(8000).then(() => { throw new Error('timed out'); })]);
    } catch (e) {
      console.warn('[PAA] snap failed', e);
      return;
    }
    if (m.deleted || !r || !r.lines || r.w !== cs[0] || r.h !== cs[1]) return;
    r.lines.forEach((x, i) => {
      const l = lines[i];
      if (!x || !l) return;
      l.sb = x.sb;
      l.sd = Geo.boxDirs(snap, x.sb, cs[0], cs[1]);
      l.bg = x.bg;
      l.fg = x.fg;
      if (typeof x.ang === 'number') l.ang = Math.round(x.ang * 10) / 10;
    });
    m.rec.overlay = { v: 1, cs: [cs[0], cs[1]], ref: [ref[0], ref[1]], on: null };
    PAA.store.save(m.rec).catch((e) => console.warn('[PAA] save failed', e));
    if (!m.dead) PAA.overlay.attach(m);
  }

  /* A mark is kept while its answer is being written even when the view has moved to another panorama. When it is finished it goes if it does not
     belong here any more (it is hidden, or is a soft anchor that was hidden to let it finish), and the panorama now showing gets its own marks back:
     this one as a normal mark if it was asked here, or as a soft anchor if it can be seen from here. The saved record is read again, so it is current. */
  function leaveIfElsewhere(m) {
    if (PAA.patch && PAA.patch.working(m)) return; // its repaint is still running: that leaves when it is over
    const here = PAA.layer.lastPano();
    if (!m.retired && !(m.rec.pano && m.rec.pano.id !== here)) return;
    PAA.layer.remove(m);
    if (m.rec.pano && here) {
      restore(here);
      PAA.far.arrive(here);
    }
  }

  /* ---------------- follow-ups (flow G) ---------------- */

  /* where, for a mark that was restored (it has no live context): the address it was asked at, coordinates only */
  function infoForRec(rec) {
    const loc = PAA.parseLocation((rec.view && rec.view.url) || '');
    const v = rec.view || {};
    if (typeof v.heading === 'number') {
      loc.heading = Math.round(v.heading * 10) / 10;
      if (typeof v.fov === 'number') loc.fov = Math.round(v.fov * 10) / 10;
    }
    return { loc: loc, host: location.hostname };
  }

  /* One more question about the same thing. The worker re-reads both pictures from storage and replays the card as the
     first answer. The reply streams into the card as a plain exchange, then the record is saved with it. */
  function followUp(m, question, retry) {
    let q = String(question || '').trim();
    if (!q || m.dead || m.state !== 'done') return;
    if (!m.busy && m.fuQueue.length && !retry) { // a follow-up failed with others waiting behind it: a new one joins them and the oldest waiting is asked now, in order
      m.fuQueue.push(q);
      q = m.fuQueue.shift();
    }
    if (m.busy) { // one is still being answered: this one waits its turn (shown under it) and is asked when that one is over
      if (m.fuPending && !m.fuPending.err) {
        m.fuQueue.push(q);
        m.fuChanged();
      }
      return;
    }
    m.busy = true;
    m.fuPending = { q: q, text: '', err: '' };
    m.fuChanged();
    const p = m.fuPending;
    // the first answer is replayed as the model gave it (the whole reply), not boiled down to the card's three fields
    const turns = [{ q: m.rec.q || PAA.DEFAULT_QUESTION, a: m.a.raw || m.raw || PAA.cardText(m.a) }].concat((m.rec.fu || []).map((f) => ({ q: f.q, a: f.a })));
    const failed = (message, settings) => {
      m.busy = false;
      m.port = null;
      p.err = message;
      p.settings = !!settings; // a key problem: the failed question shows a Settings button beside Retry
      m.fuChanged();
      if (m.retired) PAA.layer.remove(m);
    };
    let port;
    try {
      port = chrome.runtime.connect({ name: 'ask' });
    } catch (e) {
      return failed(PAA.extGone(e) ? PAA.RELOAD_MSG : 'Could not reach the extension: ' + e.message);
    }
    m.port = port;
    port.onMessage.addListener((msg) => {
      if (m.port !== port) return;
      if (msg.type === 'delta') {
        p.text += msg.text;
        m.fuChanged();
      } else if (msg.type === 'done') {
        m.port = null;
        try { port.disconnect(); } catch (e) { /* closed */ }
        const text = p.text.trim();
        if (!text) return failed('The model returned an empty answer.');
        m.rec.fu = (m.rec.fu || []).concat([{ q: q, a: text }]);
        if (m.rec.stats && typeof msg.cost === 'number') m.rec.stats.cost = (m.rec.stats.cost || 0) + msg.cost;
        m.fuPending = null;
        m.busy = false;
        m.fuChanged();
        PAA.layer.changed();
        PAA.store.save(m.rec).catch((e) => console.warn('[PAA] save failed', e));
        if (m.fuQueue.length && !m.retired) followUp(m, m.fuQueue.shift(), true); // the next one that was typed meanwhile (true: it comes from the head of the queue, so it must not be sent to the back of it)
        else leaveIfElsewhere(m);
      } else if (msg.type === 'error') {
        m.port = null;
        try { port.disconnect(); } catch (e) { /* closed */ }
        failed(msg.message, msg.settings);
      }
    });
    port.onDisconnect.addListener(() => {
      if (m.port !== port) return;
      m.port = null;
      const le = chrome.runtime.lastError;
      failed(le ? le.message : 'Connection to the extension was lost.');
    });
    port.postMessage({ type: 'ask', id: m.id, question: q, info: m.info || infoForRec(m.rec), kind: m.rec.kind, turns: turns });
  }

  /* A failed ask is not saved. The card shows the real message in amber with Retry (and Settings when the problem is a key: settings is true). */
  function fail(m, message, settings) {
    if (m.dead) return;
    m.busy = false;
    m.port = null;
    m.err = message;
    m.errSettings = !!settings;
    m.open = true;
    m.setState('error', message);
    if (m.retired) { // a screen-fixed mark whose view changed: its card can no longer be shown, so the reason goes to the console
      console.warn('[PAA] ask failed after the view changed:', message);
      PAA.layer.remove(m);
      if (PAA.dock) PAA.dock.notice('An answer failed: ' + message);
    } else if (m.rec.pano && m.rec.pano.id !== PAA.layer.lastPano()) { // asked on a panorama he has left: its card is hidden, so say so beside the dock
      if (PAA.dock) PAA.dock.notice('An answer failed: ' + message);
    }
  }

  /* ---------------- actions ---------------- */

  function retry(m) {
    if (m.dead || m.busy) return;
    m.busy = true;
    if (m.prepared) {
      request(m, m.question || PAA.DEFAULT_QUESTION); // the pictures are still saved under the id
    } else {
      m.setState('capturing');
      queue.push(m);
      pump();
    }
  }

  function submitCompose(m) {
    const text = m.input ? m.input.value.trim() : '';
    if (!text) return; // nothing typed: stay in compose
    m.busy = true;
    request(m, text);
  }

  /* Esc, or a press on the scene, while composing: cancel and remove the mark. */
  function cancelCompose(m) {
    m.deleted = true;
    PAA.store.discard(m.id).catch(() => {});
    PAA.layer.remove(m);
  }

  /* Delete for good: record, index row and images. No confirmation, it is a note, not a document. */
  function remove(m) {
    forget(m);
    PAA.store.remove(m.id).catch((e) => console.warn('[PAA] delete failed', e));
  }

  /* The mark goes from this page (its answer, if still coming, is dropped), and nothing is written: the note is already gone from storage. */
  function forget(m) {
    m.deleted = true;
    if (m.port) {
      const p = m.port;
      m.port = null;
      try { p.disconnect(); } catch (e) { /* closed */ }
    }
    m.busy = false;
    PAA.layer.remove(m);
  }

  /* Notes deleted from another place (Delete all in the settings, or the same note in another tab): the marks of this page that show them go too, so no
     later save brings one back with its pictures gone. The tab that deleted a note has already dropped it (m.deleted). */
  try {
    chrome.runtime.onMessage.addListener((msg) => {
      if (!msg || msg.type !== 'store-changed') return;
      if (msg.op === 'cleared') PAA.layer.all().slice().forEach((m) => { if (!m.deleted) forget(m); });
      else if (msg.op === 'removed') { const m = PAA.layer.get(msg.id); if (m && !m.deleted) forget(m); }
    });
  } catch (e) { /* extension gone */ }

  /* Marks saved for this panorama come back exactly where they were. */
  async function restore(panoId) {
    let records;
    try {
      records = await PAA.store.listPano(panoId);
    } catch (e) {
      return; // extension reloaded, or no storage: nothing to restore
    }
    if (PAA.layer.lastPano() !== panoId) return; // moved on while we were reading
    let added = 0;
    records.forEach((rec) => {
      if (PAA.layer.get(rec.id) || !rec.dirs) return;
      const m = new PAA.Mark(rec, { open: false });
      PAA.layer.add(m);
      added++;
      // an answer whose snap never finished (see refineOverlay): once more, from the camera saved with it
      if (!rec.overlay && rec.cam && rec.a && rec.a.lines && rec.a.lines.length) refineOverlay(m, rec.cam);
    });
    PAA.far.upgrade(panoId, records); // marks saved before stage 2 get their point in the world now, from this panorama's depth map
    if (added) {
      PAA.layer.layoutNow(); // one pass for the whole batch (30 saved notes must not each force a layout)
      PAA.layer.trackNow();
      // arrived from a notebook row: open that card
      let want = null;
      try { want = sessionStorage.getItem('paaOpen'); sessionStorage.removeItem('paaOpen'); } catch (e) { /* none */ }
      const m = want && PAA.layer.get(want);
      // The card opens where the mark is in view. Where it is not (Maps opens an address with no camera values, South Korea, looking straight
      // down at 15 degrees of field of view), the arrow chip shows the way and the card opens when the mark comes into view (flow J).
      if (m) { if (PAA.book.inView(m)) PAA.app.openMark(m); else PAA.finder.point(m, 30000); }
    }
  }

  PAA.ask = { shotSlot: shotSlot, nextFrames: nextFrames, begin: begin, retry: retry, followUp: followUp, submitCompose: submitCompose, cancelCompose: cancelCompose, remove: remove, restore: restore, leaveIfElsewhere: leaveIfElsewhere };
})();
