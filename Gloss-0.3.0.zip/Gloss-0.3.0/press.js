/* Gloss: pressing a caption, and the quiet windows that keep a second press off the scene.

   A caption is click-through (pointer-events none), so the wheel over it zooms Street View and an Option-drag can start on top of
   it. A press on one is found here, by hit-testing the rectangles of the captions that are showing, and the quadrilaterals of the labels of
   English drawn over a sign and of an AI repaint showing on one (they are click-through too, but they look pressable: a click on one opens the card, it does not walk).

   The press is let through to Maps first: a caption sits on the picture, and a drag that starts on it must pan like any other.
     - the pointer moves more than PAN_PX while the button is down: it is a pan. Nothing more is done, everything passes.
     - it is released without moving: it was a click on the caption. Its release and the click that follows are swallowed, Maps is
       told its press turned into a small drag and ended (see cancelMaps: its drag ends, it never sees a click, so it does not walk down
       the street), and the card opens.
   Open cards, the dock and the notebook are real elements and need none of this. Option presses are the gesture's business.

   Quiet windows (guard): for a moment after a caption press, and after the more menu closes, presses on that spot are swallowed, so
   a double click or a second click that lands where the thing just was does not reach the scene (Maps would zoom or walk).
   These are window capture listeners, registered after layer.js' own watchers (which therefore still see every release). */
(function () {
  'use strict';
  const PAA = self.PAA;

  const TYPES = ['pointerdown', 'pointermove', 'pointerup', 'mousedown', 'mouseup', 'click', 'dblclick'];
  const PAN_PX = 5; // a press that moves more than this is a pan
  const CAPTION_QUIET = 350; // ms a caption's spot is quiet after a press on it
  const PAD = 4; // px a quiet rectangle is grown by

  let down = null; // a press that began on a caption: { mark, x, y, target, id, type, rect, pan }
  let held = null; // a press that began inside a quiet window: swallowed whole, { until }
  const guards = []; // { rect, until }

  /* the mark whose caption is showing at this point (topmost = latest), or null */
  function capAt(x, y) {
    if (!PAA.layer) return null;
    const all = PAA.layer.all();
    for (let i = all.length - 1; i >= 0; i--) {
      const r = all[i].capRect();
      if (r && x >= r.x && x <= r.x + r.w && y >= r.y && y <= r.y + r.h) return all[i];
    }
    return null;
  }

  /* what a press at this point lands on: { mark, rect } for a caption that is showing, or for a label of English drawn over a sign (stage 3: it
     looks like something to press, and a click on it must not walk down the street), else null */
  function pressAt(x, y) {
    const m = capAt(x, y);
    if (m) return { mark: m, rect: m.capRect() };
    if (!PAA.layer || !PAA.overlay) return null;
    const all = PAA.layer.all();
    for (let i = all.length - 1; i >= 0; i--) {
      const r = PAA.overlay.hitAt(all[i], x, y) || (PAA.patch && PAA.patch.hitAt(all[i], x, y)); // (the repaint of a sign is pressable like its labels)
      if (r) return { mark: all[i], rect: r };
    }
    return null;
  }

  /* Swallow presses in this rectangle (window pixels) for ms milliseconds. */
  function guard(rect, ms) {
    if (!rect) return;
    guards.push({ rect: { x: rect.x - PAD, y: rect.y - PAD, w: rect.w + 2 * PAD, h: rect.h + 2 * PAD }, until: performance.now() + ms });
  }

  function guardAt(x, y, now) {
    for (let i = guards.length - 1; i >= 0; i--) {
      const g = guards[i];
      if (now > g.until) { guards.splice(i, 1); continue; }
      const r = g.rect;
      if (x >= r.x && x <= r.x + r.w && y >= r.y && y <= r.y + r.h) return g;
    }
    return null;
  }

  function swallow(e) {
    e.preventDefault();
    e.stopImmediatePropagation();
  }

  /* End Maps' drag without a click. Maps follows the MOUSE events for its drag and its click-to-go: a mouse press that is released
     where it began is a tap (it walks). Swallowing the release leaves Maps dragging (moving the pointer with no button pans the view);
     a release without a move walks. So Maps is told that the press turned into a small drag (a move of CANCEL_MOVE px with the button
     down) and ended there: a drag end is no tap, and a move event alone does not pan it. (Checked live: pointercancel alone leaves the
     drag running, a mouseup alone walks, this sequence does neither.) The pointercancel ends its pointer-event side. */
  const CANCEL_MOVE = 9;
  function cancelMaps(d) {
    const pt = { pointerId: d.id, pointerType: d.type, isPrimary: true, bubbles: true, cancelable: false, composed: true, view: window };
    const at = (dx) => ({ bubbles: true, cancelable: false, composed: true, view: window, clientX: d.x + dx, clientY: d.y, button: 0 });
    try {
      d.target.dispatchEvent(new PointerEvent('pointercancel', Object.assign({ clientX: d.x, clientY: d.y }, pt)));
      d.target.dispatchEvent(new MouseEvent('mousemove', Object.assign(at(CANCEL_MOVE), { buttons: 1 })));
      d.target.dispatchEvent(new MouseEvent('mouseup', Object.assign(at(CANCEL_MOVE), { buttons: 0 })));
    } catch (err) { /* nothing more to try */ }
  }

  function onEvent(e) {
    if (!e.isTrusted) return;
    const t = e.type;
    const now = performance.now();

    if (t === 'pointermove') {
      if (down && !down.pan && e.buttons && Math.hypot(e.clientX - down.x, e.clientY - down.y) > PAN_PX) down.pan = true;
      return;
    }
    if (t === 'dblclick') { // the second click of a double click that began in a quiet window
      if (!PAA.layer.inOurs(e) && guardAt(e.clientX, e.clientY, now)) swallow(e);
      return;
    }
    if (t === 'pointerdown') {
      down = null;
      held = null;
      if (e.button !== 0 || e.altKey || PAA.layer.inOurs(e) || (PAA.gesture && PAA.gesture.active())) return;
      const g = guardAt(e.clientX, e.clientY, now);
      if (g) {
        held = { until: now + 30000, g: g };
        g.until = Math.max(g.until, now + CAPTION_QUIET);
        return swallow(e);
      }
      const hit = pressAt(e.clientX, e.clientY);
      if (!hit) return;
      // it passes: Maps gets the press, and we wait to see whether it turns into a pan
      down = { mark: hit.mark, x: e.clientX, y: e.clientY, target: e.target, id: e.pointerId, type: e.pointerType, rect: hit.rect, pan: false };
      return;
    }

    if (held) { // the rest of a press we are swallowing
      if (now > held.until) { held = null; return; }
      swallow(e);
      held.g.until = Math.max(held.g.until, now + CAPTION_QUIET);
      if (t === 'pointerup' || t === 'mouseup') held.until = now + 400;
      else if (t === 'click') held = null;
      return;
    }

    if (!down) return;
    if (down.until && now > down.until) { down = null; return; }
    if (t === 'pointerup' && !down.pan && Math.hypot(e.clientX - down.x, e.clientY - down.y) > PAN_PX) down.pan = true; // moved since the last move event
    if (down.pan) { // a pan: everything passes; it is over when the button is up
      if (t === 'pointerup') down = null;
      return;
    }
    if (t === 'mousedown') return; // the compatibility event of the pointerdown that passed
    swallow(e);
    if (t === 'pointerup') {
      if (!down.opened) {
        down.opened = true;
        cancelMaps(down);
        if (!down.mark.dead) PAA.app.openMark(down.mark);
        guard(down.rect, CAPTION_QUIET);
      }
      down.until = now + 400;
    } else if (t === 'click') {
      down = null;
    }
  }

  TYPES.forEach((t) => window.addEventListener(t, onEvent, { capture: true, passive: false }));
  window.addEventListener('blur', () => { down = null; held = null; });

  PAA.press = { capAt: capAt, pressAt: pressAt, guard: guard };
})();
