/* capture-main.js — MAIN-world content script (manifest: "world": "MAIN", "run_at": "document_start").
 * Watches the Maps page's OWN panorama-metadata responses (photometa/v1 and photometa/si/v1) and hands the raw text to the
 * isolated-world content script via a DOM CustomEvent whose detail is a string (strings cross the world boundary).
 * No extra requests, no debugger permission. Never alters what the page receives. */
(() => {
  if (window.__paaPhotometaHook) return; window.__paaPhotometaHook = true;
  const RE = /\/maps\/photometa\/(?:si\/)?v1\b/;
  // the detail is the response text itself (a string crosses the world boundary as it is: no encode / decode round trip inside the page's own handler)
  const hand = (url, text) => {
    if (typeof text !== 'string' || text.length < 200) return;
    try { document.dispatchEvent(new CustomEvent('paa:photometa', { detail: text })); } catch (e) {}
  };
  const XO = XMLHttpRequest.prototype.open, XS = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (m, url) { try { this.__paaUrl = RE.test(String(url)) ? String(url) : null; } catch (e) {} return XO.apply(this, arguments); };
  XMLHttpRequest.prototype.send = function () {
    if (this.__paaUrl) {
      const url = this.__paaUrl;
      this.addEventListener('load', function () {
        try { if (this.status === 200 && (this.responseType === '' || this.responseType === 'text')) hand(url, this.responseText); } catch (e) {}
      });
    }
    return XS.apply(this, arguments);
  };
  const F = window.fetch;
  if (typeof F === 'function') {
    window.fetch = function (input, init) {
      const p = F.apply(this, arguments);
      try {
        const url = typeof input === 'string' ? input : (input && (input.url || input.href)) || ''; // a string, a Request or a URL
        if (RE.test(url)) p.then((r) => { if (r && r.ok) r.clone().text().then((t) => hand(url, t)).catch(() => {}); }).catch(() => {});
      } catch (e) {}
      return p;
    };
  }
})();
