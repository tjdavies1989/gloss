'use strict';
// the same stylesheet the content scripts use (css.js), and the panel's refraction (design/glass.js; extension pages allow no inline script)
(() => {
  const st = document.createElement('style');
  st.textContent = PAA.css;
  document.head.appendChild(st);
  PAAGlass.watch(document.getElementById('slab'), { root: document.body });
})();
const $ = (id) => document.getElementById(id);
const PROVIDERS = ['anthropic', 'openrouter'];
const KEYFIELD = { anthropic: 'anthropicKey', openrouter: 'openrouterKey' };
const NAME = { anthropic: 'Anthropic', openrouter: 'OpenRouter' };
const WHAT = { anthropic: 'Reading', openrouter: 'Repaint' };
const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

const send = (msg) => chrome.runtime.sendMessage(msg);
const fmtBytes = (n) => (n >= 1048576 ? (n / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB');
const fmtDate = (iso) => { const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso || ''); return m ? Number(m[3]) + ' ' + MONTHS[Number(m[2]) - 1] + ' ' + m[1] : ''; };

async function showStorage() {
  try {
    const s = await send({ type: 'store', op: 'stats' });
    $('storage').textContent = s.count + (s.count === 1 ? ' note' : ' notes') + ' saved, ' + fmtBytes(s.bytes) + ' used on this computer.';
  } catch (e) {
    $('storage').textContent = 'Could not read the store.';
  }
}

/* "Draw English over text automatically": kept with the other preferences (density, hint count) by the service worker, saved the moment it is changed */
async function loadOverlay() {
  try {
    const p = await send({ type: 'prefs', op: 'get' });
    $('overlayAuto').checked = !p || p.overlayAuto !== false; // on unless it was turned off
    $('showCost').checked = !!(p && p.showCost); // off unless it was turned on
  } catch (e) {
    $('overlayAuto').checked = true;
    $('showCost').checked = false;
  }
}
$('showCost').addEventListener('change', async () => {
  await send({ type: 'prefs', op: 'set', patch: { showCost: $('showCost').checked } });
  $('swStatus2').textContent = 'Saved.';
  setTimeout(() => ($('swStatus2').textContent = ''), 1800);
});
$('overlayAuto').addEventListener('change', async () => {
  await send({ type: 'prefs', op: 'set', patch: { overlayAuto: $('overlayAuto').checked } });
  $('swStatus').textContent = 'Saved.';
  setTimeout(() => ($('swStatus').textContent = ''), 1800);
});

/* ---------- the keys ----------
   What the page knows about the shared (built-in) keys is only where each key comes from: the worker answers keyStatus with { anthropic: { source }, openrouter: { source },
   expires, openrouterLimitUsd }, and source is 'own' | 'builtin' | 'none'. The page never receives a built-in key; a Check of one runs in the worker. */
let keyInfo = null; // the last keyStatus
let saved = {}; // the own keys as stored

function statusLine(p) {
  const typed = $(KEYFIELD[p]).value.trim();
  if (typed !== (saved[KEYFIELD[p]] || '')) { // the field was changed and not saved yet: say what saving it will do
    if (typed) return 'Not saved yet. Press Save to use this key.';
    return keyInfo && keyInfo[p].builtin ? 'Not saved yet. Press Save to go back to the built-in shared key.' : 'Not saved yet. Press Save to remove the key.';
  }
  const src = keyInfo ? keyInfo[p].source : 'none';
  if (src === 'own') return 'Using your own key.';
  if (src === 'builtin') {
    if (PAA.keyEnded(keyInfo.expires)) return 'The built-in shared key ended on ' + fmtDate(keyInfo.expires) + '. Add your own ' + NAME[p] + ' key above.';
    const lim = p === 'openrouter' && keyInfo.openrouterLimitUsd ? ' to $' + keyInfo.openrouterLimitUsd : '';
    return 'Using the built-in shared key (limited' + lim + (keyInfo.expires ? '; ends ' + fmtDate(keyInfo.expires) : '') + ').';
  }
  return 'No key. ' + WHAT[p] + ' needs one: paste a ' + NAME[p] + ' key above.';
}

function showStatus() {
  PROVIDERS.forEach((p) => { $(p + 'Status').textContent = statusLine(p); });
}

async function loadKeys() {
  try {
    const k = await send({ type: 'keyStatus' }); // first: the worker moves a key saved by version 0.2 into its new place
    keyInfo = { anthropic: k.anthropic, openrouter: k.openrouter, openrouterLimitUsd: k.openrouterLimitUsd, expires: k.expires };
  } catch (e) {
    keyInfo = null; // the status lines then say "No key", the safe reading
  }
  const s = await chrome.storage.local.get(['anthropicKey', 'openrouterKey', 'model']);
  saved = { anthropicKey: s.anthropicKey || '', openrouterKey: s.openrouterKey || '' };
  $('anthropicKey').value = saved.anthropicKey;
  $('openrouterKey').value = saved.openrouterKey;
  $('model').value = s.model || PAA.DEFAULT_MODEL;
  showStatus();
  showStorage();
}

PROVIDERS.forEach((p) => {
  $(KEYFIELD[p]).addEventListener('input', () => { showStatus(); $(p + 'Result').textContent = ''; });
  $(p + 'Check').addEventListener('click', async () => {
    const btn = $(p + 'Check');
    const res = $(p + 'Result');
    btn.disabled = true;
    res.className = 'res';
    res.textContent = 'Checking…';
    try {
      const r = await send({ type: 'checkKey', provider: p, key: $(KEYFIELD[p]).value.trim() });
      res.className = r && r.ok ? 'res' : 'res bad';
      res.textContent = (r && r.message) || 'No answer.';
    } catch (e) {
      res.className = 'res bad';
      res.textContent = 'Could not ask. Reload this page.';
    }
    btn.disabled = false;
  });
});

$('save').addEventListener('click', async () => {
  const say = (t, bad) => { $('status').textContent = t; $('status').style.color = bad ? '#ffe2a6' : ''; setTimeout(() => ($('status').textContent = ''), bad ? 6000 : 1800); };
  const a = $('anthropicKey').value.trim();
  const o = $('openrouterKey').value.trim();
  const model = $('model').value.trim();
  // the likely slip: a key in the wrong field would only ever say "not accepted"
  if (/^sk-or-/.test(a)) return say('That is an OpenRouter key. It goes in the OpenRouter field.', true);
  if (/^sk-ant-/.test(o)) return say('That is an Anthropic key. It goes in the Anthropic field.', true);
  if (model && !/^claude-[a-z0-9][a-z0-9.-]*$/i.test(model)) return say('The model must be a Claude model id, such as ' + PAA.DEFAULT_MODEL + '.', true);
  const set = {};
  const drop = [];
  if (!a) drop.push('anthropicKey');
  if (o) set.openrouterKey = o;
  else drop.push('openrouterKey');
  if (model && model !== PAA.DEFAULT_MODEL) set.model = model;
  else drop.push('model'); // the default is the absence of a setting, so a later default applies
  if (a) set.anthropicKey = a;
  if (Object.keys(set).length) await chrome.storage.local.set(set);
  if (drop.length) await chrome.storage.local.remove(drop);
  say('Saved.');
  loadKeys();
});

$('wipe').addEventListener('click', async () => {
  if (!confirm('Delete every saved note and its pictures? This cannot be undone.')) return;
  let n = 0;
  try { n = (await send({ type: 'store', op: 'stats' })).count || 0; } catch (e) { /* the count is only for the message */ }
  await send({ type: 'store', op: 'clear' });
  $('wipeStatus').textContent = 'Deleted ' + n + (n === 1 ? ' note.' : ' notes.');
  setTimeout(() => ($('wipeStatus').textContent = ''), 2500);
  showStorage();
});

loadKeys();
loadOverlay();
