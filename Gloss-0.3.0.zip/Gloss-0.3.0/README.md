# Gloss

Gloss is a small Chrome extension for Google Street View. Hold Option, drag a box over anything (a shop sign, a menu, a street name, a strange building) and Gloss tells you what it says and what it is. The answer is a small piece of blue glass stuck to the thing you pointed at. It follows the picture as you look around, and it is still there when you come back.

It reads with Claude (Haiku 5.5, from Anthropic). It can also draw the English over the sign, or repaint the sign in English with an image model.

This is version 0.3.0. It is a hobby project, free, and it works on Google Maps Street View (any Google country site). It has not been tried on other map sites.

## Install it (one minute)

1. Unzip the download. You get a folder called `Gloss-0.3.0`. Put it somewhere it can stay (Chrome reads the extension from that folder, so do not delete it afterwards).
2. In Chrome, open `chrome://extensions` and turn on **Developer mode** (top right).
3. Press **Load unpacked** and pick the `Gloss-0.3.0` folder.
4. Open Google Maps, go into Street View, and ask.

There is nothing to sign up for: this copy comes with shared keys built in (see "Keys" below). If you had an older version of Gloss loaded, turn it off first, or the two will both act on the page.

## How to use it

- **Option and drag** draws a box. A small "Reading" chip appears, then it grows into the card as the answer arrives. (On Windows and Linux, Option is the Alt key.)
- **Option and click** means "this thing here". A small ring, with its caption and card.
- **Option, Shift and drag** lets you type your own question. Enter sends, Esc cancels.

Click a caption to open its card. A plain press anywhere else closes a card, and Street View still gets the press. Esc closes the card too. Without Option held, Gloss does nothing to the page.

**The card** shows the answer first, then the original text, and a note only when there is one. Along the bottom:

- **Overlay** draws the English on the sign itself, when Gloss can place it reliably. It is on by default: the English is already on the sign when the card opens, and the button is lit. Press it to take the English off the sign, and again to bring it back. In Settings, "Draw English over text automatically" turns the automatic part off.
- **Repaint** asks an image model to letter the English over the sign in the sign's own style. It takes about 25 to 30 seconds and costs a few cents. Nothing is shown unless it passes a check (Claude reads the result back and every word has to be what was asked), and a repaint carries an "AI repaint" badge. If the check fails it tries once more on its own; if that fails too, nothing is shown and you have still paid for both tries (about 5 cents in all). Press and hold the badge to see the original underneath.
- **Ask** lets you type a follow-up about the same thing.
- **The three dots**: copy the translation, copy the original, delete, and how long the answer took. (The cost is recorded too; it shows there if you turn on "Show what each answer cost" in Settings.)

**The dock** is the small pill at the top right of the picture. It shows how many notes are on this view. Click it for the notebook: notes here, notes nearby (with an arrow that points the way), and the latest 20 from anywhere. Every finished answer is saved by itself, so come back to the same view and the notes are where you left them. Step to the next panorama and notes asked a few metres back are still there as a small ring ("about here").

## Keys

Gloss needs two keys, one for each service it talks to. You do not have to do anything: this copy has two **shared** keys built in, made for friends trying it out.

- **Reading** (every answer and follow-up) uses an Anthropic key.
- **Repaint** (painting the English onto a sign) uses an OpenRouter key.

The shared keys are limited. The OpenRouter one has a **$20** limit, and **both stop working on 14 December 2026**. Everyone who got this copy shares them, so please go easy. When a shared key has run out or expired, the card says so ("The shared key built into Gloss has expired or run out. Add your own ... key in Settings.") and has a **Settings** button.

**To use your own key** (you can add either or both): click the Gloss icon in Chrome's toolbar (it may be under the puzzle-piece menu) to open Settings, paste the key in its field, and press **Save**. The **Check** button next to each field asks the service whether the key works, and the line under the field says which key is in use: your own, or the built-in shared one. Your own key is always used before the shared one. To go back to the shared key, empty the field and press Save. (The "left" figure on the OpenRouter line is OpenRouter's own counter, and it can run a little behind your latest repaint.)

- Anthropic keys come from the Anthropic Console (console.anthropic.com), under API keys.
- OpenRouter keys come from openrouter.ai, under Keys. Repaint is the only thing that uses it.

The shared Anthropic key always reads with Claude Haiku 5.5. If you add your own Anthropic key, the **Model** field in Settings lets you pick another Claude model; it only applies to your own key.

## What is sent where

- **To Anthropic** (api.anthropic.com), for every question and follow-up: the picture of the box you drew, a picture of the Street View screen with the box outlined (so Claude can see the surroundings), the approximate place (the camera's latitude and longitude, the direction it faces and the field of view), and anything you typed. Never the page title, and nothing about you.
- **To OpenRouter** (openrouter.ai), only when you press Repaint: a picture of the sign, and the instruction to letter the English over it. OpenRouter passes it to the image model.
- **Stored only in your browser**: your notes, their pictures and any repaints are saved in the extension's own storage on your computer. Nothing goes to any server of ours; there is none, and there are no accounts or analytics. The keys you add are kept the same way, and only the extension itself can read them. Settings has **Delete all saved notes**.
- The **Check** button sends a key only to the service it belongs to (a key pasted into the wrong field is refused before anything is sent).

Each service's own terms apply to what you send it.

## The permission it asks for

Chrome says Gloss can "read and change all your data on all websites". It asks for that because taking a picture of the Street View tab when you press Option and drag needs it (a narrower permission only works when you click the toolbar icon). Gloss only runs on Google Maps and Yandex Maps pages, and the only places it sends anything are the two services above. It also asks to store notes on your computer.

## What it costs

Reading is cheap: a typical answer costs 0.05 to 0.1 of a cent (the model thinks before it answers, and thinking is billed), and even a long one stays under 0.2 of a cent. Repaint costs about 2 to 8 cents each (a failed check costs about double, since it tries once more), so the shared $20 pays for a few hundred of them. The card's three-dot menu shows the time and cost of each answer and repaint. With the shared keys, someone else pays: please use them lightly. With your own keys, you pay the service directly.

## If something does not work

- Nothing happens when you hold Option and drag: refresh the Street View tab, and make sure no older Gloss is also turned on.
- The card shows an amber message: it says what went wrong. A key problem has a **Settings** button; anything else has **Retry**.
- A tab that was open when you loaded Gloss needs a refresh before it works.
- Gloss was built and tested in Chrome. Other Chromium browsers may work.
