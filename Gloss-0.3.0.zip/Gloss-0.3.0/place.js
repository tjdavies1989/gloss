/* Gloss: where a card or caption goes. Pure functions (no DOM), loaded in the page and in node.
   Rects are {x, y, w, h} in screen (client) pixels. `bbox` is the mark's on-screen bounding box, `vr` the
   visible picture rectangle (the panorama may not fill the window), `size` the element's measured {w, h}.

   Card rules (EXPERIENCE.txt): beside tall marks (right, else left), below wide ones (else above), always fully
   on screen, never covering its own mark, with a caret pointing at the mark.
   These run when a card opens and when the view settles, never per frame; between those moments the element
   moves rigidly with its anchor on the mark (see mark.js). */
(function (root) {
  'use strict';

  const CARET = 4.5; // half of the caret square
  const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));
  const overlapArea = (a, b) => Math.max(0, Math.min(a.x + a.w, b.x + b.w) - Math.max(a.x, b.x)) * Math.max(0, Math.min(a.y + a.h, b.y + b.h) - Math.max(a.y, b.y));
  const intersects = (a, b, pad) => {
    pad = pad || 0;
    return a.x < b.x + b.w + pad && b.x < a.x + a.w + pad && a.y < b.y + b.h + pad && b.y < a.y + a.h + pad;
  };

  function placeCard(bbox, size, vr, o) {
    o = o || {};
    const gap = o.gap == null ? 12 : o.gap; // mark edge to card edge; the caret fills it
    const m = o.margin == null ? 14 : o.margin; // a card keeps at least this far from the edge of the picture (the window)
    const w = size.w, h = size.h;
    const cx = bbox.x + bbox.w / 2, cy = bbox.y + bbox.h / 2;
    const L = vr.x + m, R = vr.x + vr.w - m, T = vr.y + m, B = vr.y + vr.h - m;
    const tall = bbox.h >= bbox.w * 1.2;
    const order = tall ? ['right', 'left', 'below', 'above'] : ['below', 'above', 'right', 'left'];
    const aside = (s) => s === 'right' || s === 'left';

    function candidate(side, hard) {
      let x, y;
      if (aside(side)) {
        x = side === 'right' ? bbox.x + bbox.w + gap : bbox.x - gap - w;
        y = clamp(cy - 22.5, T, Math.max(T, B - h));
      } else {
        y = side === 'below' ? bbox.y + bbox.h + gap : bbox.y - gap - h;
        x = clamp(cx - 22.5, L, Math.max(L, R - w));
      }
      if (hard) { // last resort: squeeze into the picture on both axes
        x = clamp(x, L, Math.max(L, R - w));
        y = clamp(y, T, Math.max(T, B - h));
      }
      const rect = { x: x, y: y, w: w, h: h };
      const fits = x >= L - 0.01 && y >= T - 0.01 && x + w <= R + 0.01 && y + h <= B + 0.01;
      return { side: side, rect: rect, fits: fits, over: overlapArea(rect, bbox) };
    }

    /* Google's own controls (zoom, compass, mini map...) are soft obstacles: a candidate that lands on one is slid along its
       free axis (up or down for a card beside the mark, left or right for one above or below) when that clears it. */
    const avoid = o.avoid || [];
    function clearOf(c) {
      let r = c.rect;
      for (let k = 0; k < avoid.length; k++) {
        const a = avoid[k];
        if (!intersects(r, a, 0)) continue;
        const opts = aside(c.side)
          ? [{ x: r.x, y: a.y - r.h - 4 }, { x: r.x, y: a.y + a.h + 4 }]
          : [{ x: a.x - r.w - 4, y: r.y }, { x: a.x + a.w + 4, y: r.y }];
        let best = null;
        opts.forEach((p) => {
          const q = { x: p.x, y: p.y, w: r.w, h: r.h };
          const ok = q.x >= L - 0.01 && q.y >= T - 0.01 && q.x + q.w <= R + 0.01 && q.y + q.h <= B + 0.01 && !intersects(q, bbox, 0) && !avoid.some((b) => intersects(q, b, 0));
          if (ok && (!best || Math.abs(p.x - r.x) + Math.abs(p.y - r.y) < Math.abs(best.x - r.x) + Math.abs(best.y - r.y))) best = q;
        });
        if (!best) return null;
        r = best;
      }
      return r;
    }

    let pick = null;
    if (avoid.length) {
      for (let i = 0; i < order.length && !pick; i++) {
        const c = candidate(order[i], false);
        if (!c.fits || intersects(c.rect, bbox, 0)) continue;
        const r = clearOf(c);
        if (r) pick = { side: c.side, rect: r, fits: true, over: 0 };
      }
    }
    for (let i = 0; i < order.length && !pick; i++) {
      const c = candidate(order[i], false);
      if (c.fits && !intersects(c.rect, bbox, 0)) pick = c;
    }
    let nocaret = false;
    if (!pick) { // nothing fits cleanly: least overlap with the mark, squeezed on screen, no caret
      let best = null;
      order.forEach((s) => {
        const c = candidate(s, true);
        if (!best || c.over < best.over) best = c;
      });
      pick = best;
      nocaret = true;
    }
    const r = pick.rect;
    const caret = aside(pick.side) ? clamp(cy - r.y - CARET, 12, Math.max(12, h - 21)) : clamp(cx - r.x - CARET, 12, Math.max(12, w - 21));
    return { side: pick.side, x: r.x, y: r.y, w: w, h: h, caret: caret, nocaret: nocaret || pick.over > 0 };
  }

  /* Caption (or the "Reading" chip): centred just under the mark, above it when there is no room. */
  function placeCaption(bbox, size, vr, o) {
    o = o || {};
    const gap = o.gap == null ? 6 : o.gap;
    const m = o.margin == null ? 8 : o.margin;
    const w = size.w, h = size.h;
    const cx = bbox.x + bbox.w / 2;
    const L = vr.x + m, R = vr.x + vr.w - m, T = vr.y + m, B = vr.y + vr.h - m;
    let side = 'below';
    let y = bbox.y + bbox.h + gap;
    if (y + h > B) {
      const above = bbox.y - gap - h;
      if (above >= T) { side = 'above'; y = above; }
      else { side = 'inside'; y = clamp(bbox.y + bbox.h - h - 4, T, Math.max(T, B - h)); } // the mark fills the picture
    }
    const x = clamp(cx - w / 2, L, Math.max(L, R - w));
    return { side: side, x: x, y: y, w: w, h: h };
  }

  /* Several captions may land on each other (marks that are close together). items: [{key, x, y, w, h, dir}],
     dir +1 pushes down (caption below its mark), -1 pushes up. obstacles: rects already taken (the open card, the labels of English drawn over signs:
     those have lab: true, and an item with bead: true (a bead sits on its mark's corner on purpose) ignores them).
     Returns { key: dy } with the extra vertical shift for each; items are handled by priority (item.prio, lower first: the pointed-at one, then near ones), then top to bottom.
     A caption that cannot be got clear within 80 px of its place is CROWDED: it keeps its place (shift 0), takes no room from the others, and is reported by key in the
     optional third argument (an object this fills: crowded[key] = true); the caller hides it until the pointer rests on its mark. A bead and an item with keep: true are never crowded. */
  function resolveCaptions(items, obstacles, crowded) {
    const placed = (obstacles || []).slice();
    const out = {};
    const sorted = items.slice().sort((a, b) => (a.prio || 0) - (b.prio || 0) || a.y - b.y || (a.key < b.key ? -1 : 1));
    sorted.forEach((it) => {
      const r = { x: it.x, y: it.y, w: it.w, h: it.h };
      let moved = 0;
      for (let n = 0; n < 8; n++) {
        const hit = placed.find((p) => !(it.bead && p.lab) && intersects(r, p, 2));
        if (!hit) break;
        const ny = it.dir >= 0 ? hit.y + hit.h + 3 : hit.y - r.h - 3;
        const step = ny - r.y;
        if (Math.abs(moved + step) > 80) break; // do not wander far from the mark
        r.y = ny;
        moved += step;
      }
      if (crowded && !it.bead && !it.keep && placed.some((p) => !(it.bead && p.lab) && intersects(r, p, 2))) { // still on something after all the pushing
        out[it.key] = 0;
        crowded[it.key] = true;
        return;
      }
      out[it.key] = moved;
      placed.push(r);
    });
    return out;
  }

  const API = { placeCard: placeCard, placeCaption: placeCaption, resolveCaptions: resolveCaptions, intersects: intersects };
  root.PAAPlace = API;
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
})(typeof self !== 'undefined' ? self : globalThis);
