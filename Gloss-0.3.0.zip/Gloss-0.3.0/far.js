/* Gloss: marks seen from other panoramas (stage 2).

   A mark that was asked about in one panorama carries a world point (rec.world, from that panorama's depth map). From another official
   panorama within about 120 m it is shown as a SOFT ANCHOR: a small ring where the point should be, a short leader, and its caption (the
   small .far form beyond about 25 m). Positions are good to about 1 degree, so this is never a box and never an overlay: it says "about here".
   Dimmed (not removed) when the point is probably hidden behind something nearer, or is close and seen along its wall (low confidence).
   Never shown to or from a user photo sphere.

   This file: the FarMark (a Mark that hangs from one direction instead of four corners), the arrival logic (which marks to show from the
   panorama that just opened), and the world points themselves (computed at ask time, and lazily for marks saved before this stage).
   The geometry is anchor.js (pure, unit tested). Per frame a FarMark costs one projection and two transform writes. */
(function () {
  'use strict';
  const PAA = self.PAA;
  const P = self.PAAPose;
  const W = self.PAAWorld;
  const A = self.PAAAnchor;

  const RING = 24; // px, the ring's outer diameter
  const RING_LOW = 84; // px: a rough guess (close, seen along the wall) is an area, not a spot: a soft wide ring, because a spot that lands on the wrong sign is a wrong claim
  const CAP_GAP = 26; // px from the ring's edge to the caption: room for the leader
  const MAX_FAR = 30; // at most this many soft anchors at once (the nearest)
  const QUERY_PAD = 15; // m added to the query radius: the address' position is not the metadata's exact one

  const el = (tag, cls, text) => {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== undefined) e.textContent = text;
    return e;
  };

  /* ---------------- the mark ---------------- */

  class FarMark extends PAA.Mark {
    /* far: { at (the panorama it is shown from), yaw, pitch (compass degrees from here), dist (m), small, dim, occluded, low } */
    constructor(rec, far) {
      super(rec, { open: false, far: far });
      this.capGap = CAP_GAP;
      this.softLead = true;
      this.ringAt = { x: 0, y: 0 };
    }

    build() {
      super.build();
      const f = this.far;
      this.ringPx = f.low ? RING_LOW : RING; // (build() runs inside the base constructor, so this is where it is set)
      this.tick.classList.add('far');
      this.leadEl.classList.add('soft');
      this.tick.classList.toggle('dim', !!f.dim);
      this.tick.classList.toggle('low', !!f.low);
      this.tick.style.width = this.ringPx + 'px';
      this.tick.style.height = this.ringPx + 'px';
      this.capEl.classList.toggle('far', !!f.small);
      this.capEl.classList.toggle('dim', !!f.dim);
    }

    shouldShow(f) {
      return !this.retired && !this.dead && !f.hideWorld && f.pose.panoId === this.far.at;
    }

    centerDir() {
      return { yaw: this.far.yaw, pitch: this.far.pitch };
    }

    /* one projection: the ring's place, and a small square round it as this.pts (the layout, hover and cover check read that) */
    fill() {
      const p = P.dirToScreen(this.far.yaw, this.far.pitch);
      if (!p || p.behind) return false;
      this.ringAt.x = p.x;
      this.ringAt.y = p.y;
      const h = this.ringPx / 2, q = this.pts;
      q[0].x = p.x - h; q[0].y = p.y - h;
      q[1].x = p.x + h; q[1].y = p.y - h;
      q[2].x = p.x + h; q[2].y = p.y + h;
      q[3].x = p.x - h; q[3].y = p.y + h;
      return true;
    }

    geometry(f) {
      if (!this.shouldShow(f) || PAA.prefs.density === 'off') return false;
      if (this.applyDensity()) PAA.layer.requestLayout(0);
      if (!this.fill()) return false;
      const vr = f.vr, c = this.ringAt, r = this.ringPx;
      if (c.x < vr.x - r || c.x > vr.x + vr.w + r || c.y < vr.y - r || c.y > vr.y + vr.h + r) return false; // off screen
      this.tick.style.transform = 'translate3d(' + (c.x - r / 2 - f.ox) + 'px,' + (c.y - r / 2 - f.oy) + 'px,0)';
      return true;
    }

    apply() {
      super.apply();
      if (this.mKind === 'cap') this.drawLeader(); // the leader is always there (a caption that is not pushed gets none from the base class)
    }

    /* what the card shows above the answer: the picture of what was asked about, and where it is from here */
    bodyHead(body) {
      if (this.rec.thumb) {
        if (!this.shotEl) {
          this.shotEl = el('img', 'shot');
          this.shotEl.alt = '';
          this.shotEl.draggable = false;
          this.shotEl.src = this.rec.thumb;
        }
        body.appendChild(this.shotEl);
      }
      const f = this.far;
      if (f && typeof f.dist === 'number') {
        const geo = self.PAAGeo;
        const where = geo.distText(f.dist) + ' ' + geo.compassWord(f.yaw) + ' of here' + (f.occluded ? ', probably out of sight' : f.low ? ', a rough guess from this close' : '');
        body.appendChild(el('div', 'where', where));
      }
    }

    destroy() {
      super.destroy();
      this.shotEl = null;
    }

    debug() {
      const d = super.debug();
      d.far = Object.assign({}, this.far);
      d.ring = { x: this.ringAt.x, y: this.ringAt.y };
      const b = this.leadOn ? this.leadEl.getBoundingClientRect() : null;
      d.lead = b ? { x: b.x, y: b.y, w: b.width, h: b.height, shown: !this.leadPos.classList.contains('hide') } : null;
      d.capClass = this.capEl.className;
      return d;
    }
  }

  /* ---------------- world points ---------------- */

  /* The world point of a record from the panorama it was asked in. Sets rec.world and resolves to it; null (and rec.world untouched)
     when there is no usable depth there. Never fetches for a user photo sphere or for a record with no camera. */
  async function world(rec) {
    if (!rec || rec.world || !rec.dirs || !rec.pano || !rec.pano.id || rec.pano.type === 'user') return null;
    const meta = await PAA.meta.need(rec.pano.id, 2);
    if (!meta || !A.depthUsable(meta)) return null;
    const w = A.worldPoint(W, meta, rec.dirs);
    if (w) rec.world = w;
    return w;
  }

  /* Marks saved before this stage have no world point: when their panorama is open, give them one and save it. */
  async function upgrade(pid, records) {
    for (const rec of records || []) {
      if (rec.world || !rec.dirs || !rec.pano || rec.pano.id !== pid) continue;
      if (P.getPose().panoId !== pid) return; // moved on
      let w = null;
      try { w = await world(rec); } catch (e) { w = null; }
      const m = PAA.layer.get(rec.id); // deleted while the metadata was awaited: store.save is an upsert and would bring it back
      if (w && m && !m.dead) PAA.store.save(m.rec).catch((e) => console.warn('[PAA] save failed', e));
    }
  }

  /* ---------------- arrival ---------------- */

  let seq = 0;

  /* The soft anchors of any panorama but the one just opened go (pid: those of the current one are left alone). One that is busy (a follow-up is being answered on its card) is only hidden and goes when it is
     finished (retire): its answer must still be saved, and ask.leaveIfElsewhere then brings the marks of the current panorama back. */
  function clear(pid) {
    PAA.layer.all().filter((m) => m.far && m.far.at !== pid).forEach((m) => m.retire());
  }

  /* The panorama pid just opened: show the saved marks that have a world point within about 120 m of it. The store is asked first (a
     message to the worker); the metadata (this panorama's position, orientation and depth) is needed only when there is something to show. */
  async function arrive(pid) {
    const mine = ++seq;
    clear(pid); // (the soft anchors already drawn for THIS panorama stay: an answer finishing elsewhere calls arrive too, and must not blink them or close an open card)
    if (!pid) return;
    const pose = P.getPose();
    if (pose.kind === 'user' || typeof pose.lat !== 'number' || typeof pose.lng !== 'number') return; // never from a user photo sphere
    let rows;
    try {
      rows = await PAA.store.nearby({ lat: pose.lat, lng: pose.lng, radius: A.SHOW_MAX_M + QUERY_PAD, pano: pid, limit: MAX_FAR, worldOnly: true, full: true });
    } catch (e) {
      return; // no extension, no storage: nothing to show
    }
    if (mine !== seq || PAA.layer.lastPano() !== pid || !rows.length) return;
    const meta = await PAA.meta.need(pid, 2);
    if (mine !== seq || PAA.layer.lastPano() !== pid || !meta || meta.type !== 2) return;
    let added = 0;
    rows.forEach((row) => {
      const rec = row.rec;
      if (!rec || !rec.world || PAA.layer.get(rec.id)) return;
      if (rec.pano && rec.pano.type === 'user') return; // never from a photo sphere (a record of that kind has no world point, but the rule does not rest on that)
      const v = A.viewFrom(W, meta, rec.world);
      if (!v.show) return;
      const m = new FarMark(rec, { at: pid, yaw: v.yaw, pitch: v.pitch, dist: v.dist, small: v.far, dim: v.dim, occluded: v.occluded, low: v.low });
      PAA.layer.add(m);
      added++;
    });
    if (added) {
      PAA.layer.layoutNow();
      PAA.layer.trackNow();
    }
  }

  PAA.FarMark = FarMark;
  PAA.far = { arrive: arrive, world: world, upgrade: upgrade, RING: RING, RING_LOW: RING_LOW };
})();
