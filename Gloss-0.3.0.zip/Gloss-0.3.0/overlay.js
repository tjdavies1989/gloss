/* Gloss: English drawn over the sign (stage 3). One label per LINES entry that passes the gates (ovfit.js), a glossy sticker in the
   WORLD layer (so it sits under Google's own controls and takes no pointer events), warped every frame onto the entry's quadrilateral
   with PAAPose.quadToMatrix3d, exactly as a mark's ticks are. The text is laid out once at a base size (the size the question was asked
   at, or the size on screen when the view last came to rest) and the warp does the rest, so a frame costs four projections and one
   transform write per label: no layout, no measuring, no deferral to a frame of our own.

   What decides whether a mark shows its labels: its record's overlay.on (true / false, set by the card's Overlay button and remembered),
   else the setting "Draw English over text automatically" together with the gates (at least half of the lines pass).
   A mark seen from another panorama (a FarMark) never has labels: they are built only for a mark with its own four corner directions.

   Per label state (m.ov.labels[i]): el, dirs, bw / bh (base size in CSS px), font (base font in CSS px), pts (the projected corners), vis, sup
   (hidden because a newer answer about the same sign has its own label there). m.ov.nVis is how many labels are on screen this frame: the
   mark's caption comes back when it is 0 (a mark whose English cannot be seen at the moment has no reason to be quiet).

   A label is not a button, but it is pressed like one: press.js asks hitAt() and a still click on a label opens the card, as a click on a
   caption does (otherwise a click on the most prominent thing on screen would walk to the next panorama). A drag from a label pans. */
(function () {
  'use strict';
  const PAA = self.PAA;
  const P = self.PAAPose;
  const F = self.PAAOvFit;

  const STAGGER = 40; // ms between one label and the next when they appear
  const MIN_FONT = F.MIN_FONT; // CSS px on screen: below this a label hides until he zooms in
  const REBASE = 0.08; // at rest, a label whose on-screen size differs from its base by more than this is laid out again at the new size

  /* ---------- measuring ---------- */
  let ctx = null;
  let family = '';
  const wcache = new Map();
  function w100(text) {
    let w = wcache.get(text);
    if (w === undefined) {
      if (!ctx) ctx = document.createElement('canvas').getContext('2d');
      ctx.font = '700 100px ' + (family || 'sans-serif');
      w = ctx.measureText(text).width;
      if (wcache.size > 2000) wcache.clear();
      wcache.set(text, w);
    }
    return w;
  }
  function readFamily() {
    if (family) return;
    const stage = PAA.layer.stage();
    if (!stage) return;
    const probe = document.createElement('div');
    probe.className = 'ov';
    stage.appendChild(probe);
    family = getComputedStyle(probe).fontFamily || '';
    probe.remove();
    wcache.clear();
  }

  const rgb = (c) => c[0] + ',' + c[1] + ',' + c[2];

  /* ---------- building ---------- */
  function paint(L) {
    const e = L.el;
    const bw = L.bw, bh = L.bh;
    e.style.width = bw + 'px';
    e.style.height = bh + 'px';
    e.style.fontSize = L.font + 'px';
    e.style.setProperty('--ovr', Math.max(2, Math.min(9, Math.round(bh * 0.2))) + 'px');
  }

  function makeLabel(it, k) {
    const e = document.createElement('div');
    e.className = 'ov';
    const sp = document.createElement('span');
    it.fit.lines.forEach((ln, i) => {
      if (i) sp.appendChild(document.createElement('br'));
      sp.appendChild(document.createTextNode(ln)); // model text goes in as text, never as HTML
    });
    const g = document.createElement('i'); // the glint
    g.className = 'g';
    e.append(g, sp);
    const bg = it.bg || [128, 128, 128];
    e.style.setProperty('--bg', rgb(bg));
    e.style.setProperty('--fg', rgb(it.color));
    e.classList.add(F.luminance(it.color) > 0.4 ? 'lt' : 'dk');
    if (it.fit.lines.length > 1) e.classList.add('two'); // the gel cap is thin over two lines of type
    // dark signs would turn into a pale tile under the full gel cap: it is eased on them (0.55 on near black, full from a luminance of .2)
    e.style.setProperty('--ovk', String(Math.round((0.55 + 0.45 * Math.min(1, F.luminance(bg) / 0.2)) * 100) / 100));
    const L = { el: e, i: it.i, k: k, text: it.text, dirs: [it.dirs.tl, it.dirs.tr, it.dirs.br, it.dirs.bl], bw: it.bw, bh: it.bh, font: it.fit.font, lines: it.fit.lines, bg: bg, color: it.color,
      pts: [{ x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }], vis: false, glinted: false, ok: false, sup: false, scale: 1 };
    paint(L);
    return L;
  }

  function ensureLabels(m) {
    const ov = m.ov;
    if (ov.labels) return;
    const stage = PAA.layer.stage();
    ov.labels = [];
    let k = 0;
    ov.plan.items.forEach((it) => {
      if (!it.ok) return;
      const L = makeLabel(it, k++);
      stage.appendChild(L.el);
      ov.labels.push(L);
    });
  }

  function dropLabels(m) {
    const ov = m.ov;
    if (!ov || !ov.labels) return;
    ov.labels.forEach((L) => L.el.remove());
    ov.labels = null;
  }

  /* ---------- which marks show ---------- */
  function wanted(m) {
    const ov = m.ov;
    if (!ov || !ov.plan.pass) return false;
    if (PAA.patch && PAA.patch.on(m)) return false; // stage 4: a mark with a repaint showing does not also draw English labels over it
    const on = m.rec.overlay ? m.rec.overlay.on : null;
    if (on === true) return true;
    if (on === false) return false;
    return !!PAA.prefs.overlayAuto && ov.plan.auto;
  }

  /* (Re)build a mark's overlay from its record: the gates, the fit; labels are made when they are first to show. */
  function attach(m, quiet) {
    detach(m);
    const rec = m.rec;
    const o = rec.overlay;
    if (m.far || !m.dirArr || !o || !o.cs || !o.ref || !rec.a || !rec.a.lines || !rec.a.lines.length) return;
    readFamily();
    m.ov = { plan: F.plan(rec.a.lines, o.cs, o.ref, w100), labels: null, show: false, reveal: false, nVis: 0 };
    if (!refresh(m, quiet)) m.ovChanged(quiet); // (the card's action row may now offer Overlay, whether or not the labels show)
  }

  function detach(m) {
    if (!m.ov) return;
    dropLabels(m);
    m.ov = null;
    dedupe(); // an older answer about the same sign may have its labels back
  }

  /* the mark should show (or stop showing) its labels: re-evaluate, and tell the mark */
  function refresh(m, quiet) {
    const ov = m.ov;
    if (!ov) return false;
    const want = wanted(m);
    if (want === ov.show) return false;
    ov.show = want;
    if (want) {
      ensureLabels(m);
      ov.labels.forEach((L) => { L.glinted = false; }); // they glint again each time they are brought back
      ov.reveal = true; // the next frames that draw them stagger their appearance
    } else {
      ov.labels && ov.labels.forEach((L) => setVis(L, false, false));
      ov.nVis = 0;
    }
    dedupe();
    m.ovChanged(quiet);
    return true;
  }

  function toggle(m) {
    const ov = m.ov;
    if (!ov || !ov.plan.pass) return;
    if (!m.rec.overlay) return;
    m.rec.overlay.on = !ov.show;
    refresh(m);
    m.actsKey = '';
    if (m.state === 'done' && !m.dead) PAA.store.save(m.rec).catch((e) => console.warn('[PAA] save failed', e));
  }

  /* the labels on, whatever they were (the card's Overlay button with a repaint showing: the repaint goes off and the labels come, never both off) */
  function show(m) {
    const ov = m.ov;
    if (!ov || !ov.plan.pass || !m.rec.overlay) return;
    m.rec.overlay.on = true;
    refresh(m);
    m.actsKey = '';
    if (m.state === 'done' && !m.dead) PAA.store.save(m.rec).catch((e) => console.warn('[PAA] save failed', e));
  }

  const shown = (m) => !!(m.ov && m.ov.show);
  const seen = (m) => !!(m.ov && m.ov.show && m.ov.nVis > 0); // at least one label is on screen now
  const available = (m) => (m.ov ? m.ov.plan.pass : 0);

  /* ---------- every frame ---------- */
  /* instant: hidden because of motion (a flight, the 9 px floor, a pan): at once, where it is. Otherwise (the card's button, the setting) it fades. */
  function setVis(L, on, instant) {
    if (L.vis === on) return;
    L.vis = on;
    L.el.classList.toggle('now', !on && instant !== false);
    L.el.classList.toggle('vis', on);
    if (on && !L.glinted) {
      L.glinted = true;
      L.el.classList.add('glint'); // a quick glint when it first appears
      setTimeout(() => L.el.classList.remove('glint'), 1400);
    }
  }

  function place(m, f) {
    const ov = m.ov;
    if (!ov || !ov.show || !ov.labels) return 0;
    const labels = ov.labels, vr = f.vr;
    let appearing = 0, seen = 0, flipped = false;
    for (let n = 0; n < labels.length; n++) {
      const L = labels[n];
      const d = L.dirs, p = L.pts;
      let ok = !L.sup;
      for (let k = 0; ok && k < 4; k++) {
        const s = P.dirToScreen(d[k].yaw, d[k].pitch);
        if (!s || s.behind) { ok = false; break; }
        p[k].x = s.x;
        p[k].y = s.y;
      }
      if (ok) {
        const x0 = Math.min(p[0].x, p[1].x, p[2].x, p[3].x), x1 = Math.max(p[0].x, p[1].x, p[2].x, p[3].x);
        const y0 = Math.min(p[0].y, p[1].y, p[2].y, p[3].y), y1 = Math.max(p[0].y, p[1].y, p[2].y, p[3].y);
        if (x1 < vr.x - 40 || x0 > vr.x + vr.w + 40 || y1 < vr.y - 40 || y0 > vr.y + vr.h + 40) ok = false;
        else {
          // the area of the quadrilateral (half the cross product of its diagonals) against the base size: how big the letters are on screen now
          const a = Math.abs((p[2].x - p[0].x) * (p[3].y - p[1].y) - (p[3].x - p[1].x) * (p[2].y - p[1].y)) / 2;
          L.scale = Math.sqrt(a / (L.bw * L.bh));
          if (L.font * L.scale < (L.vis ? MIN_FONT - 0.5 : MIN_FONT)) ok = false; // (a little hysteresis: no flicker at the floor)
        }
      }
      if (ok) {
        const mt = P.quadToMatrix3d(d, L.bw, L.bh);
        if (mt === P.HIDDEN_MATRIX) ok = false;
        else L.el.style.transform = 'translate(' + -f.ox + 'px,' + -f.oy + 'px) ' + mt;
      }
      L.ok = ok;
      if (ok && !L.vis && ov.reveal) L.el.style.setProperty('--d', appearing++ * STAGGER + 'ms');
      if (ok !== L.vis) flipped = true;
      setVis(L, ok);
      if (ok) seen++;
    }
    ov.nVis = seen;
    if (flipped) PAA.layer.requestLayout(0); // the caption of a mark that shows no label now comes back (and goes again): a pass at the next rest
    if (ov.reveal && appearing) {
      ov.reveal = false;
      setTimeout(() => { if (ov.labels) ov.labels.forEach((L) => L.el.style.removeProperty('--d')); }, appearing * STAGGER + 800);
    }
    return seen;
  }

  /* the mark is hidden (off screen, another panorama, Off, a flight): nothing of it shows */
  function hide(m) {
    const ov = m.ov;
    if (!ov || !ov.labels) return;
    for (let n = 0; n < ov.labels.length; n++) setVis(ov.labels[n], false);
    ov.nVis = 0;
  }


  /* ---------- pressing, collisions ---------- */
  function inQuad(pts, x, y) {
    let pos = false, neg = false;
    for (let i = 0; i < 4; i++) {
      const a = pts[i], b = pts[(i + 1) % 4];
      const c = (b.x - a.x) * (y - a.y) - (b.y - a.y) * (x - a.x);
      if (c > 0) pos = true;
      else if (c < 0) neg = true;
    }
    return !(pos && neg);
  }

  /* the window rectangle of the label showing at this point, or null (press.js: a still click on it opens the card) */
  function hitAt(m, x, y) {
    const ov = m.ov;
    if (!ov || !ov.nVis || !ov.labels) return null;
    for (let n = 0; n < ov.labels.length; n++) {
      const L = ov.labels[n];
      if (L.vis && L.ok && inQuad(L.pts, x, y)) return boundsOf(L.pts);
    }
    return null;
  }

  function boundsOf(p) {
    const x0 = Math.min(p[0].x, p[1].x, p[2].x, p[3].x), x1 = Math.max(p[0].x, p[1].x, p[2].x, p[3].x);
    const y0 = Math.min(p[0].y, p[1].y, p[2].y, p[3].y), y1 = Math.max(p[0].y, p[1].y, p[2].y, p[3].y);
    return { x: x0, y: y0, w: x1 - x0, h: y1 - y0 };
  }

  /* the rectangles of the labels showing now (captions keep off them: layer.layoutAll) */
  function rects(m, out) {
    const ov = m.ov;
    if (!ov || !ov.nVis || !ov.labels) return out;
    ov.labels.forEach((L) => { if (L.vis && L.ok) out.push(boundsOf(L.pts)); });
    return out;
  }

  /* Two answers about one sign draw two sets of labels on top of each other (a faint second edge, 1 or 2 px off). Where a newer answer's label
     covers an older one's (the same stretch of the picture, by direction), the older one stays hidden. Runs when marks come and go or show
     and hide, never per frame. */
  function span(L) {
    if (L.span) return L.span;
    const y0 = L.dirs[0].yaw;
    const dy = (v) => ((v - y0 + 540) % 360) - 180;
    const ys = L.dirs.map((d) => dy(d.yaw)), ps = L.dirs.map((d) => d.pitch);
    L.span = [Math.min.apply(null, ys), Math.min.apply(null, ps), Math.max.apply(null, ys), Math.max.apply(null, ps), y0];
    return L.span;
  }
  function overlapRatio(a, b) {
    const sa = span(a), sb = span(b);
    const sh = ((sb[4] - sa[4] + 540) % 360) - 180; // b's yaw frame in a's
    const ix = Math.min(sa[2], sb[2] + sh) - Math.max(sa[0], sb[0] + sh), iy = Math.min(sa[3], sb[3]) - Math.max(sa[1], sb[1]);
    if (ix <= 0 || iy <= 0) return 0;
    const i = ix * iy, ua = (sa[2] - sa[0]) * (sa[3] - sa[1]), ub = (sb[2] - sb[0]) * (sb[3] - sb[1]);
    return i / Math.max(1e-9, ua + ub - i);
  }
  function dedupe() {
    if (!PAA.layer || !PAA.layer.all) return;
    const marks = PAA.layer.all().filter((m) => m.ov && m.ov.show && m.ov.labels && !m.dead);
    let changed = false;
    marks.forEach((m) => m.ov.labels.forEach((L) => { if (L.sup) { L.sup = false; changed = true; } }));
    marks.sort((a, b) => (a.rec.createdAt || 0) - (b.rec.createdAt || 0));
    for (let i = 0; i < marks.length; i++) {
      for (let j = i + 1; j < marks.length; j++) {
        marks[i].ov.labels.forEach((La) => {
          if (La.sup) return;
          if (marks[j].ov.labels.some((Lb) => overlapRatio(La, Lb) > 0.5)) La.sup = true;
        });
      }
    }
    if (marks.some((m) => m.ov.labels.some((L) => L.sup)) || changed) PAA.layer.trackNow();
  }

  /* At rest (called from the mark's layout): a label whose on-screen size has drifted from its base (he zoomed) is laid out again at the
     size it has now, so its text is drawn sharp, not stretched. Same shape, so the same line breaks; only the numbers change. */
  function rebase(m) {
    const ov = m.ov;
    if (!ov || !ov.show || !ov.labels) return;
    ov.labels.forEach((L) => {
      if (!L.ok || !L.scale || Math.abs(L.scale - 1) < REBASE) return;
      const bw = L.bw * L.scale, bh = L.bh * L.scale;
      const fit = F.fitText(L.text, bw, bh, w100);
      if (!fit || fit.lines.join('|') !== L.lines.join('|')) return; // a different break: keep the old layout (rare: the shape changed)
      L.bw = bw;
      L.bh = bh;
      L.font = fit.font;
      L.scale = 1;
      paint(L);
    });
  }

  function debug(m) {
    const ov = m.ov;
    if (!ov) return null;
    return {
      show: ov.show, pass: ov.plan.pass, total: ov.plan.total, auto: ov.plan.auto,
      items: ov.plan.items.map((it) => ({ i: it.i, ok: it.ok, why: it.why, font: it.fit ? it.fit.font : null, bw: it.bw, bh: it.bh })),
      labels: (ov.labels || []).map((L) => {
        const r = L.el.getBoundingClientRect();
        return { i: L.i, text: L.text, vis: L.vis, ok: L.ok, font: L.font, bw: L.bw, bh: L.bh, scale: L.scale, rect: { x: r.x, y: r.y, w: r.width, h: r.height }, pts: L.pts.map((q) => ({ x: q.x, y: q.y })),
          bg: L.bg, color: L.color, opacity: getComputedStyle(L.el).opacity, backdrop: getComputedStyle(L.el).backdropFilter };
      }),
    };
  }

  /* the setting changed (here or in another tab): every mark decides again */
  if (PAA.prefs && PAA.prefs.onOverlayChange) {
    PAA.prefs.onOverlayChange(() => PAA.layer.all().forEach((m) => refresh(m)));
  }

  PAA.overlay = { attach: attach, detach: detach, refresh: refresh, toggle: toggle, show: show, shown: shown, seen: seen, available: available, place: place, hide: hide, rebase: rebase, hitAt: hitAt, inQuad: inQuad, boundsOf: boundsOf, rects: rects, dedupe: dedupe, debug: debug, w100: w100 };
})();
